# 29-adaptive rag ENGINE_ARCHITECTURE
# XIIGen FLOW-29 — Adaptive RAG Deep Research Engine
# Factory Registry: F1075–F1146 | Families 154–163

---

## OVERVIEW

FLOW-29 extends the ENGINE with an adaptive, self-learning retrieval layer. Every retrieval call is routed dynamically: vector / GraphRAG community query / hybrid fusion. Every run is traced. Every feedback score feeds a contextual bandit router that continuously improves model+prompt+flow selection under cost/latency/quality constraints.

The key insight: we do NOT replace existing RAG FABRIC (Skills 00a/00b). We EXTEND it with a routing + learning layer that sits ABOVE the fabric interfaces and makes FREEDOM-configurable decisions at runtime.

---

## LAYER 0 EXTENSIONS — RAG FABRIC EXTENSIONS

The existing RAG FABRIC (Skills 00a/00b — IRagService) gains 7 new strategies:

```
Existing strategies:  Split, FanOut, Tiered, Hybrid, Graph, Vector, Multi (7)
FLOW-29 adds:         AdaptiveBandit, GraphCommunity, SelfReflect, DomainProfile (4)
Total after FLOW-29:  11 IRagService strategies
```

All new strategies resolve through the SAME IRagService.SearchAsync() interface.
Admin selects strategy via FREEDOM config. Service code never changes.

---

## FAMILY 154 — Adaptive RAG Router (F1075–F1082)

**Purpose:** Route each incoming task to the optimal retrieval mode based on task classifier, budget preference, and bandit router policy.

| Factory | Interface                  | Fabric Resolution                                | Purpose                                          |
|---------|----------------------------|--------------------------------------------------|--------------------------------------------------|
| F1075   | IAdaptiveRagRouter         | RAG FABRIC (IRagService — AdaptiveBandit strategy) | Primary routing decision: vector/graph/hybrid   |
| F1076   | ITaskClassifier            | AI ENGINE FABRIC (IAiProvider — lightweight model) | Classify query intent: local/global/multi-hop   |
| F1077   | IRetrievalModeSelector     | CORE FABRIC (MicroserviceBase config layer)       | Read FREEDOM config to select retrieval mode    |
| F1078   | IQueryRewriter             | AI ENGINE FABRIC (IAiProvider — fast model)       | Rewrite + decompose query before retrieval      |
| F1079   | IQueryDecomposer           | AI ENGINE FABRIC (IAiProvider — fast model)       | Split complex query into parallel sub-queries   |
| F1080   | IRetrievalModeRegistry     | DATABASE FABRIC (IDatabaseService — Elasticsearch) | Store/retrieve mode performance history        |
| F1081   | IRoutingPolicyReader       | DATABASE FABRIC (IDatabaseService — Redis cache)  | Fast-path routing policy lookup                 |
| F1082   | IRoutingAuditLogger        | QUEUE FABRIC (IQueueService — Redis Streams)      | Emit routing decision events for trace layer    |

**DNA Compliance:** All services extend MicroserviceBase. All doc ops via IDatabaseService. No typed models — Dictionary<string,object>. tenantId on every query.

---

## FAMILY 155 — Knowledge Graph & GraphRAG (F1083–F1090)

**Purpose:** Build, maintain, and query a GraphRAG knowledge graph with community hierarchy, community summaries, and multi-hop traversal.

| Factory | Interface                    | Fabric Resolution                                    | Purpose                                              |
|---------|------------------------------|------------------------------------------------------|------------------------------------------------------|
| F1083   | IGraphRagService             | DATABASE FABRIC (IDatabaseService — Neo4j/Elasticsearch graph) | Execute GraphRAG community query          |
| F1084   | IKnowledgeGraphBuilder       | AI ENGINE FABRIC (AiDispatcher — multi-model extract) | Extract entities + relations from text corpus      |
| F1085   | ICommunityHierarchyManager   | DATABASE FABRIC (IDatabaseService — graph provider)  | Partition graph into community hierarchy             |
| F1086   | ICommunitySummaryGenerator   | AI ENGINE FABRIC (IAiProvider — summarization model)  | Generate community summaries for global queries    |
| F1087   | IEntityDeduplicator          | AI ENGINE FABRIC (IAiProvider — embedding model)     | Deduplicate entities across documents                |
| F1088   | IGraphEditGate               | CORE FABRIC (MicroserviceBase — permissions layer)   | BFA-approved gate before any graph structure change |
| F1089   | IGraphIndexRebuildQueue      | QUEUE FABRIC (IQueueService — Redis Streams DLQ)     | Async rebuild requests — never block query path     |
| F1090   | IDomainGraphProfileStore     | DATABASE FABRIC (IDatabaseService — Elasticsearch)   | Tenant-scoped domain entity/relation type config    |

**Iron Rule:** IGraphIndexRebuildQueue is ASYNC. GraphRAG community rebuild NEVER blocks the synchronous query path. Violation = BUILD FAILURE.

---

## FAMILY 156 — Trace Capture & Observability (F1091–F1097)

**Purpose:** Capture every run end-to-end as OpenTelemetry spans over QUEUE FABRIC. Token counts, latency, cost, model used, retrieval mode, user feedback — all linked by trace ID.

| Factory | Interface                | Fabric Resolution                               | Purpose                                              |
|---------|--------------------------|-------------------------------------------------|------------------------------------------------------|
| F1091   | ITraceSpanService        | QUEUE FABRIC (IQueueService — Redis Streams)    | Emit OTel-compatible trace spans for every step      |
| F1092   | ITokenCostTracker        | DATABASE FABRIC (IDatabaseService — Elasticsearch)| Per-step token/cost accumulation by trace            |
| F1093   | ILatencyProfiler         | CORE FABRIC (MicroserviceBase — health layer)   | Sub-step latency recording without SDK lock-in       |
| F1094   | IRunSessionStore         | DATABASE FABRIC (IDatabaseService — Elasticsearch)| Complete run session: config, results, scores       |
| F1095   | IFeedbackLinker          | DATABASE FABRIC (IDatabaseService — Elasticsearch)| Link user feedback to exact run/config/trace        |
| F1096   | IObservabilityExporter   | QUEUE FABRIC (IQueueService — outbox pattern)   | Export traces to external OTel collectors (config)  |
| F1097   | ICostBudgetEnforcer      | CORE FABRIC (MicroserviceBase — config layer)   | Enforce FREEDOM budget_cap — halt if exceeded       |

**FREEDOM Config Keys:** `trace.export.enabled`, `trace.export.endpoint`, `cost.budget_cap_per_run`, `cost.budget_cap_per_tenant_daily`

---

## FAMILY 157 — Bandit Router & Budget Control (F1098–F1104)

**Purpose:** Contextual bandit routing — dynamically choose (model, retrieval mode, prompt version, flow variant) under explicit budget preferences (Fast / Balanced / Thorough). Learns from bandit feedback (observed outcome + cost of chosen option).

| Factory | Interface                  | Fabric Resolution                                  | Purpose                                              |
|---------|----------------------------|----------------------------------------------------|------------------------------------------------------|
| F1098   | IBanditRouter              | AI ENGINE FABRIC (IAiProvider — routing model)      | Core multi-armed bandit: select best (model+mode+prompt) |
| F1099   | IBanditFeedbackStore       | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Store bandit arm feedback: reward, cost, latency    |
| F1100   | IBudgetPreferenceReader    | CORE FABRIC (MicroserviceBase — config layer)       | Read user/tenant budget mode: Fast/Balanced/Thorough|
| F1101   | IBanditPolicyUpdater       | DATABASE FABRIC (IDatabaseService — Redis cache)    | Update routing policy weights from aggregated feedback|
| F1102   | IExplorationController     | CORE FABRIC (MicroserviceBase — config layer)       | Epsilon/UCB exploration rate (FREEDOM config)       |
| F1103   | IBanditAuditLog            | QUEUE FABRIC (IQueueService — Redis Streams)        | Emit routing decisions for BFA conflict detection   |
| F1104   | IMultiObjectiveScorer      | AI ENGINE FABRIC (IAiProvider — scoring model)       | Score runs on quality × cost × latency trade-offs  |

**MACHINE (invariant):** Bandit arm = (modelId, retrievalMode, promptVersionId, flowVariantId). Arms never collapsed. **FREEDOM (configurable):** exploration rate, reward window size, budget mode thresholds.

---

## FAMILY 158 — Evaluation & Quality Arbiter (F1105–F1111)

**Purpose:** AF-9 Judge extended with RAG-specific quality gates. Validates generated answers against retrieval faithfulness, context coverage, iron rules, and user-defined quality rubrics.

| Factory | Interface                   | Fabric Resolution                                   | Purpose                                              |
|---------|-----------------------------|-----------------------------------------------------|------------------------------------------------------|
| F1105   | IRetrievalFaithfulnessChecker | AI ENGINE FABRIC (IAiProvider — judge model)       | Verify answer is grounded in retrieved context      |
| F1106   | IContextCoverageScorer      | AI ENGINE FABRIC (IAiProvider — embedding model)    | Score how much relevant context was captured        |
| F1107   | IIronRuleValidator          | CORE FABRIC (MicroserviceBase — rules layer)        | DNA-1 to DNA-9 compliance on generated services    |
| F1108   | IQualityRubricStore         | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Tenant-scoped quality rubric documents             |
| F1109   | IEvalResultPublisher        | QUEUE FABRIC (IQueueService — Redis Streams)        | Publish eval results to trace layer + BFA          |
| F1110   | IHallucinationDetector      | AI ENGINE FABRIC (AiDispatcher — multi-model)       | Cross-model consensus on factual claims            |
| F1111   | IQualityGateEnforcer        | CORE FABRIC (MicroserviceBase — config layer)       | Block promotion if quality score < threshold        |

**IRON RULE:** IQualityGateEnforcer can BLOCK promotion but NEVER silently downgrade. If gate fails → BuildFailure event emitted via QUEUE FABRIC.

---

## FAMILY 159 — Prompt Version Registry (F1112–F1118)

**Purpose:** Immutable prompt versioning. Promote by creating new version. Never edit production prompts in place. Controlled rollout with A/B evaluation gates.

| Factory | Interface                | Fabric Resolution                                  | Purpose                                              |
|---------|--------------------------|---------------------------------------------------|------------------------------------------------------|
| F1112   | IPromptVersionRegistry   | DATABASE FABRIC (IDatabaseService — Elasticsearch) | Store immutable prompt versions with metadata       |
| F1113   | IPromptVersionPromoter   | QUEUE FABRIC (IQueueService — Redis Streams)       | Emit promotion events through approval ladder       |
| F1114   | IPromptVariantTester     | AI ENGINE FABRIC (AiDispatcher — multi-model)      | A/B test candidate prompt against current champion  |
| F1115   | IPromptRollbackManager   | DATABASE FABRIC (IDatabaseService — Elasticsearch) | Safe rollback: switch pointer, not delete version   |
| F1116   | IPromptTaggingService    | DATABASE FABRIC (IDatabaseService — Elasticsearch) | Tag prompts: domain, task type, model affinity     |
| F1117   | IPromptInjectionBuilder  | AI ENGINE FABRIC (IAiProvider — context builder)   | Build structured XML prompt injection per run       |
| F1118   | IPromptAuditTrail        | QUEUE FABRIC (IQueueService — Redis Streams)       | Emit every prompt selection to trace layer         |

**Promotion Ladder for Prompts:** DRAFT → CANDIDATE → TESTED → ACTIVE → ARCHIVED. Never skip steps. BFA validates before ACTIVE state.

---

## FAMILY 160 — Domain Compiler (F1119–F1125)

**Purpose:** Each technology domain gets a "knowledge compiler profile" — entity types, relation types, extraction prompts, dedup rules, summary strategy. Comparing compiler profiles drives measurable improvement.

| Factory | Interface                   | Fabric Resolution                                   | Purpose                                              |
|---------|-----------------------------|-----------------------------------------------------|------------------------------------------------------|
| F1119   | IDomainProfileStore         | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Tenant-scoped domain profile documents             |
| F1120   | IDomainEntityTypeRegistry   | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Register entity types per domain (.NET, React, etc.)|
| F1121   | IDomainExtractionPrompter   | AI ENGINE FABRIC (IAiProvider — extract model)      | Auto-generate domain-specific extraction prompts   |
| F1122   | IDomainSummaryStrategyPicker| CORE FABRIC (MicroserviceBase — config layer)       | Select summary strategy per domain from FREEDOM config|
| F1123   | IDomainDeduplicationRules   | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Domain-specific entity dedup rules store           |
| F1124   | IDomainCompilerProfilePublisher | QUEUE FABRIC (IQueueService — Redis Streams)    | Publish profile changes to GraphRAG rebuild queue  |
| F1125   | IDomainMetricsTracker       | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Compare profile versions: quality delta over time  |

---

## FAMILY 161 — Self-Learning Control Plane (F1126–F1133)

**Purpose:** The editable "control-plane graph" — tasks, subtasks, flows, prompts, models, evaluators as versioned assets connected in an inspectable, A/B-testable graph structure.

| Factory | Interface                     | Fabric Resolution                                    | Purpose                                              |
|---------|-------------------------------|-----------------------------------------------------|------------------------------------------------------|
| F1126   | IControlPlaneGraphStore       | DATABASE FABRIC (IDatabaseService — graph provider)  | Store task→subtask→flow→prompt→model→evaluator graph|
| F1127   | IAssetVersionManager          | DATABASE FABRIC (IDatabaseService — Elasticsearch)   | Version any control-plane asset                    |
| F1128   | IFlowVariantRegistry          | DATABASE FABRIC (IDatabaseService — Elasticsearch)   | Store flow variants for A/B testing                |
| F1129   | IImprovementSuggestionEngine  | AI ENGINE FABRIC (AiDispatcher — analysis model)     | Graph analytics over failures → suggest improvements|
| F1130   | IControlPlaneABAllocator      | CORE FABRIC (MicroserviceBase — scope layer)         | Allocate tenant/user to flow variant deterministically|
| F1131   | IPromotionPipelineOrchestrator| FLOW ENGINE FABRIC (IFlowOrchestrator)               | Execute GENERATED→INJECTED→MINIMAL→CORE ladder      |
| F1132   | ISelfLearningFeedbackAggregator| DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Aggregate feedback over configurable window         |
| F1133   | IGraphAnalyticsRunner         | AI ENGINE FABRIC (IAiProvider — analysis model)      | Run dependency hotspot + failure cluster analysis  |

---

## FAMILY 162 — RAG Asset Versioning (F1134–F1140)

**Purpose:** Version every RAG artifact — embeddings, index configurations, chunk parameters, retrieval strategies — for safe rollback and controlled A/B comparison.

| Factory | Interface                    | Fabric Resolution                                   | Purpose                                             |
|---------|------------------------------|-----------------------------------------------------|-----------------------------------------------------|
| F1134   | IRagIndexVersionStore        | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Store versioned RAG index configuration documents  |
| F1135   | IEmbeddingVersionRegistry    | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Track embedding model versions per index           |
| F1136   | IChunkParameterVersioner     | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Version chunk size / overlap / strategy params     |
| F1137   | IRagStrategyVersioner        | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Version retrieval strategy configs                 |
| F1138   | IRagRollbackManager          | QUEUE FABRIC (IQueueService — Redis Streams)        | Emit rollback events — async index rebuild         |
| F1139   | IRagVersionComparator        | AI ENGINE FABRIC (IAiProvider — eval model)         | Compare RAG version quality over eval dataset      |
| F1140   | IRagAssetPromotionGate       | CORE FABRIC (MicroserviceBase — config layer)       | Block promotion if comparator score regresses      |

---

## FAMILY 163 — Context Efficiency Monitor (F1141–F1146)

**Purpose:** Treat "context efficiency" (retrieved tokens per solved task) as a first-class metric alongside quality. Enforce optimization policies that penalize noisy retrieval.

| Factory | Interface                    | Fabric Resolution                                   | Purpose                                             |
|---------|------------------------------|-----------------------------------------------------|-----------------------------------------------------|
| F1141   | IContextEfficiencyMonitor    | CORE FABRIC (MicroserviceBase — metrics layer)      | Track retrieved_token_count per step per run       |
| F1142   | INoiseRetrievalDetector      | AI ENGINE FABRIC (IAiProvider — scoring model)      | Detect low-relevance retrieved passages             |
| F1143   | IRerankerService             | AI ENGINE FABRIC (IAiProvider — rerank model)       | Rerank retrieved passages — reduce noise before gen |
| F1144   | IBudgetCapPolicyStore        | DATABASE FABRIC (IDatabaseService — Elasticsearch)  | Store per-tenant token budget cap policies          |
| F1145   | IEfficiencyPenaltyCalculator | CORE FABRIC (MicroserviceBase — rules layer)        | Penalize runs that exceed token budget for quality  |
| F1146   | IContextPruner               | AI ENGINE FABRIC (IAiProvider — compression model)  | Compress/prune context when approaching budget cap  |

---

## ARCHITECTURE SUMMARY

### Fabric Resolution Map (FLOW-29)

```
RAG FABRIC (IRagService)           ← F1075, F1077 (routing), F1083 (GraphRAG mode)
DATABASE FABRIC (IDatabaseService) ← F1080, F1083, F1085, F1090, F1092, F1094,
                                      F1095, F1099, F1101, F1105, F1106, F1108,
                                      F1112, F1115, F1116, F1119, F1120, F1123,
                                      F1125, F1126, F1127, F1128, F1132, F1134,
                                      F1135, F1136, F1137, F1144
QUEUE FABRIC (IQueueService)       ← F1082, F1089, F1091, F1096, F1103, F1109,
                                      F1113, F1117, F1118, F1124, F1138
AI ENGINE FABRIC (IAiProvider)     ← F1076, F1078, F1079, F1084, F1086, F1087,
                                      F1098, F1104, F1110, F1114, F1117, F1121,
                                      F1129, F1133, F1139, F1142, F1143, F1146
CORE FABRIC (MicroserviceBase)     ← F1077, F1093, F1097, F1100, F1102, F1107,
                                      F1111, F1122, F1130, F1140, F1141, F1145
FLOW ENGINE FABRIC (IFlowOrchestrator) ← F1131
```

### Zero Direct Provider Imports

```csharp
// ✅ CORRECT — via fabric
var result = await _ragService.SearchAsync(query, strategy: "GraphCommunity", ctx);
var model = await _aiProvider.GenerateAsync(prompt, ctx);

// ❌ WRONG — direct import (BUILD FAILURE)
var neo4j = new Neo4jClient(...);
var openai = new OpenAIClient(...);
```

### DNA Compliance (all 9 patterns, all generated services)

| DNA Pattern | FLOW-29 Application |
|---|---|
| DNA-1 ParseDocument | All RAG results → Dictionary<string,object>, never typed models |
| DNA-2 BuildQueryFilters | RAG search filters skip empty fields automatically |
| DNA-3 DataProcessResult | Retrieval failures return DataProcessResult<T>, never throw |
| DNA-4 MicroserviceBase | All 72 factory-backed services extend MicroserviceBase |
| DNA-5 Scope Isolation | tenantId on every graph query, every feedback store, every trace |
| DNA-6 DynamicController | No entity-specific controllers for RAG endpoints |
| DNA-7 Idempotency | Trace span emission is idempotent by traceId |
| DNA-8 Outbox | Bandit feedback persisted via outbox before acknowledgment |
| DNA-9 Backward Compat | FLOW-01–25 IRagService calls unchanged; new strategies are additive |
