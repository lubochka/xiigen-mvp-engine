# XIIGen SESSION STATE — FLOW-29: Adaptive RAG Deep Research Engine
## Date: 2026-03-01
## Status: FLOW-29 IN PROGRESS 🔄
## Prerequisite: FLOW-25 COMPLETE ✅ (Flows 26–28 reserved / TBD)

---

## SYSTEM STATE (Post FLOW-25 Baseline, FLOW-29 Additions)

| Artifact         | Pre-29 Count | +FLOW-29 | New Total | Range Added          |
|------------------|--------------|----------|-----------|----------------------|
| Factories        | 1074         | +72      | 1146      | F1075–F1146          |
| Task Types       | 388          | +27      | 415       | T389–T415            |
| Templates        | 82           | +7       | 89        | 83–89                |
| BFA Rules        | 509          | +26      | 535       | CF-510–CF-535        |
| Stress Tests     | 299          | +21      | 320       | ST-300–ST-320        |
| Skills           | 250          | +15      | 265       | SK-251–SK-265        |
| Design Decisions | 244          | +14      | 258       | DD-245–DD-258        |
| Design Records   | 183          | +10      | 193       | DR-184–DR-193        |
| DNA Patterns     | 9            | 0        | 9         | DNA-1–DNA-9 (stable) |
| Engine Primitives| 5            | 0        | 5         | EP-1–EP-5 (stable)   |
| Flows Complete   | 25           | +1       | 26        | FLOW-29 added        |

---

## NEXT AVAILABLE NUMBERS (FLOW-30 starts here)

```
Factory:          F1147    Family: 164
Task Type:        T416
Template:         90
BFA Rule:         CF-536
Stress Test:      ST-321
Skill:            SK-266
Design Decision:  DD-259
Design Record:    DR-194
```

---

## FLOW-29 DETAILS

### Domain: Adaptive RAG Deep Research Engine
### Philosophy: Self-learning, adaptive retrieval orchestration with bandit routing, GraphRAG, full trace capture, and versioned prompt/flow promotion.

### 10 Factory Families

| Family | Zone                          | Factories       | Count |
|--------|-------------------------------|-----------------|-------|
| 154    | Adaptive RAG Router           | F1075–F1082     | 8     |
| 155    | Knowledge Graph & GraphRAG    | F1083–F1090     | 8     |
| 156    | Trace Capture & Observability | F1091–F1097     | 7     |
| 157    | Bandit Router & Budget Control| F1098–F1104     | 7     |
| 158    | Evaluation & Quality Arbiter  | F1105–F1111     | 7     |
| 159    | Prompt Version Registry       | F1112–F1118     | 7     |
| 160    | Domain Compiler               | F1119–F1125     | 7     |
| 161    | Self-Learning Control Plane   | F1126–F1133     | 8     |
| 162    | RAG Asset Versioning          | F1134–F1140     | 7     |
| 163    | Context Efficiency Monitor    | F1141–F1146     | 6     |

### 27 Task Types

| Range     | Zone                          |
|-----------|-------------------------------|
| T389–T392 | Retrieval Mode Selection      |
| T393–T395 | Bandit Routing & Budget       |
| T396–T397 | Trace & Feedback              |
| T398–T399 | Prompt/Domain Versioning      |
| T400–T401 | Knowledge Graph Management    |
| T402–T404 | Eval & Promotion Gates        |
| T405–T407 | Context Efficiency & Reranking|
| T408–T410 | A/B Test & Policy Update      |
| T411–T412 | Self-Reflection & Graph Edit  |
| T413–T415 | Community Summary & Multi-Hop |

### 15 Skills

| Range       | Domain                         |
|-------------|--------------------------------|
| SK-251–252  | RAG Router & GraphRAG Indexer  |
| SK-253–254  | Hybrid Fusion & Bandit Router  |
| SK-255–256  | Trace Capture & Feedback Ingest|
| SK-257–258  | Eval Arbiter & Prompt Versioner|
| SK-259–260  | Domain Compiler & Asset Registry|
| SK-261–262  | Context Efficiency & Reranker  |
| SK-263–264  | A/B Allocator & Policy Updater |
| SK-265      | Visual Control Plane UI        |

---

## PHASE COMPLETION TRACKER

| Phase | Document                          | Status      | Save Point           |
|-------|-----------------------------------|-------------|----------------------|
| P0    | Factory Registration              | ✅ Complete  | F1075–F1146 locked   |
| P1    | ENGINE_ARCHITECTURE               | ✅ Complete  | All 10 families documented |
| P2    | TASK_TYPES_CATALOG                | ✅ Complete  | T389–T415 all full format |
| P3    | SKILLS_FACTORY_RAG                | ✅ Complete  | SK-251–SK-265        |
| P4    | V62_BFA_STRESS_TEST               | ✅ Complete  | CF-510–CF-535, ST-300–ST-320 |
| P5    | UNIFIED_SOURCE_INDEX              | ✅ Complete  | All cross-refs       |
| P6    | MASTER_EXECUTION_PLAN             | ✅ Complete  | P0–P6 plan           |

---

## RECOVERY INSTRUCTIONS

To resume from any phase:
1. Load SESSION_STATE (this file) — get current numbers
2. Load ENGINE_ARCHITECTURE — factory registry state
3. Load TASK_TYPES_CATALOG — engine contract state
4. Phase in progress: check Phase Completion Tracker above
5. Continue from next available number in the relevant artifact range

**Critical: FLOW-29 adds a new FABRIC LAYER (RAG FABRIC extensions). All new task types MUST resolve through fabric interfaces. Never import IRagService implementation directly.**

---

## BACKWARD COMPATIBILITY DECLARATION

FLOW-29 is ADDITIVE ONLY.
- F1–F1074: UNCHANGED
- T1–T388: UNCHANGED
- CF-1–CF-509: UNCHANGED
- SK-1–SK-250: UNCHANGED
- All existing flows (FLOW-01 through FLOW-25): UNCHANGED
- New BFA rules (CF-510–CF-535) add conflict detection WITHOUT modifying existing flow behavior

---

## KEY ARCHITECTURAL DECISIONS (FLOW-29)

| ID     | Decision                                                                  |
|--------|---------------------------------------------------------------------------|
| DD-245 | Adaptive RAG routing is a FABRIC EXTENSION to IRagService, not a new fabric |
| DD-246 | GraphRAG community rebuild is async — never blocks synchronous query path  |
| DD-247 | Bandit router reads FREEDOM config; MACHINE layer never hard-codes model choice |
| DD-248 | All traces use OpenTelemetry spans over QUEUE FABRIC — no direct SDK calls  |
| DD-249 | Prompt versions are immutable — promote by creating new version, not editing |
| DD-250 | Domain compiler profiles are tenant-scoped (tenantId on every graph query)  |
| DD-251 | Context efficiency budget_cap is a FREEDOM config value, admin-adjustable   |
| DD-252 | A/B test allocation uses QUEUE FABRIC for result collection — no shared state|
| DD-253 | Self-reflection check (T411) can only REDUCE retrieved tokens, never expand  |
| DD-254 | Knowledge graph edits require BFA approval gate before taking effect         |
| DD-255 | Feedback aggregation window is configurable (default: 100 runs or 24h)      |
| DD-256 | Promotion pipeline follows existing ladder: GENERATED→INJECTED→MINIMAL→CORE |
| DD-257 | Multi-hop traversal depth is FREEDOM config (default max: 4 hops)           |
| DD-258 | Visual control plane is a React Flow canvas — fabric-first, zero hardcoded values|
