# 29-adaptive rag TASK_TYPES_CATALOG
# XIIGen FLOW-29 — Adaptive RAG Deep Research Engine
# Task Types: T389–T415 | Templates: 83–89

---

## PREAMBLE

All task types follow the full ENGINE CONTRACT format established in V39/V40.
Every FACTORY DEPENDENCY declares its FABRIC RESOLUTION.
Every task type maps AF stations and declares IRON RULES.
No one-line stubs. No typed models. No direct provider imports.

---

## TASK TYPE: T389 — Adaptive RAG Route Gate

**ARCHETYPE:** ORCHESTRATION
**ENTRY:** Fires when a task/subtask arrives at the retrieval layer; has query text + budget preference
**PURPOSE:** Classify query intent (local/global/multi-hop) and route to correct retrieval mode (Vector / GraphCommunity / Hybrid / SelfReflect)
**DISTINCT FROM:** T99 (simple search — no adaptive routing); T248 (vector-only step)
**FAMILY:** 154

**FACTORY DEPENDENCIES:**
- F1075: IAdaptiveRagRouter
- F1076: ITaskClassifier
- F1077: IRetrievalModeSelector
- F1082: IRoutingAuditLogger

**FABRIC RESOLUTION:**
- F1075 → RAG FABRIC (IRagService — AdaptiveBandit strategy)
- F1076 → AI ENGINE FABRIC (IAiProvider — lightweight classifier model)
- F1077 → CORE FABRIC (MicroserviceBase config layer)
- F1082 → QUEUE FABRIC (IQueueService — Redis Streams)

**AF CONFIGURATION:**
- AF-2 Planning: decompose routing decision into classification → mode selection → audit steps
- AF-4 RAG: retrieve similar past routing decisions (SK-251) for calibration
- AF-7 Compliance: verify no direct provider import in routing logic
- AF-9 Judge: validate route decision matches task classifier output; no override without trace

**BFA VALIDATION:**
- CF-510: RAG routing change must not break FLOW-09 (Search & Discovery) query contracts
- CF-511: Route gate must not bypass FLOW-25 BFA governance for structural changes

**MACHINE/FREEDOM:**
- MACHINE: Classification logic, mode registry, audit emission
- FREEDOM: Routing strategy weights, exploration rate, budget mode thresholds, classifier model

**IRON RULES:**
1. Route gate MUST emit audit event via F1082 before returning — no silent routing
2. Mode selection MUST read from FREEDOM config — never hard-coded in service code
3. Classifier MUST return confidence score — routing on zero-confidence = BUILD FAILURE

**QUALITY GATES (AF-9):**
- routing_confidence_score ≥ 0.7
- audit_event_emitted = true
- mode_selected ∈ {Vector, GraphCommunity, Hybrid, SelfReflect, DomainProfile}
- retrieved_token_estimate present before retrieval begins

---

## TASK TYPE: T390 — Vector Retrieval Step

**ARCHETYPE:** RETRIEVAL
**ENTRY:** After T389 selects Vector mode; has rewritten query + chunk parameters
**PURPOSE:** Dense embedding retrieval over chunked text corpus with query rewrite, parallel sub-queries, and reranking
**DISTINCT FROM:** T389 (routing), T391 (GraphRAG), T392 (hybrid fusion)
**FAMILY:** 154 / 162

**FACTORY DEPENDENCIES:**
- F1078: IQueryRewriter
- F1079: IQueryDecomposer
- F1134: IRagIndexVersionStore
- F1143: IRerankerService
- F1141: IContextEfficiencyMonitor

**FABRIC RESOLUTION:**
- F1078 → AI ENGINE FABRIC (IAiProvider — fast rewrite model)
- F1079 → AI ENGINE FABRIC (IAiProvider — fast decompose model)
- F1134 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1143 → AI ENGINE FABRIC (IAiProvider — rerank model)
- F1141 → CORE FABRIC (MicroserviceBase — metrics layer)

**AF CONFIGURATION:**
- AF-1 Genesis: generate vector retrieval service extending MicroserviceBase
- AF-4 RAG: retrieve SK-251 (RAG Router skill) patterns
- AF-6 Code Review: verify no typed models in retrieved chunk handling
- AF-9 Judge: context_efficiency_score ≥ threshold; reranker applied

**BFA VALIDATION:**
- CF-512: Vector index version must be declared; rolling update protocol applies

**MACHINE/FREEDOM:**
- MACHINE: Query rewrite → decompose → parallel search → rerank pipeline
- FREEDOM: chunk_size, chunk_overlap, top_k, rerank_model, index version pointer

**IRON RULES:**
1. Retrieved passages MUST be Dictionary<string,object> — never typed Passage model
2. Reranker MUST run before context is passed to generator — no raw top-k to generator
3. context_efficiency_monitor MUST record retrieved_token_count per call

**QUALITY GATES (AF-9):**
- retrieved_token_count ≤ budget_cap
- rerank_applied = true
- passage_relevance_score ≥ 0.6
- parallel_decomposition_used when query_complexity = HIGH

---

## TASK TYPE: T391 — GraphRAG Community Query

**ARCHETYPE:** RETRIEVAL
**ENTRY:** After T389 selects GraphCommunity mode; global or multi-hop query
**PURPOSE:** Query GraphRAG community hierarchy — community summaries for global answers; multi-hop traversal for relational questions
**DISTINCT FROM:** T390 (vector-only), T413 (community summary generation), T414 (multi-hop traversal)
**FAMILY:** 155

**FACTORY DEPENDENCIES:**
- F1083: IGraphRagService
- F1085: ICommunityHierarchyManager
- F1086: ICommunitySummaryGenerator
- F1091: ITraceSpanService
- F1141: IContextEfficiencyMonitor

**FABRIC RESOLUTION:**
- F1083 → DATABASE FABRIC (IDatabaseService — Neo4j/Elasticsearch graph provider)
- F1085 → DATABASE FABRIC (IDatabaseService — graph provider)
- F1086 → AI ENGINE FABRIC (IAiProvider — summarization model)
- F1091 → QUEUE FABRIC (IQueueService — Redis Streams)
- F1141 → CORE FABRIC (MicroserviceBase — metrics layer)

**AF CONFIGURATION:**
- AF-1 Genesis: generate GraphRAG query service on DATABASE FABRIC — never direct Neo4j import
- AF-4 RAG: retrieve SK-252 (GraphRAG Indexer skill) patterns
- AF-7 Compliance: verify tenantId scoping on every graph query (DNA-5)
- AF-8 Security: graph query injection prevention
- AF-9 Judge: community_level_used declared; token budget respected

**BFA VALIDATION:**
- CF-513: Graph query must include tenantId scope — cross-tenant graph leak = CRITICAL conflict
- CF-514: Community rebuild events must NOT block synchronous query path

**MACHINE/FREEDOM:**
- MACHINE: Community level selection logic, graph traversal protocol
- FREEDOM: max_community_level, max_hops (default 4), summary_model, community_rebuild_schedule

**IRON RULES:**
1. tenantId MUST be on every graph query — no exceptions
2. Community rebuild MUST go through IGraphIndexRebuildQueue (async) — never inline rebuild
3. Graph provider MUST be resolved via IDatabaseService factory — never direct driver

**QUALITY GATES (AF-9):**
- tenant_scope_verified = true
- community_level_selected and declared in trace
- rebuild_not_blocking = true
- retrieved_token_count ≤ budget_cap

---

## TASK TYPE: T392 — Hybrid Retrieval Fusion

**ARCHETYPE:** RETRIEVAL
**ENTRY:** After T389 selects Hybrid mode; query requires both dense retrieval and graph context
**PURPOSE:** Fuse vector retrieval results with GraphRAG community context; rerank unified result set; enforce context budget
**DISTINCT FROM:** T390 (vector-only), T391 (graph-only)
**FAMILY:** 154 / 155 / 163

**FACTORY DEPENDENCIES:**
- F1075: IAdaptiveRagRouter
- F1083: IGraphRagService
- F1143: IRerankerService
- F1144: IBudgetCapPolicyStore
- F1141: IContextEfficiencyMonitor
- F1146: IContextPruner

**FABRIC RESOLUTION:**
- F1075 → RAG FABRIC (Hybrid strategy)
- F1083 → DATABASE FABRIC (graph provider)
- F1143 → AI ENGINE FABRIC (rerank model)
- F1144 → DATABASE FABRIC (Elasticsearch — budget policies)
- F1141 → CORE FABRIC (metrics layer)
- F1146 → AI ENGINE FABRIC (compression model)

**AF CONFIGURATION:**
- AF-1 Genesis: generate fusion service — parallel vector + graph fetch, then merge
- AF-5 Multi-model: run competing fusion strategies; AiDispatcher aggregates
- AF-9 Judge: fusion_ratio declared; context_efficiency_score computed

**BFA VALIDATION:**
- CF-515: Hybrid fusion result shape must be compatible with T390/T391 downstream consumers

**IRON RULES:**
1. Fusion MUST produce Dictionary<string,object> result — no typed FusionResult model
2. If total retrieved_token_count > budget_cap → IContextPruner MUST run before returning
3. Fusion ratio (vector:graph weight) MUST be FREEDOM config — never hard-coded

**QUALITY GATES (AF-9):**
- fusion_ratio declared in trace
- context_pruning_applied_if_over_budget = true
- unified_rerank_applied = true

---

## TASK TYPE: T393 — Contextual Bandit Model Select

**ARCHETYPE:** ROUTING
**ENTRY:** After retrieval completes; before generation step; has retrieved context + task profile
**PURPOSE:** Select optimal (model, prompt version, flow variant) under budget preference using contextual bandit policy
**DISTINCT FROM:** T389 (retrieval routing), T389 routes retrieval mode; T393 routes generation model
**FAMILY:** 157

**FACTORY DEPENDENCIES:**
- F1098: IBanditRouter
- F1099: IBanditFeedbackStore
- F1100: IBudgetPreferenceReader
- F1101: IBanditPolicyUpdater
- F1103: IBanditAuditLog

**FABRIC RESOLUTION:**
- F1098 → AI ENGINE FABRIC (IAiProvider — lightweight bandit/routing model)
- F1099 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1100 → CORE FABRIC (MicroserviceBase — config layer)
- F1101 → DATABASE FABRIC (IDatabaseService — Redis cache)
- F1103 → QUEUE FABRIC (IQueueService — Redis Streams)

**AF CONFIGURATION:**
- AF-2 Planning: decompose into policy-read → arm selection → exploration-exploit decision → audit
- AF-9 Judge: selected arm within budget mode constraints; exploration rate respected

**BFA VALIDATION:**
- CF-516: Bandit selection MUST NOT override explicit model assignments in FLOW-13 (AI Content Pipeline)
- CF-517: Bandit policy update MUST be async — never block the generation call

**MACHINE/FREEDOM:**
- MACHINE: Multi-armed bandit arm = (modelId, promptVersionId, flowVariantId); arm structure invariant
- FREEDOM: exploration_rate (epsilon/UCB), reward_window_size, budget_mode_thresholds, arm_set

**IRON RULES:**
1. Arm selection MUST be logged via F1103 before generation call
2. Policy update MUST be async (via IQueueService) — never synchronous during live request
3. Budget mode MUST be read from FREEDOM config — never inferred from request body

**QUALITY GATES (AF-9):**
- arm_selected declared: {modelId, promptVersionId, flowVariantId}
- budget_mode_respected = true
- audit_emitted_before_generation = true

---

## TASK TYPE: T394 — Budget Enforcement Gate

**ARCHETYPE:** GUARD
**ENTRY:** After any retrieval or generation step that produces token/cost metrics
**PURPOSE:** Hard-stop if budget_cap exceeded; soft-warn if within 80% of cap; emit cost event
**DISTINCT FROM:** T393 (selection under budget), T394 enforces the hard boundary
**FAMILY:** 157 / 163

**FACTORY DEPENDENCIES:**
- F1097: ICostBudgetEnforcer
- F1144: IBudgetCapPolicyStore
- F1145: IEfficiencyPenaltyCalculator
- F1092: ITokenCostTracker

**FABRIC RESOLUTION:**
- F1097 → CORE FABRIC (MicroserviceBase — config layer)
- F1144 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1145 → CORE FABRIC (MicroserviceBase — rules layer)
- F1092 → DATABASE FABRIC (IDatabaseService — Elasticsearch)

**IRON RULES:**
1. If retrieved_token_count > budget_cap → HALT, return DataProcessResult with BudgetExceeded error
2. NEVER silently truncate context to fit budget — must HALT and surface error
3. Penalty calculation MUST feed back to bandit router (async)

**QUALITY GATES (AF-9):**
- budget_enforced = true (halt on exceed, never silent truncate)
- cost_event_emitted = true
- penalty_queued_for_bandit = true

---

## TASK TYPE: T395 — Routing Policy Update

**ARCHETYPE:** LEARNING
**ENTRY:** Triggered async after feedback aggregation window closes (100 runs OR 24h, FREEDOM config)
**PURPOSE:** Update bandit routing policy weights from aggregated feedback; never during live request
**DISTINCT FROM:** T393 (selection), T395 UPDATES the policy that T393 reads
**FAMILY:** 157 / 161

**FACTORY DEPENDENCIES:**
- F1101: IBanditPolicyUpdater
- F1132: ISelfLearningFeedbackAggregator
- F1133: IGraphAnalyticsRunner
- F1129: IImprovementSuggestionEngine

**FABRIC RESOLUTION:**
- F1101 → DATABASE FABRIC (Redis cache)
- F1132 → DATABASE FABRIC (Elasticsearch)
- F1133 → AI ENGINE FABRIC (analysis model)
- F1129 → AI ENGINE FABRIC (AiDispatcher — analysis)

**IRON RULES:**
1. Policy update ALWAYS async — no synchronous call during live request path
2. Previous policy version MUST be archived before new version activates
3. Analytics runner MUST emit improvement suggestions via QUEUE FABRIC (not direct callback)

**QUALITY GATES (AF-9):**
- previous_policy_archived = true
- improvement_suggestions_emitted = true
- aggregation_window_respected = true

---

## TASK TYPE: T396 — Trace Span Capture

**ARCHETYPE:** OBSERVABILITY
**ENTRY:** Wraps every step in every task type; fires at step start and step end
**PURPOSE:** Emit OpenTelemetry-compatible trace spans for every retrieval, generation, eval, and routing step over QUEUE FABRIC
**DISTINCT FROM:** All other task types — T396 is a cross-cutting concern applied to all of them
**FAMILY:** 156

**FACTORY DEPENDENCIES:**
- F1091: ITraceSpanService
- F1092: ITokenCostTracker
- F1093: ILatencyProfiler
- F1094: IRunSessionStore
- F1096: IObservabilityExporter

**FABRIC RESOLUTION:**
- F1091 → QUEUE FABRIC (IQueueService — Redis Streams)
- F1092 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1093 → CORE FABRIC (MicroserviceBase — health layer)
- F1094 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1096 → QUEUE FABRIC (IQueueService — outbox pattern)

**IRON RULES:**
1. Trace span MUST be emitted via QUEUE FABRIC — never via direct OTel SDK call
2. traceId + spanId MUST be propagated across all sub-steps (DNA-8 outbox pattern)
3. Export to external OTel collector is FREEDOM config — off by default

**QUALITY GATES (AF-9):**
- traceId propagated across all child spans = true
- token_cost_recorded per step = true
- outbox_confirmed before acknowledgment = true

---

## TASK TYPE: T397 — User Feedback Ingest

**ARCHETYPE:** LEARNING
**ENTRY:** User provides explicit feedback (rating, correction, "wrong because...") on a completed run
**PURPOSE:** Link feedback to exact (run, config, trace, model, prompt version, retrieval mode) that produced the result; feed bandit router
**DISTINCT FROM:** T396 (system trace), T397 captures HUMAN feedback
**FAMILY:** 156 / 157

**FACTORY DEPENDENCIES:**
- F1095: IFeedbackLinker
- F1099: IBanditFeedbackStore
- F1132: ISelfLearningFeedbackAggregator
- F1091: ITraceSpanService

**FABRIC RESOLUTION:**
- F1095 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1099 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1132 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1091 → QUEUE FABRIC (IQueueService — Redis Streams)

**IRON RULES:**
1. Feedback MUST be linked to exact traceId+runId — orphan feedback = BUILD FAILURE
2. Feedback stored as Dictionary<string,object> — never typed FeedbackModel
3. Feedback ingestion MUST be idempotent by (userId, runId, feedbackTimestamp)

**QUALITY GATES (AF-9):**
- trace_linkage_verified = true
- idempotency_key_present = true
- bandit_store_updated = true

---

## TASK TYPE: T398 — Prompt Version Promote

**ARCHETYPE:** GOVERNANCE
**ENTRY:** Candidate prompt has passed A/B evaluation and quality gate
**PURPOSE:** Promote prompt through ladder: DRAFT → CANDIDATE → TESTED → ACTIVE → ARCHIVED. Immutable — never edit in place
**DISTINCT FROM:** T399 (domain profile compile), T254 in earlier flows
**FAMILY:** 159

**FACTORY DEPENDENCIES:**
- F1112: IPromptVersionRegistry
- F1113: IPromptVersionPromoter
- F1115: IPromptRollbackManager
- F1111: IQualityGateEnforcer

**FABRIC RESOLUTION:**
- F1112 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1113 → QUEUE FABRIC (IQueueService — Redis Streams)
- F1115 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1111 → CORE FABRIC (MicroserviceBase — config layer)

**IRON RULES:**
1. Promotion MUST create a NEW version record — never update existing version document
2. Rollback MUST switch pointer to previous ACTIVE version — never delete versions
3. BFA validation MUST complete before ACTIVE state is set

**QUALITY GATES (AF-9):**
- new_version_created (not updated) = true
- quality_gate_passed = true
- bfa_validation_complete = true
- previous_version_archived = true

---

## TASK TYPE: T399 — Domain Profile Compile

**ARCHETYPE:** BUILD
**ENTRY:** Admin configures a new technology domain profile (entity types, relation types, extraction prompts)
**PURPOSE:** Compile domain profile → trigger GraphRAG index rebuild for that domain → track metrics
**DISTINCT FROM:** T398 (prompt versioning), T399 covers the entire knowledge compiler profile
**FAMILY:** 160

**FACTORY DEPENDENCIES:**
- F1119: IDomainProfileStore
- F1120: IDomainEntityTypeRegistry
- F1121: IDomainExtractionPrompter
- F1124: IDomainCompilerProfilePublisher
- F1125: IDomainMetricsTracker

**FABRIC RESOLUTION:**
- F1119 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1120 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1121 → AI ENGINE FABRIC (IAiProvider — extract model)
- F1124 → QUEUE FABRIC (IQueueService — Redis Streams)
- F1125 → DATABASE FABRIC (IDatabaseService — Elasticsearch)

**IRON RULES:**
1. Domain profile is tenant-scoped (tenantId) — cross-tenant profile access = CRITICAL
2. Rebuild trigger MUST go via F1124 (QUEUE FABRIC) — never inline rebuild
3. Extraction prompts auto-generated by F1121 MUST be versioned (F1112) before activation

**QUALITY GATES (AF-9):**
- tenant_scope = true
- rebuild_queued_async = true
- extraction_prompts_versioned = true

---

## TASK TYPE: T400 — Knowledge Graph Edit Gate

**ARCHETYPE:** GOVERNANCE
**ENTRY:** Any request to modify graph structure (add entity type, add relation type, change community partition)
**PURPOSE:** BFA-approved gate — validate graph edit won't corrupt live queries; approve/reject before writing
**DISTINCT FROM:** T399 (compile profile), T400 is the GUARD before any structural graph change
**FAMILY:** 155

**FACTORY DEPENDENCIES:**
- F1088: IGraphEditGate
- F1089: IGraphIndexRebuildQueue

**FABRIC RESOLUTION:**
- F1088 → CORE FABRIC (MicroserviceBase — permissions layer)
- F1089 → QUEUE FABRIC (IQueueService — Redis Streams DLQ)

**IRON RULES:**
1. No graph structural change without BFA approval via F1088
2. Async rebuild ALWAYS via F1089 — never inline
3. Gate decision (approve/reject) MUST be persisted in audit trail

**QUALITY GATES (AF-9):**
- bfa_approval_obtained = true
- rebuild_queued_not_inline = true
- audit_persisted = true

---

## TASK TYPE: T401 — RAG Asset Version Compare

**ARCHETYPE:** EVALUATION
**ENTRY:** Two RAG index versions available; evaluation dataset present
**PURPOSE:** A/B compare two RAG versions on eval dataset; block promotion if quality regresses
**DISTINCT FROM:** T398 (prompt promotion), T401 compares full RAG index assets
**FAMILY:** 162

**FACTORY DEPENDENCIES:**
- F1139: IRagVersionComparator
- F1140: IRagAssetPromotionGate
- F1134: IRagIndexVersionStore

**FABRIC RESOLUTION:**
- F1139 → AI ENGINE FABRIC (IAiProvider — eval model)
- F1140 → CORE FABRIC (MicroserviceBase — config layer)
- F1134 → DATABASE FABRIC (IDatabaseService — Elasticsearch)

**IRON RULES:**
1. Promotion blocked if comparator score shows regression > 3% on any core metric
2. Comparator MUST run on same eval dataset across both versions
3. Result stored in F1134 before promotion decision

**QUALITY GATES (AF-9):**
- eval_dataset_consistent = true
- regression_check_passed = true
- promotion_decision_persisted = true

---

## TASK TYPE: T402 — Eval Quality Gate

**ARCHETYPE:** GUARD
**ENTRY:** After generation step; before response returned to user
**PURPOSE:** Validate generated answer against retrieval faithfulness, context coverage, hallucination detection, quality rubric
**DISTINCT FROM:** T401 (version compare), T402 is the per-run live quality check
**FAMILY:** 158

**FACTORY DEPENDENCIES:**
- F1105: IRetrievalFaithfulnessChecker
- F1106: IContextCoverageScorer
- F1110: IHallucinationDetector
- F1108: IQualityRubricStore
- F1109: IEvalResultPublisher

**FABRIC RESOLUTION:**
- F1105 → AI ENGINE FABRIC (IAiProvider — judge model)
- F1106 → AI ENGINE FABRIC (IAiProvider — embedding model)
- F1110 → AI ENGINE FABRIC (AiDispatcher — multi-model consensus)
- F1108 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1109 → QUEUE FABRIC (IQueueService — Redis Streams)

**IRON RULES:**
1. Hallucination detection MUST use multi-model consensus (AiDispatcher) — not single model
2. Quality rubric MUST be tenant-scoped — global rubric is default, never forced
3. Eval result MUST be published via F1109 before response returned

**QUALITY GATES (AF-9):**
- faithfulness_score ≥ 0.8
- hallucination_consensus_checked = true
- quality_rubric_applied = true
- eval_result_published = true

---

## TASK TYPE: T403 — Promotion Pipeline Gate

**ARCHETYPE:** GOVERNANCE
**ENTRY:** Any generated service or flow variant ready to advance through GENERATED→INJECTED→MINIMAL→CORE ladder
**PURPOSE:** Orchestrate promotion steps: eval → BFA check → quality gate → version archive → promote
**DISTINCT FROM:** T398 (prompt-specific), T403 is the general promotion pipeline for all assets
**FAMILY:** 161

**FACTORY DEPENDENCIES:**
- F1131: IPromotionPipelineOrchestrator
- F1111: IQualityGateEnforcer
- F1127: IAssetVersionManager

**FABRIC RESOLUTION:**
- F1131 → FLOW ENGINE FABRIC (IFlowOrchestrator)
- F1111 → CORE FABRIC (MicroserviceBase — config layer)
- F1127 → DATABASE FABRIC (IDatabaseService — Elasticsearch)

**IRON RULES:**
1. Promotion steps MUST execute in order via IFlowOrchestrator — never skip steps
2. Each step persists state — resumable after failure (DNA-8)
3. BFA check via FLOW-25 governance is MANDATORY before CORE promotion

**QUALITY GATES (AF-9):**
- all_promotion_steps_completed_in_order = true
- bfa_governance_passed = true
- version_archived = true

---

## TASK TYPE: T404 — A/B Test Allocation

**ARCHETYPE:** EXPERIMENTATION
**ENTRY:** Request arrives; bandit policy identifies variant candidates for testing
**PURPOSE:** Deterministically allocate tenant/user to a flow variant for A/B testing; collect results via QUEUE FABRIC
**FAMILY:** 161

**FACTORY DEPENDENCIES:**
- F1130: IControlPlaneABAllocator
- F1128: IFlowVariantRegistry
- F1091: ITraceSpanService

**FABRIC RESOLUTION:**
- F1130 → CORE FABRIC (MicroserviceBase — scope layer)
- F1128 → DATABASE FABRIC (IDatabaseService — Elasticsearch)
- F1091 → QUEUE FABRIC (IQueueService — Redis Streams)

**IRON RULES:**
1. Allocation MUST be deterministic by (tenantId + userId + experimentId) — no random per-request
2. Variant assignment persisted before request handled
3. No shared mutable state between variant branches (DNA-8 outbox)

**QUALITY GATES (AF-9):**
- deterministic_allocation = true
- assignment_persisted = true
- trace_span_emitted = true

---

## TASK TYPE: T405 — Context Efficiency Check

**ARCHETYPE:** GUARD
**ENTRY:** After retrieval; before reranking; monitors token consumption
**PURPOSE:** Check retrieved_token_count against budget; apply pruning if needed; emit efficiency score
**FAMILY:** 163

**FACTORY DEPENDENCIES:**
- F1141: IContextEfficiencyMonitor
- F1142: INoiseRetrievalDetector
- F1145: IEfficiencyPenaltyCalculator

**FABRIC RESOLUTION:**
- F1141 → CORE FABRIC (MicroserviceBase — metrics layer)
- F1142 → AI ENGINE FABRIC (IAiProvider — scoring model)
- F1145 → CORE FABRIC (MicroserviceBase — rules layer)

**IRON RULES:**
1. Self-reflection check can only REDUCE retrieved tokens, never expand
2. Noise detector result feeds penalty calculator → bandit router feedback (async)
3. efficiency_score MUST be emitted before generation step

**QUALITY GATES (AF-9):**
- noise_detection_applied = true
- efficiency_score_emitted = true
- token_reduction_if_over_budget = true

---

## TASK TYPE: T406 — Reranker Step

**ARCHETYPE:** RETRIEVAL-POST
**ENTRY:** After vector or hybrid retrieval; before context passed to generator
**PURPOSE:** Rerank retrieved passages to reduce noise; reject low-relevance passages below threshold
**FAMILY:** 163

**FACTORY DEPENDENCIES:**
- F1143: IRerankerService
- F1141: IContextEfficiencyMonitor

**FABRIC RESOLUTION:**
- F1143 → AI ENGINE FABRIC (IAiProvider — rerank model)
- F1141 → CORE FABRIC (metrics layer)

**IRON RULES:**
1. Reranker ALWAYS runs before context reaches generator — no raw top-k
2. Passages below relevance_threshold MUST be excluded (FREEDOM config value)
3. Reranker model MUST be FREEDOM config — never hard-coded

**QUALITY GATES (AF-9):**
- reranker_applied = true
- low_relevance_excluded = true
- final_passage_count ≤ max_passages (FREEDOM)

---

## TASK TYPE: T407 — Self-Reflection Retrieval Check

**ARCHETYPE:** RETRIEVAL-GUARD
**ENTRY:** After initial retrieval; BEFORE committing retrieved context to generation
**PURPOSE:** Agentic self-check: Is retrieval needed? Is retrieved content relevant enough? Avoid retrieving when unnecessary or low-quality
**DISTINCT FROM:** T405 (budget check), T407 decides WHETHER to use retrieval at all
**FAMILY:** 154

**FACTORY DEPENDENCIES:**
- F1075: IAdaptiveRagRouter
- F1077: IRetrievalModeSelector
- F1142: INoiseRetrievalDetector

**FABRIC RESOLUTION:**
- F1075 → RAG FABRIC (SelfReflect strategy)
- F1077 → CORE FABRIC (config layer)
- F1142 → AI ENGINE FABRIC (scoring model)

**IRON RULES:**
1. If self-reflection score < threshold → skip retrieval, proceed with parametric knowledge
2. Self-reflection CANNOT override explicit user request for retrieval
3. Skip-retrieval decision MUST be logged in trace

**QUALITY GATES (AF-9):**
- self_reflection_score declared = true
- skip_decision_logged = true

---

## TASK TYPES T408–T415 (Summary Contracts)

### T408 — Feedback Aggregation Window
ARCHETYPE: LEARNING | FAMILY: 161
Aggregates feedback over configurable window (100 runs OR 24h). Triggers T395.
FACTORIES: F1132 (DATABASE), F1103 (QUEUE for trigger emission)
IRON RULE: Window close triggers async policy update — never synchronous

### T409 — Improvement Suggestion Engine
ARCHETYPE: ANALYSIS | FAMILY: 161
Graph analytics over failure clusters → AI-generated improvement suggestions for prompts/flows.
FACTORIES: F1129 (AI ENGINE), F1133 (AI ENGINE)
IRON RULE: Suggestions emitted via QUEUE FABRIC — never auto-applied without human approval

### T410 — Control Plane Graph Edit
ARCHETYPE: GOVERNANCE | FAMILY: 161
Edit task→subtask→flow→prompt→model→evaluator connections in control plane graph.
FACTORIES: F1126 (DATABASE graph), F1088 (CORE — permissions gate)
IRON RULE: BFA approval required; every edit creates new version, never mutates

### T411 — Knowledge Graph Multi-Hop Traversal
ARCHETYPE: RETRIEVAL | FAMILY: 155
Deep relational traversal up to max_hops (FREEDOM config, default 4).
FACTORIES: F1083 (DATABASE graph), F1085 (DATABASE hierarchy), F1091 (QUEUE trace)
IRON RULE: tenantId on every hop; max_hops enforced hard — never exceeded

### T412 — Community Summary Generation
ARCHETYPE: BUILD | FAMILY: 155
Generate/refresh community summaries for GraphRAG global query support.
FACTORIES: F1086 (AI ENGINE — summarize), F1089 (QUEUE — async queue)
IRON RULE: Summary generation is ALWAYS async — never blocks query path

### T413 — Domain GraphRAG Index Rebuild
ARCHETYPE: BUILD | FAMILY: 160
Full domain index rebuild from compiled domain profile. Async.
FACTORIES: F1124 (QUEUE — publish rebuild), F1119 (DATABASE — profile), F1125 (DATABASE — metrics)
IRON RULE: Rebuild via QUEUE FABRIC only; live queries use previous index until rebuild completes

### T414 — RAG Strategy Version Rollback
ARCHETYPE: GOVERNANCE | FAMILY: 162
Safe rollback to previous RAG strategy version. Pointer swap, never delete.
FACTORIES: F1138 (QUEUE — rollback event), F1137 (DATABASE — strategy version store)
IRON RULE: Previous version preserved; rollback is pointer change not data deletion

### T415 — Visual Control Plane Node Render
ARCHETYPE: UI | FAMILY: 161
Render control plane graph as fabric-first React Flow canvas. Zero platform-specific values.
FACTORIES: F1126 (DATABASE — graph store), F1128 (DATABASE — variant registry)
IRON RULE: UI reads FREEDOM config only — never hard-codes node types, model names, or strategy names

---

## TEMPLATE 83 — Adaptive RAG Route + Generate Pipeline

```json
{
  "templateId": "83",
  "name": "adaptive-rag-route-generate",
  "version": "1.0",
  "flow-29-template": true,
  "steps": [
    { "stepId": "s1", "taskType": "T389", "label": "AdaptiveRouteGate" },
    { "stepId": "s2", "taskType": "T407", "label": "SelfReflectionCheck", "dependsOn": ["s1"] },
    { "stepId": "s3", "taskType": "T390", "label": "VectorRetrieval", "condition": "mode==Vector", "dependsOn": ["s2"] },
    { "stepId": "s4", "taskType": "T391", "label": "GraphRAGQuery", "condition": "mode==GraphCommunity", "dependsOn": ["s2"] },
    { "stepId": "s5", "taskType": "T392", "label": "HybridFusion", "condition": "mode==Hybrid", "dependsOn": ["s2"] },
    { "stepId": "s6", "taskType": "T406", "label": "Reranker", "dependsOn": ["s3","s4","s5"] },
    { "stepId": "s7", "taskType": "T405", "label": "ContextEfficiencyCheck", "dependsOn": ["s6"] },
    { "stepId": "s8", "taskType": "T394", "label": "BudgetEnforcementGate", "dependsOn": ["s7"] },
    { "stepId": "s9", "taskType": "T393", "label": "BanditModelSelect", "dependsOn": ["s8"] },
    { "stepId": "s10", "taskType": "T402", "label": "EvalQualityGate", "dependsOn": ["s9"] },
    { "stepId": "s11", "taskType": "T396", "label": "TraceSpanCapture", "wraps": "all" }
  ],
  "fabricResolution": "all-steps-via-factory-CreateAsync",
  "dnaCompliance": "DNA-1-through-DNA-9"
}
```

## TEMPLATES 84–89 (Registered)

| Template | Name                            | Key Steps                        |
|----------|---------------------------------|----------------------------------|
| 84       | feedback-ingest-policy-update   | T397 → T408 → T395               |
| 85       | prompt-version-promote          | T398 → T403 → T401               |
| 86       | domain-profile-compile-rebuild  | T399 → T400 → T412 → T413        |
| 87       | ab-test-allocate-collect        | T404 → T396 → T397 → T408        |
| 88       | knowledge-graph-edit-governance | T410 → T400 → T411               |
| 89       | promotion-pipeline-full         | T401 → T402 → T403               |
