# 29-adaptive rag V62_BFA_STRESS_TEST
# XIIGen FLOW-29 — Adaptive RAG Deep Research Engine
# BFA Rules: CF-510–CF-535 | Stress Tests: ST-300–ST-320

---

## OVERVIEW

26 new Business Flow Arbiter rules protect FLOW-29's adaptive RAG layer from breaking existing flows (FLOW-01 through FLOW-25) and from internal self-modification risks. 21 stress tests validate the BFA rules under adversarial conditions.

Rule format: ID | TRIGGER | SEVERITY | ACTION | CROSS-FLOW IMPACT

---

## BFA CONFLICT RULES — CF-510–CF-535

### CF-510 — RAG Routing Change vs. Search & Discovery
**TRIGGER:** Any modification to IAdaptiveRagRouter (F1075) routing strategy config
**SEVERITY:** HIGH
**ACTION:** Cross-check against FLOW-09 (Search & Discovery) query contracts. If FLOW-09 uses IRagService.SearchAsync() with a strategy that is being renamed or removed → HALT, require COMPAT_WRAPPER
**CROSS-FLOW:** FLOW-09 (F261–F280, T99–T118)
**REASON:** FLOW-09 depends on stable IRagService strategy names. Renaming AdaptiveBandit → BanditV2 without compat wrapper breaks live search queries.

### CF-511 — Route Gate Bypasses BFA Governance
**TRIGGER:** T389 route decision that modifies graph structure without going through T410 (Knowledge Graph Edit Gate)
**SEVERITY:** CRITICAL
**ACTION:** REJECT — structural graph changes require BFA approval via T410/T400. No exceptions.
**CROSS-FLOW:** FLOW-25 (F1028–F1074, BFA Governance)
**REASON:** FLOW-25 is the governance layer. FLOW-29 routing cannot bypass it.

### CF-512 — Vector Index Version Rolling Update
**TRIGGER:** IRagIndexVersionStore (F1134) version pointer change
**SEVERITY:** MEDIUM
**ACTION:** Require rolling update declaration in deployment manifest. Cannot swap index version without declaring previous version as ROLLBACK_TARGET.
**CROSS-FLOW:** FLOW-09, FLOW-13 (AI Content Pipeline)
**REASON:** FLOW-09 and FLOW-13 queries may be in-flight during index version swap.

### CF-513 — Cross-Tenant Graph Query Leak
**TRIGGER:** Any IGraphRagService (F1083) query missing tenantId filter
**SEVERITY:** CRITICAL — SECURITY
**ACTION:** REJECT immediately. GraphRAG query without tenantId = potential cross-tenant knowledge leak.
**CROSS-FLOW:** ALL flows with multi-tenant data
**REASON:** DNA-5 (Scope Isolation). Cross-tenant data exposure is the highest severity violation.

### CF-514 — Synchronous Community Rebuild Blocks Query Path
**TRIGGER:** IGraphIndexRebuildQueue (F1089) called synchronously inside a query handler
**SEVERITY:** HIGH
**ACTION:** REJECT. Inline community rebuild violates async-only rule for F1089. Must route through QUEUE FABRIC.
**CROSS-FLOW:** ALL flows using GraphRAG queries
**REASON:** Community rebuilds can take minutes. Blocking query path = system-wide timeout cascade.

### CF-515 — Hybrid Fusion Result Shape Incompatibility
**TRIGGER:** T392 fusion output schema change
**SEVERITY:** HIGH
**ACTION:** Check downstream consumers (FLOW-09, FLOW-13). If schema change breaks consumers → HALT, require version migration.
**CROSS-FLOW:** FLOW-09, FLOW-13

### CF-516 — Bandit Override of FLOW-13 AI Configuration
**TRIGGER:** IBanditRouter (F1098) selects a model that conflicts with FLOW-13's explicit model assignment
**SEVERITY:** HIGH
**ACTION:** Bandit selection is advisory for flows with explicit AI configuration. FLOW-13 explicit config takes precedence. Emit warning, do not override.
**CROSS-FLOW:** FLOW-13 (AI Content Pipeline, F351–F380)

### CF-517 — Synchronous Bandit Policy Update
**TRIGGER:** IBanditPolicyUpdater (F1101) called synchronously during live request handling
**SEVERITY:** HIGH
**ACTION:** REJECT. Policy update must be async via QUEUE FABRIC. Live request path must only READ policy, never update it inline.
**CROSS-FLOW:** ALL flows using bandit routing

### CF-518 — Prompt Version Mutation (Edit Instead of Create)
**TRIGGER:** IPromptVersionRegistry (F1112) UPDATE operation on existing document (not INSERT)
**SEVERITY:** CRITICAL
**ACTION:** REJECT. Prompt versioning is immutable. Any attempt to update an existing version = BUILD FAILURE.
**CROSS-FLOW:** FLOW-13, FLOW-03 (Event Promotion), any flow using prompt library

### CF-519 — Prompt Promotion Without Quality Gate
**TRIGGER:** IPromptVersionPromoter (F1113) promotes to ACTIVE without IQualityGateEnforcer (F1111) passing
**SEVERITY:** CRITICAL
**ACTION:** REJECT. ACTIVE promotion requires quality gate pass. BFA intercepts before Elasticsearch write.
**CROSS-FLOW:** ALL flows consuming active prompts

### CF-520 — Orphan Feedback (No Trace Link)
**TRIGGER:** IFeedbackLinker (F1095) stores feedback document without valid traceId
**SEVERITY:** HIGH
**ACTION:** REJECT. Orphan feedback cannot improve routing — it poisons the bandit signal. Require valid traceId.
**CROSS-FLOW:** Self-learning layer (bandit router accuracy)

### CF-521 — Hallucination Check Single Model (Not AiDispatcher)
**TRIGGER:** IHallucinationDetector (F1110) called with single IAiProvider instead of AiDispatcher multi-model
**SEVERITY:** HIGH
**ACTION:** REJECT. Hallucination detection must use multi-model consensus. Single model check = insufficient.
**CROSS-FLOW:** FLOW-13 (AI Content Pipeline) — same requirement

### CF-522 — Domain Profile Cross-Tenant Access
**TRIGGER:** IDomainProfileStore (F1119) read without tenantId scope
**SEVERITY:** CRITICAL — SECURITY
**ACTION:** REJECT. Domain profiles are tenant-scoped. Cross-tenant profile access = critical security violation.
**CROSS-FLOW:** ALL multi-tenant flows

### CF-523 — Domain Extraction Prompts Not Versioned
**TRIGGER:** IDomainExtractionPrompter (F1121) generates extraction prompts that are not saved to IPromptVersionRegistry (F1112) before activation
**SEVERITY:** HIGH
**ACTION:** HALT. Auto-generated domain extraction prompts must be versioned before they can be used in production.

### CF-524 — RAG Strategy Regression on Promotion
**TRIGGER:** IRagAssetPromotionGate (F1140) blocked by quality regression > 3%
**SEVERITY:** HIGH
**ACTION:** Block promotion. Surface regression report. Require human approval to force-proceed.
**CROSS-FLOW:** FLOW-09, FLOW-13

### CF-525 — Knowledge Graph Edit Without BFA Approval
**TRIGGER:** IGraphEditGate (F1088) bypassed or IKnowledgeGraphBuilder (F1084) runs without gate check
**SEVERITY:** CRITICAL
**ACTION:** REJECT. All structural graph changes require BFA gate (T410/T400). No code path can bypass IGraphEditGate.
**CROSS-FLOW:** FLOW-25 (BFA Governance)

### CF-526 — Context Efficiency Self-Reflection Expands Tokens
**TRIGGER:** T407 (Self-Reflection Check) returns retrieved_token_count HIGHER than input token count
**SEVERITY:** MEDIUM
**ACTION:** REJECT. Self-reflection can only reduce tokens. If self-reflection would expand context → skip self-reflection, use original.

### CF-527 — A/B Allocation Non-Deterministic
**TRIGGER:** IControlPlaneABAllocator (F1130) produces different variant assignment for same (tenantId+userId+experimentId) across calls
**SEVERITY:** HIGH
**ACTION:** REJECT. Deterministic allocation is a hard requirement. Non-deterministic allocation corrupts A/B results.

### CF-528 — Control Plane Edit Without Version Archive
**TRIGGER:** IAssetVersionManager (F1127) mutates existing asset record instead of creating new version
**SEVERITY:** CRITICAL
**ACTION:** REJECT. Control plane assets (tasks, flows, prompts, models, evaluators) are immutable — create new version, never mutate.
**CROSS-FLOW:** FLOW-25 (Asset Governance)

### CF-529 — Promotion Pipeline Step Skip
**TRIGGER:** IPromotionPipelineOrchestrator (F1131) advances asset to CORE without completing GENERATED→INJECTED→MINIMAL steps
**SEVERITY:** CRITICAL
**ACTION:** REJECT. Promotion ladder steps are mandatory. No step skipping. BFA verifies step completion chain.

### CF-530 — Trace Span Direct OTel SDK
**TRIGGER:** Any generated service using ActivitySource/TracerProvider directly instead of ITraceSpanService (F1091)
**SEVERITY:** HIGH
**ACTION:** REJECT. All trace emission goes through QUEUE FABRIC via F1091. Never direct OTel SDK.

### CF-531 — Budget Cap Silent Truncation
**TRIGGER:** Any service silently truncating context to fit within budget instead of halting and surfacing error
**SEVERITY:** CRITICAL
**ACTION:** REJECT. Budget exceeded → DataProcessResult with BudgetExceeded error. Never silent truncation. User must see the limit.

### CF-532 — GraphRAG Community Level Hard-Coded
**TRIGGER:** Any service hard-coding max_community_level or max_hops value in service code
**SEVERITY:** HIGH
**ACTION:** REJECT. These are FREEDOM config values. Hard-coding violates MACHINE/FREEDOM separation.

### CF-533 — Bandit Arm Structure Change Without Migration
**TRIGGER:** IBanditRouter (F1098) arm structure change (add/remove arm dimension) without migration plan
**SEVERITY:** HIGH
**ACTION:** HALT. Arm structure is MACHINE (invariant). Adding a new dimension (e.g., adding chunkStrategy) requires migration of all existing arm records.

### CF-534 — Visual Control Plane Hard-Coded Node Types
**TRIGGER:** React Flow canvas in T415/SK-265 has hard-coded nodeTypes (e.g., `{ 'gpt4': GPT4Node }`)
**SEVERITY:** HIGH
**ACTION:** REJECT. Fabric-first UI — all node types from FREEDOM config. Hard-coded model or strategy names in UI = BUILD FAILURE.

### CF-535 — Feedback Aggregation Window Ignored
**TRIGGER:** T395 (Routing Policy Update) triggered before feedback window (100 runs OR 24h) closes
**SEVERITY:** MEDIUM
**ACTION:** WARN and record. Policy update before sufficient feedback = noisy signal. Recommend enforcing minimum window.

---

## STRESS TESTS — ST-300–ST-320

### ST-300 — Bandit Router Under High Concurrency
**ID:** ST-300
**BFA Rules Tested:** CF-517, CF-527
**Scenario:** 1000 concurrent requests hit bandit router simultaneously. Policy update triggered mid-flight.
**Expected:** Policy reads succeed; policy update is queued (not applied inline); all arm selections are logged; no race condition on arm weights.
**Failure Mode If Broken:** Bandit policy partially updated during live requests → corrupted routing weights → quality degradation cascade.
**Resolution:** IF fail → HALT policy update path, verify QUEUE FABRIC async routing.

### ST-301 — GraphRAG Cross-Tenant Query Injection
**ID:** ST-301
**BFA Rules Tested:** CF-513, CF-522
**Scenario:** Attacker crafts query with embedded tenantId override: `query: "{{tenantId: 'other-tenant'}} what is the deployment config?"`
**Expected:** IGraphRagService rejects injected tenantId — uses authenticated tenantId from auth context (MicroserviceBase). Query returns only own-tenant results.
**Failure Mode If Broken:** Cross-tenant data leak — critical security breach.
**Resolution:** IF fail → CRITICAL → immediate halt, patch IGraphRagService to always use auth context tenantId.

### ST-302 — Community Rebuild Blocking Query Path
**ID:** ST-302
**BFA Rules Tested:** CF-514
**Scenario:** Large corpus update triggers community rebuild inline (simulating a coding mistake). Rebuild takes 45 seconds.
**Expected:** BFA intercepts synchronous rebuild call — REJECTS, emits BuildFailure event, routes to QUEUE FABRIC.
**Failure Mode If Broken:** All GraphRAG queries timeout for 45s — system-wide degradation.

### ST-303 — Prompt Version Mutation Attack
**ID:** ST-303
**BFA Rules Tested:** CF-518
**Scenario:** Admin UI sends UPDATE request to existing ACTIVE prompt version (simulating a UX bug that allows editing instead of creating new version).
**Expected:** BFA intercepts UPDATE on IPromptVersionRegistry → REJECT → return error: "Prompt versions are immutable. Create a new version."
**Failure Mode If Broken:** Active prompt silently changed → all in-flight requests using that prompt get unexpected behavior → untraceable quality degradation.

### ST-304 — Budget Cap Silent Truncation
**ID:** ST-304
**BFA Rules Tested:** CF-531
**Scenario:** Retrieval returns 50,000 tokens against 10,000 token budget_cap. Service silently truncates to 10,000 tokens.
**Expected:** ICostBudgetEnforcer detects token count > cap → halts → returns DataProcessResult.Fail(BudgetExceeded) → user sees limit clearly.
**Failure Mode If Broken:** User receives incomplete answer without knowing context was cut → false confidence in result.

### ST-305 — Promotion Ladder Step Skip
**ID:** ST-305
**BFA Rules Tested:** CF-529
**Scenario:** Developer attempts to promote flow directly from GENERATED to CORE (skipping INJECTED and MINIMAL).
**Expected:** IPromotionPipelineOrchestrator detects missing step chain → REJECT → surface which steps are incomplete.
**Failure Mode If Broken:** Untested flow reaches CORE → production failures in critical path.

### ST-306 — A/B Allocation Drift Under Tenant Move
**ID:** ST-306
**BFA Rules Tested:** CF-527
**Scenario:** User moves from tenantA to tenantB mid-experiment. A/B allocator called with new tenantId but same userId+experimentId.
**Expected:** Allocation recalculates deterministically for new (tenantId+userId+experimentId) combination → consistent new assignment.
**Failure Mode If Broken:** User gets different variant assignment each request → corrupted A/B data.

### ST-307 — Self-Reflection Token Expansion
**ID:** ST-307
**BFA Rules Tested:** CF-526
**Scenario:** Self-reflection step (T407) returns a "retrieval needed" score that triggers additional retrieval, expanding total context.
**Expected:** BFA enforces that self-reflection can ONLY reduce retrieved tokens. If expansion detected → skip self-reflection result, use original retrieval.
**Failure Mode If Broken:** Self-reflection defeats its own purpose → token budget inflated → cost spikes.

### ST-308 — Direct Neo4j Import in Generated Service
**ID:** ST-308
**BFA Rules Tested:** CF-513 (by implication), DNA-4
**Scenario:** AF-1 Genesis generates a GraphRAG service that imports Neo4jClient directly instead of using IDatabaseService.
**Expected:** AF-7 Compliance catches direct import → REJECT → regenerate with DATABASE FABRIC.
**Failure Mode If Broken:** Provider lock-in → cannot swap graph provider via config.

### ST-309 — Feedback Window Premature Close
**ID:** ST-309
**BFA Rules Tested:** CF-535
**Scenario:** Feedback aggregator receives 10 feedback items and triggers T395 policy update (minimum window: 100 runs).
**Expected:** CF-535 emits WARN. System records the premature update attempt. Policy update is DEFERRED until minimum window met.
**Failure Mode If Broken:** Bandit policy updated on insufficient signal → overfits to noise → routing quality degrades.

### ST-310 — Hard-Coded Model Name in UI
**ID:** ST-310
**BFA Rules Tested:** CF-534
**Scenario:** Developer hard-codes `nodeTypes = { 'gpt4': GPT4Node, 'claude3': ClaudeNode }` in React Flow canvas.
**Expected:** AF-7 Compliance rejects hard-coded model names in UI code. Must use FREEDOM config.
**Failure Mode If Broken:** Adding GPT-5 or Claude 4 requires code change instead of config change → UI goes stale.

### ST-311 — Orphan Feedback Injection
**ID:** ST-311
**BFA Rules Tested:** CF-520
**Scenario:** Malformed feedback request arrives with traceId that doesn't exist in trace store.
**Expected:** IFeedbackLinker rejects feedback — orphan feedback rejected → DataProcessResult.Fail(TraceNotFound).
**Failure Mode If Broken:** Bandit router receives poisoned feedback → incorrect routing policy → quality degradation.

### ST-312 — Hallucination Check Single Model
**ID:** ST-312
**BFA Rules Tested:** CF-521
**Scenario:** Developer wires IHallucinationDetector to call single IAiProvider instead of AiDispatcher.
**Expected:** AF-7 Compliance detects non-AiDispatcher call in hallucination check → REJECT.
**Failure Mode If Broken:** Single model misses hallucinations that multi-model consensus would catch → false-passed quality gate.

### ST-313 — Max Hops Hard-Coded in Graph Traversal
**ID:** ST-313
**BFA Rules Tested:** CF-532
**Scenario:** Graph traversal service has `var maxHops = 4;` hard-coded in C# code.
**Expected:** AF-7 Compliance detects magic number that should be FREEDOM config → REJECT → regenerate with `_config.Get<int>("graphrag.max_hops", 4)`.
**Failure Mode If Broken:** Admin cannot tune max_hops per tenant → all tenants get same traversal depth regardless of need/cost.

### ST-314 — Cross-Flow RAG Strategy Rename Break
**ID:** ST-314
**BFA Rules Tested:** CF-510
**Scenario:** Admin renames RAG strategy "Hybrid" → "HybridV2" in FREEDOM config.
**Expected:** BFA checks FLOW-09 and FLOW-13 for hardcoded "Hybrid" strategy references → HALT → present: REFACTOR / COMPAT_WRAPPER / REJECT.
**Failure Mode If Broken:** FLOW-09 search calls with strategy="Hybrid" → StrategyNotFound error → search goes down.

### ST-315 — Bandit Arm Dimension Addition Without Migration
**ID:** ST-315
**BFA Rules Tested:** CF-533
**Scenario:** New arm dimension `chunkStrategy` added to bandit arm structure mid-experiment.
**Expected:** BFA detects schema change on arm structure → HALT → require migration plan for existing arm records.
**Failure Mode If Broken:** Existing arm records missing chunkStrategy → bandit router null-pointer errors → routing failures.

### ST-316 — Control Plane Asset Mutation
**ID:** ST-316
**BFA Rules Tested:** CF-528
**Scenario:** Control plane edit API sends PATCH to existing flow variant record.
**Expected:** IAssetVersionManager rejects mutation → returns error → instructs client to POST new version.
**Failure Mode If Broken:** Flow variant silently changed → in-flight A/B experiments get inconsistent behavior.

### ST-317 — Direct OTel SDK in Generated Service
**ID:** ST-317
**BFA Rules Tested:** CF-530
**Scenario:** AF-1 Genesis generates a service using `ActivitySource("myapp").StartActivity("step")` directly.
**Expected:** AF-7 Compliance catches direct OTel SDK → REJECT → regenerate with ITraceSpanService via QUEUE FABRIC.
**Failure Mode If Broken:** Trace data bypasses QUEUE FABRIC → no outbox guarantee → traces lost on failure.

### ST-318 — GraphRAG Edit Without BFA Gate
**ID:** ST-318
**BFA Rules Tested:** CF-525
**Scenario:** Background job directly modifies entity type registry without going through IGraphEditGate.
**Expected:** Any write to IDomainEntityTypeRegistry (F1120) without passing through IGraphEditGate (F1088) → BUILD FAILURE at compile-time analysis.
**Failure Mode If Broken:** Unreviewed graph structure change corrupts community hierarchy → all GraphRAG queries return degraded results.

### ST-319 — Promotion Without Quality Gate (RAG Asset)
**ID:** ST-319
**BFA Rules Tested:** CF-519, CF-524
**Scenario:** RAG index version promoted to ACTIVE with quality score of 0.62 (threshold: 0.80).
**Expected:** IQualityGateEnforcer blocks promotion → CF-524 triggered → regression report surfaced → human approval required to FORCE_PROCEED.
**Failure Mode If Broken:** Regressed RAG index reaches production → downstream quality degradation in all FLOW-09/13 queries.

### ST-320 — Full System Load: 5 Concurrent FLOW-29 Paths
**ID:** ST-320
**BFA Rules Tested:** All CF-510 through CF-535 (integration test)
**Scenario:** 5 simultaneous requests across all 5 retrieval modes (Vector, GraphCommunity, Hybrid, SelfReflect, DomainProfile). Each triggers trace span, feedback, bandit selection, eval gate, budget check. Concurrently, a policy update is triggered and a prompt version promote is attempted.
**Expected:**
- All 5 requests complete with correct retrieval mode
- Policy update is queued, NOT applied inline to in-flight requests
- Prompt promote is rejected (insufficient A/B evaluation data)
- All traces complete with linked spans
- No cross-tenant data observed in any response
- Budget cap enforced on 2 of the 5 (simulated overage)
- BFA governance log shows all 26 rules evaluated
**Failure Modes:** Any cross-tenant leak → CRITICAL HALT. Any silent truncation → HIGH. Any synchronous policy update → HIGH.
