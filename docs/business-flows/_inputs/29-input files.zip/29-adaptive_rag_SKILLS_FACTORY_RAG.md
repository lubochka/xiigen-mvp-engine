# 29-adaptive rag SKILLS_FACTORY_RAG
# XIIGen FLOW-29 — Adaptive RAG Deep Research Engine
# Skills: SK-251–SK-265 | AF-4 RAG Search Index

---

## OVERVIEW

15 new skills extend the existing 250-skill library. AF-4 (RAG Task Context) indexes these skills so every AF-1 Genesis code generation call can retrieve relevant patterns.

All skills follow the standard pattern:
- SKILL.md with YAML frontmatter
- Core implementation guide (fabric-first, no direct imports)
- Multi-language alternatives (Node.js, Python, Rust, PHP)
- AI agent config entries for Cursor / Claude Code / Copilot / Cline

---

## SK-251 — Adaptive RAG Router Skill

**ID:** SK-251
**Domain:** Retrieval Orchestration
**Promoted From:** FLOW-29
**Ladder Status:** GENERATED → MINIMAL (proven in FLOW-29)

**Purpose:** Guide AF-1 Genesis in generating the adaptive routing service that classifies query intent and selects retrieval mode.

**Core Pattern:**
```csharp
// ✅ CORRECT — through fabric interfaces
public class AdaptiveRagRouterService : MicroserviceBase
{
    private readonly IAdaptiveRagRouter _router;  // F1075 — RAG FABRIC
    private readonly ITaskClassifier _classifier;  // F1076 — AI ENGINE FABRIC

    public async Task<DataProcessResult<RouteDecision>> RouteAsync(
        string query, string tenantId, BudgetMode budget)
    {
        var intentResult = await _classifier.ClassifyAsync(
            ParseDocument(new { query, tenantId }));
        if (!intentResult.Success) return DataProcessResult<RouteDecision>.Fail(intentResult.Error);

        var modeResult = await _router.SelectModeAsync(
            ParseDocument(new { intent = intentResult.Data, budget, tenantId }));

        await _auditLogger.EmitAsync(ParseDocument(new { 
            mode = modeResult.Data, confidence = intentResult.Data.Confidence, tenantId }));

        return modeResult;
    }
}

// ❌ WRONG
var neo4j = new Neo4jClient(...);    // never direct provider
var mode = "Vector";                  // never hard-coded mode
```

**AF-4 Retrieval Tags:** `routing, retrieval-mode-selection, task-classification, fabric-first`

**Multi-Language Alternatives:**
- Node.js: `AdaptiveRagRouter.ts` — extends MicroserviceBase JS port, same interface pattern
- Python: `adaptive_rag_router.py` — uses IRagService ABC, never LangChain direct import
- Rust: `adaptive_rag_router.rs` — trait-based IRagService, async/await

---

## SK-252 — GraphRAG Indexer Skill

**ID:** SK-252
**Domain:** Knowledge Graph Construction
**Ladder Status:** GENERATED

**Purpose:** Guide AF-1 in generating the GraphRAG indexing service — entity/relation extraction, community partition, community summary generation. ALL through fabric interfaces.

**Core Pattern:**
```csharp
public class GraphRagIndexerService : MicroserviceBase
{
    private readonly IKnowledgeGraphBuilder _builder; // F1084 — AI ENGINE FABRIC
    private readonly ICommunityHierarchyManager _hierarchy; // F1085 — DATABASE FABRIC
    private readonly IGraphIndexRebuildQueue _rebuildQueue; // F1089 — QUEUE FABRIC

    public async Task<DataProcessResult<bool>> TriggerRebuildAsync(
        string domainProfileId, string tenantId)
    {
        // NEVER inline rebuild — always queue
        var queueResult = await _rebuildQueue.EnqueueAsync(
            ParseDocument(new { domainProfileId, tenantId, requestedAt = DateTime.UtcNow }));
        return queueResult;
    }
}
// Community rebuild is ASYNC — never blocks query path
```

**Iron Rule Reminder:** `IGraphIndexRebuildQueue` → async queue only. Inline rebuild = BUILD FAILURE.

**AF-4 Tags:** `graphrag, knowledge-graph, community-hierarchy, async-rebuild, fabric-first`

---

## SK-253 — Hybrid Retrieval Fusion Skill

**ID:** SK-253
**Domain:** Retrieval Post-Processing
**Ladder Status:** GENERATED

**Purpose:** Fuse vector results + GraphRAG community context; unified reranking; context budget enforcement before returning to generator.

**Core Pattern:**
```csharp
public class HybridFusionService : MicroserviceBase
{
    public async Task<DataProcessResult<Dictionary<string,object>>> FuseAsync(
        List<Dictionary<string,object>> vectorPassages,
        List<Dictionary<string,object>> graphContext,
        string tenantId, decimal budgetCap)
    {
        var fusionRatio = _config.Get<decimal>("rag.fusion.vector_weight", 0.6m);
        var merged = MergeWithRatio(vectorPassages, graphContext, fusionRatio);
        var reranked = await _reranker.RerankAsync(ParseDocument(new { passages = merged, tenantId }));

        var tokenCount = reranked.Data.Sum(p => (int)p["token_count"]);
        if (tokenCount > budgetCap)
            return await _pruner.PruneAsync(ParseDocument(new { passages = reranked.Data, budgetCap }));

        return DataProcessResult<Dictionary<string,object>>.Ok(
            ParseDocument(new { passages = reranked.Data, fusionRatio, tokenCount }));
    }
}
// fusionRatio MUST come from config — never hard-coded
```

**AF-4 Tags:** `hybrid-retrieval, fusion, reranking, context-budget, fabric-first`

---

## SK-254 — Contextual Bandit Router Skill

**ID:** SK-254
**Domain:** Self-Learning Routing
**Ladder Status:** GENERATED

**Purpose:** Implement the contextual bandit arm selection — (modelId, promptVersionId, flowVariantId) — with epsilon-greedy or UCB exploration. Policy updates are always async.

**Core Pattern:**
```csharp
public class BanditRouterService : MicroserviceBase
{
    public async Task<DataProcessResult<BanditArm>> SelectArmAsync(
        Dictionary<string,object> context, string tenantId)
    {
        var policy = await _policyReader.GetAsync(
            BuildSearchFilter(new { tenantId }));
        var budgetMode = await _budgetReader.GetModeAsync(tenantId);

        // Exploration vs exploitation
        var explorationRate = _config.Get<double>("bandit.exploration_rate", 0.1);
        var arm = Random.NextDouble() < explorationRate
            ? SelectRandomArm(policy.Data.Arms)
            : SelectBestArm(policy.Data.Arms, budgetMode);

        await _auditLog.EmitAsync(
            ParseDocument(new { arm, tenantId, budgetMode, explorationRate }));

        return DataProcessResult<BanditArm>.Ok(arm);
    }

    // Policy update — ALWAYS async
    public async Task<DataProcessResult<bool>> QueuePolicyUpdateAsync(
        Dictionary<string,object> feedbackBatch, string tenantId)
    {
        return await _policyUpdater.EnqueueAsync(
            ParseDocument(new { feedbackBatch, tenantId, queuedAt = DateTime.UtcNow }));
    }
}
```

**AF-4 Tags:** `bandit-routing, contextual-bandit, model-selection, self-learning, async-policy-update`

---

## SK-255 — Trace Span Capture Skill

**ID:** SK-255
**Domain:** Observability
**Ladder Status:** GENERATED

**Purpose:** Wrap every step with OTel-compatible span emission via QUEUE FABRIC. Never direct OTel SDK. Propagate traceId across all child spans.

**Core Pattern:**
```csharp
public class TraceSpanService : MicroserviceBase, ITraceSpanService
{
    public async Task<DataProcessResult<string>> StartSpanAsync(
        string spanName, string traceId, string parentSpanId, string tenantId)
    {
        var spanId = Guid.NewGuid().ToString();
        await _queue.EnqueueAsync("trace-spans",
            ParseDocument(new {
                traceId, spanId, parentSpanId, spanName, tenantId,
                startedAt = DateTime.UtcNow, status = "OPEN"
            }));
        return DataProcessResult<string>.Ok(spanId);
    }

    public async Task<DataProcessResult<bool>> EndSpanAsync(
        string traceId, string spanId, Dictionary<string,object> metrics)
    {
        // Outbox pattern — persist before acknowledge
        var stored = await _db.StoreDocumentAsync(
            ParseDocument(new { traceId, spanId, metrics, endedAt = DateTime.UtcNow }));
        if (!stored.Success) return DataProcessResult<bool>.Fail(stored.Error);

        await _queue.AcknowledgeAsync(spanId);
        return DataProcessResult<bool>.Ok(true);
    }
}
// NEVER: new ActivitySource("...").StartActivity() — always through QUEUE FABRIC
```

**AF-4 Tags:** `observability, trace, opentelemetry, queue-fabric, outbox, idempotency`

---

## SK-256 — User Feedback Ingest Skill

**ID:** SK-256
**Domain:** Self-Learning
**Ladder Status:** GENERATED

**Purpose:** Ingest user feedback linked to exact (traceId, runId, modelId, promptVersionId, retrievalMode). Feed bandit router. Idempotent.

**Core Pattern:**
```csharp
public async Task<DataProcessResult<bool>> IngestAsync(
    string traceId, string runId, int rating, string correctionText,
    string userId, string tenantId)
{
    var idempotencyKey = $"{userId}:{runId}:{traceId}";
    var existing = await _db.SearchDocumentsAsync(
        BuildSearchFilter(new { idempotencyKey, tenantId }));
    if (existing.Data?.Any() == true)
        return DataProcessResult<bool>.Ok(true); // idempotent

    var feedback = ParseDocument(new {
        traceId, runId, rating, correctionText, userId, tenantId,
        idempotencyKey, ingestedAt = DateTime.UtcNow });

    await _feedbackLinker.LinkAsync(feedback);
    await _banditStore.RecordFeedbackAsync(feedback);
    await _aggregator.AddToWindowAsync(feedback);
    return DataProcessResult<bool>.Ok(true);
}
```

**AF-4 Tags:** `feedback, self-learning, trace-linkage, idempotency, bandit-feedback`

---

## SK-257 — Eval Quality Arbiter Skill

**ID:** SK-257
**Domain:** Quality Control
**Ladder Status:** GENERATED

**Purpose:** Per-run quality evaluation — faithfulness check, context coverage, hallucination detection (multi-model consensus), quality rubric validation.

**Core Pattern:**
```csharp
public async Task<DataProcessResult<EvalReport>> EvaluateAsync(
    string answer, List<Dictionary<string,object>> retrievedPassages,
    string tenantId)
{
    var faithfulness = await _faithfulnessChecker.CheckAsync(
        ParseDocument(new { answer, passages = retrievedPassages, tenantId }));

    var hallucinationCheck = await _hallucinationDetector.CheckAsync(
        ParseDocument(new { answer, tenantId })); // multi-model via AiDispatcher

    var rubric = await _rubricStore.GetAsync(
        BuildSearchFilter(new { tenantId })); // tenant-scoped rubric

    var report = ParseDocument(new {
        faithfulness_score = faithfulness.Data,
        hallucination_detected = hallucinationCheck.Data.Detected,
        consensus_models = hallucinationCheck.Data.Models,
        rubric_applied = rubric.Data.Id,
        passed = faithfulness.Data >= 0.8m && !hallucinationCheck.Data.Detected
    });

    await _publisher.PublishAsync(ParseDocument(new { report, tenantId }));
    return DataProcessResult<EvalReport>.Ok(MapReport(report));
}
// Hallucination: ALWAYS AiDispatcher multi-model — never single model
```

**AF-4 Tags:** `eval, quality-gate, hallucination-detection, faithfulness, multi-model-consensus`

---

## SK-258 — Prompt Version Registry Skill

**ID:** SK-258
**Domain:** Prompt Governance
**Ladder Status:** GENERATED

**Purpose:** Immutable prompt versioning — create, promote, rollback. Never edit existing version document. Full promotion ladder with quality gate enforcement.

**Core Pattern:**
```csharp
public async Task<DataProcessResult<string>> CreateVersionAsync(
    string promptContent, string domain, string taskType,
    string[] modelAffinity, string tenantId)
{
    var versionId = Guid.NewGuid().ToString();
    var doc = ParseDocument(new {
        versionId, promptContent, domain, taskType, modelAffinity,
        tenantId, status = "DRAFT", createdAt = DateTime.UtcNow,
        // NEVER update this document — create new version for changes
    });
    return await _db.StoreDocumentAsync(doc);
}

public async Task<DataProcessResult<bool>> PromoteAsync(
    string versionId, string targetStatus, string tenantId)
{
    // Archive current ACTIVE version first
    var current = await GetActiveVersionAsync(tenantId);
    if (current.Success)
        await _db.StoreDocumentAsync(
            ParseDocument(new { current.Data.versionId, status = "ARCHIVED" }));

    // Create promotion event (not inline mutation)
    await _promoter.EmitAsync(ParseDocument(new { versionId, targetStatus, tenantId }));
    return DataProcessResult<bool>.Ok(true);
}
```

**AF-4 Tags:** `prompt-versioning, immutable, promotion-ladder, rollback, governance`

---

## SK-259 — Domain Profile Compiler Skill

**ID:** SK-259
**Domain:** Knowledge Compiler
**Ladder Status:** GENERATED

**Purpose:** Compile domain knowledge profiles (entity types, relation types, extraction prompts) — trigger async graph rebuild via QUEUE FABRIC.

**AF-4 Tags:** `domain-compiler, graphrag-profile, entity-types, async-rebuild, tenant-scoped`

**Core Pattern (abbreviated):**
```csharp
// Profile is always tenant-scoped
var profile = ParseDocument(new { 
    tenantId, domainId, entityTypes, relationTypes, 
    extractionPromptVersionId, summaryStrategy, compiledAt = DateTime.UtcNow });
await _profileStore.StoreDocumentAsync(profile); // DATABASE FABRIC
await _rebuildPublisher.EnqueueAsync(profile);   // QUEUE FABRIC — async rebuild
```

---

## SK-260 — RAG Asset Version Manager Skill

**ID:** SK-260
**Domain:** Asset Governance
**Ladder Status:** GENERATED

**Purpose:** Version all RAG artifacts (embeddings, index configs, chunk params, strategies). Safe rollback via pointer swap. Block promotion on regression.

**AF-4 Tags:** `rag-versioning, asset-governance, rollback, pointer-swap, regression-check`

---

## SK-261 — Context Efficiency Monitor Skill

**ID:** SK-261
**Domain:** Cost Optimization
**Ladder Status:** GENERATED

**Purpose:** Track retrieved_token_count per step. Enforce budget_cap. Emit efficiency score. Feed penalty to bandit router.

**Core insight:** Higher accuracy can coincide with fewer retrieved tokens. Monitor and enforce.

**AF-4 Tags:** `context-efficiency, token-budget, cost-optimization, noise-detection`

---

## SK-262 — Reranker Service Skill

**ID:** SK-262
**Domain:** Retrieval Post-Processing
**Ladder Status:** GENERATED

**Purpose:** Rerank retrieved passages via AI ENGINE FABRIC (rerank model). Exclude passages below relevance_threshold. Always runs before generator receives context.

**AF-4 Tags:** `reranking, passage-relevance, noise-reduction, ai-engine-fabric`

---

## SK-263 — A/B Test Allocator Skill

**ID:** SK-263
**Domain:** Experimentation
**Ladder Status:** GENERATED

**Purpose:** Deterministic allocation of (tenantId + userId + experimentId) to flow variant. No shared mutable state between branches. Results via QUEUE FABRIC.

**AF-4 Tags:** `ab-testing, deterministic-allocation, flow-variants, experimentation`

---

## SK-264 — Routing Policy Updater Skill

**ID:** SK-264
**Domain:** Self-Learning
**Ladder Status:** GENERATED

**Purpose:** Update bandit routing policy weights from aggregated feedback window. ALWAYS async. Archive previous policy before activating new one.

**AF-4 Tags:** `policy-update, bandit-weights, async-learning, policy-versioning`

---

## SK-265 — Visual Control Plane Canvas Skill

**ID:** SK-265
**Domain:** UI — Fabric-First
**Ladder Status:** GENERATED

**Purpose:** React Flow canvas for the self-learning control plane. Renders tasks→subtasks→flows→prompts→models→evaluators as editable graph. ZERO platform-specific values hardcoded. All node types, model names, strategy names from FREEDOM config.

**Core Pattern:**
```tsx
// ✅ CORRECT — fabric-first React Flow canvas
const { data: graphConfig } = useFreedomConfig('control-plane.graph');
const nodeTypes = graphConfig.nodeTypes; // from config, not hard-coded

const ControlPlaneCanvas = () => (
  <ReactFlow
    nodeTypes={nodeTypes}  // from FREEDOM config
    nodes={nodes.map(n => ({ ...n, type: n.nodeType }))} // never hardcode type
    onNodeChange={async (change) => {
      await routerService.CreateAsync(factoryCtx); // F1126 via CreateAsync
      await graphService.EditAsync(change, tenantId); // T410 gate
    }}
  />
);

// ❌ WRONG
const nodeTypes = { 'gpt4': GPT4Node, 'claude': ClaudeNode }; // never hardcode models
```

**AF-4 Tags:** `visual-ui, react-flow, fabric-first, control-plane, freedom-config, zero-hardcode`

---

## AF-4 RAG SEARCH INDEX UPDATE (FLOW-29)

New skills added to IRagService search index with tags:

```json
{
  "flow": "FLOW-29",
  "newSkills": [
    { "id": "SK-251", "tags": ["routing","retrieval-mode","adaptive","rag"] },
    { "id": "SK-252", "tags": ["graphrag","knowledge-graph","community","indexing"] },
    { "id": "SK-253", "tags": ["hybrid","fusion","reranking","context-budget"] },
    { "id": "SK-254", "tags": ["bandit","routing","self-learning","model-selection"] },
    { "id": "SK-255", "tags": ["trace","observability","opentelemetry","queue"] },
    { "id": "SK-256", "tags": ["feedback","ingest","trace-link","idempotency"] },
    { "id": "SK-257", "tags": ["eval","quality","hallucination","faithfulness","multi-model"] },
    { "id": "SK-258", "tags": ["prompt-versioning","immutable","promotion","rollback"] },
    { "id": "SK-259", "tags": ["domain-compiler","graphrag-profile","entity-types"] },
    { "id": "SK-260", "tags": ["rag-versioning","asset-governance","rollback"] },
    { "id": "SK-261", "tags": ["context-efficiency","token-budget","cost"] },
    { "id": "SK-262", "tags": ["reranking","noise-reduction","relevance"] },
    { "id": "SK-263", "tags": ["ab-test","allocation","experimentation","variants"] },
    { "id": "SK-264", "tags": ["policy-update","bandit","async","learning"] },
    { "id": "SK-265", "tags": ["visual","react-flow","fabric-first","control-plane","ui"] }
  ]
}
```

## SKILL DEPENDENCY MAP (FLOW-29)

```
SK-251 (Router) ──depends──► SK-254 (Bandit) ──depends──► SK-264 (Policy)
SK-252 (GraphRAG) ──depends──► SK-259 (Domain Compiler)
SK-253 (Hybrid) ──depends──► SK-262 (Reranker) ──depends──► SK-261 (Efficiency)
SK-255 (Trace) ──feeds──► SK-256 (Feedback) ──feeds──► SK-264 (Policy)
SK-257 (Eval) ──gates──► SK-258 (Prompt Version Promote)
SK-260 (RAG Version) ──gates──► SK-263 (A/B Test)
SK-265 (UI) ──reads──► SK-251, SK-252, SK-253, SK-254 (all routing skills)
```
