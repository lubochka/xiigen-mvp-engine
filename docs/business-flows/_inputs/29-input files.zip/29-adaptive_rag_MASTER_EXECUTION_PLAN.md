# 29-adaptive rag MASTER_EXECUTION_PLAN
# XIIGen FLOW-29 — Adaptive RAG Deep Research Engine
# Execution: P0–P6 | Duration: 7 phases, each saveable

---

## EXECUTION OVERVIEW

| Phase | Name                              | Artifacts                          | Duration Est. | Save Point           |
|-------|-----------------------------------|------------------------------------|---------------|----------------------|
| P0    | Factory Registration              | F1075–F1146, Families 154–163      | 30 min        | All factories locked |
| P1    | Knowledge & Retrieval Fabrics     | T389–T392, SK-251–253              | 45 min        | Retrieval layer done |
| P2    | Trace + Feedback + Budget         | T393–T397, SK-254–256              | 45 min        | Learning signals done|
| P3    | Eval + Prompt + Domain            | T398–T403, SK-257–259              | 45 min        | Quality layer done   |
| P4    | Asset Versioning + A/B            | T404–T410, SK-260–263              | 45 min        | Governance done      |
| P5    | Self-Learning + Efficiency        | T411–T415, SK-264–265              | 30 min        | All tasks complete   |
| P6    | BFA + Validation + Integration    | CF-510–535, ST-300–320, Templates  | 30 min        | FLOW-29 COMPLETE     |

---

## P0 — Factory Registration (Save Point: All 72 factories declared in registry)

**Objective:** Register all 72 new factory interfaces in the engine's factory registry. No implementation code yet — interfaces only.

**Steps:**
1. Add Families 154–163 to ENGINE_ARCHITECTURE factory registry
2. Register each IExternalServiceFactory<TService> binding:
   - IAdaptiveRagRouter → RagFabricAdapter (resolves to IRagService via AdaptiveBandit strategy)
   - IGraphRagService → DatabaseFabricAdapter (resolves to IDatabaseService — graph provider config)
   - ITraceSpanService → QueueFabricAdapter (resolves to IQueueService — Redis Streams)
   - IBanditRouter → AiFabricAdapter (resolves to IAiProvider — routing model config)
   - [all 72 mappings as documented in ENGINE_ARCHITECTURE]
3. Add factory capability declarations to factory capability matrix
4. Add health check probes for new factory endpoints
5. Update factory registry document checksum

**Validation:** `factory_registry.Validate()` — all 72 factories have:
- Interface declared ✅
- Fabric resolution mapping ✅
- Health check probe ✅
- CreateAsync() registration ✅

**SAVE POINT:** Factory registry locked. Proceed to P1.

---

## P1 — Knowledge & Retrieval Fabrics (Save Point: T389–T392, SK-251–253 complete)

**Objective:** Implement the retrieval layer — adaptive routing, vector retrieval, GraphRAG community query, hybrid fusion. All through fabric interfaces.

### P1.1 — Adaptive Route Gate (T389)
1. AF-1 Genesis: generate AdaptiveRagRouterService extending MicroserviceBase
2. Inject: F1075 (IAdaptiveRagRouter), F1076 (ITaskClassifier), F1077 (IRetrievalModeSelector), F1082 (IRoutingAuditLogger)
3. AF-7 Compliance: verify no direct provider import; all via CreateAsync()
4. AF-9 Judge: routing_confidence_score ≥ 0.7; audit event emitted before return
5. Save SK-251 pattern to skill library

### P1.2 — Vector Retrieval Step (T390)
1. AF-1 Genesis: generate VectorRetrievalService extending MicroserviceBase
2. Inject: F1078 (query rewrite), F1079 (decompose), F1134 (index version), F1143 (reranker), F1141 (efficiency monitor)
3. Key: parallel sub-query execution (IQueryDecomposer splits → parallel calls → merge)
4. AF-9 Judge: reranker applied; retrieved_token_count recorded; no typed Passage models

### P1.3 — GraphRAG Community Query (T391)
1. AF-1 Genesis: generate GraphRagQueryService extending MicroserviceBase
2. Critical: F1089 (IGraphIndexRebuildQueue) is ASYNC only — BFA CF-514 enforced at compile
3. AF-7 Compliance: tenantId on every graph query (DNA-5)
4. AF-9 Judge: community_level_selected; rebuild_not_blocking; tenant_scope verified
5. Save SK-252 pattern

### P1.4 — Hybrid Retrieval Fusion (T392)
1. AF-1 Genesis: generate HybridFusionService
2. fusionRatio from FREEDOM config (never hard-coded)
3. IContextPruner (F1146) runs if total > budget_cap — never silent truncation
4. Save SK-253 pattern

**SAVE POINT:** Retrieval layer (T389–T392, SK-251–253) complete. All patterns in skill library.

---

## P2 — Trace + Feedback + Budget (Save Point: T393–T397, SK-254–256 complete)

**Objective:** Implement the self-learning signals — bandit routing, budget enforcement, trace capture, user feedback ingestion.

### P2.1 — Contextual Bandit Model Select (T393)
1. AF-1 Genesis: generate BanditRouterService extending MicroserviceBase
2. Arm = (modelId, promptVersionId, flowVariantId) — structure is MACHINE (invariant)
3. Exploration rate from FREEDOM config; policy read is synchronous; policy update is async via QUEUE
4. AF-9 Judge: arm declared in trace; budget_mode respected; audit emitted before generation call
5. Save SK-254 pattern

### P2.2 — Budget Enforcement Gate (T394)
1. AF-1 Genesis: generate BudgetEnforcementService
2. Hard rule: if token_count > budget_cap → DataProcessResult.Fail(BudgetExceeded); NEVER truncate silently
3. CF-531 BFA rule active — any silent truncation = BUILD FAILURE on next BFA scan

### P2.3 — Routing Policy Update (T395)
1. AF-1 Genesis: generate PolicyUpdateWorker (background service extending MicroserviceBase)
2. ALWAYS async — triggered by QUEUE FABRIC event from T408 (feedback aggregation window close)
3. Previous policy archived before new version activates

### P2.4 — Trace Span Capture (T396)
1. AF-1 Genesis: generate TraceSpanService
2. OTel-compatible span format, emitted via IQueueService (never direct OTel SDK)
3. Outbox pattern: persist to DATABASE FABRIC before acknowledging span
4. traceId propagated via MicroserviceBase auth context (not per-call parameter)
5. Save SK-255 pattern

### P2.5 — User Feedback Ingest (T397)
1. AF-1 Genesis: generate FeedbackIngestService
2. Idempotency key: (userId + runId + traceId)
3. Links feedback to bandit store, feedback aggregator, AND trace
4. All fields as Dictionary<string,object> — no typed FeedbackModel
5. Save SK-256 pattern

**SAVE POINT:** Learning signals layer (T393–T397, SK-254–256) complete.

---

## P3 — Eval + Prompt + Domain (Save Point: T398–T403, SK-257–259 complete)

**Objective:** Implement the quality + governance layer — evaluation, prompt versioning, domain profiles.

### P3.1 — Eval Quality Gate (T402)
1. AF-1 Genesis: generate EvalQualityGateService
2. Hallucination detection via AiDispatcher (F1110) — multi-model consensus required (CF-521)
3. Quality rubric from DATABASE FABRIC, tenant-scoped (CF-522)
4. Eval result published via QUEUE FABRIC before response returned
5. Save SK-257 pattern

### P3.2 — Prompt Version Promote (T398)
1. AF-1 Genesis: generate PromptVersionRegistryService
2. CREATE new document on promote — never UPDATE existing (CF-518 enforced)
3. Ladder: DRAFT → CANDIDATE → TESTED → ACTIVE → ARCHIVED
4. Rollback = pointer swap to previous ACTIVE, never delete (CF-519)
5. Save SK-258 pattern

### P3.3 — Domain Profile Compile (T399)
1. AF-1 Genesis: generate DomainCompilerService
2. Profile is always tenant-scoped (CF-522)
3. Auto-generated extraction prompts → versioned via F1112 before activation (CF-523)
4. Rebuild triggered async via F1124 (QUEUE FABRIC)
5. Save SK-259 pattern

### P3.4 — Knowledge Graph Edit Gate (T400) + Promotion Pipeline Gate (T403)
1. T400: IGraphEditGate (F1088) — permissions layer check before ANY structural graph change
2. T403: IPromotionPipelineOrchestrator (F1131) — FLOW ENGINE FABRIC — executes promotion steps in order, resumable

**SAVE POINT:** Quality & governance layer (T398–T403, SK-257–259) complete.

---

## P4 — Asset Versioning + A/B + Efficiency (Save Point: T404–T410, SK-260–263 complete)

**Objective:** Implement RAG asset versioning, A/B experimentation, context efficiency enforcement, control plane governance.

### P4.1 — RAG Asset Version Compare (T401)
1. Comparator (F1139) runs on same eval dataset for both versions
2. Block promotion if regression > 3% (F1140)
3. Save SK-260 pattern

### P4.2 — A/B Test Allocation (T404)
1. Deterministic allocation: hash(tenantId + userId + experimentId) → variant index
2. No shared mutable state between variant branches
3. Results via QUEUE FABRIC (CF-527)
4. Save SK-263 pattern

### P4.3 — Context Efficiency Check (T405) + Reranker Step (T406)
1. T405: Monitor token_count → emit efficiency_score → feed penalty to bandit async
2. T406: Reranker always runs before generator sees context; relevance_threshold from FREEDOM
3. Save SK-261, SK-262 patterns

### P4.4 — Self-Reflection Check (T407) + Control Plane Governance (T410)
1. T407: Self-reflection can ONLY reduce tokens — if expansion detected → skip (CF-526)
2. T410: Control plane graph edits require IGraphEditGate + BFA approval (CF-528)

**SAVE POINT:** Asset versioning + experimentation layer (T404–T410, SK-260–263) complete.

---

## P5 — Self-Learning + Communities + Visual UI (Save Point: T411–T415, SK-264–265 complete)

### P5.1 — Community & Domain Tasks (T411–T413)
1. T411 Multi-Hop Traversal: tenantId on every hop; max_hops from FREEDOM config (CF-532)
2. T412 Community Summary: ALWAYS async via IGraphIndexRebuildQueue (CF-514)
3. T413 Domain Index Rebuild: async, metrics tracked via F1125

### P5.2 — Rollback + Policy Tasks (T414–T415)
1. T414 RAG Rollback: pointer swap to previous version — never delete history
2. T415 Visual Control Plane: React Flow canvas reading FREEDOM config for node types (CF-534)

### P5.3 — Learning Loop Tasks (T408–T409)
1. T408 Feedback Aggregation: window = min(100 runs, 24h) from FREEDOM config; triggers T395
2. T409 Improvement Suggestions: graph analytics over failure clusters → suggestions via QUEUE, never auto-applied

### P5.4 — Save SK-264 (Policy Updater) + SK-265 (Visual Canvas)

**SAVE POINT:** All 27 task types complete. All 15 skills complete.

---

## P6 — BFA + Stress Tests + Integration (Save Point: FLOW-29 COMPLETE)

### P6.1 — Register BFA Rules CF-510–CF-535
1. Add 26 rules to BFA conflict detection engine (FLOW-25 engine, F1028–F1074)
2. Priority order: CRITICAL rules first, then HIGH, then MEDIUM
3. CRITICAL rules execute on every code generation pass (AF-7 Compliance + AF-9 Judge)
4. HIGH rules execute on every deployment manifest check
5. MEDIUM rules execute on scheduled BFA scan (configurable interval)

### P6.2 — Run Stress Tests ST-300–ST-320
Execute in priority order:
1. CRITICAL security tests first: ST-301 (cross-tenant), ST-303 (mutation), ST-304 (truncation)
2. HIGH integrity tests: ST-302 (sync rebuild), ST-305 (ladder skip), ST-308 (direct import)
3. MEDIUM signal quality tests: ST-309 (premature window), ST-310 (hard-coded UI)
4. Integration test: ST-320 (full system load — 5 concurrent paths)

Resolution for each test:
- PASS: log to BFA validation report
- FAIL CRITICAL: HALT, patch, rerun
- FAIL HIGH: log, queue fix, continue other tests
- FAIL MEDIUM: warn, continue

### P6.3 — Register Templates 83–89
Add 7 new flow templates to FlowOrchestrator template registry (FLOW ENGINE FABRIC).

### P6.4 — AF Station Mapping Verification
For each of the 27 task types, verify:
- AF-1 (Genesis): generates service extending MicroserviceBase ✅
- AF-4 (RAG): retrieves relevant SK from SK-251–265 ✅
- AF-7 (Compliance): DNA-1 through DNA-9 checked ✅
- AF-9 (Judge): all quality gates validated ✅
- AF-11 (Feedback): generation quality stored ✅

### P6.5 — Backward Compatibility Final Check
- Run FLOW-01 through FLOW-25 task type contracts against new BFA rules
- Confirm: zero existing task types break under CF-510–535
- Confirm: F1–F1074 unchanged in factory registry
- Confirm: IRagService existing 7 strategies still resolve correctly

### P6.6 — Update SESSION_STATE
- Mark FLOW-29 as COMPLETE ✅
- Update all counters to post-FLOW-29 totals
- Set FLOW-30 start numbers

**SAVE POINT: FLOW-29 COMPLETE ✅**

---

## RECOVERY PROTOCOL (any phase)

To recover from a session break at any phase:
1. Open `29-adaptive_rag_SESSION_STATE.md` → check Phase Completion Tracker
2. Open `29-adaptive_rag_ENGINE_ARCHITECTURE.md` → confirm last factory registered (F1075–F1146)
3. Open `29-adaptive_rag_TASK_TYPES_CATALOG.md` → find last T### completed
4. Resume from next incomplete task type or step
5. All artifacts are additive — no rollback needed for incomplete phases

**Critical rule:** If stopped mid-task-type, complete the full ENGINE CONTRACT format before starting next one. Partial task types = BUILD FAILURE when BFA runs.

---

## SELF-LEARNING IMPROVEMENT TARGETS

FLOW-29 establishes measurable improvement targets (tracked via IContextEfficiencyMonitor + IBanditFeedbackStore):

| Metric                          | Baseline (Pre-FLOW-29) | Target (Post FLOW-29 90 days) |
|---------------------------------|------------------------|-------------------------------|
| First-try success rate          | Measured baseline      | +20–30% improvement           |
| Average retrieved tokens/task   | Measured baseline      | -15% (context efficiency)     |
| Model cost per solved task      | Measured baseline      | -10% (bandit routing)         |
| Hallucination detection rate    | Single model           | Multi-model consensus (3+)    |
| Prompt rollback incidents       | Untracked              | <2/month (versioning)         |
| Cross-tenant data leaks         | Undetected             | 0 (CF-513, CF-522 enforcement)|

These targets feed back into T409 (Improvement Suggestion Engine) and T395 (Routing Policy Update) for continuous improvement beyond FLOW-29.
