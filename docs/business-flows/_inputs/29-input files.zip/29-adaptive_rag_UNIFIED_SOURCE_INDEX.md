# 29-adaptive rag UNIFIED_SOURCE_INDEX
# XIIGen FLOW-29 — Adaptive RAG Deep Research Engine
# Full cross-reference of all FLOW-29 artifacts + backward-compat links

---

## ARTIFACT REGISTRY — FLOW-29

### Factory Index (F1075–F1146)

| Factory | Interface                       | Family | Task Types Used In    | Skills Referenced |
|---------|---------------------------------|--------|-----------------------|-------------------|
| F1075   | IAdaptiveRagRouter              | 154    | T389, T392, T407      | SK-251, SK-253    |
| F1076   | ITaskClassifier                 | 154    | T389                  | SK-251            |
| F1077   | IRetrievalModeSelector          | 154    | T389, T407            | SK-251            |
| F1078   | IQueryRewriter                  | 154    | T390                  | SK-251            |
| F1079   | IQueryDecomposer                | 154    | T390                  | SK-251            |
| F1080   | IRetrievalModeRegistry          | 154    | T389                  | SK-251            |
| F1081   | IRoutingPolicyReader            | 154    | T389                  | SK-251, SK-264    |
| F1082   | IRoutingAuditLogger             | 154    | T389, T407            | SK-251            |
| F1083   | IGraphRagService                | 155    | T391, T392, T411      | SK-252            |
| F1084   | IKnowledgeGraphBuilder          | 155    | T399 (via domain)     | SK-252, SK-259    |
| F1085   | ICommunityHierarchyManager      | 155    | T391, T411            | SK-252            |
| F1086   | ICommunitySummaryGenerator      | 155    | T391, T412            | SK-252            |
| F1087   | IEntityDeduplicator             | 155    | T399                  | SK-259            |
| F1088   | IGraphEditGate                  | 155    | T400, T410            | SK-252            |
| F1089   | IGraphIndexRebuildQueue         | 155    | T400, T412, T413      | SK-252, SK-259    |
| F1090   | IDomainGraphProfileStore        | 155    | T399                  | SK-259            |
| F1091   | ITraceSpanService               | 156    | T391, T396, T397, T404| SK-255, SK-256    |
| F1092   | ITokenCostTracker               | 156    | T394, T396            | SK-255            |
| F1093   | ILatencyProfiler                | 156    | T396                  | SK-255            |
| F1094   | IRunSessionStore                | 156    | T396, T397            | SK-255            |
| F1095   | IFeedbackLinker                 | 156    | T397                  | SK-256            |
| F1096   | IObservabilityExporter          | 156    | T396                  | SK-255            |
| F1097   | ICostBudgetEnforcer             | 157    | T394                  | SK-261            |
| F1098   | IBanditRouter                   | 157    | T393                  | SK-254            |
| F1099   | IBanditFeedbackStore            | 157    | T393, T397            | SK-254, SK-256    |
| F1100   | IBudgetPreferenceReader         | 157    | T393, T394            | SK-254            |
| F1101   | IBanditPolicyUpdater            | 157    | T393, T395            | SK-254, SK-264    |
| F1102   | IExplorationController          | 157    | T393                  | SK-254            |
| F1103   | IBanditAuditLog                 | 157    | T393, T408            | SK-254            |
| F1104   | IMultiObjectiveScorer           | 157    | T393, T395            | SK-254            |
| F1105   | IRetrievalFaithfulnessChecker   | 158    | T402                  | SK-257            |
| F1106   | IContextCoverageScorer          | 158    | T402                  | SK-257            |
| F1107   | IIronRuleValidator              | 158    | T402, T403            | SK-257            |
| F1108   | IQualityRubricStore             | 158    | T402                  | SK-257            |
| F1109   | IEvalResultPublisher            | 158    | T402                  | SK-257            |
| F1110   | IHallucinationDetector          | 158    | T402                  | SK-257            |
| F1111   | IQualityGateEnforcer            | 158    | T398, T401, T402, T403| SK-257, SK-258    |
| F1112   | IPromptVersionRegistry          | 159    | T398, T399, T523      | SK-258            |
| F1113   | IPromptVersionPromoter          | 159    | T398                  | SK-258            |
| F1114   | IPromptVariantTester            | 159    | T398, T404            | SK-258, SK-263    |
| F1115   | IPromptRollbackManager          | 159    | T398, T414            | SK-258, SK-260    |
| F1116   | IPromptTaggingService           | 159    | T398                  | SK-258            |
| F1117   | IPromptInjectionBuilder         | 159    | T393                  | SK-258            |
| F1118   | IPromptAuditTrail               | 159    | T398                  | SK-258            |
| F1119   | IDomainProfileStore             | 160    | T399, T413            | SK-259            |
| F1120   | IDomainEntityTypeRegistry       | 160    | T399                  | SK-259            |
| F1121   | IDomainExtractionPrompter       | 160    | T399                  | SK-259            |
| F1122   | IDomainSummaryStrategyPicker    | 160    | T399                  | SK-259            |
| F1123   | IDomainDeduplicationRules       | 160    | T399                  | SK-259            |
| F1124   | IDomainCompilerProfilePublisher | 160    | T399, T413            | SK-259            |
| F1125   | IDomainMetricsTracker           | 160    | T399, T413            | SK-259            |
| F1126   | IControlPlaneGraphStore         | 161    | T410, T415            | SK-265            |
| F1127   | IAssetVersionManager            | 161    | T403, T410            | SK-260            |
| F1128   | IFlowVariantRegistry            | 161    | T404, T415            | SK-263            |
| F1129   | IImprovementSuggestionEngine    | 161    | T409                  | SK-264            |
| F1130   | IControlPlaneABAllocator        | 161    | T404                  | SK-263            |
| F1131   | IPromotionPipelineOrchestrator  | 161    | T403                  | SK-260            |
| F1132   | ISelfLearningFeedbackAggregator | 161    | T395, T397, T408      | SK-256, SK-264    |
| F1133   | IGraphAnalyticsRunner           | 161    | T409                  | SK-264            |
| F1134   | IRagIndexVersionStore           | 162    | T390, T401            | SK-260            |
| F1135   | IEmbeddingVersionRegistry       | 162    | T401                  | SK-260            |
| F1136   | IChunkParameterVersioner        | 162    | T390, T401            | SK-260            |
| F1137   | IRagStrategyVersioner           | 162    | T401, T414            | SK-260            |
| F1138   | IRagRollbackManager             | 162    | T414                  | SK-260            |
| F1139   | IRagVersionComparator           | 162    | T401                  | SK-260            |
| F1140   | IRagAssetPromotionGate          | 162    | T401, T403            | SK-260            |
| F1141   | IContextEfficiencyMonitor       | 163    | T390, T391, T392, T405| SK-261            |
| F1142   | INoiseRetrievalDetector         | 163    | T405, T407            | SK-261, SK-262    |
| F1143   | IRerankerService                | 163    | T390, T392, T406      | SK-262            |
| F1144   | IBudgetCapPolicyStore           | 163    | T394, T405            | SK-261            |
| F1145   | IEfficiencyPenaltyCalculator    | 163    | T394, T405            | SK-261            |
| F1146   | IContextPruner                  | 163    | T392, T405            | SK-261            |

---

### Task Type Index (T389–T415)

| Task Type | Name                             | Family | Templates  | BFA Rules           | Skills         |
|-----------|----------------------------------|--------|------------|---------------------|----------------|
| T389      | Adaptive RAG Route Gate          | 154    | 83         | CF-510, CF-511      | SK-251         |
| T390      | Vector Retrieval Step            | 154/162| 83         | CF-512              | SK-251, SK-260 |
| T391      | GraphRAG Community Query         | 155    | 83         | CF-513, CF-514      | SK-252         |
| T392      | Hybrid Retrieval Fusion          | 154-163| 83         | CF-515              | SK-253         |
| T393      | Contextual Bandit Model Select   | 157    | 83, 84     | CF-516, CF-517      | SK-254         |
| T394      | Budget Enforcement Gate          | 157/163| 83         | CF-531              | SK-261         |
| T395      | Routing Policy Update            | 157/161| 84         | CF-517              | SK-264         |
| T396      | Trace Span Capture               | 156    | 83, 84–89  | CF-530              | SK-255         |
| T397      | User Feedback Ingest             | 156/157| 84         | CF-520              | SK-256         |
| T398      | Prompt Version Promote           | 159    | 85         | CF-518, CF-519      | SK-258         |
| T399      | Domain Profile Compile           | 160    | 86         | CF-522, CF-523      | SK-259         |
| T400      | Knowledge Graph Edit Gate        | 155    | 86, 88     | CF-525              | SK-252         |
| T401      | RAG Asset Version Compare        | 162    | 85, 89     | CF-524              | SK-260         |
| T402      | Eval Quality Gate                | 158    | 83, 89     | CF-521              | SK-257         |
| T403      | Promotion Pipeline Gate          | 161    | 89         | CF-529              | SK-260         |
| T404      | A/B Test Allocation              | 161    | 87         | CF-527              | SK-263         |
| T405      | Context Efficiency Check         | 163    | 83         | CF-526              | SK-261         |
| T406      | Reranker Step                    | 163    | 83         | —                   | SK-262         |
| T407      | Self-Reflection Retrieval Check  | 154    | 83         | CF-526              | SK-251         |
| T408      | Feedback Aggregation Window      | 161    | 84         | CF-535              | SK-256, SK-264 |
| T409      | Improvement Suggestion Engine    | 161    | —          | —                   | SK-264         |
| T410      | Control Plane Graph Edit         | 161    | 88         | CF-528              | SK-265         |
| T411      | Knowledge Graph Multi-Hop        | 155    | 88         | CF-513, CF-532      | SK-252         |
| T412      | Community Summary Generation     | 155    | 86         | CF-514              | SK-252         |
| T413      | Domain GraphRAG Index Rebuild    | 160    | 86         | CF-514, CF-522      | SK-259         |
| T414      | RAG Strategy Version Rollback    | 162    | —          | CF-524              | SK-260         |
| T415      | Visual Control Plane Node Render | 161    | —          | CF-534              | SK-265         |

---

### BFA Rules Index (CF-510–CF-535)

| Rule   | Severity | Trigger Domain              | Affected Flows          | Action     |
|--------|----------|-----------------------------|-------------------------|------------|
| CF-510 | HIGH     | RAG routing strategy rename | FLOW-09, FLOW-13        | COMPAT_WRAPPER |
| CF-511 | CRITICAL | Route gate bypasses BFA     | FLOW-25                 | REJECT     |
| CF-512 | MEDIUM   | Index version rolling update| FLOW-09, FLOW-13        | REQUIRE PLAN|
| CF-513 | CRITICAL | Cross-tenant graph query    | ALL                     | REJECT     |
| CF-514 | HIGH     | Sync community rebuild      | ALL GraphRAG consumers  | REJECT     |
| CF-515 | HIGH     | Hybrid fusion schema change | FLOW-09, FLOW-13        | HALT       |
| CF-516 | HIGH     | Bandit overrides FLOW-13    | FLOW-13                 | WARN       |
| CF-517 | HIGH     | Sync bandit policy update   | ALL                     | REJECT     |
| CF-518 | CRITICAL | Prompt version mutation     | ALL prompt consumers    | REJECT     |
| CF-519 | CRITICAL | Promotion without quality gate | ALL                  | REJECT     |
| CF-520 | HIGH     | Orphan feedback (no trace)  | Self-learning layer     | REJECT     |
| CF-521 | HIGH     | Single-model hallucination check | FLOW-13           | REJECT     |
| CF-522 | CRITICAL | Domain profile cross-tenant | ALL                     | REJECT     |
| CF-523 | HIGH     | Extraction prompts not versioned | Knowledge compiler | HALT   |
| CF-524 | HIGH     | RAG regression > 3%         | FLOW-09, FLOW-13        | BLOCK + HUMAN APPROVAL |
| CF-525 | CRITICAL | Graph edit without BFA gate | FLOW-25                 | REJECT     |
| CF-526 | MEDIUM   | Self-reflection token expansion | Self-learning       | REJECT     |
| CF-527 | HIGH     | Non-deterministic A/B alloc | A/B experiments         | REJECT     |
| CF-528 | CRITICAL | Control plane asset mutation| FLOW-25, asset governance| REJECT    |
| CF-529 | CRITICAL | Promotion ladder step skip  | All promoted assets     | REJECT     |
| CF-530 | HIGH     | Direct OTel SDK in service  | Observability layer     | REJECT     |
| CF-531 | CRITICAL | Budget cap silent truncation| ALL                     | REJECT     |
| CF-532 | HIGH     | Max hops hard-coded         | GraphRAG consumers      | REJECT     |
| CF-533 | HIGH     | Bandit arm dimension change without migration | All | HALT |
| CF-534 | HIGH     | Hard-coded node types in UI | Visual control plane    | REJECT     |
| CF-535 | MEDIUM   | Premature policy update     | Self-learning layer     | WARN       |

---

### Skill Index (SK-251–SK-265)

| Skill  | Name                          | Ladder Status | Depends On          | Used By Tasks               |
|--------|-------------------------------|---------------|---------------------|-----------------------------|
| SK-251 | Adaptive RAG Router           | MINIMAL       | —                   | T389, T390, T407            |
| SK-252 | GraphRAG Indexer              | GENERATED     | —                   | T391, T400, T411, T412      |
| SK-253 | Hybrid Retrieval Fusion       | GENERATED     | SK-251, SK-262      | T392                        |
| SK-254 | Contextual Bandit Router      | GENERATED     | SK-264              | T393, T395                  |
| SK-255 | Trace Span Capture            | GENERATED     | —                   | T396 (all tasks)            |
| SK-256 | User Feedback Ingest          | GENERATED     | SK-255              | T397, T408                  |
| SK-257 | Eval Quality Arbiter          | GENERATED     | —                   | T402                        |
| SK-258 | Prompt Version Registry       | GENERATED     | SK-257              | T398, T399                  |
| SK-259 | Domain Profile Compiler       | GENERATED     | SK-252, SK-258      | T399, T413                  |
| SK-260 | RAG Asset Version Manager     | GENERATED     | —                   | T401, T403, T414            |
| SK-261 | Context Efficiency Monitor    | GENERATED     | —                   | T394, T405                  |
| SK-262 | Reranker Service              | GENERATED     | SK-261              | T390, T392, T406            |
| SK-263 | A/B Test Allocator            | GENERATED     | SK-260              | T404                        |
| SK-264 | Routing Policy Updater        | GENERATED     | SK-256              | T395, T408, T409            |
| SK-265 | Visual Control Plane Canvas   | GENERATED     | SK-251–254 (all)    | T415, T410                  |

---

## BACKWARD COMPATIBILITY INDEX

### FLOW-29 → Existing Flows — Interaction Map

| Existing Flow | Interaction Type | FLOW-29 Impact | Protection |
|---|---|---|---|
| FLOW-09 Search & Discovery | IRagService consumer | RAG strategy extension adds strategies, never renames existing | CF-510, CF-512 |
| FLOW-13 AI Content Pipeline | Prompt library consumer, model consumer | Bandit router advisory only; FLOW-13 explicit config takes precedence | CF-516, CF-518 |
| FLOW-15 MVP Builder | Flow definition consumer | New FLOW-29 flow templates (83–89) are additive, not modifying FLOW-15 templates | None |
| FLOW-25 BFA Governance | Governance provider | FLOW-29 EXTENDS BFA with CF-510–535; FLOW-25 rules CF-1–509 unchanged | CF-511, CF-525 |
| ALL flows | Multi-tenant scope | FLOW-29 adds CF-513, CF-522 for stronger tenant isolation enforcement | CF-513, CF-522 |
| ALL flows | Trace observability | FLOW-29 adds ITraceSpanService — existing flows optionally adopt SK-255 | CF-530 |

### What Is NOT Changed by FLOW-29

```
F1–F1074:     UNCHANGED — all 153 existing families untouched
T1–T388:      UNCHANGED — all existing task types unchanged  
CF-1–CF-509:  UNCHANGED — existing BFA rules unchanged (new rules are additive)
SK-1–SK-250:  UNCHANGED — existing 250 skills unchanged
Templates 1–82: UNCHANGED
IRagService (existing 7 strategies): UNCHANGED — 4 new strategies are additive
```

---

## ANCHOR DOCUMENT MAP (FLOW-29)

| Anchor Document | FLOW-29 Reference |
|---|---|
| TASK_TYPES_CATALOG (current) | T1–T415 — T389–T415 are FLOW-29 additions |
| V39 ENGINE DESIGN (factory-first) | All FLOW-29 factories follow CreateAsync() pattern |
| V40 ENGINE-FABRIC-FIRST (AF+factory+task type deps) | AF-1→AF-11 mapping in each FLOW-29 task type |
| V17/V18 skill library (Skills 01-09) | SK-251–265 extend existing skill library |
| Genie DNA RULES (9 patterns) | Enforced by CF-513, CF-518, CF-528, CF-531 etc. |
| SESSION_STATE_MERGE (post-FLOW-25) | FLOW-29 builds on F1074/T388/CF-509/SK-250 baseline |

---

## DESIGN DECISIONS INDEX (DD-245–DD-258)

| ID     | Decision Summary                                    | Enforced By        |
|--------|-----------------------------------------------------|-------------------|
| DD-245 | Adaptive RAG = IRagService extension, not new fabric| Architecture     |
| DD-246 | GraphRAG community rebuild always async             | CF-514, SK-252    |
| DD-247 | Bandit router reads FREEDOM config only             | CF-517, SK-254    |
| DD-248 | Traces via QUEUE FABRIC (not direct OTel SDK)       | CF-530, SK-255    |
| DD-249 | Prompt versions immutable — promote by new version  | CF-518, SK-258    |
| DD-250 | Domain profiles are tenant-scoped                   | CF-522, SK-259    |
| DD-251 | budget_cap is FREEDOM config, admin-adjustable      | CF-531, SK-261    |
| DD-252 | A/B test results collected via QUEUE FABRIC         | CF-527, SK-263    |
| DD-253 | Self-reflection can only reduce tokens, never expand| CF-526, SK-251    |
| DD-254 | Knowledge graph edits require BFA approval          | CF-525, T400      |
| DD-255 | Feedback aggregation window is configurable         | CF-535, SK-256    |
| DD-256 | Promotion pipeline follows existing GENERATED→CORE  | CF-529, T403      |
| DD-257 | Multi-hop traversal depth is FREEDOM config (max 4) | CF-532, T411      |
| DD-258 | Visual control plane: React Flow, zero hard-coded   | CF-534, SK-265    |

## DESIGN RECORDS INDEX (DR-184–DR-193)

| ID     | Design Record Summary                                  |
|--------|--------------------------------------------------------|
| DR-184 | Why bandit routing is async policy-only (not real-time)|
| DR-185 | Why GraphRAG is a "mode" not the default strategy      |
| DR-186 | Why context efficiency is a first-class metric         |
| DR-187 | Why prompt versions are immutable (not editable)       |
| DR-188 | Why domain compiler profiles are tenant-scoped         |
| DR-189 | Why hallucination detection requires multi-model       |
| DR-190 | Why self-reflection can only reduce (never expand)     |
| DR-191 | Why A/B allocation must be deterministic               |
| DR-192 | Why traces go via QUEUE FABRIC (not direct OTel)       |
| DR-193 | Why promotion pipeline steps cannot be skipped         |
