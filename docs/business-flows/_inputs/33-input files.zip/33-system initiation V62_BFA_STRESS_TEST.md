# FLOW-33 — System Initiation: Self-Building Bootstrap Engine
## BFA CONFLICT RULES & STRESS TESTS

**FLOW Reference:** FLOW-33  
**Backward Compatibility:** CF-1-CF-294 and ST-1-ST-163 UNCHANGED  
**New BFA Rules:** CF-295 through CF-306  
**New Stress Tests:** ST-164 through ST-171  

---

## BFA RULES — FLOW-33

### CF-295 — Plan Bundle Oracle Validation Before Registry Writes

**Severity:** CRITICAL  
**Entities:** PlanBundle, FactoryRegistry, TaskTypeRegistry, SkillRegistry, BFARuleRegistry  
**Events:** PlanBundleUploaded → PlanBundleValidated | PlanBundleRejected  
**APIs:** F632:ValidatePlanBundle, F632:CompileRegistry  

**Conflict:**
Registry compilation (F632:CompileRegistry) begins BEFORE ValidatePlanBundle confirms ranges match the session state oracle (F1-F630, T1-T246, SK-1-SK-144, CF-1-CF-294). Result: partial or corrupt registries that pass integrity checks but contain wrong artifact counts.

**Resolution:**
ValidatePlanBundle MUST emit PlanBundleValidated before any CompileRegistry call is triggered. FlowOrchestrator enforces ordering via `dependsOn` on the import_plan_bundle node. If ValidatePlanBundle returns valid=false, flow emits PlanBundleRejected and routes to DLQ — NO registry mutations occur.

**Enforcement Index:** `bfa-install-gate` (Elasticsearch index tracking bundle validation states)

**Detection Pattern:**
```
IF (event: CompileRegistry) AND NOT (event: PlanBundleValidated for same bundleId)
→ BFA VIOLATION: halt compilation, emit BfaViolationDetected { cfId: 'CF-295' }
```

**Cross-Flow Impact:** FLOW-01–FLOW-17 registries (F1-F630, T1-T246) are read-only from this flow's perspective. CF-295 ensures FLOW-33 additions (F631-F640, T247-T253) do not overwrite existing ranges.

---

### CF-296 — Outbox Ordering: Phase State Before Event Emission

**Severity:** CRITICAL  
**Entities:** BootstrapPhase, BootstrapSentinel  
**Events:** BootstrapPhaseAdvanced, BootstrapCompleted  
**APIs:** F631:AdvanceBootstrapPhase, F631:SetBootstrappedSentinel  

**Conflict:**
BootstrapCompleted event is emitted BEFORE BootstrapSentinel is written to Elasticsearch. If the process restarts, the sentinel is missing, causing a second bootstrap run — double-registration of schemas, registries, and graph nodes.

**Resolution:**
Outbox pattern: F631:SetBootstrappedSentinel writes sentinel doc to ES with `status: 'committed'`, THEN emits BootstrapCompleted via queue. On restart, F631:CheckBootstrapStatus reads sentinel — if present and version ≥ desired, emit BootstrapCompleted again (idempotent) and exit. Never re-execute bootstrap phases.

**Enforcement Index:** `bfa-bootstrap-phases` (tracks committed phase states per version)

**Detection Pattern:**
```
IF (event: BootstrapCompleted) AND NOT (document: bootstrap-sentinel in ES with status='committed')
→ VIOLATION: process likely died mid-write; next run will re-bootstrap (data integrity risk)
```

---

### CF-297 — Schema-Before-Event: Schema Registry Before First Use

**Severity:** HIGH  
**Entities:** SchemaRegistry, EventSchema  
**Events:** BootstrapCompleted, PlanBundleImported, GraphCatalogSeeded, FamilyImplementationCompleted  
**APIs:** F194:RegisterSchema  

**Conflict:**
Bootstrap flow emits events (e.g., CoreSchemasRegistered) whose schemas have not yet been registered in the SchemaRegistry. Consumers that validate incoming events against registered schemas will reject them.

**Resolution:**
Node `register_core_schemas` (F194:RegisterSchema) MUST be the first non-sentinel-check node in T247 DAG. All FLOW-33 event schemas (BootstrapCompleted, PlanBundleImported, GraphCatalogSeeded, FamilyImplementationCompleted, RegressionRunRequested, CapabilityGapDetected) registered before any node that emits them.

**Enforcement Index:** `bfa-schema-registry` (tracks which schemas are registered per tenant/scope)

---

### CF-298 — Atomic Registry Compilation: No Partial Updates on Failure

**Severity:** CRITICAL  
**Entities:** FactoryRegistry, TaskTypeRegistry, SkillRegistry  
**Events:** RegistryCompiled, RegistryCompilationFailed  
**APIs:** F632:CompileRegistry  

**Conflict:**
F632:CompileRegistry processes 7 registry types sequentially. If it fails mid-way (e.g., after factory_registry but before skill_registry), the system has a partial state — factory_registry up-to-date but skill_registry stale — causing mismatches in AF-4 retrieval and BFA rule lookups.

**Resolution:**
CompileRegistry uses a bundle version marker. On failure: write `registry-compilation-state` to ES with `status: 'partial', lastCompletedType, bundleId`. On retry: resume from `lastCompletedType`. All compiled docs carry `bundleVersion` — consumers filter by version to avoid mixing partial state.

**Enforcement Index:** `bfa-registry-compilation` (tracks bundle version + completion state per registry type)

---

### CF-299 — Graph Fabric Isolation: No Direct Graph Driver in Service Code

**Severity:** CRITICAL  
**Entities:** GraphCatalogSeeder, ProviderImpl, FlowDef  
**APIs:** F635:ExecuteGraphQuery, F635:SeedCatalogGraph  

**Conflict:**
Service code directly imports Neo4j driver (or Neptune SDK) to execute Cypher queries, bypassing F635:IGraphCatalogSeeder. Result: graph provider becomes a hard dependency — swapping to Neptune requires code changes (violates fabric-first rule).

**Resolution:**
ALL graph operations MUST go through F635:IGraphCatalogSeeder.ExecuteGraphQuery with a query template name. Cypher strings MUST reside in stored query templates (prompt_registry) — not embedded in service files. AF-7 (Compliance) checks for `Neo4jDriver`, `IAsyncSession`, `driver.AsyncSession()` imports — any match = BUILD FAILURE.

**Enforcement Index:** `bfa-fabric-isolation` (scans generated code for direct provider imports)

**Detection Pattern:**
```
Generated file contains: 
  'using Neo4j' OR 'IDriver' OR '_neo4jDriver' OR 'AsyncSession()'
→ DNA VIOLATION + CF-299 violation → BUILD FAILURE
```

---

### CF-300 — Graph Scope Isolation: No Cross-Tenant Graph Edges

**Severity:** CRITICAL  
**Entities:** Graph nodes (Family, Factory, TaskType, etc.)  
**APIs:** F635:SeedCatalogGraph, F635:UpsertProviderImplementation  

**Conflict:**
A SYSTEM-scoped catalog graph node is linked to a TENANT-scoped implementation node without scope validation. Result: a tenant's provider implementation appears in the SYSTEM catalog graph — corrupts global context for all other tenants.

**Resolution:**
F635:SeedCatalogGraph enforces: `source.scope` and `target.scope` must match OR the edge type explicitly permits cross-scope (none defined for FLOW-33). Node schema validation on every upsert: if `scope != 'SYSTEM'` AND the node connects to a SYSTEM node via a Catalog Graph edge → reject with `ScopeBoundaryViolation`.

**Enforcement Index:** `bfa-graph-scope` (edge validation log)

---

### CF-301 — Graph Integrity Before Completion Event

**Severity:** HIGH  
**Entities:** GraphCatalogSeeded event, Family nodes, Factory nodes  
**APIs:** F635:ValidateGraphIntegrity  

**Conflict:**
GraphCatalogSeeded event is emitted with node counts below the oracle (e.g., 40 families instead of ≥85). Downstream flows that trust GraphCatalogSeeded will operate on incomplete graph data.

**Resolution:**
F635:ValidateGraphIntegrity runs BEFORE emitting GraphCatalogSeeded. Validation checks: familiesCount ≥ (registry oracle), factoriesCount ≥ (registry oracle), all DEPENDS_ON edges resolve. If deviation > 5% → emit GraphCatalogSeedFailed (not GraphCatalogSeeded) → bootstrap halts at this phase.

**Enforcement Index:** `bfa-graph-integrity` (oracle comparison log)

---

### CF-302 — BFA Registration Before Promotion

**Severity:** HIGH  
**Entities:** GeneratedFactory, BFAEntityIndex, BFAEventIndex  
**Events:** FamilyImplementationCompleted  
**APIs:** F633:UpdateImplementationStatus  

**Conflict:**
Generated factory is promoted from GENERATED to INJECTED (or higher) without registering its entities/events/APIs in BFA indices. Future BFA conflict checks will miss this factory's entities — cross-flow conflicts go undetected.

**Resolution:**
Arbiter E (BFA) in T251 checks that BFA registration docs exist before passing. F633:UpdateImplementationStatus rejects promotions above GENERATED without `bfaRegistrationCompleted: true` in evidence dict. BFA registration = entities doc + events doc + APIs doc in `bfa-entity-index`, `bfa-event-index`, `bfa-api-index`.

**Enforcement Index:** `bfa-registration-gate` (tracks registration completeness per factory)

---

### CF-303 — Multi-Model Candidate Isolation

**Severity:** HIGH  
**Entities:** GenerationCandidates (AF-5 outputs)  
**APIs:** F636:StartFamilyImplementation (AF-5 parallel execution)  

**Conflict:**
Two parallel model generations (e.g., OpenAI + Claude) write to the same candidate buffer or share mutable state. Result: merged output contains code from both in a non-deterministic mix — arbiter evaluation is not reproducible.

**Resolution:**
AiDispatcher (Skill 07) allocates separate result buffers per model provider. Each candidate identified by `{ runId, modelProvider, iteration }`. AF-10 merge receives all candidates as a list — never mutates individual candidate buffers. All candidate results stored in ES (with modelProvider tag) before merge begins.

**Enforcement Index:** `bfa-candidate-isolation` (generation run audit log)

---

### CF-304 — Verbatim Failure Trace Propagation

**Severity:** HIGH  
**Entities:** ArbiterResult, GenerationPrompt  
**APIs:** F637:BuildArbiterPrompt  

**Conflict:**
Arbiter failure trace is paraphrased or summarized before injection into the next generation prompt. The original error location, rule reference, and line reference are lost. Next generation attempt does not fix the exact issue because it received a vague description.

**Resolution:**
F637:BuildArbiterPrompt injects `priorFailures[].failureTrace` verbatim — no transformation. AiDispatcher is invoked with the raw trace string from the previous arbiter result. AF-11 checks that the trace in the prompt matches the stored arbiter output (string equality on first 200 chars).

**Enforcement Index:** `bfa-trace-fidelity` (traces per run are stored and compared)

---

### CF-305 — Arbiter Prompt Citations Required

**Severity:** MEDIUM  
**Entities:** ArbiterOutput, ContextPack  
**APIs:** F637:RunSingleArbiter  

**Conflict:**
Arbiter returns a pass/fail verdict but does not cite which ContextPack skills or BFA rules it checked. Result: AF-11 cannot score which skills are effective — prompt evolution is blind.

**Resolution:**
Arbiter output schema requires `citedSkills[]` and `citedRules[]` fields (non-empty). F637 validates response schema before accepting. If `citedSkills` is empty → treat as "analysis incomplete" → reduce score by 20 points (still may pass if score ≥ threshold, but logged as quality concern).

**Enforcement Index:** `bfa-arbiter-citations` (per-run citation completeness log)

---

### CF-306 — Regression Completeness: All Impacted Providers

**Severity:** CRITICAL  
**Entities:** ProviderImpl, TestSuite, RegressionRunRequested  
**APIs:** F639:ComputeImpact, F639:TriggerRegressionRun  

**Conflict:**
After a factory interface change, T252 (Regression Impact Trigger) retests only SOME providers implementing the changed interface (e.g., tests Elastic but not Mongo). The untested provider may have a missing method implementation — goes to production broken.

**Resolution:**
F639:ComputeImpact queries Impact Graph exhaustively: ALL (ProviderImpl)-[:IMPLEMENTS]->(Method {factoryId: X}) nodes. The returned `impactedProviders[]` list must match the count of provider implementations in F633 for that factory. If counts differ → F639 emits `ImpactScopeIncomplete` and halts regression trigger until reconciled.

**Enforcement Index:** `bfa-regression-completeness` (provider count validation per factory per regression run)

---

## STRESS TESTS — FLOW-33

### ST-164 — Double Bootstrap Scenario

**Scenario:** Two `PlatformBootRequested` events arrive within the debounce window (30s) — one from a service restart and one from an admin trigger. Both reach the flow orchestrator simultaneously.

**Attack Vector:** Race condition — both instances check sentinel, both find it absent, both proceed to Phase 1 (schema registration) in parallel.

**Defense Layers:**
1. Debounce window (30s, latest_wins policy) collapses duplicate events at queue level
2. F631:CheckBootstrapStatus uses ES optimistic locking — only one writer succeeds for `bootstrap-sentinel` document
3. F631:AdvanceBootstrapPhase is idempotent — duplicate phase-advance writes are safe (same phase key + version)
4. CF-296 enforcement: if sentinel exists with correct version → immediate exit

**Expected Result:** Only one bootstrap sequence completes. Second instance detects sentinel and exits. No double-registration of schemas, registries, or graph nodes.

**Verification:**
- `factory_registry` doc count == oracle (F1-F640), not 2×
- `bootstrap-sentinel.version` == 1 (not 2)
- Queue: exactly 1 BootstrapCompleted event

---

### ST-165 — Plan Bundle Range Mismatch Attack

**Scenario:** A corrupted or outdated plan bundle is uploaded with factory range F1-F500 (instead of F1-F640). CF-295 must catch this before any registry mutations.

**Attack Vector:** Stale plan bundle from a previous session is accidentally re-uploaded after FLOW-33 has been designed (which adds F631-F640).

**Defense Layers:**
1. F632:ValidatePlanBundle compares `expectedRanges.factories = F1-F500` against session state oracle `F1-F640` → mismatch detected
2. PlanBundleRejected emitted with structured error report
3. Zero registry writes occur — CF-295 enforced by `dependsOn` in T247 DAG

**Expected Result:**
- `PlanBundleRejected { reason: 'RANGE_MISMATCH', expected: 'F1-F640', got: 'F1-F500' }` emitted
- No factory_registry docs written
- Bootstrap phase remains at `VALIDATING` (not COMPILED)
- Admin receives rejection report with exact gap (F631-F640 missing)

---

### ST-166 — Graph Seeding Partial Failure Mid-Run

**Scenario:** During T249 (GraphRAG Catalog Seed), the process fails after seeding Factory nodes but before wiring DEPENDS_ON edges. System restarts.

**Attack Vector:** Infrastructure failure (OOM, container restart) mid-graph-seeding.

**Defense Layers:**
1. F635:SeedCatalogGraph uses a phase-based seeding state stored in ES (which node types have been seeded)
2. On restart: reads seeding state → resumes from edge wiring phase (nodes already exist)
3. Node upserts are idempotent (unique constraint on `id` — duplicate upsert = no-op)
4. CF-301 enforcement: GraphCatalogSeeded only emitted after ValidateGraphIntegrity passes

**Expected Result:**
- After restart, seeding resumes from DEPENDS_ON edge wiring
- No duplicate Family/Factory nodes
- GraphCatalogSeeded emitted only after full integrity check passes
- `edgesCount` in result matches expected value

---

### ST-167 — Arbiter Loop Infinite Retry Prevention

**Scenario:** T250 (Implement-Family Meta-Loop) runs 10 iterations but every candidate fails Arbiter C (DNA_COMPLIANCE) because the model consistently uses typed models. Max iteration limit must trigger escalation, not infinite loop.

**Attack Vector:** Systematic prompt failure — every candidate violates DNA-1 regardless of prior failure traces.

**Defense Layers:**
1. MACHINE rule: maxIterations = 10 — no config override
2. At iteration 10 with failure: F636 emits FamilyImplementationFailed { runId, failedArbiter: 'DNA', trace }
3. Event routes to DLQ — not re-queued
4. AF-11 stores all 10 failure traces for prompt analysis (SK-153 evolution trigger)
5. Human escalation: DLQ message includes family spec + all failure traces for manual review

**Expected Result:**
- Exactly 10 iterations run
- FamilyImplementationFailed emitted to DLQ
- No 11th attempt (hard limit enforced)
- AF-11 feedback stored for all 10 iterations
- Prompt performance report (F640) shows 10 failures → triggers prompt review flag

---

### ST-168 — Cross-Tenant Graph Contamination

**Scenario:** A tenant-scoped ProviderImpl node for TenantA is accidentally linked with a SYSTEM-scope TaskType node via DEPENDS_ON edge. This would expose TenantA's implementation details in SYSTEM-level context queries.

**Attack Vector:** Missing scope check in F635:UpsertProviderImplementation when creating Impact Graph edges.

**Defense Layers:**
1. CF-300 enforcement: F635 validates `source.scope == target.scope` before edge creation
2. If cross-scope edge attempted → ScopeBoundaryViolation error, edge rejected
3. Q1/Q2/Q3 queries always filter by `WHERE n.scope = $scope` — cross-scope data not returned even if edge exists
4. Graph integrity validation includes scope check on edges

**Expected Result:**
- Edge creation rejected with `ScopeBoundaryViolation`
- SYSTEM graph Q1/Q2/Q3 do not return TenantA nodes
- `bfa-graph-scope` enforcement index records the violation attempt
- No contamination of SYSTEM context packs with tenant data

---

### ST-169 — Regression Scope Explosion Containment

**Scenario:** IDatabaseService (the shared database fabric interface) is updated with a new method. F639:ComputeImpact runs on this — theoretically every factory using DATABASE FABRIC is impacted. This could trigger regression for 600+ factories simultaneously.

**Attack Vector:** Unscoped regression trigger on a shared fabric interface causes system overload.

**Defense Layers:**
1. CF-306 scopes regression to the specific factory (e.g., F631:IBootstrapService), not the base fabric interface
2. Impact computation uses factory-level graph edges (ProviderImpl-[:IMPLEMENTS]->Method {factoryId: X}), not fabric-level
3. Regression trigger for fabric changes: deferred batch mode (queue with `batchSize: 50`, spread over 2h window)
4. Priority system: CORE-tier factories regressed first, GENERATED-tier deferred

**Expected Result:**
- Regression triggered only for factories directly implementing the changed interface
- Batch processing prevents queue overflow
- CORE factories regressed within 1h, GENERATED factories within 4h
- No timeout or DLQ overflow

---

### ST-170 — Plan Bundle Referential Integrity Failure

**Scenario:** T248 (Plan Bundle Install Gate) extracts factory registry but T47 task type references F999 (a factory that doesn't exist in the extracted factory_registry). Referential integrity check must catch this.

**Attack Vector:** Documentation drift — a task type was updated to add a factory dependency but the factory definition wasn't included in the same plan bundle update.

**Defense Layers:**
1. CF-295 referential integrity check: for every TaskType in task_type_registry, validate all `factoryDependencies[]` exist in factory_registry by ID
2. Missing F999 → `IntegrityViolation { taskTypeId: 'T47', missingFactory: 'F999' }` included in validation report
3. PlanBundleRejected (not partial install)
4. Admin receives structured gap report identifying which T/F pairs are inconsistent

**Expected Result:**
- PlanBundleRejected with referential integrity report
- Zero registry writes
- Report: `{ violations: [{ taskTypeId: 'T47', missingFactories: ['F999'] }] }`
- No partial factory_registry state (CF-298 enforced)

---

### ST-171 — Verbatim Failure Trace Drift

**Scenario:** After Arbiter C (DNA) returns a failure trace "Line 47: typed model BootstrapSentinel used", F637:BuildArbiterPrompt injects a modified version "DNA violation found in sentinel handling" into the next generation prompt. CF-304 must detect this.

**Attack Vector:** A middleware layer accidentally summarizes failure traces (e.g., a logging/truncation layer) before they reach the next generation prompt.

**Defense Layers:**
1. CF-304 enforcement: F637:BuildArbiterPrompt stores both original trace (from ArbiterResult) and injected trace (in prompt)
2. AF-11 compares: `injectedTrace.startsWith(originalTrace.substring(0, 200))` — must match
3. If drift detected: `TraceFidelityViolation` logged, run paused pending manual inspection
4. Prompt template uses raw string interpolation — no AI paraphrasing of failure content

**Expected Result:**
- Verbatim trace "Line 47: typed model BootstrapSentinel used" appears unchanged in next generation prompt
- AF-11 trace fidelity check passes
- If truncation was applied: TraceFidelityViolation emitted, generation paused
- Model on next iteration addresses the exact line 47 issue

---

## BFA RULES SUMMARY — FLOW-33

| CF ID | Title | Severity | Key Guard |
|-------|-------|----------|-----------|
| CF-295 | Oracle validation before registry writes | CRITICAL | PlanBundleValidated before CompileRegistry |
| CF-296 | Outbox: phase state before event | CRITICAL | ES write before queue emit |
| CF-297 | Schema-before-event: schemas registered first | HIGH | F194 first node in T247 |
| CF-298 | Atomic registry compilation | CRITICAL | bundle version + partial-state resume |
| CF-299 | Graph fabric isolation | CRITICAL | no direct Neo4j driver import |
| CF-300 | Graph scope isolation | CRITICAL | no cross-tenant edges |
| CF-301 | Graph integrity before completion | HIGH | ValidateGraphIntegrity before event |
| CF-302 | BFA registration before promotion | HIGH | evidence check in F633 |
| CF-303 | Multi-model candidate isolation | HIGH | separate buffers per model |
| CF-304 | Verbatim failure trace propagation | HIGH | string equality check |
| CF-305 | Arbiter prompt citations required | MEDIUM | citedSkills[] non-empty |
| CF-306 | Regression completeness | CRITICAL | all providers tested |

## STRESS TESTS SUMMARY — FLOW-33

| ST ID | Scenario | Defense | Expected |
|-------|----------|---------|---------|
| ST-164 | Double bootstrap | debounce + ES lock + idempotency | single completion |
| ST-165 | Range mismatch bundle | CF-295 + zero writes | PlanBundleRejected |
| ST-166 | Graph seed partial failure | phase state + node idempotency | resume from edges |
| ST-167 | Arbiter infinite loop | maxIterations=10 MACHINE | DLQ + escalation |
| ST-168 | Cross-tenant graph contamination | CF-300 scope check | edge rejected |
| ST-169 | Regression scope explosion | factory-level scoping + batch | controlled rollout |
| ST-170 | Referential integrity failure | CF-295 ref check | PlanBundleRejected |
| ST-171 | Failure trace drift | CF-304 string equality | TraceFidelityViolation |

---

## STATE CHECKPOINT

```yaml
FLOW_33_BFA_CHECKPOINT:
  status: COMPLETE
  new_bfa_rules: CF-295 through CF-306 (12 rules)
  new_stress_tests: ST-164 through ST-171 (8 tests)
  next_cf: CF-307
  next_st: ST-172
  critical_rules: CF-295, CF-296, CF-298, CF-299, CF-300, CF-306
  backward_compatibility: CF-1-CF-294 and ST-1-ST-163 unchanged
  next_doc: SESSION_STATE
```
