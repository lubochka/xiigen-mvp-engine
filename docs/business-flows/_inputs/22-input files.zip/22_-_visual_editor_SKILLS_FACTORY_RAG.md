# SKILLS FACTORY RAG — FLOW-20 EXTENSION
# Visual Editor & Site Builder Platform
# Extends: SKILLS_FACTORY_RAG_MERGED.md (SK-1–SK-144)
# FLOW-20 adds: SK-145–SK-154 (10 new skills)
# Save Point: FLOW20:P4:SKILLS:COMPLETE

---

## STATE REFERENCE
```
Previous: SK-1–SK-144 — SKILLS_FACTORY_RAG_MERGED.md
This file: SK-145–SK-154 (10 new skills)
```

---

## SK-145 — Page Tree Versioned Mutation Pattern

```
SKILL:        SK-145
NAME:         Page Tree Versioned Mutation Pattern
DOMAIN:       Visual Editor / Family 84
FACTORIES:    F631 (IPageTreeService), F635 (ICollaborationLockService)
FLOW:         FLOW-20
TASK TYPES:   T247, T249

PATTERN DESCRIPTION:
  Safely mutate a hierarchical page tree with full version history,
  optimistic concurrency, and collaboration lock enforcement.
  All nodes stored as Dictionary<string,object> in Elasticsearch.

PRIMARY (.NET 9):
  // Extend MicroserviceBase — always
  public class PageTreeMutationService : MicroserviceBase
  {
    private readonly IExternalServiceFactory<IPageTreeService> _treeFactory;
    private readonly IExternalServiceFactory<ICollaborationLockService> _lockFactory;

    public async Task<DataProcessResult<string>> MutateNodeAsync(
      Dictionary<string, object> request)
    {
      // DNA-5: always extract tenantId first
      var tenantId = ObjectProcessor.ExtractString(request, "tenantId");
      var siteId   = ObjectProcessor.ExtractString(request, "siteId");
      var nodeData = ObjectProcessor.ParseDocument(request, "node"); // DNA-1

      // Validate lock (DNA-3: return result, never throw)
      var lockService = await _lockFactory.CreateAsync(new FactoryResolutionContext
        { TenantId = tenantId });
      var lockCheck = await lockService.AcquireLockAsync(
        $"{siteId}:node:{nodeData["id"]}", request["userId"].ToString(), tenantId);
      if (!lockCheck.Success) return DataProcessResult<string>.Failure(lockCheck.Error);

      // Write snapshot before mutation (IR-631-1)
      var treeService = await _treeFactory.CreateAsync(
        new FactoryResolutionContext { TenantId = tenantId, SiteId = siteId });
      var snapshot = await treeService.GetVersionAsync(siteId, nodeData["pageId"].ToString(),
        null, tenantId);

      // Build filter — skip empty fields (DNA-2)
      var filter = BuildSearchFilter(new Dictionary<string, object>
      {
        ["tenantId"] = tenantId, ["siteId"] = siteId, ["nodeId"] = nodeData["id"],
        ["etag"] = ObjectProcessor.ExtractString(request, "etag") // optimistic concurrency
      });

      var result = await treeService.StoreNodeAsync(siteId, nodeData, tenantId);
      return result;
    }
  }

LANGUAGE VARIANTS:
  Node.js:
    class PageTreeMutationService extends MicroserviceBase {
      async mutateNode(request) {
        const { tenantId, siteId, node, userId, etag } = request;
        const lockSvc = await this.lockFactory.createAsync({ tenantId });
        const lock = await lockSvc.acquireLock(`${siteId}:node:${node.id}`, userId, tenantId);
        if (!lock.success) return DataProcessResult.failure(lock.error);
        const treeSvc = await this.treeFactory.createAsync({ tenantId, siteId });
        return await treeSvc.storeNode(siteId, node, tenantId);
      }
    }

AI AGENT PROMPT:
  "Generate a page tree mutation service following SK-145.
   Rules: extend MicroserviceBase, use IPageTreeService via factory, acquire collaboration lock
   via ICollaborationLockService before any write, write version snapshot (append-only),
   use BuildSearchFilter (DNA-2), return DataProcessResult (DNA-3), include tenantId (DNA-5)."

RAG RETRIEVAL TRIGGERS:
  - "page tree mutation"  - "component drag drop"  - "editor node update"
  - "version history visual editor"  - "ETag concurrency editor"
```

---

## SK-146 — JSON Schema 2020-12 Registry Pattern

```
SKILL:        SK-146
NAME:         JSON Schema 2020-12 Registry Pattern
DOMAIN:       CMS Data Modeling / Family 85
FACTORIES:    F637 (IPostTypeRegistryService), F639 (IPostTypeSchemaService)
FLOW:         FLOW-20
TASK TYPES:   T248, T251

PATTERN DESCRIPTION:
  Schema-first content modeling using JSON Schema 2020-12.
  Validates, versions, and registers PostType schemas with additive-only
  evolution guarantee. Generates form schemas for admin UI without code changes.

PRIMARY (.NET 9):
  public class PostTypeRegistrationService : MicroserviceBase
  {
    private readonly IExternalServiceFactory<IPostTypeRegistryService> _registryFactory;
    private readonly IExternalServiceFactory<IPostTypeSchemaService> _schemaFactory;

    public async Task<DataProcessResult<string>> RegisterAsync(
      Dictionary<string, object> request)
    {
      var tenantId = ObjectProcessor.ExtractString(request, "tenantId");
      var schema   = ObjectProcessor.ParseDocument(request, "schema"); // DNA-1

      // Validate schema is JSON Schema 2020-12 (IR-637-1 / DD-130)
      var schemaService = await _schemaFactory.CreateAsync(
        new FactoryResolutionContext { TenantId = tenantId });
      var validation = await schemaService.ValidateDocumentAsync(
        schema, "meta-schema-2020-12", tenantId);
      if (!validation.Success) return DataProcessResult<string>.Failure(
        $"Schema must be JSON Schema 2020-12: {validation.Error}");

      // Backward compat check (IR-637-2)
      var registryService = await _registryFactory.CreateAsync(
        new FactoryResolutionContext { TenantId = tenantId });
      var existing = await registryService.GetPostTypeAsync(
        schema["$id"].ToString(), tenantId);
      if (existing.Success)
      {
        var backwardCompatCheck = CheckAdditiveOnly(existing.Value, schema);
        if (!backwardCompatCheck.IsAdditive)
          return DataProcessResult<string>.Failure("Schema changes must be additive only");
      }

      return await registryService.RegisterPostTypeAsync(schema, tenantId);
    }
  }

AI AGENT PROMPT:
  "Generate a PostType registration service following SK-146.
   Rules: validate schema is JSON Schema 2020-12 (DD-130), check additive-only
   evolution (IR-637-2), version all changes, use ParseDocument (DNA-1),
   extend MicroserviceBase (DNA-4), scope by tenantId (DNA-5)."

RAG RETRIEVAL TRIGGERS:
  - "post type schema"  - "cms schema registry"  - "JSON Schema 2020-12"
  - "content type definition"  - "schema validation CMS"
```

---

## SK-147 — CMS Collection Relation Pattern

```
SKILL:        SK-147
NAME:         CMS Collection Relation Pattern
DOMAIN:       CMS Data Modeling / Family 85
FACTORIES:    F642 (ICollectionRelationService), F638 (IPostService)
FLOW:         FLOW-20
TASK TYPES:   T251, T254

PATTERN DESCRIPTION:
  Manages typed relationships between CMS collections (post→author, post→tags,
  post→category) using config-driven relation types. Validates referential
  integrity before writes. Detects circular relations.

AI AGENT PROMPT:
  "Generate a collection relation service following SK-147.
   Rules: relation types from FREEDOM config (not hardcoded), circular detection,
   referential integrity check before post save (CF-301), ParseDocument (DNA-1),
   tenantId scope (DNA-5), DataProcessResult (DNA-3)."

RAG RETRIEVAL TRIGGERS:
  - "post category relation"  - "cms collection reference"
  - "content relationship"  - "referential integrity CMS"
```

---

## SK-148 — Optimistic Concurrency Content Write Pattern

```
SKILL:        SK-148
NAME:         Optimistic Concurrency Content Write Pattern
DOMAIN:       CMS / Content Authoring
FACTORIES:    F638 (IPostService), F641 (IContentVersionService)
FLOW:         FLOW-20
TASK TYPES:   T252

PATTERN DESCRIPTION:
  Write post content with ETag-based optimistic concurrency. Snapshot version
  before every update. Return 409 Conflict result on concurrent write collision.
  Version journal is append-only (no UPDATE/DELETE).

PRIMARY (.NET 9 key excerpt):
  public async Task<DataProcessResult<Dictionary<string,object>>> UpdatePostAsync(
    Dictionary<string, object> request)
  {
    var tenantId  = ObjectProcessor.ExtractString(request, "tenantId");
    var postId    = ObjectProcessor.ExtractString(request, "postId");
    var version   = ObjectProcessor.ExtractString(request, "version");
    var content   = ObjectProcessor.ParseDocument(request, "content"); // DNA-1

    var postService = await _postFactory.CreateAsync(
      new FactoryResolutionContext { TenantId = tenantId });

    // Check current version (ETag/If-Match — IR-638-2)
    var current = await postService.GetPostAsync(postId, tenantId);
    if (!current.Success) return DataProcessResult<Dictionary<string,object>>.Failure("Post not found");
    if (current.Value["version"].ToString() != version)
      return DataProcessResult<Dictionary<string,object>>.Failure("409: Concurrent modification detected");

    // Snapshot before update (IR-641-1 append-only)
    var versionService = await _versionFactory.CreateAsync(
      new FactoryResolutionContext { TenantId = tenantId });
    await versionService.SnapshotAsync(postId, current.Value, tenantId);

    return await postService.UpdatePostAsync(postId, content,
      int.Parse(version) + 1, tenantId);
  }

AI AGENT PROMPT:
  "Generate post update service following SK-148.
   Rules: ETag/If-Match version check (IR-638-2), snapshot before update (IR-641-1),
   409 result on version mismatch (DNA-3), version journal append-only,
   RFC 3339 timestamps (DD-132), ParseDocument (DNA-1), tenantId (DNA-5)."

RAG RETRIEVAL TRIGGERS:
  - "optimistic concurrency post"  - "version conflict CMS"  - "ETag content update"
  - "concurrent edit content"  - "post version history"
```

---

## SK-149 — CMS Feed Query Pattern

```
SKILL:        SK-149
NAME:         CMS Feed Query Pattern
DOMAIN:       CMS Data Modeling / Family 85
FACTORIES:    F640 (ICmsQueryService), F638 (IPostService)
FLOW:         FLOW-20
TASK TYPES:   T255

PATTERN DESCRIPTION:
  Execute tenant-scoped, status-filtered CMS content queries for feed widgets.
  Always enforces status=Published for public feeds. Supports latest/category/tag
  filter combinations using BuildSearchFilter (DNA-2).

PRIMARY (.NET 9 key excerpt):
  var filter = BuildSearchFilter(new Dictionary<string, object>
  {
    ["tenantId"] = tenantId,     // DNA-5 — never skip
    ["siteId"]   = siteId,
    ["status"]   = "published",  // CF-306 — always for public feeds
    ["category"] = category,     // DNA-2 — skipped if empty
    ["tag"]      = tag,          // DNA-2 — skipped if empty
  });

AI AGENT PROMPT:
  "Generate CMS feed query service following SK-149.
   Rules: always filter status=published for public feeds (CF-306), BuildSearchFilter
   skips empty category/tag (DNA-2), tenantId + siteId mandatory (DNA-5),
   query definitions in ES not hardcoded (IR-640-2), DataProcessResult (DNA-3)."

RAG RETRIEVAL TRIGGERS:
  - "blog feed query"  - "CMS content listing"  - "post feed widget"
  - "category filter posts"  - "related posts"
```

---

## SK-150 — Publish Saga with Compensation Pattern

```
SKILL:        SK-150
NAME:         Publish Saga with Compensation Pattern
DOMAIN:       Publishing Pipeline / Family 87
FACTORIES:    F647 (IPublishJobService), F649 (IStaticBuildService),
              F648 (ICacheInvalidationService), F651 (ISitemapRssService),
              F652 (IPublishRollbackService)
FLOW:         FLOW-20
TASK TYPES:   T256, T258

PATTERN DESCRIPTION:
  Implements the full publish pipeline as a saga with compensation steps for
  partial failures. Each step is idempotent (idempotency-key enforced).
  Pipeline steps: render → CDN deploy → cache invalidate → sitemap refresh → search index.
  Compensation: if step N fails, steps N-1...1 are compensated in reverse.
  CloudEvents envelope on all job events (DD-132).

PIPELINE STEPS:
  1. SSG Build trigger (F649)
  2. CDN pointer swap (F649)
  3. Cache invalidation (F648)
  4. Sitemap + RSS refresh (F651)
  5. Search index update (F672)
  6. Audit log + completion (F670)

COMPENSATION STEPS (on failure):
  - Step 6 failure → log failure; step 5–1 already committed (partial success logged)
  - Step 3 failure → CDN still points to new artifact; re-trigger invalidation
  - Step 2 failure → rollback CDN pointer to previous version via F652

AI AGENT PROMPT:
  "Generate publish saga service following SK-150.
   Rules: idempotency-key in all job payloads (IR-647-1), CloudEvents envelope (DD-132),
   compensation steps on failure (IR-T256-4), cache invalidation confirmed before complete
   (QG-T256-3), all steps audit-logged (F670), tenantId on all ops (DNA-5)."

RAG RETRIEVAL TRIGGERS:
  - "publish pipeline"  - "content deploy saga"  - "publish compensation"
  - "SSG build trigger"  - "CDN deploy event"  - "cache invalidation publish"
```

---

## SK-151 — Idempotent Scheduled Publish Pattern

```
SKILL:        SK-151
NAME:         Idempotent Scheduled Publish Pattern
DOMAIN:       Publishing Pipeline / Family 87
FACTORIES:    F671 (ISchedulerService), F638 (IPostService), F647 (IPublishJobService)
FLOW:         FLOW-20
TASK TYPES:   T257

PATTERN DESCRIPTION:
  Time-based publish trigger that is fully idempotent. Handles duplicate fire events,
  post-already-published scenarios, and clock drift. RFC 3339 timestamp mandatory.
  Deduplication via idempotency-key = siteId + postId + publishAt-epoch.

AI AGENT PROMPT:
  "Generate scheduled publish trigger following SK-151.
   Rules: RFC 3339 publishAt (DD-132 / IR-T257-3), idempotency-key = siteId+postId+epoch,
   duplicate fire = no-op DataProcessResult (IR-T257-2), trigger at-or-after publishAt
   (IR-T257-1), post already Published = no-op, DataProcessResult for all states (DNA-3)."

RAG RETRIEVAL TRIGGERS:
  - "scheduled publish"  - "time-based publish trigger"  - "publish at future time"
  - "RFC 3339 scheduler"  - "idempotent job scheduler"
```

---

## SK-152 — Asset Upload Pipeline Pattern

```
SKILL:        SK-152
NAME:         Asset Upload Pipeline Pattern
DOMAIN:       Media Library / Family 90
FACTORIES:    F662 (IAssetUploadService), F663 (IImageTransformService),
              F664 (IAssetCdnService), F665 (IMediaLibraryService)
FLOW:         FLOW-20
TASK TYPES:   T264, T265

PATTERN DESCRIPTION:
  Multi-stage asset processing pipeline: presigned URL generation → upload confirmation
  → async transform pipeline (WebP, resize, responsive set) → CDN registration.
  Transform variants are immutable (each stored as new assetId). AI alt-text generation
  included as optional pipeline step with safety validation.

PIPELINE STAGES:
  Stage 1: InitiateUploadAsync (F662) → presigned URL with tenantId namespace
  Stage 2: CompleteUploadAsync (F662) → enqueue transform events via QUEUE FABRIC
  Stage 3: GenerateResponsiveSetAsync (F663) → WebP + 3 sizes (async, QUEUE FABRIC)
  Stage 4: GenerateAltTextAsync (F663) → AI-powered, safety validated, user-confirmable
  Stage 5: GetCdnUrlAsync (F664) → register CDN URL for each variant
  Stage 6: TagAssetAsync (F665) → register in media library

AI AGENT PROMPT:
  "Generate asset upload pipeline following SK-152.
   Rules: presigned URL with tenantId namespace (IR-662-2), transform variants as new assetId
   (IR-663-1), WebP generation async via QUEUE FABRIC (IR-663-2), AI alt-text requires
   safety validation + user confirmation (CF-321), all pipeline steps idempotent,
   tenantId on all operations (DNA-5)."

RAG RETRIEVAL TRIGGERS:
  - "asset upload pipeline"  - "image transform CDN"  - "responsive image generation"
  - "media library upload"  - "WebP AVIF conversion"  - "AI alt text generation"
```

---

## SK-153 — Hybrid SSR/SSG Rendering Pattern

```
SKILL:        SK-153
NAME:         Hybrid SSR/SSG Rendering Pattern
DOMAIN:       Publishing Pipeline + Visual Editor
FACTORIES:    F634 (ILivePreviewService), F649 (IStaticBuildService),
              F650 (IRenderRuntimeService)
FLOW:         FLOW-20
TASK TYPES:   T250, T259, T263

PATTERN DESCRIPTION:
  Two-mode rendering architecture enforcing DD-131:
  - PREVIEW MODE: always SSR via F650 (IRenderRuntimeService) — fresh on every request
  - PUBLISHED MODE: SSG artifact via F649 (IStaticBuildService) — CDN-cached
  
  The engine NEVER serves an SSG artifact to a preview request.
  The engine NEVER triggers an SSR render for a published production page.
  Mode selection is determined by request context (editor session vs public URL).

ROUTING LOGIC:
  if (request.HasEditorSession) {
    // CF-316: MUST NOT use F649 artifact
    return await renderRuntime.RenderPageAsync(siteId, slug, tenantId); // F650 SSR
  } else {
    // Return CDN URL pointing to F649 build artifact
    return await cdnService.GetCdnUrlAsync(assetId, variant, tenantId); // F664
  }

AI AGENT PROMPT:
  "Generate hybrid rendering service following SK-153.
   Rules: editor session = SSR via F650 ALWAYS (DD-131 / CF-316),
   published = SSG CDN artifact via F649, no SSG artifact in preview path (IR-634-1),
   mode detection from request context not URL pattern, tenantId isolation (DNA-5)."

RAG RETRIEVAL TRIGGERS:
  - "SSR SSG hybrid rendering"  - "live preview vs published"
  - "editor preview render"  - "static site generation"  - "CDN artifact rendering"
```

---

## SK-154 — SEO + Sitemap Pipeline Pattern

```
SKILL:        SK-154
NAME:         SEO + Sitemap Pipeline Pattern
DOMAIN:       Routing / SEO / Family 89-87
FACTORIES:    F651 (ISitemapRssService), F657 (ISlugService),
              F659 (ISeoMetadataService), F658 (IRedirectService)
FLOW:         FLOW-20
TASK TYPES:   T260

PATTERN DESCRIPTION:
  Generates SEO metadata, sitemap.xml, and RSS feed from published CMS content.
  Enforces: published-only URLs in sitemap (CF-306), tenantId scoping (CF-314),
  AI-generated SEO meta with user confirmation gate (CF-321),
  auto-redirect on slug change (CF-303).

AI AGENT PROMPT:
  "Generate SEO + sitemap service following SK-154.
   Rules: sitemap contains ONLY published posts (CF-306), tenantId + siteId scoped (CF-314),
   AI SEO meta requires user confirmation before write (CF-321 / IR-659-1),
   slug change creates 301 redirect (CF-303 / IR-657-1), no base64 in OG images (IR-659-2),
   BuildSearchFilter for all ES queries (DNA-2), DataProcessResult (DNA-3)."

RAG RETRIEVAL TRIGGERS:
  - "sitemap generation"  - "SEO metadata"  - "RSS feed"  - "slug redirect"
  - "OG image"  - "meta title description CMS"  - "search engine optimization"
```

---

## AF-4 RAG INDEX — FLOW-20 ADDITIONS

| Skill | Keywords | Task Types | Domain |
|-------|----------|------------|--------|
| SK-145 | page tree, node mutation, version snapshot, editor lock | T247, T249 | Visual Editor |
| SK-146 | JSON Schema 2020-12, PostType, schema registry, additive | T248, T251 | CMS Modeling |
| SK-147 | collection relation, referential integrity, circular detection | T251, T254 | CMS |
| SK-148 | optimistic concurrency, ETag, version conflict, content write | T252 | Content Auth |
| SK-149 | feed query, published filter, BuildSearchFilter, CMS widget | T255 | CMS |
| SK-150 | publish saga, pipeline steps, compensation, CloudEvents | T256, T258 | Publishing |
| SK-151 | scheduled publish, RFC 3339, idempotent trigger, time-based | T257 | Publishing |
| SK-152 | asset upload, image transform, CDN, WebP, responsive set | T264, T265 | Media |
| SK-153 | SSR SSG hybrid, live preview, published CDN, mode routing | T250, T259 | Rendering |
| SK-154 | sitemap, RSS, SEO meta, slug redirect, OG image | T260 | SEO/Routing |

---

## BACKWARD COMPATIBILITY
```
SK-1–SK-144:  UNCHANGED ✅
New: SK-145–SK-154 (10 skills)
```

---

## SAVE POINT: FLOW20:P4:SKILLS:COMPLETE ✅
## Recovery: "FLOW-20 P4 complete. SK-145–SK-154. Continue with P5 unified source index."
