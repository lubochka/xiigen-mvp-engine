# UNIFIED SOURCE INDEX — FLOW-20 EXTENSION
# Visual Editor & Site Builder Platform
# Extends: UNIFIED_SOURCE_INDEX_MERGED.md (DD-1–DD-129, DR-1–DR-98)
# FLOW-20 adds: DD-130–DD-141 (12 design decisions) | DR-99–DR-106 (8 design records)
# Save Point: FLOW20:P5:INDEX:COMPLETE

---

## STATE REFERENCE
```
Previous: DD-1–DD-129 | DR-1–DR-98 — UNIFIED_SOURCE_INDEX_MERGED.md
This file: DD-130–DD-141 (12 new) | DR-99–DR-106 (8 new)
Next: SESSION_STATE (global tracker update)
```

---

## DESIGN DECISIONS — FLOW-20

Design Decisions record WHY a significant architectural choice was made.
Format: ID | Decision | Alternatives considered | Rationale | Enforcing artifacts

---

### DD-130 — JSON Schema 2020-12 for Post Type Schema Registry

```
ID:           DD-130
DOMAIN:       CMS & Content (Family 85)
DECISION:     Post Type schemas (F637 IPostTypeRegistryService, F639 IPostTypeSchemaService)
              use JSON Schema 2020-12 as the canonical contract for content validation
              and admin form generation.
ALTERNATIVES:
  A) TypeScript interface (code-as-schema): tight coupling to runtime; requires code deploy
     for schema changes; not readable by non-technical admins. REJECTED.
  B) Custom schema format: no ecosystem tooling; must write custom validator. REJECTED.
  C) GraphQL SDL: strong for API contracts; not designed for form generation or admin UIs. REJECTED.
  D) JSON Schema 2020-12 (CHOSEN): published spec; wide tooling; supports $ref,
     unevaluatedProperties, vocabulary extensibility; readable by admins; version-tracked.
RATIONALE:    Schema changes must not require code deployment (FREEDOM principle).
              Admins must configure new PostTypes without developer involvement.
              JSON Schema 2020-12 is the current released version with broadest tooling.
SOURCES:      22-visual-editor-deep-search.md (schema validation requirement);
              basic_prompt.txt (FREEDOM: admin-configurable values)
ENFORCING:    F637, F639, T248, T251, SK-146, CF-297, CF-313
```

---

### DD-131 — Hybrid SSR/SSG Rendering (Not Pure SSG)

```
ID:           DD-131
DOMAIN:       Publishing Pipeline (Family 87)
DECISION:     Rendering uses hybrid SSR+SSG:
              PREVIEW/EDITOR: always SSR via F650 IRenderRuntimeService (always fresh)
              PUBLISHED CONTENT: SSG via F649 IStaticBuildService (CDN-cached, fast)
ALTERNATIVES:
  A) Pure SSG: simplest for publishing; but live preview impossible without rebuild. REJECTED.
  B) Pure SSR: live preview works; but prohibitive runtime cost at high traffic. REJECTED.
  C) Hybrid SSR/SSG (CHOSEN): preview via SSR (always fresh); published via SSG (fast, CDN).
     Satisfies both 22-*-deep-search-engine.md requirements: live preview + high-performance pages.
RATIONALE:    22-* specs require both live preview (needs SSR) and high-performance published
              pages (needs SSG/CDN). Hybrid is the only approach satisfying both.
              CF-316 enforces preview-always-SSR invariant.
SOURCES:      22-visual-editor-deep-search.md (SSR/SSG alternatives table);
              22-visual-editor-deep-search-engine.md (live preview requirement)
ENFORCING:    F634, F649, F650, T250, T259, CF-316, SK-153
```

---

### DD-132 — CloudEvents Envelope for All Pipeline Events

```
ID:           DD-132
DOMAIN:       Publishing Pipeline (Family 87) + QUEUE FABRIC
DECISION:     All inter-service events in FLOW-20 use CloudEvents-compatible envelope:
              {source, type, subject, time, datacontenttype, data, id (idempotency-key)}
ALTERNATIVES:
  A) Raw JSON payload: fast; no standard metadata; custom correlation IDs required. REJECTED.
  B) Custom engine envelope: consistent within engine; creates another non-standard format. REJECTED.
  C) CloudEvents (CHOSEN): CNCF-backed open spec; standardized metadata; supports correlation IDs
     (source+id); works with existing QUEUE FABRIC consumers unchanged; tracing-ready.
RATIONALE:    22-*-deep-search-engine.md explicitly recommends CloudEvents for event envelopes.
              Aligns with BFA cross-flow rules (CF-311–CF-318) requiring cross-service tracing.
SOURCES:      22-visual-editor-deep-search-engine.md (CloudEvents recommendation)
ENFORCING:    CF-318, T256, T257, AF-7 Compliance check, IR-647-3
```

---

### DD-133 — Elasticsearch as Primary Store with PostgreSQL State Journal

```
ID:           DD-133
DOMAIN:       Visual Editor + CMS (Families 84, 85)
DECISION:     Page trees (F631) and post content (F638) use Elasticsearch as primary
              queryable store. PostgreSQL used for state machine records (post lifecycle
              transitions) and append-only version journals (content history).
ALTERNATIVES:
  A) MongoDB: good for documents; but adds a DB provider not currently primary in the engine. REJECTED.
  B) Pure PostgreSQL: strong ACID; but CMS full-text search and tree diffing are ES strengths;
     JSONB less flexible for dynamic document queries. REJECTED.
  C) ES + PG (CHOSEN): ES for flexible document queries, full-text, aggregations;
     PG for state machine records, append-only journals, strict ACID transactions.
RATIONALE:    Both are already in DATABASE FABRIC (Skill 05) — zero new provider dependencies.
              ES handles dynamic Dictionary<string,object> documents natively (DNA-1).
              PG append-only tables provide tamper-evident version history (IR-641-1).
SOURCES:      22-visual-editor-deep-search-engine.md (persistence strategy);
              22-visual-editor-deep-search.md (CMS requirements)
ENFORCING:    F631, F638, F641, F652, F667, T252, T253
```

---

### DD-134 — Optimistic Concurrency for Content Editing (No Pessimistic Locks)

```
ID:           DD-134
DOMAIN:       Content Authoring (Family 86) + CMS (Family 85)
DECISION:     Content writes (F638, F631) use ETag/If-Match optimistic concurrency.
              Concurrent update without matching version = 409 DataProcessResult.
              No pessimistic locking for content edits.
ALTERNATIVES:
  A) Pessimistic locking: guarantees one writer at a time; but blocks parallel editing; deadlock
     risk; poor UX for collaborative editing. REJECTED.
  B) Last-write-wins: simple; but silently loses data — unacceptable for CMS. REJECTED.
  C) Optimistic concurrency (CHOSEN): writer must prove their version matches current;
     conflicts surface as 409 for user-visible merge resolution; no blocked threads.
RATIONALE:    Collaborative multi-author editing is a core FLOW-20 requirement
              (22-visual-editor.md). Pessimistic locks block collaboration.
              ETag/If-Match is a proven HTTP-level pattern; implementable in DATABASE FABRIC.
SOURCES:      22-visual-editor.md (multi-author editing); 22-visual-editor-deep-search.md
ENFORCING:    F638, F641, T252, CF-302, SK-148, IR-642-1
```

---

### DD-135 — Workspace = Unit of Multi-Tenancy Isolation

```
ID:           DD-135
DOMAIN:       Multi-Tenant Support (Family 90)
DECISION:     All FLOW-20 resources are scoped to a workspaceId (≡ tenantId in prior flows).
              workspaceId is present on every DB query, queue event, and API endpoint.
              Workspace provisioning is an atomic transaction (F671 IWorkspaceProvisionService).
ALTERNATIVES:
  A) Global namespace (no workspace isolation): ignores multi-tenancy requirement. REJECTED.
  B) Per-table tenant column: works but doesn't prevent cross-tenant query bugs without
     enforcement at the fabric level. REJECTED.
  C) Workspace ≡ tenantId (CHOSEN): reuses DNA-5 Scope Isolation pattern already in MicroserviceBase;
     workspaceId flows from AuthContext.TenantId; zero additional infrastructure.
RATIONALE:    22-visual-editor-deep_search_engine_multi_tenant.md mandates per-workspace isolation.
              Reusing tenantId pattern avoids adding a new isolation dimension.
              DNA-5 enforcement catches any query missing workspaceId at compliance scan time.
SOURCES:      22-visual-editor-deep_search_engine_multi_tenant.md;
              basic_prompt.txt (DNA-5: Scope Isolation)
ENFORCING:    F671, F672, F673, T266, CF-307, CF-322, SK-145 (note), AF-7
```

---

### DD-136 — Design Token Inheritance Tree (CSS Custom Properties + Build-Time Resolution)

```
ID:           DD-136
DOMAIN:       Design Tokens (Family 89)
DECISION:     Design tokens stored as inheritance trees in ES (F656 IDesignTokenService).
              Parent → child token resolution happens at build time (F649 IStaticBuildService).
              Runtime: CSS Custom Properties injected; no server-side resolution per request.
ALTERNATIVES:
  A) Runtime server-side token resolution per request: flexible but high latency. REJECTED.
  B) Flat token map (no inheritance): simple; but prevents theming/variant systems. REJECTED.
  C) CSS Custom Properties + build-time resolution (CHOSEN): inheritance tree stored in ES;
     build pipeline resolves and outputs :root { --token: value } CSS; CDN-cached.
RATIONALE:    Admins need to create theme variants without code (FREEDOM).
              Build-time resolution gives CDN-cached zero-latency output.
              CSS Custom Properties are browser-native — no JS runtime dependency.
SOURCES:      22-visual-editor-deep-search-engine.md (design token system)
ENFORCING:    F656, F633, T261, T262, SK-146 (extended), CF-303
```

---

### DD-137 — Component Registry is Immutable + Append-Only (Version-Tagged)

```
ID:           DD-137
DOMAIN:       Visual Editor (Family 84)
DECISION:     Component registry entries (F632 IComponentRegistryService) are immutable
              after publication. Updates create a new version; old versions remain active
              for backward compatibility until explicitly deprecated.
ALTERNATIVES:
  A) Mutable registry: simple; but existing pages referencing old version silently break. REJECTED.
  B) Replace on update: breaks live pages that use the previous component version. REJECTED.
  C) Append-only versioned registry (CHOSEN): new version = new registry entry; pages
     reference component@version; old pages continue to work; deprecation is explicit.
RATIONALE:    Sites in production must not break when a component is updated
              (backward compatibility = a core engine principle from basic_prompt.txt).
              22-visual-editor.md requires component versioning.
SOURCES:      basic_prompt.txt (backward compatibility); 22-visual-editor.md
ENFORCING:    F632, T247, T248, CF-295, CF-301, IR-631-1
```

---

### DD-138 — AI Content Assist is Non-Blocking (Fire-and-Suggest Pattern)

```
ID:           DD-138
DOMAIN:       AI Assist (Family 88)
DECISION:     AI content assistance (F658 IAiContentAssistService) is non-blocking:
              user writes freely; AI suggestions arrive asynchronously via QUEUE FABRIC;
              user accepts/rejects; AI output never blocks the save path.
ALTERNATIVES:
  A) Blocking AI call on save: simple integration; but adds latency to every save. REJECTED.
  B) Inline autocomplete (synchronous): good UX; but ties every keystroke to AI latency. REJECTED.
  C) Fire-and-suggest async (CHOSEN): user initiates save immediately; AI suggestion arrives
     via event; UI shows suggestion overlay; user action required to apply. Non-blocking save path.
RATIONALE:    AI latency (100ms–5s) must not gate content saves (basic_prompt.txt: DataProcessResult
              never throws for business logic — DNA-3). Non-blocking preserves author flow.
              22-visual-editor.md requires AI assist without blocking authoring.
SOURCES:      22-visual-editor.md (AI assist); basic_prompt.txt (DNA-3)
ENFORCING:    F658, F659, T263, SK-149 (extended), CF-309
```

---

### DD-139 — Single-Pass Media Transform Pipeline (No Re-Origination)

```
ID:           DD-139
DOMAIN:       Media Pipeline (Family 89)
DECISION:     All media transforms (F661 IMediaTransformService) operate from the
              original upload only. Transformed variants are never re-transformed.
              Originals are stored immutably in CDN cold storage (F662 ICdnStorageService).
ALTERNATIVES:
  A) Re-transform from previous variant: allows chained transforms; but quality degrades
     (lossy formats); provenance lost. REJECTED.
  B) Store all intermediate variants: full provenance; but exponential storage growth. REJECTED.
  C) Single-pass from original (CHOSEN): original immutable; all variants derived from original;
     re-derive on demand; predictable quality; storage = original + named variants only.
RATIONALE:    22-visual-editor-deep-search.md (media pipeline requirements).
              Single-pass from original is the industry standard (imgix, Cloudinary model).
              Aligns with QUEUE FABRIC async processing (F663 IMediaProcessingQueueService).
SOURCES:      22-visual-editor-deep-search.md; 22-visual-editor-deep-search-engine.md
ENFORCING:    F661, F662, F663, T264, T265, CF-319, SK-152
```

---

### DD-140 — SEO Outputs are Engine-Generated (Not Handwritten)

```
ID:           DD-140
DOMAIN:       SEO & Routing (Family 87 extension)
DECISION:     Sitemap XML, RSS feeds, OG images, structured data (JSON-LD), and canonical
              redirects are generated by the engine at publish time (F657 ISeoMetaService,
              F660 ISitemapService). Admins configure rules; engine generates output.
ALTERNATIVES:
  A) Manual SEO markup: error-prone; requires developer per-page. REJECTED.
  B) Plugin/third-party SEO tool: external dependency; breaks FREEDOM architecture. REJECTED.
  C) Engine-generated SEO outputs (CHOSEN): admins configure SEO rules as FREEDOM config;
     engine generates canonical sitemap/RSS/OG at publish time via T260; zero manual markup.
RATIONALE:    FREEDOM principle: admins configure, engine generates.
              SEO outputs must be consistent, complete, and not require developer intervention.
SOURCES:      22-visual-editor-deep-search.md (SEO requirements); basic_prompt.txt (FREEDOM)
ENFORCING:    F657, F660, T260, CF-310, SK-154
```

---

### DD-141 — BFA Registers FLOW-20 Entities Against All Prior Flows at Provision Time

```
ID:           DD-141
DOMAIN:       BFA Cross-Flow Validation
DECISION:     On workspace provisioning (F671), the BFA automatically registers all
              FLOW-20 entity types, event topics, and API paths against the global
              BFA index. Conflict checks run at provision time before any content is created.
ALTERNATIVES:
  A) Lazy registration (register on first use): defers conflicts to runtime; too late. REJECTED.
  B) Manual BFA registration by developers: error-prone; easily forgotten. REJECTED.
  C) Provision-time auto-registration (CHOSEN): F671 provisioning step includes BFA index
     update; conflicts with FLOW-01–FLOW-17 detected before workspace is activated.
RATIONALE:    22-visual-editor-deep_search_engine_multi_tenant.md: workspace provisioning
              must be atomic and validated. BFA must catch conflicts before users encounter them.
              Aligns with "BFA detects conflicts BEFORE code ships" (basic_prompt.txt).
SOURCES:      basic_prompt.txt (BFA guardrails); 22-visual-editor-multi-tenant-support.md
ENFORCING:    F671, CF-307, CF-322, T266, AF-9 quality gate
```

---

## DESIGN RECORDS — FLOW-20

Design Records document WHAT was built and PROVE it conforms to requirements.
Format: ID | Requirement → Implementation traceability | Validation evidence

---

### DR-99 — Visual Editor Canvas: Requirement Traceability

```
ID:           DR-99
REQUIREMENT:  22-visual-editor.md: "drag-and-drop visual editor for page composition
              with component library, undo/redo, and live preview"
IMPLEMENTATION:
  F631 IPageTreeService          → page tree storage + snapshot for undo/redo
  F632 IComponentRegistryService → component library (versioned, append-only per DD-137)
  F633 IEditorCanvasService      → drag-and-drop canvas orchestration
  F634 ILivePreviewService       → SSR live preview per DD-131
  T247 (Visual Edit Node)        → engine contract for canvas mutation
  T249 (Canvas Snapshot)         → undo/redo snapshot management
  T250 (Live Preview Render)     → SSR preview rendering contract
VALIDATION:
  CF-295 (component version locked at placement)
  CF-300 (snapshot before mutation)
  CF-316 (preview always SSR)
  SK-145 (RAG: page tree mutation patterns)
STATUS:       COMPLETE ✅
```

---

### DR-100 — CMS Post Lifecycle: Requirement Traceability

```
ID:           DR-100
REQUIREMENT:  22-visual-editor.md: "headless CMS with post types, editorial workflow
              (draft/review/published), and scheduled publishing"
IMPLEMENTATION:
  F637 IPostTypeRegistryService  → admin-defined post types (JSON Schema 2020-12, DD-130)
  F638 IPostContentService       → content authoring + optimistic concurrency (DD-134)
  F641 IEditorialWorkflowService → draft→review→published state machine
  F646 IContentSchedulerService  → scheduled publish (RFC 3339, T257)
  F647 IPublishGatekeeperService → pre-publish validation gate
  T252 (Draft Content)           → content authoring engine contract
  T253 (Publish Gate)            → gatekeeper + schedule branch
  T256 (Publish Saga)            → async publish pipeline with compensation
  T257 (Scheduled Publish)       → time-triggered publish contract
VALIDATION:
  CF-297 (PostType changes additive only)
  CF-298 (publication state machine transitions)
  CF-305 (no direct-to-published without review gate)
  SK-146 (RAG: schema patterns), SK-148 (RAG: concurrency patterns)
STATUS:       COMPLETE ✅
```

---

### DR-101 — Publishing Pipeline: Requirement Traceability

```
ID:           DR-101
REQUIREMENT:  22-visual-editor-deep-search.md: "static site generation pipeline with
              CDN invalidation, sitemap, RSS, and structured data output"
IMPLEMENTATION:
  F648 IPublishEventBusService   → CloudEvents envelope (DD-132) for pipeline steps
  F649 IStaticBuildService       → SSG build pipeline
  F650 IRenderRuntimeService     → SSR for preview (hybrid DD-131)
  F651 ICdnInvalidationService   → CDN cache invalidation post-build
  F657 ISeoMetaService           → structured data / OG image generation (DD-140)
  F660 ISitemapService           → sitemap XML + RSS feed generation (DD-140)
  T256 (Publish Saga)            → coordinated pipeline with compensation
  T259 (SSR/SSG Render Gate)     → routing to correct render mode
  T260 (SEO Build Gate)          → SEO outputs at publish time
VALIDATION:
  CF-306 (CDN invalidation before new content visible)
  CF-316 (preview always SSR)
  CF-318 (CloudEvents envelope on all events)
  SK-150 (RAG: publish saga patterns), SK-154 (RAG: SEO patterns)
STATUS:       COMPLETE ✅
```

---

### DR-102 — Design Token System: Requirement Traceability

```
ID:           DR-102
REQUIREMENT:  22-visual-editor-deep-search-engine.md: "design token system with
              inheritance tree, theme variants, and build-time CSS variable resolution"
IMPLEMENTATION:
  F656 IDesignTokenService        → token inheritance tree storage + resolution (DD-136)
  F633 IEditorCanvasService       → token-aware canvas rendering
  F649 IStaticBuildService        → build-time CSS Custom Property injection (DD-136)
  F653 IThemeVariantService       → admin-configurable theme variants
  T261 (Token Propagation)        → engine contract for token change → rebuild trigger
  T262 (Theme Variant Switch)     → variant activation contract
VALIDATION:
  CF-303 (design token changes trigger rebuild)
  CF-315 (tokens resolved before build outputs)
  SK-146 (extended: token inheritance patterns)
  DD-136 (architectural rationale)
STATUS:       COMPLETE ✅
```

---

### DR-103 — Media Pipeline: Requirement Traceability

```
ID:           DR-103
REQUIREMENT:  22-visual-editor-deep-search.md: "asset management with image transforms
              (WebP, responsive sets), CDN storage, and async processing queue"
IMPLEMENTATION:
  F661 IMediaTransformService      → single-pass transforms from original (DD-139)
  F662 ICdnStorageService          → immutable cold storage for originals
  F663 IMediaProcessingQueueService → async transform queue via QUEUE FABRIC
  F664 IMediaMetadataService       → EXIF, alt-text, dimensions metadata
  T264 (Asset Upload)              → upload + original storage contract
  T265 (Image Transform)           → WebP + responsive set generation contract
  T266 (Asset Replace)             → replace original + re-derive all variants
VALIDATION:
  CF-319 (originals immutable after upload)
  CF-320 (transforms queue-async, not blocking upload response)
  SK-152 (RAG: asset pipeline patterns)
  DD-139 (single-pass rationale)
STATUS:       COMPLETE ✅
```

---

### DR-104 — AI Content Assist: Requirement Traceability

```
ID:           DR-104
REQUIREMENT:  22-visual-editor.md: "AI-powered content suggestions, auto-tagging,
              and SEO recommendations integrated into the editor"
IMPLEMENTATION:
  F658 IAiContentAssistService     → non-blocking AI suggestions via AI ENGINE FABRIC (DD-138)
  F659 IAiTaggingService           → auto-tagging via IAiProvider.GenerateAsync()
  F665 ISeoRecommendationService   → SEO recommendations via AI + rule engine hybrid
  T263 (AI Content Suggestion)     → fire-and-suggest async contract
  T254 (Editorial Review + AI Assist) → AI assist in review workflow
VALIDATION:
  CF-309 (AI assist non-blocking on save path)
  CF-312 (AI provider resolved via AI ENGINE FABRIC only)
  SK-149 (extended: feed query + AI assist patterns)
  DD-138 (non-blocking rationale)
STATUS:       COMPLETE ✅
```

---

### DR-105 — Multi-Tenant Workspace Isolation: Requirement Traceability

```
ID:           DR-105
REQUIREMENT:  22-visual-editor-deep-search-engine-multi-tenant.md: "per-workspace
              isolation for all resources, users, sites, and content"
IMPLEMENTATION:
  F671 IWorkspaceProvisionService  → atomic workspace creation + BFA registration (DD-141)
  F672 IWorkspaceRoleService       → RBAC within workspace boundary
  F673 IWorkspaceBillingService    → per-workspace usage tracking + limits
  F674 IWorkspaceAnalyticsService  → per-workspace analytics (scope-isolated)
  T266 (Workspace Provision)       → provision + BFA register contract
  DNA-5 Scope Isolation            → workspaceId on every query (≡ tenantId)
VALIDATION:
  CF-307 (workspaceId on all FLOW-20 queries)
  CF-322 (workspace provision atomic + BFA validated)
  DD-135 (workspace = tenantId rationale)
  AF-7 compliance scan: workspaceId presence
STATUS:       COMPLETE ✅
```

---

### DR-106 — Genie DNA Full Compliance Audit: FLOW-20

```
ID:           DR-106
AUDIT TYPE:   Full DNA compliance check — all 6 patterns vs FLOW-20 factories
SCOPE:        F631–F674 (44 factories), T247–T266 (20 task types)

DNA-1 ParseDocument (Dictionary, not typed models):
  STATUS: ✅ ALL 44 factories use Dictionary<string,object> via ObjectProcessor
  EVIDENCE: T247 IR: "content payload must be parsed via ParseDocument — no typed models"
            CF-295, CF-301, SK-145 all enforce Dictionary-first patterns

DNA-2 BuildQueryFilters (empty fields auto-skipped):
  STATUS: ✅ ALL DATABASE FABRIC calls in FLOW-20 use BuildSearchFilter
  EVIDENCE: F631, F638, F641, F652, F655, F667 all reference BuildSearchFilter in IRON RULES

DNA-3 DataProcessResult<T> (never throw for business logic):
  STATUS: ✅ ALL task types return DataProcessResult; iron rules prohibit throws
  EVIDENCE: All T247–T266 IRON RULES include "return DataProcessResult on all errors"
            CF-308 prohibits exceptions in publish pipeline

DNA-4 MicroserviceBase (19 components inherited):
  STATUS: ✅ ALL generated services extend MicroserviceBase (IRON RULES enforce)
  EVIDENCE: T247 IR-1: "all services extend MicroserviceBase"; repeated in every task type
            AF-7 Compliance station validates this at generation time

DNA-5 Scope Isolation (workspaceId ≡ tenantId on every query):
  STATUS: ✅ workspaceId present on all F631–F674 queries per DD-135
  EVIDENCE: CF-307 enforces workspaceId; AF-7 compliance scan flags any missing workspaceId

DNA-6 DynamicController (no entity-specific controllers):
  STATUS: ✅ All FLOW-20 APIs route through DynamicController
  EVIDENCE: No entity-specific controller created in F631–F674 definitions
            CF-295 (component), CF-297 (post type) both enforce DynamicController routing

OVERALL DNA COMPLIANCE: ✅ 6/6 — ZERO VIOLATIONS
PROMOTION LADDER:       GENERATED → INJECTED (after AF-6/AF-7 pass) → MINIMAL → CORE
STATUS:       COMPLETE ✅
```

---

## CROSS-REFERENCE MAP — FLOW-20

```
22-visual-editor.md                            → Families 84, 85, 86, 88
22-visual-editor-deep-search.md                → Families 85, 86, 87, 89 (media)
22-visual-editor-deep-search-engine.md         → Families 84, 87, 88, 89 (tokens)
22-visual-editor-deep-search-engine-multi-tenant.md → Family 90

DD-130  → F637, F639, SK-146
DD-131  → F634, F649, F650, SK-153
DD-132  → F648, CF-318
DD-133  → F631, F638, F652
DD-134  → F638, F641, SK-148
DD-135  → F671–F674, CF-307
DD-136  → F656, F649, F653
DD-137  → F632, CF-295
DD-138  → F658, F659, CF-309
DD-139  → F661, F662, F663
DD-140  → F657, F660, CF-310
DD-141  → F671, CF-322

DR-99   → F631–F634, T247, T249, T250
DR-100  → F637, F638, F641, F646, F647, T252, T253, T256, T257
DR-101  → F648–F651, F657, F660, T256, T259, T260
DR-102  → F649, F653, F656, T261, T262
DR-103  → F661–F664, T264–T266
DR-104  → F658, F659, F665, T254, T263
DR-105  → F671–F674, T266
DR-106  → All F631–F674, all T247–T266 (DNA audit)
```

---

## BACKWARD COMPATIBILITY
```
DD-1–DD-129:  UNCHANGED ✅
DR-1–DR-98:   UNCHANGED ✅
New: DD-130–DD-141 (12 design decisions)
New: DR-99–DR-106 (8 design records)
System total: DD-1–DD-141 | DR-1–DR-106
```

---

## SAVE POINT: FLOW20:P5:INDEX:COMPLETE ✅
## Recovery: "FLOW-20 P5 complete. DD-130–DD-141 / DR-99–DR-106. Continue with P6 session state."
