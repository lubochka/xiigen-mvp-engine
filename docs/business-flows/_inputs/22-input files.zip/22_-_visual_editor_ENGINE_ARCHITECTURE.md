# ENGINE ARCHITECTURE — FLOW-20 EXTENSION
# Visual Editor & Site Builder Platform
# Extends: ENGINE_ARCHITECTURE_MERGED.md (F1–F630, Families 1–83)
# FLOW-20 adds: F631–F674 (44 factories) | Families 84–90 (7 families)
# Save Point: FLOW20:P1:ENGINE_ARCH:COMPLETE

---

## STATE REFERENCE
```
Previous: F1–F630 | Families 1–83 — ENGINE_ARCHITECTURE_MERGED.md
This file: F631–F674 (44 new) | Families 84–90 (7 new)
Next: TASK_TYPES_CATALOG (T247–T266)
```

---

## FABRIC RESOLUTION QUICK-REFERENCE

| Fabric | Skill | Resolution |
|--------|-------|------------|
| DATABASE FABRIC | Skill 05 — IDatabaseService | ES/MongoDB/PG/Redis/MySQL/SQLServer |
| QUEUE FABRIC | Skill 04 — IQueueService | EnqueueAsync/DequeueAsync/AcknowledgeAsync |
| AI ENGINE FABRIC | Skills 06/07 — IAiProvider + AiDispatcher | GenerateAsync via config |
| RAG FABRIC | Skills 00a/00b — IRagService | SearchAsync via 7 strategies |
| CORE FABRIC | Skill 01 — MicroserviceBase | 19 components inherited |
| FLOW ENGINE FABRIC | Skills 08/09 — IFlowDefinition + IFlowOrchestrator | DAG in ES |

---

## GENIE DNA — 6 PATTERNS (ALL generated services)
```
DNA-1  ParseDocument        Dictionary<string,object> — NEVER typed models
DNA-2  BuildSearchFilter    empty fields auto-skipped
DNA-3  DataProcessResult<T> NEVER throw for business logic
DNA-4  MicroserviceBase     19 components — ALL services
DNA-5  Scope Isolation      tenantId on EVERY query/cache/index
DNA-6  DynamicController    no entity-specific controllers
```

---

## FAMILY 84 — VISUAL EDITOR (Page Builder)

### F631 — IPageTreeService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    GetTreeAsync / StoreNodeAsync / MoveNodeAsync / DeleteNodeAsync / GetVersionAsync
IRON RULES:
  IR-631-1: tree mutations MUST write version snapshot before modifying (append-only)
  IR-631-2: tenantId + siteId composite key on every ES document
  IR-631-3: node IDs are UUIDs — never sequential integers
```

### F632 — IComponentRegistryService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    RegisterComponentAsync / GetComponentAsync / ListComponentsAsync / ValidateComponentAsync
IRON RULES:
  IR-632-1: components immutable once published — new version = new componentId
  IR-632-2: system-level components (tenantId=SYSTEM) readable by all tenants
```

### F633 — IResponsiveLayoutService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Redis (hot read path)
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    GetBreakpointsAsync / SetBreakpointAsync / ResolveLayoutAsync
IRON RULES:
  IR-633-1: breakpoint cache MUST invalidate when design tokens update (CF-295)
  IR-633-2: layout resolution is read-only — mutations go through F631
```

### F634 — ILivePreviewService
```
FABRIC:     AI ENGINE FABRIC (Skill 07) → AiDispatcher
RESOLUTION: CreateAsync(ctx{tenantId, siteId})  Config: visual_editor.live_preview.ai_provider
METHODS:    RenderPreviewAsync / StreamPreviewAsync / ValidatePreviewAsync
IRON RULES:
  IR-634-1: preview ALWAYS uses SSR path — never stale SSG artifact (DD-131)
  IR-634-2: rendered preview isolated per tenantId
```

### F635 — ICollaborationLockService
```
FABRIC:     QUEUE FABRIC (Skill 04) → Redis Streams
RESOLUTION: CreateAsync(ctx{tenantId})  Config: visual_editor.collab.queue_provider
METHODS:    AcquireLockAsync / ReleaseLockAsync / GetActiveLocks / BroadcastPresenceAsync
IRON RULES:
  IR-635-1: locks expire after configurable TTL (FREEDOM: collab.lock_ttl_seconds)
  IR-635-2: ETag/If-Match enforced before any write (DD-133)
```

### F636 — IEditorSessionService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Redis
RESOLUTION: CreateAsync(ctx{tenantId, userId})
METHODS:    CreateSessionAsync / UpdateSessionAsync / GetSessionAsync / ExpireSessionAsync
IRON RULES:
  IR-636-1: session data never contains PII beyond userId reference
  IR-636-2: sessions scoped by tenantId — no global session store
```

---

## FAMILY 85 — CMS DATA MODELING

### F637 — IPostTypeRegistryService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    RegisterPostTypeAsync / GetPostTypeAsync / ListPostTypesAsync / UpdatePostTypeSchemaAsync
IRON RULES:
  IR-637-1: schema format MUST be JSON Schema 2020-12 (DD-130)
  IR-637-2: schema updates additive only — no field removals
  IR-637-3: schema versioned — each update increments schema_version
```

### F638 — IPostService
```
FABRIC:     DATABASE FABRIC → Elasticsearch (primary) + PostgreSQL (state journal)
RESOLUTION: CreateAsync(ctx{tenantId, siteId, postTypeId})
METHODS:    CreatePostAsync / UpdatePostAsync / GetPostAsync / TransitionStatusAsync /
            QueryPostsAsync / GetVersionHistoryAsync
IRON RULES:
  IR-638-1: valid transitions ONLY: Draft→Published, Draft→Scheduled, Scheduled→Published,
            Published→Archived — any other = BUILD FAILURE
  IR-638-2: version field enforced — concurrent update without matching version = 409 result
  IR-638-3: publishAt uses RFC 3339 format (DD-132)
```

### F639 — IPostTypeSchemaService
```
FABRIC:     RAG FABRIC (Skills 00a/00b) → Hybrid strategy
RESOLUTION: CreateAsync(ctx{tenantId})  Config: cms.schema.rag_strategy
METHODS:    ValidateDocumentAsync / GenerateFormSchemaAsync / SuggestFieldsAsync /
            GetSchemaEmbeddingAsync
IRON RULES:
  IR-639-1: form schema generation derives from PostType — never hardcoded
  IR-639-2: AI field suggestions require admin approval before schema commit
```

### F640 — ICmsQueryService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    ExecuteQueryAsync / BuildFeedQueryAsync / GetRelatedPostsAsync / SearchPostsAsync
IRON RULES:
  IR-640-1: ALL queries MUST include tenantId filter (DNA-5)
  IR-640-2: query definitions are JSON documents in ES — no hardcoded query objects
```

### F641 — IContentVersionService
```
FABRIC:     DATABASE FABRIC (Skill 05) → PostgreSQL (append-only journal)
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    SnapshotAsync / GetVersionAsync / DiffVersionsAsync / RestoreVersionAsync
IRON RULES:
  IR-641-1: version store is APPEND-ONLY — no UPDATE/DELETE
  IR-641-2: restore creates new version snapshot — does not rewrite history
```

### F642 — ICollectionRelationService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    LinkAsync / UnlinkAsync / GetRelatedAsync
IRON RULES:
  IR-642-1: circular relations rejected at engine level
  IR-642-2: relation types config-driven (FREEDOM) — not hardcoded enum
```

---

## FAMILY 86 — CONTENT AUTHORING

### F643 — IRichEditorService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, postId})
METHODS:    SaveDraftAsync / AutosaveAsync / GetDraftAsync / ApplyBlockAsync
IRON RULES:
  IR-643-1: autosave interval configurable (FREEDOM: editor.autosave_interval_ms)
  IR-643-2: blocks stored as Dictionary<string,object> — no typed Block class
```

### F644 — IAiWritingAssistantService
```
FABRIC:     AI ENGINE FABRIC (Skill 07) → AiDispatcher (multi-model)
RESOLUTION: CreateAsync(ctx{tenantId})  Config: content_authoring.ai_writing.ai_provider
METHODS:    SuggestContinuationAsync / GenerateSeoSummaryAsync / CheckToneAsync / EnhanceBlockAsync
IRON RULES:
  IR-644-1: AI suggestions always user-confirmable — engine never auto-commits AI output
  IR-644-2: model selection config-driven (FREEDOM: ai_writing.model_preference)
```

### F645 — ICommentThreadService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    AddCommentAsync / ResolveThreadAsync / GetThreadsAsync / ModerateAsync
IRON RULES:
  IR-645-1: moderation events enqueued through QUEUE FABRIC
  IR-645-2: threadId scoped by tenantId
```

### F646 — IEditorialWorkflowService
```
FABRIC:     FLOW ENGINE FABRIC (Skills 08/09) → IFlowOrchestrator
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    SubmitForReviewAsync / ApproveAsync / RequestRevisionAsync / GetWorkflowStateAsync
IRON RULES:
  IR-646-1: workflow config = FREEDOM config in ES (approval steps, required roles)
  IR-646-2: state changes generate audit events through QUEUE FABRIC
```

---

## FAMILY 87 — PUBLISHING PIPELINE

### F647 — IPublishJobService
```
FABRIC:     QUEUE FABRIC (Skill 04) → Redis Streams
RESOLUTION: CreateAsync(ctx{tenantId, siteId})  Config: publishing.publish_job.queue_provider
METHODS:    EnqueuePublishAsync / EnqueueScheduledAsync / CancelJobAsync / GetJobStatusAsync
IRON RULES:
  IR-647-1: publish operations MUST be idempotent (idempotency-key in job payload)
  IR-647-2: scheduled publish uses RFC 3339 timestamp (DD-132)
  IR-647-3: job envelope MUST use CloudEvents format (DD-132)
```

### F648 — ICacheInvalidationService
```
FABRIC:     QUEUE FABRIC → Redis Streams + DATABASE FABRIC → Redis
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    InvalidatePageAsync / InvalidateSiteAsync / InvalidateTokensAsync / GetInvalidationLogAsync
IRON RULES:
  IR-648-1: cache keys always include tenantId prefix
  IR-648-2: invalidation events broadcast via QUEUE FABRIC before Redis flush
  IR-648-3: design token update MUST trigger full site invalidation (CF-299)
```

### F649 — IStaticBuildService
```
FABRIC:     AI ENGINE FABRIC (Skill 07) → AiDispatcher (build optimization)
RESOLUTION: CreateAsync(ctx{tenantId, siteId})  Config: publishing.static_build.ai_provider
METHODS:    TriggerBuildAsync / GetBuildStatusAsync / RollbackBuildAsync / GetBuildArtifactsAsync
IRON RULES:
  IR-649-1: published content = SSG path — preview = SSR path (DD-131)
  IR-649-2: build artifacts immutable — rollback = switch pointer, not delete
  IR-649-3: every build tagged with tenantId + siteId + timestamp
```

### F650 — IRenderRuntimeService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    RenderPageAsync / RenderTemplateAsync / GetRenderMetricsAsync
IRON RULES:
  IR-650-1: SSR render MUST NOT use cached SSG artifact (DD-131)
  IR-650-2: render errors return DataProcessResult — never unhandled 500
```

### F651 — ISitemapRssService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    GenerateSitemapAsync / GenerateRssAsync / InvalidateSitemapAsync
IRON RULES:
  IR-651-1: sitemap regenerated on every publish event (F647 event via QUEUE FABRIC)
  IR-651-2: sitemap scoped by tenantId + siteId
```

### F652 — IPublishRollbackService
```
FABRIC:     DATABASE FABRIC (Skill 05) → PostgreSQL (version journal)
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    GetPublishHistoryAsync / RollbackToVersionAsync / CreateCheckpointAsync
IRON RULES:
  IR-652-1: rollback is non-destructive — creates new "rollback publish" version
  IR-652-2: requires RBAC permission: publish.rollback (FREEDOM config)
```

---

## FAMILY 88 — THEME / DESIGN SYSTEM

### F653 — IDesignTokenService
```
FABRIC:     DATABASE FABRIC → Elasticsearch (store) + Redis (hot cache)
RESOLUTION: CreateAsync(ctx{tenantId, siteId})  Config: design_system.tokens.db_provider
METHODS:    GetTokensAsync / SetTokenAsync / GetTokensByThemeAsync / ExportCssVariablesAsync
IRON RULES:
  IR-653-1: token update MUST trigger cache invalidation via F648 (CF-299)
  IR-653-2: tokens stored as flat Dictionary — no nested typed ThemeConfig
  IR-653-3: token change events published to QUEUE FABRIC for downstream rebuild
```

### F654 — IGlobalStyleService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    GetGlobalStylesAsync / SetGlobalStyleAsync / GetTypographyScaleAsync / PropagateStyleChangeAsync
IRON RULES:
  IR-654-1: global style change propagation via QUEUE FABRIC (async rebuild)
  IR-654-2: per-block override validated against global style guardrails
```

### F655 — IThemeRegistryService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    RegisterThemeAsync / ApplyThemeAsync / ForkThemeAsync / ListThemesAsync
IRON RULES:
  IR-655-1: system themes (tenantId=SYSTEM) read-only — fork required
  IR-655-2: theme application triggers token propagation via F653
```

### F656 — IDesignTokenRebuildService
```
FABRIC:     QUEUE FABRIC (Skill 04) → Redis Streams
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    TriggerRebuildAsync / GetRebuildStatusAsync / GetAffectedPagesAsync
IRON RULES:
  IR-656-1: rebuild scope from token dependency graph (F653 maintains)
  IR-656-2: partial rebuild supported — only affected pages
```

---

## FAMILY 89 — ROUTING / URLS / SEO

### F657 — ISlugService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    RegisterSlugAsync / ResolveSlugAsync / ChangeSlugAsync / GetSlugHistoryAsync
IRON RULES:
  IR-657-1: slug change MUST auto-create 301 redirect via F658 (CF-303)
  IR-657-2: slug uniqueness enforced per siteId + tenantId
  IR-657-3: slug format: lowercase, hyphen-only, no trailing slash
```

### F658 — IRedirectService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Redis (hot read path)
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    CreateRedirectAsync / ResolveRedirectAsync / DeleteRedirectAsync / GetAllRedirectsAsync
IRON RULES:
  IR-658-1: redirect type (301/302) config-driven (FREEDOM)
  IR-658-2: circular redirect chains rejected (CF-304)
  IR-658-3: redirect entries keyed by tenantId + siteId
```

### F659 — ISeoMetadataService
```
FABRIC:     AI ENGINE FABRIC (Skill 07) → AiDispatcher + DATABASE FABRIC → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    GenerateSeoMetaAsync / GetSeoMetaAsync / SetSeoMetaAsync / ValidateSeoAsync
IRON RULES:
  IR-659-1: AI-generated SEO meta requires user confirmation
  IR-659-2: OG image stored as URL reference — never embedded base64
```

### F660 — IPermalinkRuleService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Redis
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    GetRuleAsync / SetRuleAsync / ResolvePermalinkAsync
IRON RULES:
  IR-660-1: permalink patterns config-driven (FREEDOM: routing.permalink_patterns)
  IR-660-2: pattern change requires bulk redirect generation via F658 + F647
```

### F661 — IRobotsService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    GetRobotsAsync / SetRobotsRuleAsync / GenerateRobotsAsync
IRON RULES:
  IR-661-1: robots.txt scoped per siteId + tenantId
```

---

## FAMILY 90 — MEDIA LIBRARY / ASSETS

### F662 — IAssetUploadService
```
FABRIC:     QUEUE FABRIC (Skill 04) → Redis Streams
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    InitiateUploadAsync / CompleteUploadAsync / CancelUploadAsync
IRON RULES:
  IR-662-1: upload completion triggers async transform pipeline via QUEUE FABRIC
  IR-662-2: presigned URL includes tenantId-scoped bucket path
  IR-662-3: max upload size = FREEDOM config
```

### F663 — IImageTransformService
```
FABRIC:     AI ENGINE FABRIC (Skill 07) → AiDispatcher
RESOLUTION: CreateAsync(ctx{tenantId})  Config: assets.transforms.ai_provider
METHODS:    ResizeAsync / CropAsync / ConvertFormatAsync / GenerateAltTextAsync / GenerateResponsiveSetAsync
IRON RULES:
  IR-663-1: transform output immutable — variants stored as new assetId
  IR-663-2: WebP/AVIF generation is async (QUEUE FABRIC) — not blocking
```

### F664 — IAssetCdnService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Redis (CDN URL cache)
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    GetCdnUrlAsync / PurgeCdnAsync / GetCdnStatsAsync
IRON RULES:
  IR-664-1: CDN provider config-driven (FREEDOM: assets.cdn_provider)
  IR-664-2: CDN URL includes tenantId namespace
```

### F665 — IMediaLibraryService
```
FABRIC:     DATABASE FABRIC (Skill 05) → Elasticsearch
RESOLUTION: CreateAsync(ctx{tenantId, siteId})
METHODS:    CreateFolderAsync / MoveAssetAsync / SearchAssetsAsync / TagAssetAsync / GetUsageAsync
IRON RULES:
  IR-665-1: folder hierarchy stored as flat ES documents with parentId
  IR-665-2: asset search MUST include tenantId filter (DNA-5)
```

### F666 — IAssetReplacementService
```
FABRIC:     QUEUE FABRIC (Skill 04) → Redis Streams
RESOLUTION: CreateAsync(ctx{tenantId})
METHODS:    ReplaceAssetAsync / GetReplacementStatusAsync / PreviewReplacementAsync
IRON RULES:
  IR-666-1: replacement is async — fan-out via QUEUE FABRIC
  IR-666-2: old asset retained until replacement confirmed
```

---

## CROSS-CUTTING FACTORIES (F667–F674)

| Factory | Interface | Fabric | Provider | Purpose |
|---------|-----------|--------|----------|---------|
| F667 | IWorkspaceService | DATABASE FABRIC | PostgreSQL | Multi-tenant workspace/site management |
| F668 | ISiteConfigService | DATABASE FABRIC | Elasticsearch | Site-level FREEDOM config |
| F669 | IRbacSiteService | DATABASE FABRIC | Elasticsearch | RBAC within site context |
| F670 | IAuditLogService | QUEUE + DATABASE | Redis Streams + PG | Append-only audit trail |
| F671 | ISchedulerService | QUEUE FABRIC | Redis Streams | Time-based publish trigger |
| F672 | ISearchIndexService | DATABASE + RAG | ES + Vector | Full-text + semantic search |
| F673 | IAnalyticsEventService | QUEUE FABRIC | Redis Streams | Page view/engagement events |
| F674 | ITenantProvisioningService | FLOW ENGINE FABRIC | IFlowOrchestrator | New tenant provisioning DAG |

**Iron Rules F667–F674 (shared)**:
- IR-667-1: workspace creation provisions tenantId — never shared
- IR-668-1: all FREEDOM values stored in ES — never in code
- IR-669-1: role assignments are (tenantId, siteId, userId, role) composite
- IR-670-1: audit events immutable — append-only
- IR-671-1: schedule time as RFC 3339 string; idempotency-key required
- IR-672-1: index updated via QUEUE FABRIC from publish pipeline; ALL docs include tenantId
- IR-673-1: analytics events must not include PII without consent config
- IR-674-1: provisioning idempotent; IR-674-2: DAG stored in ES (Skill 08)

---

## FACTORY COUNT — FLOW-20
```
F631–F666: 36 domain factories (Families 84–90)
F667–F674:  8 cross-cutting factories
Total FLOW-20: 44 factories
Running total: F1–F674 (644 total factories, 91 total families)
```

---

## BACKWARD COMPATIBILITY
```
F1–F630:       UNCHANGED ✅
Families 1–83: UNCHANGED ✅
New: F631–F674 (44 factories) | Families 84–90 (7 families)
DNA-1–6:       UNCHANGED ✅ — enforced on all new factories
EP-1–EP-5:     STABLE ✅
```

---

## SAVE POINT: FLOW20:P1:ENGINE_ARCH:COMPLETE ✅
## Recovery: "FLOW-20 P1 complete. F631-F674 / Families 84-90. Continue with P2 task types."
