# TASK TYPES CATALOG — FLOW-20 EXTENSION
# Visual Editor & Site Builder Platform
# Extends: TASK_TYPES_CATALOG_MERGED.md (T1–T246, Templates 1–49)
# FLOW-20 adds: T247–T266 (20 task types) | Templates 50–52 (3 templates)
# Save Point: FLOW20:P2:TASK_TYPES:COMPLETE

---

## STATE REFERENCE
```
Previous: T1–T246 | Templates 1–49 — TASK_TYPES_CATALOG_MERGED.md
This file: T247–T266 (20 new) | Templates 50–52 (3 new)
Archetypes introduced: PAGE_BUILDER, CMS_LIFECYCLE, PUBLISH_SAGA, DESIGN_PROPAGATION, MEDIA_PIPELINE
```

---

## NEW ARCHETYPES

| Archetype | Description | Used by |
|-----------|-------------|---------|
| PAGE_BUILDER | Visual editor node manipulation + versioning | T247–T250 |
| CMS_LIFECYCLE | Schema + content lifecycle state machine | T251–T255 |
| PUBLISH_SAGA | Publish/schedule/rollback saga with compensation | T256–T260 |
| DESIGN_PROPAGATION | Token change fan-out + rebuild coordination | T261–T263 |
| MEDIA_PIPELINE | Upload → transform → CDN pipeline | T264–T266 |

---

## TASK TYPE: T247 — Page Tree Node Mutation
```
TASK TYPE:    T247 — Page Tree Node Mutation
ARCHETYPE:    PAGE_BUILDER
ENTRY:        Fires when editor submits node add/move/delete/update operation
PURPOSE:      Atomically mutate page tree node with version snapshot + collaboration lock check
DISTINCT FROM: T248 (component registration), T249 (layout resolve) — T247 is the write path
FACTORY DEPENDENCIES: F631, F635, F636, F670
FABRIC RESOLUTION:
  F631 → DATABASE FABRIC (Elasticsearch) — page tree storage
  F635 → QUEUE FABRIC (Redis Streams) — collaboration lock broadcast
  F636 → DATABASE FABRIC (Redis) — editor session validation
  F670 → QUEUE FABRIC + DATABASE FABRIC — audit trail
AF CONFIGURATION:
  AF-1 (Genesis): generates MicroserviceBase-extended PageTreeMutationService
  AF-2 (Planning): decomposes into lock-check → snapshot → mutate → broadcast
  AF-4 (RAG): searches SK-145 (Page Tree Versioning) for reusable patterns
  AF-6 (Code Review): validates ETag/If-Match implementation
  AF-7 (Compliance): checks DNA-1 (no PageNode typed model), DNA-5 (tenantId on all ops)
  AF-8 (Security): validates lock token ownership before write
  AF-9 (Judge): checks IR-631-1, IR-635-2, DNA-5 compliance
BFA VALIDATION:
  CF-295: page tree write must not conflict with active publish job (F647)
  CF-296: lock token must belong to requesting userId + tenantId
MACHINE (fixed):
  - Version snapshot always before mutation
  - ETag/If-Match concurrency control
  - tenantId + siteId composite key
FREEDOM (configurable):
  - collab.lock_ttl_seconds
  - visual_editor.max_tree_depth
IRON RULES:
  IR-T247-1: NO mutation without valid session (F636) + lock token (F635)
  IR-T247-2: version history stored APPEND-ONLY (IR-631-1 enforced)
  IR-T247-3: node operations return DataProcessResult — never throw
QUALITY GATES (AF-9):
  QG-T247-1: mutation latency P99 < 200ms
  QG-T247-2: version snapshot written before mutation confirmed
  QG-T247-3: audit event enqueued within same transaction window
```

---

## TASK TYPE: T248 — Component Registration
```
TASK TYPE:    T248 — Component Registration
ARCHETYPE:    PAGE_BUILDER
ENTRY:        Fires when developer/admin registers a new UI component
PURPOSE:      Validate, version, and register component in registry for use by all tenants
DISTINCT FROM: T247 (page tree mutation) — T248 is admin-level component catalog management
FACTORY DEPENDENCIES: F632, F639, F669, F670
FABRIC RESOLUTION:
  F632 → DATABASE FABRIC (Elasticsearch) — component registry
  F639 → RAG FABRIC (Hybrid) — AI schema validation + field suggestions
  F669 → DATABASE FABRIC (Elasticsearch) — RBAC permission check
  F670 → QUEUE FABRIC + DATABASE — audit
AF CONFIGURATION:
  AF-1 (Genesis): generates ComponentRegistrationService extending MicroserviceBase
  AF-3 (Prompt Library): retrieves component validation prompts
  AF-4 (RAG): searches SK-146 (JSON Schema 2020-12 patterns) for reuse
  AF-7 (Compliance): checks DNA-1 (no typed Component class)
  AF-9 (Judge): validates schema format = JSON Schema 2020-12 (DD-130)
BFA VALIDATION:
  CF-297: component ID must not conflict with existing F632 registry
MACHINE: component immutability once published; version increment on update
FREEDOM: allowed component categories (FREEDOM config)
IRON RULES:
  IR-T248-1: schema format MUST be JSON Schema 2020-12 (DD-130) — build failure otherwise
  IR-T248-2: system components (tenantId=SYSTEM) can only be registered by SYSTEM role
QUALITY GATES (AF-9):
  QG-T248-1: schema validation passes JSON Schema 2020-12 validator
  QG-T248-2: component has at least 1 required prop defined
```

---

## TASK TYPE: T249 — Responsive Layout Resolution
```
TASK TYPE:    T249 — Responsive Layout Resolution
ARCHETYPE:    PAGE_BUILDER
ENTRY:        Fires on breakpoint change or new node render request
PURPOSE:      Resolve layout constraints for a node across desktop/tablet/mobile breakpoints
DISTINCT FROM: T247 (write path) — T249 is read-only layout resolution
FACTORY DEPENDENCIES: F633, F631, F636
FABRIC RESOLUTION:
  F633 → DATABASE FABRIC (Redis) — breakpoint cache
  F631 → DATABASE FABRIC (Elasticsearch) — page tree source of truth
  F636 → DATABASE FABRIC (Redis) — session context
AF CONFIGURATION:
  AF-1: generates LayoutResolutionService
  AF-7: checks DNA-2 (BuildSearchFilter for empty breakpoint fields)
  AF-9: validates IR-633-2 (read-only resolution)
BFA VALIDATION: CF-295 (must not block active publish)
MACHINE: cache-first resolution; ES fallback on cache miss
FREEDOM: breakpoint definitions (FREEDOM: visual_editor.breakpoints)
IRON RULES:
  IR-T249-1: layout resolution NEVER mutates page tree
  IR-T249-2: cache miss must re-populate from ES source of truth
QUALITY GATES: QG-T249-1: resolution latency P99 < 50ms
```

---

## TASK TYPE: T250 — Live Preview Render
```
TASK TYPE:    T250 — Live Preview Render
ARCHETYPE:    PAGE_BUILDER
ENTRY:        Fires on page tree save or CMS data change in editor context
PURPOSE:      Real-time SSR preview combining page tree + CMS data via AI-enhanced rendering
DISTINCT FROM: T259 (publish-time SSG) — T250 is always SSR, never cached artifact
FACTORY DEPENDENCIES: F634, F631, F640, F650
FABRIC RESOLUTION:
  F634 → AI ENGINE FABRIC (AiDispatcher) — live preview rendering
  F631 → DATABASE FABRIC (Elasticsearch) — page tree
  F640 → DATABASE FABRIC (Elasticsearch) — CMS data query
  F650 → DATABASE FABRIC (Elasticsearch) — render runtime
AF CONFIGURATION:
  AF-1: generates LivePreviewService
  AF-5 (Multi-model): parallel preview generation for quality comparison
  AF-9: validates IR-634-1 (always SSR, never SSG artifact — DD-131)
BFA VALIDATION:
  CF-298: preview must not read unpublished content from other tenants
MACHINE: always SSR; never returns cached publish artifact
FREEDOM: preview_render.ai_provider; preview.timeout_ms
IRON RULES:
  IR-T250-1: preview ALWAYS SSR — build failure if any SSG cache lookup occurs
  IR-T250-2: preview isolated by tenantId + sessionId
QUALITY GATES:
  QG-T250-1: preview render < 2s P95
  QG-T250-2: no cross-tenant data in preview response
```

---

## TASK TYPE: T251 — Post Type Schema Registration
```
TASK TYPE:    T251 — Post Type Schema Registration
ARCHETYPE:    CMS_LIFECYCLE
ENTRY:        Fires when admin creates or updates a PostType collection definition
PURPOSE:      Register new PostType schema, generate form schema, validate backward compat
DISTINCT FROM: T248 (component registry) — T251 manages content schemas, not UI components
FACTORY DEPENDENCIES: F637, F639, F642, F669, F670
FABRIC RESOLUTION:
  F637 → DATABASE FABRIC (Elasticsearch) — PostType registry
  F639 → RAG FABRIC (Hybrid) — AI schema assistance
  F642 → DATABASE FABRIC (Elasticsearch) — collection relations
  F669 → DATABASE FABRIC (Elasticsearch) — RBAC check
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates PostTypeRegistrationService
  AF-3: retrieves CMS schema prompts
  AF-4: searches SK-146 (JSON Schema patterns), SK-147 (CMS relation patterns)
  AF-7: checks DNA-1 (no typed PostType class), DNA-5 (tenantId)
  AF-9: validates DD-130 (JSON Schema 2020-12 mandatory)
BFA VALIDATION:
  CF-297: PostType ID must not collide with existing registry entries
  CF-299: schema change triggers cache invalidation (F648)
MACHINE: additive-only schema updates; version increment
FREEDOM: allowed field types (FREEDOM: cms.allowed_field_types)
IRON RULES:
  IR-T251-1: schema MUST be JSON Schema 2020-12 — enforced at engine level
  IR-T251-2: schema changes MUST be backward-compatible (no field removal)
  IR-T251-3: AI-suggested fields require admin approval (IR-639-2)
QUALITY GATES: QG-T251-1: schema validates against JSON Schema 2020-12 meta-schema
```

---

## TASK TYPE: T252 — Post Create / Update
```
TASK TYPE:    T252 — Post Create / Update
ARCHETYPE:    CMS_LIFECYCLE
ENTRY:        Fires when author saves post content (create or update)
PURPOSE:      Persist post with schema validation, version snapshot, and autosave support
DISTINCT FROM: T253 (status transition) — T252 is content write; T253 is lifecycle change
FACTORY DEPENDENCIES: F638, F639, F641, F643, F670
FABRIC RESOLUTION:
  F638 → DATABASE FABRIC (ES primary + PG journal)
  F639 → RAG FABRIC (Hybrid) — schema validation
  F641 → DATABASE FABRIC (PostgreSQL) — version journal
  F643 → DATABASE FABRIC (Elasticsearch) — rich editor draft
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates PostWriteService
  AF-4: searches SK-148 (Optimistic Concurrency), SK-145 (version journal)
  AF-6: reviews ETag/If-Match usage
  AF-7: DNA-1 (no Post typed model), DNA-2 (BuildSearchFilter), DNA-5 (tenantId)
  AF-9: validates IR-638-2 (version concurrency), IR-641-1 (append-only journal)
BFA VALIDATION:
  CF-300: post slug must not duplicate existing published slugs (F657)
  CF-301: category/tag references must exist before post saved
MACHINE: version increment on every update; ETag concurrency
FREEDOM: autosave interval; max content blocks per post
IRON RULES:
  IR-T252-1: concurrent update without matching version = DataProcessResult 409
  IR-T252-2: version journal APPEND-ONLY — no UPDATE/DELETE
  IR-T252-3: publishAt stored as RFC 3339 (DD-132)
QUALITY GATES:
  QG-T252-1: save latency P99 < 500ms
  QG-T252-2: version snapshot confirmed before response
```

---

## TASK TYPE: T253 — Post Status Transition
```
TASK TYPE:    T253 — Post Status Transition
ARCHETYPE:    CMS_LIFECYCLE
ENTRY:        Fires when editorial action triggers status change (Draft→Published etc.)
PURPOSE:      Enforce valid state machine transitions with audit trail and downstream event fan-out
DISTINCT FROM: T252 (content write) — T253 is lifecycle state change only
FACTORY DEPENDENCIES: F638, F646, F647, F671, F670
FABRIC RESOLUTION:
  F638 → DATABASE FABRIC (ES + PG) — post state update
  F646 → FLOW ENGINE FABRIC — editorial workflow gate
  F647 → QUEUE FABRIC — enqueue publish job if transitioning to Published
  F671 → QUEUE FABRIC — schedule trigger if transitioning to Scheduled
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates PostStatusTransitionService
  AF-2: decomposes into validate → gate → transition → fan-out
  AF-7: checks DNA-3 (invalid transition = DataProcessResult error, never throw)
  AF-9: validates IR-638-1 (only valid transitions — build failure for illegal path)
BFA VALIDATION:
  CF-302: transition to Published must trigger cache invalidation (CF-299 chain)
  CF-303: slug change within transition must create redirect (F657 → F658)
MACHINE: transition validity enforced by engine state machine
FREEDOM: approval requirements per transition (FREEDOM: cms.workflow_config)
IRON RULES:
  IR-T253-1: ONLY valid transitions: Draft→Published, Draft→Scheduled, 
              Scheduled→Published, Published→Archived — all others = BUILD FAILURE
  IR-T253-2: Published status triggers F647 publish job enqueue (idempotent)
  IR-T253-3: Scheduled status triggers F671 scheduler with RFC 3339 time
QUALITY GATES:
  QG-T253-1: transition events reach QUEUE FABRIC within 100ms
  QG-T253-2: invalid transition attempt returns structured DataProcessResult error
```

---

## TASK TYPE: T254 — Editorial Workflow Gate
```
TASK TYPE:    T254 — Editorial Workflow Gate
ARCHETYPE:    CMS_LIFECYCLE
ENTRY:        Fires on review request from author; blocks publish path until resolved
PURPOSE:      Configurable approval workflow: Author → Editor → Publisher
DISTINCT FROM: T253 (status transition) — T254 is the human approval gate within the flow
FACTORY DEPENDENCIES: F646, F669, F670, F671
FABRIC RESOLUTION:
  F646 → FLOW ENGINE FABRIC (IFlowOrchestrator) — workflow DAG execution
  F669 → DATABASE FABRIC (Elasticsearch) — RBAC role check
  F670 → QUEUE + DATABASE — audit
  F671 → QUEUE FABRIC — timeout/reminder scheduler
AF CONFIGURATION:
  AF-1: generates EditorialWorkflowGateService
  AF-3: retrieves workflow prompts
  AF-9: validates workflow config = FREEDOM (IR-646-1), not hardcoded
BFA VALIDATION:
  CF-305: workflow config must be in FREEDOM ES index — not in code
MACHINE: workflow state transitions (Submitted→InReview→Approved/Rejected)
FREEDOM: approval steps, role requirements, timeout duration
IRON RULES:
  IR-T254-1: workflow config MUST come from FREEDOM config (F668) — never hardcoded
  IR-T254-2: workflow timeout triggers automatic escalation event
QUALITY GATES: QG-T254-1: workflow state durable — survives service restart
```

---

## TASK TYPE: T255 — CMS Feed Query
```
TASK TYPE:    T255 — CMS Feed Query
ARCHETYPE:    CMS_LIFECYCLE
ENTRY:        Fires on widget render requesting blog feed / related posts
PURPOSE:      Execute configurable CMS content queries for display widgets
DISTINCT FROM: T249 (layout resolution) — T255 is CMS data retrieval, not UI layout
FACTORY DEPENDENCIES: F640, F638, F672
FABRIC RESOLUTION:
  F640 → DATABASE FABRIC (Elasticsearch) — query execution
  F638 → DATABASE FABRIC (ES) — post data
  F672 → DATABASE + RAG FABRIC (ES + Vector) — semantic search/related posts
AF CONFIGURATION:
  AF-1: generates CmsFeedQueryService
  AF-4: searches SK-149 (Feed Query Patterns)
  AF-7: DNA-2 (BuildSearchFilter for empty category/tag), DNA-5 (tenantId)
  AF-9: validates all query results tenant-scoped
BFA VALIDATION:
  CF-306: feed must never surface unpublished posts to public endpoints
MACHINE: always filter status=Published for public feeds
FREEDOM: query limit, sort order, cache TTL
IRON RULES:
  IR-T255-1: public feeds filter status=Published — never expose Draft/Scheduled
  IR-T255-2: tenantId on every ES query — BuildSearchFilter enforces (DNA-2)
QUALITY GATES: QG-T255-1: feed query P99 < 100ms; QG-T255-2: no unpublished content in public response
```

---

## TASK TYPE: T256 — Publish Job Orchestration
```
TASK TYPE:    T256 — Publish Job Orchestration
ARCHETYPE:    PUBLISH_SAGA
ENTRY:        Fires when post transitions to Published or publish job dequeued
PURPOSE:      Orchestrate full publish pipeline: render → CDN deploy → cache invalidate → sitemap → index
DISTINCT FROM: T253 (status transition trigger) — T256 is the pipeline execution after trigger
FACTORY DEPENDENCIES: F647, F649, F648, F651, F672, F670
FABRIC RESOLUTION:
  F647 → QUEUE FABRIC (Redis Streams) — job lifecycle
  F649 → AI ENGINE FABRIC (AiDispatcher) — SSG build trigger
  F648 → QUEUE + DATABASE FABRIC — cache invalidation
  F651 → DATABASE FABRIC (Elasticsearch) — sitemap/RSS refresh
  F672 → DATABASE + RAG — search index update
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates PublishPipelineOrchestratorService
  AF-2: decomposes into 6 sequential steps with compensation on failure
  AF-4: searches SK-150 (Publish Saga Pattern), SK-151 (Idempotent Pipeline)
  AF-6: reviews idempotency-key usage
  AF-7: DNA-4 (MicroserviceBase), DNA-5 (tenantId on all ops)
  AF-8: security scan — validates CDN URL namespace isolation
  AF-9: validates IR-647-1 (idempotency), IR-647-3 (CloudEvents envelope)
BFA VALIDATION:
  CF-307: publish job must check BFA for cross-flow entity conflicts
  CF-308: concurrent publish jobs for same siteId prohibited
MACHINE: CloudEvents envelope; idempotency-key; compensation on partial failure
FREEDOM: publish pipeline steps enabled/disabled (FREEDOM: publishing.pipeline_steps)
IRON RULES:
  IR-T256-1: publish is idempotent — duplicate job = no-op (idempotency-key check)
  IR-T256-2: each pipeline step generates audit event via F670
  IR-T256-3: CloudEvents envelope on ALL job events (DD-132)
  IR-T256-4: failure at any step triggers compensation — rollback partial state
QUALITY GATES:
  QG-T256-1: full publish pipeline < 30s P95 (configurable)
  QG-T256-2: idempotency proven by duplicate-job test
  QG-T256-3: cache invalidation confirmed before job marked complete
```

---

## TASK TYPE: T257 — Scheduled Publish Trigger
```
TASK TYPE:    T257 — Scheduled Publish Trigger
ARCHETYPE:    PUBLISH_SAGA
ENTRY:        Fires at publishAt time by F671 ISchedulerService
PURPOSE:      Transition Scheduled post to Published and trigger publish pipeline
DISTINCT FROM: T256 (pipeline) — T257 is the time-based trigger
FACTORY DEPENDENCIES: F671, F638, F647
FABRIC RESOLUTION:
  F671 → QUEUE FABRIC (Redis Streams) — scheduler event
  F638 → DATABASE FABRIC (ES + PG) — post status update
  F647 → QUEUE FABRIC — publish job enqueue
AF CONFIGURATION:
  AF-1: generates ScheduledPublishTriggerService
  AF-7: DNA-3 (timing race = DataProcessResult, never throw), DNA-5 (tenantId)
  AF-9: validates RFC 3339 timestamp (DD-132), idempotency
MACHINE: RFC 3339 timestamp; idempotency-key; Scheduled→Published transition
FREEDOM: scheduler.check_interval_seconds
IRON RULES:
  IR-T257-1: scheduler fires at or after publishAt — never before
  IR-T257-2: duplicate fire = idempotent (post already Published = no-op)
  IR-T257-3: publishAt in RFC 3339 format mandatory
QUALITY GATES: QG-T257-1: trigger delay < 60s from publishAt time
```

---

## TASK TYPE: T258 — Publish Rollback
```
TASK TYPE:    T258 — Publish Rollback
ARCHETYPE:    PUBLISH_SAGA
ENTRY:        Fires on admin rollback request to previous published version
PURPOSE:      Restore previous publish artifact without destroying history
DISTINCT FROM: T252 (content update) — T258 is a non-destructive publish pointer switch
FACTORY DEPENDENCIES: F652, F648, F649, F669, F670
FABRIC RESOLUTION:
  F652 → DATABASE FABRIC (PostgreSQL) — version history
  F648 → QUEUE + DATABASE — cache invalidation
  F649 → AI ENGINE FABRIC — build artifact pointer switch
  F669 → DATABASE FABRIC — RBAC (publish.rollback permission)
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates PublishRollbackService
  AF-8: validates permission check (publish.rollback RBAC)
  AF-9: validates IR-652-1 (non-destructive rollback)
BFA VALIDATION: CF-309: rollback prohibited during active publish job
MACHINE: creates new rollback-publish version; immutable artifact preservation
IRON RULES:
  IR-T258-1: rollback is NON-DESTRUCTIVE — creates new version, never deletes
  IR-T258-2: requires publish.rollback RBAC permission (IR-652-2)
  IR-T258-3: rollback triggers cache invalidation (F648)
QUALITY GATES: QG-T258-1: rollback complete < 10s; QG-T258-2: version history preserved after rollback
```

---

## TASK TYPE: T259 — Static Site Generation
```
TASK TYPE:    T259 — Static Site Generation
ARCHETYPE:    PUBLISH_SAGA
ENTRY:        Fires as part of publish pipeline (T256 step 2) or on manual rebuild
PURPOSE:      Generate static site artifacts for CDN delivery
DISTINCT FROM: T250 (live SSR preview) — T259 is SSG for published content only
FACTORY DEPENDENCIES: F649, F650, F653, F656
FABRIC RESOLUTION:
  F649 → AI ENGINE FABRIC (AiDispatcher) — AI-optimized build
  F650 → DATABASE FABRIC (Elasticsearch) — render runtime
  F653 → DATABASE FABRIC (ES + Redis) — design tokens
  F656 → QUEUE FABRIC — rebuild event coordination
AF CONFIGURATION:
  AF-1: generates StaticSiteGenerationService
  AF-5: parallel multi-model build optimization
  AF-9: validates DD-131 (SSG for published; SSR for preview)
MACHINE: SSG for published content only; artifacts immutable
IRON RULES:
  IR-T259-1: SSG artifacts tagged with tenantId + siteId + buildVersion
  IR-T259-2: SSG NEVER used for editor preview (DD-131)
QUALITY GATES: QG-T259-1: build artifacts deterministic for identical inputs
```

---

## TASK TYPE: T260 — Sitemap + RSS Refresh
```
TASK TYPE:    T260 — Sitemap + RSS Refresh
ARCHETYPE:    PUBLISH_SAGA
ENTRY:        Fires as step in T256 publish pipeline (after CDN deploy)
PURPOSE:      Regenerate sitemap.xml and RSS feed for newly published/archived content
DISTINCT FROM: T259 (SSG) — T260 is sitemap/feed metadata, not page content
FACTORY DEPENDENCIES: F651, F657, F638
FABRIC RESOLUTION:
  F651 → DATABASE FABRIC (Elasticsearch)
  F657 → DATABASE FABRIC (Elasticsearch) — slug resolution
  F638 → DATABASE FABRIC (ES) — published post data
AF CONFIGURATION:
  AF-1: generates SitemapRssRefreshService
  AF-7: DNA-5 (tenantId + siteId on all outputs)
  AF-9: validates IR-651-1 (regenerates on every publish)
MACHINE: regenerated on every publish event
IRON RULES:
  IR-T260-1: sitemap scoped per siteId + tenantId — no cross-tenant URLs
  IR-T260-2: only Published posts appear in sitemap/RSS
QUALITY GATES: QG-T260-1: sitemap generated < 5s; QG-T260-2: no Draft URLs in sitemap
```

---

## TASK TYPE: T261 — Design Token Update + Propagation
```
TASK TYPE:    T261 — Design Token Update + Propagation
ARCHETYPE:    DESIGN_PROPAGATION
ENTRY:        Fires when admin saves new design token values
PURPOSE:      Update token store, compute affected pages, trigger partial rebuild
DISTINCT FROM: T262 (global style) — T261 is token-level; T262 is typography/spacing scale
FACTORY DEPENDENCIES: F653, F648, F656, F633, F670
FABRIC RESOLUTION:
  F653 → DATABASE FABRIC (ES + Redis) — token store + cache
  F648 → QUEUE + DATABASE — cache invalidation
  F656 → QUEUE FABRIC — rebuild trigger
  F633 → DATABASE FABRIC (Redis) — breakpoint cache invalidation
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates DesignTokenUpdateService
  AF-2: decomposes into update → invalidate → compute-scope → enqueue-rebuild
  AF-7: DNA-5 (tenantId on token cache keys)
  AF-9: validates CF-299 (token update must trigger cache invalidation)
BFA VALIDATION: CF-299 enforced here; CF-310: token update not allowed during active publish
MACHINE: token update always triggers partial rebuild scope computation
FREEDOM: design_system.token_rebuild_strategy (full vs partial)
IRON RULES:
  IR-T261-1: token update MUST trigger cache invalidation (F648) within same operation
  IR-T261-2: token change events published to QUEUE FABRIC BEFORE cache clear
  IR-T261-3: partial rebuild scope computed from dependency graph (IR-656-1)
QUALITY GATES:
  QG-T261-1: affected pages computed < 2s
  QG-T261-2: cache invalidation confirmed before rebuild enqueued
```

---

## TASK TYPE: T262 — Global Style Propagation
```
TASK TYPE:    T262 — Global Style Propagation
ARCHETYPE:    DESIGN_PROPAGATION
ENTRY:        Fires on typography scale, color, or spacing system change
PURPOSE:      Propagate global style changes to all affected pages; coordinate async rebuild
DISTINCT FROM: T261 (token-level) — T262 is typography/scale-level propagation
FACTORY DEPENDENCIES: F654, F653, F648, F656
FABRIC RESOLUTION:
  F654 → DATABASE FABRIC (Elasticsearch) — global style store
  F653 → DATABASE FABRIC (ES + Redis) — token dependency
  F648 → QUEUE + DATABASE — cache invalidation
  F656 → QUEUE FABRIC — rebuild trigger
AF CONFIGURATION:
  AF-1: generates GlobalStylePropagationService
  AF-9: validates IR-654-1 (async via QUEUE FABRIC)
MACHINE: always async propagation through QUEUE FABRIC
IRON RULES:
  IR-T262-1: style propagation ALWAYS async — never inline blocking
  IR-T262-2: per-block overrides preserved after global style update
QUALITY GATES: QG-T262-1: all affected pages queued for rebuild < 5s
```

---

## TASK TYPE: T263 — Theme Switch
```
TASK TYPE:    T263 — Theme Switch
ARCHETYPE:    DESIGN_PROPAGATION
ENTRY:        Fires when user selects a different theme for their site
PURPOSE:      Swap active theme, propagate token set, trigger full site rebuild
DISTINCT FROM: T261 (single token update) — T263 is full theme replacement
FACTORY DEPENDENCIES: F655, F653, F648, F656
FABRIC RESOLUTION:
  F655 → DATABASE FABRIC (Elasticsearch) — theme registry
  F653 → DATABASE FABRIC (ES + Redis) — token set swap
  F648 → QUEUE + DATABASE — full site cache invalidation
  F656 → QUEUE FABRIC — full site rebuild
AF CONFIGURATION:
  AF-1: generates ThemeSwitchService
  AF-9: validates IR-655-2 (token propagation via F653)
MACHINE: full site cache invalidation + rebuild on theme switch
IRON RULES:
  IR-T263-1: system theme switch = fork + customize (IR-655-1)
  IR-T263-2: theme switch triggers FULL site rebuild (not partial)
QUALITY GATES: QG-T263-1: rebuild job enqueued < 1s after theme switch confirmed
```

---

## TASK TYPE: T264 — Asset Upload + Processing
```
TASK TYPE:    T264 — Asset Upload + Processing
ARCHETYPE:    MEDIA_PIPELINE
ENTRY:        Fires when user initiates file upload in media library
PURPOSE:      Presigned URL upload → async transform pipeline → CDN registration
DISTINCT FROM: T265 (image transforms only) — T264 is full upload lifecycle
FACTORY DEPENDENCIES: F662, F663, F664, F665, F670
FABRIC RESOLUTION:
  F662 → QUEUE FABRIC (Redis Streams) — upload lifecycle events
  F663 → AI ENGINE FABRIC (AiDispatcher) — transforms + alt text
  F664 → DATABASE FABRIC (Redis) — CDN URL registration
  F665 → DATABASE FABRIC (Elasticsearch) — media library record
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates AssetUploadPipelineService
  AF-2: decomposes into initiate → upload → complete → transform → CDN → library
  AF-4: searches SK-152 (Media Pipeline Pattern)
  AF-7: DNA-5 (tenantId on all bucket paths)
  AF-8: validates file type + size limits
  AF-9: validates IR-662-2 (tenantId-scoped bucket path), IR-663-1 (immutable variants)
BFA VALIDATION: CF-311: asset IDs must not collide across tenants
MACHINE: async transforms; immutable variants; tenantId-scoped storage
FREEDOM: max upload size; allowed MIME types; transform quality settings
IRON RULES:
  IR-T264-1: presigned URL includes tenantId namespace (IR-662-2)
  IR-T264-2: transform variants stored as new assetId (IR-663-1) — original preserved
  IR-T264-3: transform pipeline runs async via QUEUE FABRIC
QUALITY GATES:
  QG-T264-1: presigned URL returned < 200ms
  QG-T264-2: WebP variant generated within 30s of upload
```

---

## TASK TYPE: T265 — Image Transform
```
TASK TYPE:    T265 — Image Transform
ARCHETYPE:    MEDIA_PIPELINE
ENTRY:        Fires on explicit transform request or as part of T264 pipeline
PURPOSE:      AI-powered resize, crop, format conversion, responsive set generation
DISTINCT FROM: T264 (full upload) — T265 can run standalone on existing assets
FACTORY DEPENDENCIES: F663, F664, F670
FABRIC RESOLUTION:
  F663 → AI ENGINE FABRIC (AiDispatcher) — AI transforms
  F664 → DATABASE FABRIC (Redis) — CDN URL update
  F670 → QUEUE + DATABASE — audit
AF CONFIGURATION:
  AF-1: generates ImageTransformService
  AF-5: multi-model AI for auto-crop quality comparison
  AF-9: validates IR-663-1 (immutable variants)
MACHINE: async transforms; immutable output; AI model via config
IRON RULES:
  IR-T265-1: transform output is immutable — stored as new assetId
  IR-T265-2: AI alt-text generation requires content safety validation
QUALITY GATES: QG-T265-1: responsive set (3 variants) generated < 60s
```

---

## TASK TYPE: T266 — Asset Replacement Fan-out
```
TASK TYPE:    T266 — Asset Replacement Fan-out
ARCHETYPE:    MEDIA_PIPELINE
ENTRY:        Fires when user replaces an asset and confirms fan-out to all usages
PURPOSE:      Replace old asset reference in all posts/pages with new assetId; async fan-out
DISTINCT FROM: T264/T265 (new upload/transform) — T266 is reference replacement
FACTORY DEPENDENCIES: F666, F665, F631, F638, F648
FABRIC RESOLUTION:
  F666 → QUEUE FABRIC (Redis Streams) — fan-out events
  F665 → DATABASE FABRIC (Elasticsearch) — usage lookup
  F631 → DATABASE FABRIC (Elasticsearch) — page tree update
  F638 → DATABASE FABRIC (ES + PG) — post content update
  F648 → QUEUE + DATABASE — cache invalidation
AF CONFIGURATION:
  AF-1: generates AssetReplacementFanoutService
  AF-2: decomposes into preview-scope → confirm → fan-out → invalidate
  AF-9: validates IR-666-2 (old asset retained until confirmed)
BFA VALIDATION: CF-312: replacement job must not conflict with active publish
MACHINE: async fan-out; old asset retained until confirmed
IRON RULES:
  IR-T266-1: old asset RETAINED until replacement confirmed (IR-666-2)
  IR-T266-2: fan-out events use idempotency-key per replacement job
  IR-T266-3: replacement triggers cache invalidation for all affected pages
QUALITY GATES:
  QG-T266-1: fan-out preview computed < 3s
  QG-T266-2: all pages updated within 60s for < 1000 usages
```

---

## AF STATION MAPPING — FLOW-20 (11 × 20 task types)

| Task Type | AF-1 Genesis | AF-2 Plan | AF-3 Prompts | AF-4 RAG | AF-5 Multi-model | AF-6 Review | AF-7 Compliance | AF-8 Security | AF-9 Judge | AF-10 Merge | AF-11 Feedback |
|-----------|------------|-----------|-------------|---------|-----------------|-------------|----------------|--------------|-----------|------------|----------------|
| T247 | PageTreeMutationSvc | lock→snap→mutate→broadcast | editor prompts | SK-145 | — | ETag impl | DNA-1,DNA-5 | lock ownership | IR-631-1,CF-296 | — | latency score |
| T248 | ComponentRegSvc | validate→register | schema prompts | SK-146 | — | schema check | DNA-1 | — | DD-130,CF-297 | — | schema quality |
| T249 | LayoutResolutionSvc | — | layout prompts | SK-145 | — | read-only check | DNA-2 | — | IR-633-2 | — | latency |
| T250 | LivePreviewSvc | — | preview prompts | SK-153 | ✅ parallel preview | — | DNA-5 | tenant isolation | DD-131,CF-298 | ✅ quality | preview score |
| T251 | PostTypeRegSvc | validate→register | cms prompts | SK-146,SK-147 | — | additive-only | DNA-1,DNA-5 | — | DD-130,CF-297 | — | schema quality |
| T252 | PostWriteSvc | draft→validate→snapshot | content prompts | SK-148,SK-145 | — | ETag impl | DNA-1,DNA-2 | — | IR-638-2,CF-300 | — | write latency |
| T253 | PostTransitionSvc | validate→gate→transition→fanout | workflow prompts | SK-150 | — | state machine | DNA-3,DNA-5 | — | IR-638-1,CF-302 | — | transition latency |
| T254 | EditorialGateSvc | submit→review→approve/reject | approval prompts | SK-147 | — | — | DNA-4 | RBAC check | CF-305,IR-646-1 | — | approval time |
| T255 | CmsFeedQuerySvc | — | feed prompts | SK-149 | — | filter review | DNA-2,DNA-5 | — | CF-306,IR-T255-1 | — | query latency |
| T256 | PublishPipelineSvc | render→CDN→invalidate→sitemap→index | publish prompts | SK-150,SK-151 | — | idempotency | DNA-4,DNA-5 | CDN isolation | IR-647-1,CF-307 | ✅ merge | pipeline score |
| T257 | ScheduledPublishSvc | trigger→validate→transition | scheduler prompts | SK-151 | — | — | DNA-3 | — | DD-132,IR-T257-3 | — | timing accuracy |
| T258 | PublishRollbackSvc | validate→repoint→invalidate | rollback prompts | SK-150 | — | — | DNA-4 | RBAC check | IR-652-1,CF-309 | — | rollback time |
| T259 | StaticBuildSvc | tree→render→artifact | build prompts | SK-153 | ✅ build optimize | — | DNA-5 | — | DD-131,IR-T259-2 | ✅ quality | build quality |
| T260 | SitemapRssSvc | query→generate→submit | SEO prompts | SK-154 | — | slug check | DNA-5 | — | IR-651-1,CF-306 | — | coverage |
| T261 | DesignTokenUpdateSvc | update→invalidate→scope→rebuild | token prompts | SK-145 | — | cache review | DNA-5 | — | CF-299,CF-310 | — | propagation time |
| T262 | GlobalStylePropSvc | compute→propagate→queue-rebuild | style prompts | SK-145 | — | async check | DNA-5 | — | IR-654-1 | — | propagation scope |
| T263 | ThemeSwitchSvc | fork→swap→rebuild | theme prompts | SK-153 | — | — | DNA-5 | — | IR-655-2,IR-T263-2 | — | rebuild time |
| T264 | AssetUploadSvc | initiate→upload→transform→CDN | asset prompts | SK-152 | — | MIME validation | DNA-5 | file safety | IR-662-2,CF-311 | — | pipeline latency |
| T265 | ImageTransformSvc | transform→variant→CDN | transform prompts | SK-152 | ✅ AI quality | — | DNA-5 | alt-text safety | IR-663-1 | ✅ quality | transform quality |
| T266 | AssetReplacementSvc | preview→confirm→fanout→invalidate | replacement prompts | SK-152 | — | usage scan | DNA-5 | — | IR-666-2,CF-312 | — | fanout coverage |

---

## FLOW TEMPLATES

### Template 50 — visual-editor-builder-v1 (Page Build + Publish)
```json
{
  "template_id": "visual-editor-builder-v1",
  "flow_id": "FLOW-20",
  "description": "Create page, add components, live preview, publish",
  "steps": [
    { "id": "step-1", "task_type": "T247", "factory": "F631,F635,F636,F670", "on_success": "step-2" },
    { "id": "step-2", "task_type": "T249", "factory": "F633,F631,F636", "on_success": "step-3" },
    { "id": "step-3", "task_type": "T250", "factory": "F634,F631,F640,F650", "on_success": "step-4" },
    { "id": "step-4", "task_type": "T253", "factory": "F638,F646,F647,F671,F670", "on_success": "step-5" },
    { "id": "step-5", "task_type": "T256", "factory": "F647,F649,F648,F651,F672,F670", "on_success": "complete" }
  ]
}
```

### Template 51 — cms-authoring-v1 (Draft + Review + Publish)
```json
{
  "template_id": "cms-authoring-v1",
  "flow_id": "FLOW-20",
  "description": "Author post, editorial review, schedule or immediate publish",
  "steps": [
    { "id": "step-1", "task_type": "T252", "factory": "F638,F639,F641,F643,F670", "on_success": "step-2" },
    { "id": "step-2", "task_type": "T254", "factory": "F646,F669,F670,F671", "on_success": "step-3", "optional": true },
    { "id": "step-3", "task_type": "T253", "factory": "F638,F646,F647,F671,F670", "branches": ["step-4a-immediate","step-4b-scheduled"] },
    { "id": "step-4a-immediate", "task_type": "T256", "factory": "F647,F649,F648,F651,F672,F670" },
    { "id": "step-4b-scheduled", "task_type": "T257", "factory": "F671,F638,F647" }
  ]
}
```

### Template 52 — design-token-rebuild-v1 (Token Change → Rebuild)
```json
{
  "template_id": "design-token-rebuild-v1",
  "flow_id": "FLOW-20",
  "description": "Design token update triggers partial or full site rebuild",
  "steps": [
    { "id": "step-1", "task_type": "T261", "factory": "F653,F648,F656,F633,F670", "on_success": "step-2" },
    { "id": "step-2", "task_type": "T259", "factory": "F649,F650,F653,F656", "on_success": "step-3" },
    { "id": "step-3", "task_type": "T260", "factory": "F651,F657,F638", "on_success": "complete" }
  ]
}
```

---

## BACKWARD COMPATIBILITY
```
T1–T246:        UNCHANGED ✅
Templates 1–49: UNCHANGED ✅
New: T247–T266 (20 task types)
New: Templates 50–52 (3 templates)
New archetypes: PAGE_BUILDER, CMS_LIFECYCLE, PUBLISH_SAGA, DESIGN_PROPAGATION, MEDIA_PIPELINE
System: T1–T266, Templates 1–52
```

---

## SAVE POINT: FLOW20:P2:TASK_TYPES:COMPLETE ✅
## Recovery: "FLOW-20 P2 complete. T247-T266 / Templates 50-52. Continue with P3 BFA."
