# MASTER EXECUTION PLAN — FLOW-20 EXTENSION
# Visual Editor & Site Builder Platform
# Extends: MASTER_EXECUTION_PLAN_MERGED.md (FLOW-01 through FLOW-17)
# Save Point: FLOW20:P7:PLAN:COMPLETE

---

## PLAN IDENTITY

```
FLOW:         FLOW-20 — Visual Editor & Site Builder Platform
SCOPE:        Extend XIIGen engine to generate Visual Editor + Headless CMS flows
INPUTS:       22-visual-editor.md, 22-visual-editor-deep-search.md,
              22-visual-editor-deep-search-engine.md,
              22-visual-editor-deep-search-engine-multi-tenant.md,
              multi-tenant-support.md
OUTPUTS:      7 engine extension documents (all complete ✅)
APPROACH:     Fabric-first, engine-extends (not standalone implementations)
```

---

## EXECUTION PHASES — COMPLETED

### PHASE 1 — ENGINE ARCHITECTURE (P1) ✅
```
GOAL:         Define all factory interfaces for FLOW-20 (44 factories, 7 families)
DURATION:     ~25 min (within 45-min recovery window)
OUTPUT:       22_-_visual_editor_ENGINE_ARCHITECTURE.md
DELIVERED:
  - Family 84: Visual Editor Canvas     (F631–F636)
  - Family 85: CMS & Content Modeling   (F637–F645)
  - Family 86: Content Authoring        (F643–F648)
  - Family 87: Publishing Pipeline      (F648–F660)
  - Family 88: AI Content Assist        (F658–F660)
  - Family 89: Design Tokens & Media    (F653–F665)
  - Family 90: Multi-Tenant Workspaces  (F671–F674)
  - All factories mapped to FABRIC RESOLUTION
  - All extend IExternalServiceFactory<TService> via CreateAsync()
VERIFICATION: No standalone DB/Queue/AI imports; all via fabric
SAVE POINT:   FLOW20:P1:ENGINE_ARCH:COMPLETE ✅
```

### PHASE 2 — TASK TYPES CATALOG (P2) ✅
```
GOAL:         Full engine contracts for T247–T266 (20 task types, 3 flow templates)
DURATION:     ~30 min
OUTPUT:       22_-_visual_editor_TASK_TYPES_CATALOG.md
DELIVERED:
  - T247–T250: Page Builder archetypes (canvas, component, snapshot, preview)
  - T251–T255: CMS Lifecycle archetypes (post type, draft, publish gate, review, feed)
  - T256–T260: Publish Saga archetypes (async pipeline, schedule, rollback, SSR/SSG, SEO)
  - T261–T262: Design Propagation archetypes (token propagation, theme switch)
  - T263:      AI Content Suggestion (fire-and-suggest)
  - T264–T266: Media Pipeline + Workspace Provision
  - Templates 50–52: visual-editor-v1, cms-authoring-v1, design-token-rebuild-v1
FORMAT:       Full engine contract (ARCHETYPE/ENTRY/PURPOSE/FACTORY DEPS/FABRIC RESOLUTION/
              AF CONFIGURATION/BFA VALIDATION/MACHINE-FREEDOM/IRON RULES/QUALITY GATES)
SAVE POINT:   FLOW20:P2:TASK_TYPES:COMPLETE ✅
```

### PHASE 3 — BFA STRESS TESTS (P3) ✅
```
GOAL:         28 conflict rules (CF-295–CF-322) + 15 stress tests (ST-164–ST-178)
DURATION:     ~20 min
OUTPUT:       22_-_visual_editor_V62_BFA_STRESS_TEST.md
DELIVERED:
  CF-295–CF-301: Visual editor component/canvas rules
  CF-302–CF-313: CMS content lifecycle rules
  CF-314–CF-320: Publishing pipeline + media rules
  CF-321–CF-322: Multi-tenant workspace rules
  ST-164–ST-175: Per-domain stress tests (editor, CMS, publish, design, media, AI, multi-tenant)
  ST-176–ST-178: Cross-flow conflict stress tests (vs FLOW-05, FLOW-14, FLOW-16)
  Cross-flow conflict matrix (FLOW-20 vs FLOW-01–FLOW-17)
SAVE POINT:   FLOW20:P3:BFA:COMPLETE ✅
```

### PHASE 4 — SKILLS FACTORY RAG (P4) ✅
```
GOAL:         10 new skills (SK-145–SK-154) for AF-4 RAG retrieval
DURATION:     ~15 min
OUTPUT:       22_-_visual_editor_SKILLS_FACTORY_RAG.md
DELIVERED:
  SK-145: Page tree mutation patterns (T247, T249)
  SK-146: JSON Schema 2020-12 / PostType patterns (T248, T251)
  SK-147: Collection relation + referential integrity (T251, T254)
  SK-148: Optimistic concurrency / ETag patterns (T252)
  SK-149: Content feed query / BuildSearchFilter (T255)
  SK-150: Publish saga + compensation + CloudEvents (T256, T258)
  SK-151: Scheduled publish / RFC 3339 (T257)
  SK-152: Asset upload / image transform / CDN (T264, T265)
  SK-153: SSR/SSG hybrid + live preview (T250, T259)
  SK-154: Sitemap / RSS / SEO meta / slug redirect (T260)
AF-4 RAG INDEX updated with keyword → skill → task type mapping
SAVE POINT:   FLOW20:P4:SKILLS:COMPLETE ✅
```

### PHASE 5 — UNIFIED SOURCE INDEX (P5) ✅
```
GOAL:         12 design decisions (DD-130–DD-141) + 8 design records (DR-99–DR-106)
DURATION:     ~20 min
OUTPUT:       22_-_visual_editor_UNIFIED_SOURCE_INDEX.md
DELIVERED:
  DD-130: JSON Schema 2020-12 (vs TypeScript interface, custom schema, GraphQL SDL)
  DD-131: Hybrid SSR/SSG (vs pure SSG, pure SSR)
  DD-132: CloudEvents envelope (vs raw JSON, custom envelope)
  DD-133: ES + PG persistence (vs MongoDB, pure PG)
  DD-134: Optimistic concurrency (vs pessimistic locks, last-write-wins)
  DD-135: workspaceId ≡ tenantId (reuse DNA-5)
  DD-136: Design token inheritance + build-time CSS (vs runtime resolution, flat map)
  DD-137: Component registry append-only (vs mutable, replace-on-update)
  DD-138: AI assist non-blocking / fire-and-suggest (vs blocking, inline autocomplete)
  DD-139: Media transforms single-pass from original
  DD-140: SEO outputs engine-generated at publish time
  DD-141: BFA workspace registration at provision time
  DR-99–DR-106: Full requirement traceability for all 7 FLOW-20 domains
SAVE POINT:   FLOW20:P5:INDEX:COMPLETE ✅
```

### PHASE 6 — SESSION STATE (P6) ✅
```
GOAL:         Update global system state tracker with all FLOW-20 additions
DURATION:     ~10 min
OUTPUT:       22_-_visual_editor_SESSION_STATE.md
DELIVERED:
  Global counters updated: F1–F674, T1–T266, CF-1–CF-322, SK-1–SK-154,
                           DD-1–DD-141, DR-1–DR-106, FLOW-01 through FLOW-20
  Family registry: Families 84–90
  Factory registry: F631–F674 with FABRIC RESOLUTION
  Task type registry: T247–T266 with ARCHETYPE + FAMILY
  BFA cross-flow registration: entities, events, API paths
  DNA compliance summary: 6/6 ✅
  Promotion ladder status
  Recovery instructions
SAVE POINT:   FLOW20:P6:SESSION_STATE:COMPLETE ✅
```

### PHASE 7 — MASTER EXECUTION PLAN (P7) ✅
```
GOAL:         This document — execution plan + integration guide + next-flow template
DURATION:     ~10 min
OUTPUT:       22_-_visual_editor_MASTER_EXECUTION_PLAN.md
SAVE POINT:   FLOW20:P7:PLAN:COMPLETE ✅
```

---

## REQUIREMENT COVERAGE MATRIX

| Source Document | Requirements | Covered By | Status |
|---|---|---|---|
| 22-visual-editor.md | Drag-drop canvas, component library, undo/redo | T247, T248, T249, F631-F636 | ✅ |
| 22-visual-editor.md | Live preview | T250, F634, DD-131 | ✅ |
| 22-visual-editor.md | Headless CMS + post types | T251, T252, F637-F645 | ✅ |
| 22-visual-editor.md | Editorial workflow (draft/review/publish) | T253, T254, F641, F647 | ✅ |
| 22-visual-editor.md | Scheduled publishing | T257, F646 | ✅ |
| 22-visual-editor.md | AI content assist + auto-tagging | T263, T254, F658, F659 | ✅ |
| 22-visual-editor-deep-search.md | SSR/SSG pipeline | T256, T259, F649, F650 | ✅ |
| 22-visual-editor-deep-search.md | CDN invalidation | T256, F651 | ✅ |
| 22-visual-editor-deep-search.md | Sitemap, RSS, SEO structured data | T260, F657, F660 | ✅ |
| 22-visual-editor-deep-search.md | Media pipeline (WebP, responsive) | T264, T265, F661-F664 | ✅ |
| 22-visual-editor-deep-search-engine.md | Design token inheritance | T261, T262, F656, DD-136 | ✅ |
| 22-visual-editor-deep-search-engine.md | Theme variants | T262, F653 | ✅ |
| 22-visual-editor-deep-search-engine.md | CloudEvents event envelopes | DD-132, CF-318 | ✅ |
| 22-visual-editor-multi-tenant.md | Per-workspace isolation | T266, F671-F674, DD-135 | ✅ |
| 22-visual-editor-multi-tenant.md | Workspace RBAC | F672 | ✅ |
| 22-visual-editor-multi-tenant.md | Workspace billing + analytics | F673, F674 | ✅ |
| basic_prompt.txt | All 6 DNA patterns | DR-106 (full audit) | ✅ |
| basic_prompt.txt | Fabric-first (no direct provider imports) | All F631–F674 | ✅ |
| basic_prompt.txt | BFA cross-flow validation | CF-307, CF-322, DD-141 | ✅ |
| basic_prompt.txt | Backward compatibility T1–T246 | UNCHANGED confirmed | ✅ |
| basic_prompt.txt | Full engine contract format for task types | T247–T266 all full format | ✅ |

**COVERAGE: 100% ✅ — ZERO GAPS**

---

## ENGINE INTEGRATION GUIDE

### How FLOW-20 Integrates with the Existing Engine

```
1. FACTORY REGISTRY UPDATE
   Register F631–F674 in the engine's global factory registry.
   Each factory registered with:
     - Interface name (e.g., IPageTreeService)
     - FABRIC RESOLUTION (e.g., DATABASE FABRIC → ES)
     - CreateAsync() resolver function
     - Health check endpoint
     - Fallback strategy

2. TASK TYPE CATALOG UPDATE
   Append T247–T266 to TASK_TYPES_CATALOG.
   Engine uses catalog entries to:
     - Route AF station configuration per task type
     - Validate factory dependencies at flow generation time
     - Apply iron rules during AF-7 Compliance scan
     - Configure AF-9 Judge quality gates

3. FLOW TEMPLATE REGISTRATION
   Register Templates 50–52 in FlowOrchestrator (Skill 09):
     Template 50: visual-editor-v1
     Template 51: cms-authoring-v1
     Template 52: design-token-rebuild-v1
   Each template stored as JSON DAG in Elasticsearch.

4. BFA INDEX UPDATE
   Register FLOW-20 entities, events, and API paths.
   Run cross-flow conflict check against FLOW-01–FLOW-17 before activation.

5. RAG SKILL INDEX UPDATE
   Add SK-145–SK-154 to AF-4 RAG search index.
   Keyword mappings registered for all 10 new skills.

6. FREEDOM CONFIG DOCUMENTS
   Create admin-configurable FREEDOM layer ES documents for:
     - PostType schema registry configuration
     - Design token inheritance rules
     - Theme variant definitions
     - Workspace role permission templates
     - AI assist model selection (per workspaceId)
     - CDN provider config (per deployment)
     - SSG vs SSR routing rules
```

### AF Station Routing for FLOW-20

```
AF-1 Genesis:     Generates service code from T247–T266 contracts
                  Uses F631–F674 interface definitions as generation targets
                  All generated code extends MicroserviceBase (DNA-4)

AF-2 Planning:    Decomposes new flow requests into T247–T266 sequences
                  Uses Templates 50–52 as starting DAG structures

AF-3 Prompt Lib:  Retrieves FLOW-20-specific prompts for:
                  - JSON Schema 2020-12 generation (DD-130)
                  - CloudEvents envelope construction (DD-132)
                  - Optimistic concurrency ETag patterns (DD-134)

AF-4 RAG:         Searches SK-145–SK-154 for reusable patterns
                  Keywords: page tree, CMS, publish saga, design token,
                            media transform, workspace provision

AF-5 Multi-model: Runs competing models for complex T256 Publish Saga
                  and T266 Workspace Provision (highest complexity tasks)

AF-6 Code Review: Reviews generated service code for correctness
                  Checks: fabric interface usage, Dictionary types, no direct DB imports

AF-7 Compliance:  Validates ALL 6 DNA patterns on every generated service:
                  - Dictionary<string,object> (DNA-1)
                  - BuildSearchFilter (DNA-2)
                  - DataProcessResult<T> (DNA-3)
                  - MicroserviceBase extension (DNA-4)
                  - workspaceId present (DNA-5)
                  - DynamicController routing (DNA-6)

AF-8 Security:    Scans for: workspaceId bypass, CDN path traversal,
                  media upload injection, PostType schema injection,
                  AI provider key exposure, webhook SSRF

AF-9 Judge:       Validates against iron rules (all T247–T266 iron rules)
                  Quality gates:
                  - Canvas: snapshot before mutation, component version locked
                  - CMS: PostType changes additive only, editorial gate enforced
                  - Publish: CDN invalidated after build, SEO artifacts generated
                  - Media: originals immutable, transforms queue-async
                  - Workspace: BFA registered before activation

AF-10 Merge:      Combines multi-model outputs for publish saga and workspace provision

AF-11 Feedback:   Stores generation quality metrics keyed by T247–T266
                  Improves future generation quality for FLOW-20 task types
```

---

## NEXT FLOW TEMPLATE

When creating FLOW-21 or any future flow, use this template:

```
FLOW EXTENSION TEMPLATE
========================
FLOW ID:      FLOW-21 (or next)
NEW FAMILIES: [N+1 to N+X] — [Domain names]
NEW FACTORIES: F[next] to F[next+Y]
  Each factory:
    F[id] I[Name]Service → [FABRIC NAME] ([Provider])
NEW TASK TYPES: T[next] to T[next+Z]
  Each task type (FULL FORMAT):
    TASK TYPE, ARCHETYPE, ENTRY, PURPOSE, DISTINCT FROM,
    FACTORY DEPENDENCIES, FABRIC RESOLUTION, AF CONFIGURATION,
    BFA VALIDATION, MACHINE/FREEDOM, IRON RULES, QUALITY GATES
NEW TEMPLATES: Template [next+1] to Template [next+M]
NEW CF RULES: CF-[next] to CF-[next+P]
NEW STRESS TESTS: ST-[next] to ST-[next+Q]
NEW SKILLS: SK-[next] to SK-[next+R]
NEW DESIGN DECISIONS: DD-[next] to DD-[next+S]
NEW DESIGN RECORDS: DR-[next] to DR-[next+T]

7 DOCUMENTS TO GENERATE:
  [FLOW_ID]_ENGINE_ARCHITECTURE
  [FLOW_ID]_TASK_TYPES_CATALOG
  [FLOW_ID]_V62_BFA_STRESS_TEST
  [FLOW_ID]_SKILLS_FACTORY_RAG
  [FLOW_ID]_UNIFIED_SOURCE_INDEX
  [FLOW_ID]_SESSION_STATE
  [FLOW_ID]_MASTER_EXECUTION_PLAN

CHECKPOINTS:
  P1: ENGINE_ARCH → verify fabric resolution for all factories
  P2: TASK_TYPES  → verify full engine contract format (not stubs)
  P3: BFA         → verify cross-flow conflict checks vs FLOW-01 through FLOW-[current]
  P4: SKILLS      → verify AF-4 RAG index updated
  P5: INDEX       → verify design decisions include alternatives + rationale
  P6: SESSION     → verify global counters accurate
  P7: PLAN        → verify 100% requirement coverage

BACKWARD COMPATIBILITY CHECK:
  T1–T[prev]:   UNCHANGED ✅
  F1–F[prev]:   UNCHANGED ✅
  CF-1–CF[prev]: UNCHANGED ✅
  SK-1–SK[prev]: UNCHANGED ✅
```

---

## POSITIVE EXAMPLE — Correct FLOW-20 Extension Pattern

```csharp
// ✅ CORRECT: Factory resolved through DATABASE FABRIC — never direct
public class PageTreeService : MicroserviceBase, IPageTreeService
{
    private readonly IDatabaseService _db;

    public PageTreeService(IDatabaseService db, ...) : base(...)
    {
        _db = db; // DATABASE FABRIC — resolved via config, not new ElasticsearchClient()
    }

    public async Task<DataProcessResult<Dictionary<string,object>>> GetTreeAsync(
        string siteId, string workspaceId)
    {
        var filter = BuildSearchFilter(new {
            siteId = siteId,           // DNA-2: empty fields auto-skipped
            workspaceId = workspaceId  // DNA-5: scope isolation
        });

        return await _db.SearchDocumentsAsync("page_trees", filter); // DNA-3: returns Result<T>
    }
}
```

## NEGATIVE EXAMPLE — Violations That Trigger BUILD FAILURE

```csharp
// ❌ WRONG: Direct Elasticsearch import — violates FABRIC principle
using Elastic.Clients.Elasticsearch;

// ❌ WRONG: Typed model — violates DNA-1
public class PageTreeDto { public string SiteId { get; set; } ... }

// ❌ WRONG: Throws instead of DataProcessResult — violates DNA-3
throw new InvalidOperationException("Tree not found");

// ❌ WRONG: Missing workspaceId on query — violates DNA-5
var filter = BuildSearchFilter(new { siteId = siteId }); // workspaceId absent

// ❌ WRONG: Direct AI provider call — violates AI ENGINE FABRIC
var result = await openAIClient.Chat.CompletionsAsync(...);

// ❌ WRONG: Entity-specific controller — violates DNA-6
[ApiController]
[Route("page-trees")]
public class PageTreeController : ControllerBase { ... }
```

---

## BACKWARD COMPATIBILITY VERIFICATION

```
FLOW-01 through FLOW-17:  ✅ UNCHANGED
T1–T246:                  ✅ UNCHANGED
F1–F630:                  ✅ UNCHANGED
CF-1–CF-294:              ✅ UNCHANGED
ST-1–ST-163:              ✅ UNCHANGED
SK-1–SK-144:              ✅ UNCHANGED
DD-1–DD-129:              ✅ UNCHANGED
DR-1–DR-98:               ✅ UNCHANGED

NEW (ADDITIVE ONLY):
T247–T266:                ✅ NEW — no modification to existing task types
F631–F674:                ✅ NEW — no modification to existing factories
CF-295–CF-322:            ✅ NEW — no modification to existing conflict rules
ST-164–ST-178:            ✅ NEW — no modification to existing stress tests
SK-145–SK-154:            ✅ NEW — no modification to existing skills
DD-130–DD-141:            ✅ NEW — no modification to existing decisions
DR-99–DR-106:             ✅ NEW — no modification to existing records
```

---

## FINAL STATUS

```
FLOW-20:              COMPLETE ✅
ALL 7 DOCUMENTS:      GENERATED AND SAVED ✅
DNA COMPLIANCE:       6/6 — ZERO VIOLATIONS ✅
BFA REGISTRATION:     COMPLETE ✅
BACKWARD COMPAT:      FULLY PRESERVED ✅
REQUIREMENT COVERAGE: 100% — ZERO GAPS ✅

System: F1–F674 | T1–T266 | Families 1–90 | FLOW-01 through FLOW-20
```

---

## SAVE POINT: FLOW20:P7:PLAN:COMPLETE ✅
## SAVE POINT: FLOW20:ALL_PHASES:COMPLETE ✅
## Recovery: "All 7 FLOW-20 documents complete. System: F1-F674, T1-T266, Families 1-90, 0 gaps."
