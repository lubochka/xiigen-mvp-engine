# V62 BFA STRESS TEST — FLOW-20 EXTENSION
# Visual Editor & Site Builder Platform
# Extends: V62_BFA_STRESS_TEST_MERGED.md (CF-1–CF-294, ST-1–ST-163)
# FLOW-20 adds: CF-295–CF-322 (28 rules) | ST-164–ST-178 (15 stress tests)
# Save Point: FLOW20:P3:BFA:COMPLETE

---

## STATE REFERENCE
```
Previous: CF-1–CF-294 | ST-1–ST-163 — V62_BFA_STRESS_TEST_MERGED.md
This file: CF-295–CF-322 (28 new) | ST-164–ST-178 (15 new)
```

---

## BFA CONFLICT RULES — FLOW-20

---

### CF-295 — Design Token Update vs Active Publish Job
```
RULE:         CF-295
TYPE:         WRITE_CONFLICT
DESCRIPTION:  Design token update (T261) must not proceed while an active publish job (T256)
              is running for the same siteId + tenantId
ENTITIES:     IDesignTokenService (F653), IPublishJobService (F647)
TRIGGER:      F653.SetTokenAsync called while F647 has status=RUNNING for same siteId
DETECTION:    BFA checks publish_jobs index for active jobs before allowing token write
RESOLUTION:   Queue token update — execute after active publish job completes
ENFORCED BY:  T261, IR-T261-1, AF-9 of T261
CROSS-FLOW:   None (internal FLOW-20)
SEVERITY:     HIGH — token change during publish = inconsistent build artifact
```

### CF-296 — Collaboration Lock Ownership Violation
```
RULE:         CF-296
TYPE:         SECURITY_CONFLICT
DESCRIPTION:  Page tree mutation (T247) rejected if lock token does not belong to
              requesting userId + tenantId
ENTITIES:     ICollaborationLockService (F635), IPageTreeService (F631)
TRIGGER:      Lock token userId != authenticated userId
DETECTION:    F635 validates lock ownership before F631 write
RESOLUTION:   Reject mutation; return DataProcessResult 403 Forbidden
ENFORCED BY:  T247, IR-T247-1, AF-8 of T247
SEVERITY:     CRITICAL — unauthorized page tree mutations
```

### CF-297 — Component/PostType ID Collision
```
RULE:         CF-297
TYPE:         UNIQUENESS_CONFLICT
DESCRIPTION:  Component ID (F632) or PostType ID (F637) must not collide with existing
              registry entries within the same tenantId scope
ENTITIES:     IComponentRegistryService (F632), IPostTypeRegistryService (F637)
TRIGGER:      RegisterComponentAsync or RegisterPostTypeAsync with duplicate ID
DETECTION:    BFA checks registry before write
RESOLUTION:   Reject registration; return DataProcessResult with collision detail
ENFORCED BY:  T248, T251, AF-9 of both
SEVERITY:     HIGH — duplicate IDs break engine factory resolution
```

### CF-298 — Preview Cross-Tenant Data Exposure
```
RULE:         CF-298
TYPE:         DATA_ISOLATION_CONFLICT
DESCRIPTION:  Live preview (T250) must not read post/page data from other tenants
ENTITIES:     ILivePreviewService (F634), ICmsQueryService (F640)
TRIGGER:      Preview render with missing or mismatched tenantId filter
DETECTION:    AF-9 validates all ICmsQueryService calls include tenantId (DNA-5)
RESOLUTION:   Build failure if any query lacks tenantId
ENFORCED BY:  T250, DNA-5, AF-7 Compliance
SEVERITY:     CRITICAL — cross-tenant data exposure in preview
```

### CF-299 — Token Update Without Cache Invalidation
```
RULE:         CF-299
TYPE:         CONSISTENCY_CONFLICT
DESCRIPTION:  Any design token write (F653) MUST be followed by cache invalidation (F648)
              within the same operation chain
ENTITIES:     IDesignTokenService (F653), ICacheInvalidationService (F648)
TRIGGER:      F653 write without subsequent F648 InvalidateTokensAsync
DETECTION:    AF-9 validates token update task type includes F648 in factory dependencies
RESOLUTION:   Build failure if token update task type omits F648
ENFORCED BY:  T261, IR-T261-1, IR-648-3
SEVERITY:     HIGH — stale cached pages after token change
```

### CF-300 — Duplicate Published Slug
```
RULE:         CF-300
TYPE:         UNIQUENESS_CONFLICT
DESCRIPTION:  Post save (T252) must not create a slug that duplicates an existing
              published post slug within the same siteId + tenantId
ENTITIES:     IPostService (F638), ISlugService (F657)
TRIGGER:      CreatePostAsync or UpdatePostAsync with duplicate slug
DETECTION:    F657.RegisterSlugAsync checks existing registry before commit
RESOLUTION:   Return DataProcessResult with slug conflict; suggest alternative
ENFORCED BY:  T252, IR-T252-1 (version conflict), F657 IR-657-2
SEVERITY:     HIGH — duplicate slugs break routing
```

### CF-301 — Dangling Category/Tag Reference
```
RULE:         CF-301
TYPE:         REFERENTIAL_INTEGRITY_CONFLICT
DESCRIPTION:  Post save must not reference category or tag IDs that do not exist
              in the CMS collection for this siteId + tenantId
ENTITIES:     IPostService (F638), ICollectionRelationService (F642)
TRIGGER:      CreatePostAsync or UpdatePostAsync with non-existent categoryId/tagId
DETECTION:    F642 validates relation existence before post write
RESOLUTION:   Reject save; return DataProcessResult with missing reference detail
ENFORCED BY:  T252, AF-9 of T252
SEVERITY:     MEDIUM — content integrity issue
```

### CF-302 — Publish Event Without Cache Invalidation Chain
```
RULE:         CF-302
TYPE:         CONSISTENCY_CONFLICT
DESCRIPTION:  Post Published status (T253) must trigger cache invalidation (F648) chain
ENTITIES:     IPostService (F638), ICacheInvalidationService (F648)
TRIGGER:      Status transition to Published without F648 in event chain
DETECTION:    T256 publish pipeline validates F648 step present
RESOLUTION:   Build failure if publish pipeline omits cache invalidation step
ENFORCED BY:  T253, T256, IR-T256-3
SEVERITY:     HIGH — stale pages served after publish
```

### CF-303 — Slug Change Without Redirect
```
RULE:         CF-303
TYPE:         CONSISTENCY_CONFLICT
DESCRIPTION:  Any slug change (F657.ChangeSlugAsync) MUST auto-create a 301 redirect
              via IRedirectService (F658)
ENTITIES:     ISlugService (F657), IRedirectService (F658)
TRIGGER:      Slug changed without F658.CreateRedirectAsync called with old slug
DETECTION:    F657.ChangeSlugAsync validates F658 registration in same operation
RESOLUTION:   Atomic: slug change + redirect creation in same transaction
ENFORCED BY:  T253, IR-657-1, IR-T253-?
SEVERITY:     HIGH — broken links, SEO damage
```

### CF-304 — Circular Redirect Chain
```
RULE:         CF-304
TYPE:         LOOP_CONFLICT
DESCRIPTION:  Redirect chain A→B→C→A must be rejected at engine level
ENTITIES:     IRedirectService (F658)
TRIGGER:      CreateRedirectAsync where target is in existing chain originating from source
DETECTION:    F658 traverses existing redirect graph before write
RESOLUTION:   Reject; return DataProcessResult with cycle detail
ENFORCED BY:  F658 IR-658-2, AF-9 of routing tasks
SEVERITY:     HIGH — infinite redirect loop for visitors
```

### CF-305 — Hardcoded Workflow Config
```
RULE:         CF-305
TYPE:         FREEDOM_VIOLATION
DESCRIPTION:  Editorial workflow configuration (approval steps, required roles, timeouts)
              MUST come from FREEDOM config (F668) — never hardcoded in service
ENTITIES:     IEditorialWorkflowService (F646), ISiteConfigService (F668)
TRIGGER:      Workflow configuration found in generated service code instead of ES config
DETECTION:    AF-7 Compliance scans for hardcoded role strings or step counts
RESOLUTION:   Build failure; refactor to read from F668 ISiteConfigService
ENFORCED BY:  T254, IR-T254-1, DNA-4 (FREEDOM principle)
SEVERITY:     HIGH — workflow changes require code deploy (violates FREEDOM principle)
```

### CF-306 — Draft/Scheduled Content in Public Feed
```
RULE:         CF-306
TYPE:         DATA_EXPOSURE_CONFLICT
DESCRIPTION:  Public CMS feed queries (T255) and sitemap (T260) must NEVER surface
              Draft or Scheduled posts
ENTITIES:     ICmsQueryService (F640), ISitemapRssService (F651)
TRIGGER:      Query or sitemap generation without status=Published filter
DETECTION:    AF-9 validates BuildSearchFilter includes status field
RESOLUTION:   Build failure if status filter absent from public query
ENFORCED BY:  T255, T260, IR-T255-1, IR-T260-2
SEVERITY:     CRITICAL — unreleased content exposure
```

### CF-307 — Publish Job Entity Conflict (Cross-Flow)
```
RULE:         CF-307
TYPE:         CROSS_FLOW_CONFLICT
DESCRIPTION:  Publish job (T256, FLOW-20) must check BFA for entity conflicts with
              FLOW-01 through FLOW-17 before executing pipeline
ENTITIES:     IPublishJobService (F647) and all prior flow BFA registrations
TRIGGER:      Publish job for entity types also managed by prior flows
DETECTION:    BFA index checked at publish job enqueue time
RESOLUTION:   Conflict logged; publish job may proceed with conflict notification
ENFORCED BY:  T256, AF-9 of T256
SEVERITY:     MEDIUM — cross-flow entity state inconsistency
```

### CF-308 — Concurrent Publish Jobs for Same Site
```
RULE:         CF-308
TYPE:         CONCURRENCY_CONFLICT
DESCRIPTION:  Only one active publish job per siteId + tenantId at a time
ENTITIES:     IPublishJobService (F647)
TRIGGER:      Second EnqueuePublishAsync while first still RUNNING for same siteId
DETECTION:    F647 checks active job index before enqueue
RESOLUTION:   Second job queued (pending) until first completes
ENFORCED BY:  T256, IR-T256-? (single active publish per site)
SEVERITY:     HIGH — concurrent publish = artifact collision
```

### CF-309 — Rollback During Active Publish
```
RULE:         CF-309
TYPE:         CONCURRENCY_CONFLICT
DESCRIPTION:  Rollback (T258) prohibited while active publish job running for same site
ENTITIES:     IPublishRollbackService (F652), IPublishJobService (F647)
TRIGGER:      RollbackToVersionAsync while F647 has RUNNING job for siteId
DETECTION:    F652 checks F647 active job status before proceeding
RESOLUTION:   Reject rollback; return DataProcessResult with active job reference
ENFORCED BY:  T258, IR-T258-3
SEVERITY:     HIGH — rollback + publish race = corrupted published state
```

### CF-310 — Token Update During Active Design Rebuild
```
RULE:         CF-310
TYPE:         WRITE_CONFLICT
DESCRIPTION:  Token update (T261) must not proceed while design rebuild (T259) is active
ENTITIES:     IDesignTokenService (F653), IDesignTokenRebuildService (F656)
TRIGGER:      F653 write while F656 has active rebuild job for same siteId
DETECTION:    F653 checks rebuild job status via F656 before write
RESOLUTION:   Queue token update until rebuild completes
ENFORCED BY:  T261, CF-295 (related)
SEVERITY:     MEDIUM — mid-rebuild token change = inconsistent build output
```

### CF-311 — Asset ID Cross-Tenant Collision
```
RULE:         CF-311
TYPE:         UNIQUENESS_CONFLICT
DESCRIPTION:  Asset IDs must be globally unique — no collision across tenants
ENTITIES:     IAssetUploadService (F662), IMediaLibraryService (F665)
TRIGGER:      Asset upload producing ID that collides with existing asset in any tenant
DETECTION:    F662 generates UUID v4 — collision probability negligible but validated
RESOLUTION:   Re-generate UUID on collision (extremely rare)
ENFORCED BY:  T264, IR-662-2
SEVERITY:     MEDIUM — cross-tenant CDN URL guessing risk
```

### CF-312 — Asset Replacement During Active Publish
```
RULE:         CF-312
TYPE:         CONCURRENCY_CONFLICT
DESCRIPTION:  Asset replacement fan-out (T266) must not run while active publish job
              references the same siteId
ENTITIES:     IAssetReplacementService (F666), IPublishJobService (F647)
TRIGGER:      ReplaceAssetAsync while F647 has active publish job for siteId
DETECTION:    F666 checks F647 active job status before initiating fan-out
RESOLUTION:   Queue replacement until publish completes
ENFORCED BY:  T266, IR-T266-3
SEVERITY:     HIGH — replacement during publish = broken asset references in build
```

### CF-313 — Schema Removal Attempted
```
RULE:         CF-313
TYPE:         BACKWARD_COMPAT_CONFLICT
DESCRIPTION:  PostType schema field removal is prohibited — only additive changes allowed
ENTITIES:     IPostTypeRegistryService (F637), IPostTypeSchemaService (F639)
TRIGGER:      UpdatePostTypeSchemaAsync with field count less than previous version
DETECTION:    F637 diffs incoming schema against stored schema before write
RESOLUTION:   Reject; return DataProcessResult with removed field list
ENFORCED BY:  T251, IR-637-2, IR-T251-2
SEVERITY:     HIGH — field removal breaks existing post data
```

### CF-314 — Sitemap Cross-Tenant URL Exposure
```
RULE:         CF-314
TYPE:         DATA_ISOLATION_CONFLICT
DESCRIPTION:  Sitemap (F651) and RSS (F651) must never contain URLs from other tenants
ENTITIES:     ISitemapRssService (F651)
TRIGGER:      Sitemap generation query missing tenantId + siteId filter
DETECTION:    AF-9 validates BuildSearchFilter includes tenantId + siteId (DNA-5)
RESOLUTION:   Build failure if filter absent
ENFORCED BY:  T260, IR-T260-1, DNA-5
SEVERITY:     CRITICAL — cross-tenant SEO data exposure
```

### CF-315 — Redirect Scoping Violation
```
RULE:         CF-315
TYPE:         DATA_ISOLATION_CONFLICT
DESCRIPTION:  Redirect lookup must be scoped by tenantId + siteId — no global redirects
ENTITIES:     IRedirectService (F658)
TRIGGER:      ResolveRedirectAsync without tenantId + siteId in lookup
DETECTION:    F658 validates filter parameters — rejects unscoped lookup
RESOLUTION:   Build failure; reject unscoped redirect resolution
ENFORCED BY:  F658, IR-658-3, DNA-5
SEVERITY:     HIGH — wrong tenant's redirects served
```

### CF-316 — SSG Artifact Used for Preview
```
RULE:         CF-316
TYPE:         CORRECTNESS_CONFLICT
DESCRIPTION:  Live preview (T250) must NEVER return a cached SSG artifact — always fresh SSR
ENTITIES:     ILivePreviewService (F634), IStaticBuildService (F649)
TRIGGER:      Preview response served from F649 build artifact cache
DETECTION:    AF-9 validates T250 has no dependency on F649 in its resolution path
RESOLUTION:   Build failure if T250 task type references F649
ENFORCED BY:  T250, DD-131, IR-634-1
SEVERITY:     HIGH — preview shows stale published content, not live editor state
```

### CF-317 — Publish Without Idempotency Key
```
RULE:         CF-317
TYPE:         RELIABILITY_CONFLICT
DESCRIPTION:  All publish job enqueue operations (F647) must include an idempotency-key
ENTITIES:     IPublishJobService (F647)
TRIGGER:      EnqueuePublishAsync call without idempotency-key in payload
DETECTION:    F647 validates idempotency-key presence before enqueue
RESOLUTION:   Reject enqueue; return DataProcessResult with missing key error
ENFORCED BY:  T256, T257, IR-647-1
SEVERITY:     HIGH — duplicate publish events without idempotency = duplicate builds
```

### CF-318 — Non-CloudEvents Job Envelope
```
RULE:         CF-318
TYPE:         FORMAT_CONFLICT
DESCRIPTION:  All QUEUE FABRIC events in FLOW-20 must use CloudEvents-compatible envelope
ENTITIES:     All QUEUE FABRIC factories (F635, F647, F648, F656, F662, F666, F670, F671, F673)
TRIGGER:      Event payload missing CloudEvents required fields (source, type, subject, time)
DETECTION:    AF-7 validates event schemas in generated service code
RESOLUTION:   Build failure; regenerate with CloudEvents wrapper
ENFORCED BY:  DD-132, AF-7 Compliance
SEVERITY:     MEDIUM — cross-service correlation/tracing breaks
```

### CF-319 — Analytics PII Without Consent Config
```
RULE:         CF-319
TYPE:         PRIVACY_CONFLICT
DESCRIPTION:  Analytics events (F673) must not capture PII fields without consent config
              being explicitly enabled in FREEDOM config
ENTITIES:     IAnalyticsEventService (F673), ISiteConfigService (F668)
TRIGGER:      Analytics event with email/userId/IP without consent_enabled=true in F668
DETECTION:    F673 checks F668 consent config before including PII fields
RESOLUTION:   Strip PII fields from event if consent not configured
ENFORCED BY:  IR-673-1, AF-8 Security
SEVERITY:     HIGH — GDPR/CCPA violation risk
```

### CF-320 — RBAC Role Assignment Missing Composite Key
```
RULE:         CF-320
TYPE:         DATA_MODEL_CONFLICT
DESCRIPTION:  Role assignments in IRbacSiteService (F669) MUST be composite
              (tenantId, siteId, userId, role) — no single-field role assignments
ENTITIES:     IRbacSiteService (F669)
TRIGGER:      Role assignment stored without all four fields
DETECTION:    AF-7 validates RBAC writes include composite key
RESOLUTION:   Build failure; schema validation enforces all four fields
ENFORCED BY:  IR-669-1, AF-7 Compliance
SEVERITY:     CRITICAL — role elevation across tenants or sites
```

### CF-321 — AI Output Auto-Committed Without User Confirmation
```
RULE:         CF-321
TYPE:         SAFETY_CONFLICT
DESCRIPTION:  AI-generated content (F644 writing assistant, F659 SEO meta, F663 alt-text)
              MUST NOT be committed to content store without explicit user confirmation
ENTITIES:     IAiWritingAssistantService (F644), ISeoMetadataService (F659),
              IImageTransformService (F663)
TRIGGER:      AI output written to F638/F659/F665 without confirmation flag
DETECTION:    AF-9 validates AI task types include confirmation step in pipeline
RESOLUTION:   Build failure; insert confirmation gate task
ENFORCED BY:  IR-644-1, IR-659-1, IR-663-2
SEVERITY:     HIGH — unreviewed AI content published inadvertently
```

### CF-322 — Tenant Provisioning Non-Idempotent
```
RULE:         CF-322
TYPE:         RELIABILITY_CONFLICT
DESCRIPTION:  ITenantProvisioningService (F674) must be idempotent — re-running provisioning
              for an existing tenant must not create duplicate resources
ENTITIES:     ITenantProvisioningService (F674)
TRIGGER:      ProvisionAsync called for tenantId that already has resources
DETECTION:    F674 checks existence of tenantId in workspace registry before provisioning
RESOLUTION:   No-op result with existing tenant detail returned
ENFORCED BY:  IR-674-1
SEVERITY:     HIGH — duplicate tenant resources = data isolation failure
```

---

## STRESS TESTS — FLOW-20

### ST-164 — Concurrent Editors Race Condition
```
TEST:         ST-164
SCENARIO:     Two editors simultaneously mutate same page tree node (T247)
              Second mutation arrives 50ms after first lock acquired
EXPECTED:     Second mutation rejected with CF-296 (lock ownership violation)
              Returns DataProcessResult with lock owner detail
              No data corruption in page tree
FAILURE MODE: Both mutations succeed = split-brain page tree
FACTORIES:    F631, F635
VERIFY:       Single winning version in ES; loser receives 409 result
```

### ST-165 — Token Update During Build Race
```
TEST:         ST-165
SCENARIO:     Admin updates design token while SSG build (T259) is 50% complete
EXPECTED:     CF-295 + CF-310 fire; token update queued until build completes
              Build artifact uses original tokens (consistent)
              Post-build: token update applies, new rebuild triggered
FAILURE MODE: Token update mid-build = partially tokenized artifact
FACTORIES:    F653, F649, F656
VERIFY:       Build artifact token hash matches pre-update snapshot
```

### ST-166 — Duplicate Publish Idempotency
```
TEST:         ST-166
SCENARIO:     Publish job enqueued twice with same idempotency-key (simulating retry)
EXPECTED:     CF-317: second enqueue returns no-op DataProcessResult
              Only one build artifact created
              Sitemap/cache invalidation runs exactly once
FAILURE MODE: Duplicate publish = two concurrent builds + race on CDN
FACTORIES:    F647, F649, F648
VERIFY:       Build count = 1; F647 job log shows duplicate detection
```

### ST-167 — Slug Change Without Redirect (Prevention Test)
```
TEST:         ST-167
SCENARIO:     Post slug changed via T252 without F658 redirect creation
EXPECTED:     CF-303 fires; slug change rejected unless atomic with redirect creation
              Old URL would return 404 without redirect
FAILURE MODE: Slug change succeeds silently; all old links broken
FACTORIES:    F657, F658
VERIFY:       F658 redirect record exists for old slug after any slug change
```

### ST-168 — Draft Post in Public Feed (Prevention Test)
```
TEST:         ST-168
SCENARIO:     T255 CMS feed query executed without status=Published filter
EXPECTED:     CF-306 fires; AF-9 build failure
              Query returns DataProcessResult error describing missing filter
FAILURE MODE: Draft post titles/content visible in public feed widget
FACTORIES:    F640, F638
VERIFY:       Zero Draft/Scheduled posts in any T255 response
```

### ST-169 — Schema Field Removal Attempt
```
TEST:         ST-169
SCENARIO:     Admin attempts to remove required field from PostType schema (T251)
EXPECTED:     CF-313 fires; UpdatePostTypeSchemaAsync returns DataProcessResult error
              Schema version unchanged; removed fields listed in error
FAILURE MODE: Existing posts with removed field become invalid; form breaks
FACTORIES:    F637, F639
VERIFY:       Schema version not incremented; field still in registry
```

### ST-170 — Cross-Tenant Sitemap Leak (Prevention Test)
```
TEST:         ST-170
SCENARIO:     ISitemapRssService called without tenantId + siteId filter
EXPECTED:     CF-314 fires; AF-9 build failure
              No multi-tenant URLs in sitemap response
FAILURE MODE: Tenant A's URLs appear in Tenant B's sitemap
FACTORIES:    F651
VERIFY:       All sitemap URLs belong to single tenantId + siteId
```

### ST-171 — Rollback During Active Publish
```
TEST:         ST-171
SCENARIO:     Admin triggers rollback (T258) while publish pipeline (T256) is at step 3/6
EXPECTED:     CF-309 fires; rollback rejected with active job reference
              Publish pipeline completes normally
              Rollback queued for after completion
FAILURE MODE: Partial publish + partial rollback = corrupted deployed state
FACTORIES:    F652, F647, F649
VERIFY:       Published version = completed publish artifact; rollback logged as deferred
```

### ST-172 — AI Writing Assistant Auto-Commit Prevention
```
TEST:         ST-172
SCENARIO:     IAiWritingAssistantService (F644) generates continuation; system attempts
              to write directly to F638 without user confirmation flag
EXPECTED:     CF-321 fires; AF-9 build failure
              AI suggestion stored in temp buffer only
FAILURE MODE: Unreviewed AI content auto-published to live blog
FACTORIES:    F644, F638
VERIFY:       AI output in temp buffer only; F638 not written until confirmation
```

### ST-173 — Responsive Layout Cache Stale After Token Update
```
TEST:         ST-173
SCENARIO:     Design tokens updated (T261); responsive layout cache (F633) not invalidated
EXPECTED:     CF-295 chain: F653 update triggers F648 → F648 invalidates F633 Redis cache
              Next layout resolution fetches from ES source of truth
FAILURE MODE: Old breakpoint layout served after token change
FACTORIES:    F653, F648, F633
VERIFY:       F633 cache miss after F653 write; ES re-fetch confirmed
```

### ST-174 — Concurrent PostType Registration Collision
```
TEST:         ST-174
SCENARIO:     Two admins simultaneously register PostType with same ID (T251)
EXPECTED:     CF-297 fires for second; DataProcessResult collision error
              Only one PostType registered
FAILURE MODE: Two conflicting schemas registered = factory resolution ambiguity
FACTORIES:    F637
VERIFY:       Single PostType entry in registry after race
```

### ST-175 — Theme Switch During Active Build
```
TEST:         ST-175
SCENARIO:     User switches theme (T263) while SSG build (T259) is running
EXPECTED:     CF-295 (active build check); theme switch queued
              Current build uses original theme tokens
              Post-build: full site rebuild with new theme triggers
FAILURE MODE: Theme-mixed build artifact
FACTORIES:    F655, F653, F649
VERIFY:       Build artifact has single consistent theme token set
```

### ST-176 — Asset Replacement Fan-out During Publish
```
TEST:         ST-176
SCENARIO:     Asset replacement (T266) triggered while active publish job uses replaced asset
EXPECTED:     CF-312 fires; replacement queued until publish completes
              Publish artifact references original asset (consistent)
              Post-publish: replacement fan-out executes
FAILURE MODE: Replacement mid-build = broken asset references in published pages
FACTORIES:    F666, F647, F631, F638
VERIFY:       Published artifact asset references consistent; replacement deferred log entry
```

### ST-177 — Tenant Provisioning Idempotency
```
TEST:         ST-177
SCENARIO:     ITenantProvisioningService called twice for same tenantId
              (simulating retry after network timeout)
EXPECTED:     CF-322: second call returns no-op DataProcessResult with existing resources
              No duplicate workspace, site, or config entries
FAILURE MODE: Duplicate tenant resources = data isolation breakdown
FACTORIES:    F674, F667, F668
VERIFY:       Resource count after double provision = same as after single provision
```

### ST-178 — Preview SSG Artifact Contamination
```
TEST:         ST-178
SCENARIO:     ILivePreviewService (F634) attempts to use IStaticBuildService (F649) artifact
              for performance optimization
EXPECTED:     CF-316 fires; AF-9 build failure at T250 task type definition
              Preview always renders fresh SSR
FAILURE MODE: Preview shows published version instead of current editor state
FACTORIES:    F634, F649
VERIFY:       T250 factory dependencies contain no F649 reference
```

---

## BFA ENTITY / EVENT REGISTRY — FLOW-20

### Entities Registered
```
visual_editor:page_tree         (F631)  — conflicts with F1-F630? No overlap
visual_editor:component         (F632)  — new entity type
visual_editor:session           (F636)  — new entity type
cms:post_type                   (F637)  — new entity type
cms:post                        (F638)  — new entity type; may overlap with F1-F630 content entities
cms:version                     (F641)  — new entity type
design_system:token             (F653)  — new entity type
design_system:theme             (F655)  — new entity type
routing:slug                    (F657)  — new entity type
routing:redirect                (F658)  — new entity type
media:asset                     (F662)  — new entity type
media:folder                    (F665)  — new entity type
platform:workspace              (F667)  — potential overlap with FLOW-01–FLOW-17 tenant entities
publish_job                     (F647)  — new entity type
```

### APIs Registered
```
POST /pages/*/nodes                     T247
POST /components/register               T248
GET  /layout/resolve                    T249
GET  /preview/render                    T250
POST /cms/post-types                    T251
POST /cms/posts                         T252
PATCH /cms/posts/:id/status             T253
POST /cms/workflow/review               T254
GET  /cms/feed                          T255
POST /publish/jobs                      T256
POST /publish/scheduled                 T257
POST /publish/rollback                  T258
POST /build/static                      T259
GET  /sitemap.xml                       T260
PATCH /design/tokens                    T261
PATCH /design/global-styles             T262
POST /design/themes/:id/apply           T263
POST /assets/upload                     T264
POST /assets/:id/transform              T265
POST /assets/:id/replace                T266
```

---

## CROSS-FLOW CONFLICT MATRIX (FLOW-20 vs FLOW-01–FLOW-17)

| FLOW-20 Entity | Potential Conflict | Prior Flow | Conflict Rule | Mitigation |
|---|---|---|---|---|
| cms:post | Content entity | FLOW-05, FLOW-14 | CF-307 | BFA check at publish time |
| platform:workspace | Tenant entity | All flows | CF-307, CF-322 | Provisioning idempotency |
| media:asset | Binary asset | FLOW-16 (marketplace assets) | CF-311 | UUID global uniqueness |
| publish_job | Job entity | FLOW-10 (data jobs) | CF-308 | Per-siteId mutex |

---

## BACKWARD COMPATIBILITY
```
CF-1–CF-294:   UNCHANGED ✅
ST-1–ST-163:   UNCHANGED ✅
New: CF-295–CF-322 (28 conflict rules)
New: ST-164–ST-178 (15 stress tests)
```

---

## SAVE POINT: FLOW20:P3:BFA:COMPLETE ✅
## Recovery: "FLOW-20 P3 complete. CF-295–CF-322 / ST-164–ST-178. Continue with P4 skills."
