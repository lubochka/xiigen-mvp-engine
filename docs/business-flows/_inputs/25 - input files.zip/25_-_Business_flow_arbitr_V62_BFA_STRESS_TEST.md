# XIIGen BFA CONFLICT RULES & STRESS TESTS — FLOW-22 DELTA
# Business Flow Arbiter — New BFA Rules CF-402 through CF-430, Stress Tests ST-227–ST-248
# Extends: V62_BFA_STRESS_TEST_MERGED.md (CF-1–CF-401, ST-1–ST-226)
# Status: FLOW-22 NEW ARTIFACTS ONLY

---

## SAVE POINT: FLOW22:BFA_STRESS:START
## Entering at CF-402 (next after CF-401 — Forms entries DWH conflict)

---

## CONFLICT RULES (CF-402 through CF-430)

### Category 1: Proposed Change Intake & Parsing

```
CF-402: CHANGE_TYPE_VALIDATION
  TRIGGER:    Proposed change submitted with change_type not in supported set
  CONDITION:  change_type ∉ {ENTITY_SCHEMA, FLOW_DAG, API_CONTRACT, CODE_AST}
  SEVERITY:   CRITICAL
  ACTION:     Reject intake. Return DataProcessResult failure. Session never created.
  REFERENCES: T327, SK-201, IR-327-2

CF-403: PROPOSED_CHANGE_UNIQUENESS
  TRIGGER:    Duplicate proposed_change_id submitted (UUID collision or replay attack)
  CONDITION:  proposed_change_id already exists in bfa_change_store (PG)
  SEVERITY:   HIGH
  ACTION:     Reject with idempotency response (return existing record).
  REFERENCES: T327, DR-147

CF-404: DEPENDENCY_INDEX_STALENESS
  TRIGGER:    Dependency index last_updated_at < flow_registry last_published_at by > 5 minutes
  CONDITION:  Index stale after flow publication
  SEVERITY:   MEDIUM
  ACTION:     Warn, continue with stale index, trigger async re-index
  REFERENCES: T328, SK-202

CF-405: DEPENDENCY_QUERY_SCOPE_MISSING
  TRIGGER:    Dependency index query executed without tenantId filter
  CONDITION:  Query document missing tenant_id field (BuildSearchFilter not applied)
  SEVERITY:   CRITICAL
  ACTION:     Block query. Emit scope-violation alert. DataProcessResult failure.
  REFERENCES: T328, DNA-5, SK-202, IR-328-1
```

### Category 2: Static Conflict Detection

```
CF-406: REQUIRED_FIELD_REMOVAL_BREAKING
  TRIGGER:    Proposed change removes a field that is marked required=true in entity schema
  CONDITION:  change_type=ENTITY_SCHEMA AND field_removal AND target_field.required=true
  SEVERITY:   CRITICAL
  ACTION:     T329 classifies as TRUE_CONFLICT. Escalate to T331 with CRITICAL composite severity.
  REFERENCES: T329, SK-203, DR-145
  EXAMPLE:    Removing UserProfile.billingAddress (required) → breaks checkout-flow + subscription-flow

CF-407: STATE_TRANSITION_REMOVAL_BREAKING
  TRIGGER:    Proposed change removes a state transition that is referenced by at least 1 existing flow
  CONDITION:  change_type=FLOW_DAG AND transition_removed AND bfa_dependency_index has references
  SEVERITY:   CRITICAL
  ACTION:     T329 classifies as TRUE_CONFLICT. State machine expects removed transition.
  REFERENCES: T329, F906, SK-203

CF-408: CONFLICT_RULE_MISSING_REFERENCE
  TRIGGER:    Static conflict detection returns TRUE_CONFLICT without citing a specific CF rule
  CONDITION:  conflict_classification=TRUE_CONFLICT AND rule_id is null or empty
  SEVERITY:   HIGH
  ACTION:     Reject conflict result. Return LOW severity advisory. Log to BFA analytics.
              (Prevents fabricated conflicts without traceable rule basis)
  REFERENCES: T329, IR-329-3, SK-203

CF-409: SEMANTIC_ANALYSIS_ORDER_VIOLATION
  TRIGGER:    T330 (Semantic Analysis) fires before T329 (Static Detection) completes
  CONDITION:  semantic_analysis_session started AND static_detection_result not yet written to session
  SEVERITY:   CRITICAL
  ACTION:     Block semantic analysis start. Re-sequence.
  REFERENCES: T329, T330, IR-329-1

CF-410: AI_CRITICAL_WITHOUT_EVIDENCE
  TRIGGER:    AI semantic analysis returns HIGH or CRITICAL severity without evidence_links
  CONDITION:  ai_impact_result.severity ∈ {HIGH, CRITICAL} AND evidence_links is empty
  SEVERITY:   HIGH
  ACTION:     Downgrade AI severity to LOW. Advisory-only. Log to F944 for quality tracking.
  REFERENCES: T330, SK-204, IR-330-2

CF-411: CONTEXT_BUNDLE_EMPTY_FLOWS
  TRIGGER:    Context bundle assembled with 0 impacted flow definitions
  CONDITION:  context_bundle.flows.length == 0 AND composite_severity ∈ {CRITICAL, HIGH}
  SEVERITY:   HIGH
  ACTION:     Block semantic analysis. Trigger dependency index re-query. Log as anomaly.
  REFERENCES: T330, SK-211, IR-330-4
```

### Category 3: Severity Aggregation & Routing

```
CF-412: CRITICAL_SEVERITY_MUST_BLOCK
  TRIGGER:    Composite severity = CRITICAL and arbitration state transitions to skip_arbitration
  CONDITION:  composite_severity=CRITICAL AND state=SKIP_ARBITRATION
  SEVERITY:   CRITICAL
  ACTION:     BUILD FAILURE. State machine forced back to PENDING_RESOLUTION. Alert emitted.
  REFERENCES: T331, T333, SK-207, IR-331-1

CF-413: NONE_SEVERITY_MUST_SKIP
  TRIGGER:    Composite severity = NONE and arbitration state transitions to PENDING_RESOLUTION
  CONDITION:  composite_severity=NONE AND state=PENDING_RESOLUTION
  SEVERITY:   HIGH
  ACTION:     Override state to SKIP_ARBITRATION. Unblock publish path immediately.
  REFERENCES: T331, T333, IR-331-2

CF-414: BLAST_RADIUS_DEPTH_EXCEEDED
  TRIGGER:    Blast radius traversal exceeds max_hop_depth configured in FREEDOM config
  CONDITION:  traversal_depth > bfa_tenant_config.max_hop_depth
  SEVERITY:   MEDIUM
  ACTION:     Stop traversal at max depth. Add warning to blast_radius_report.
  REFERENCES: T332, SK-206, IR-332-1

CF-415: CIRCULAR_DEPENDENCY_DETECTED
  TRIGGER:    Blast radius traversal encounters already-visited flow (circular dependency)
  CONDITION:  flow_id ∈ visited_set during BFS traversal
  SEVERITY:   LOW
  ACTION:     Skip (do not throw). Add circular_dependency_detected: true to blast radius report.
  REFERENCES: T332, SK-206, DNA-3
```

### Category 4: Arbitration State Machine

```
CF-416: STATE_PERSIST_BEFORE_EMIT_VIOLATION
  TRIGGER:    State machine emits queue event before PG write completes
  CONDITION:  event_emitted_at < pg_write_committed_at (or PG write failed)
  SEVERITY:   CRITICAL
  ACTION:     BUILD FAILURE. State machine must re-sequence (DNA-8). Rollback if possible.
  REFERENCES: T333, SK-207, DR-146, DNA-8, IR-333-1

CF-417: TIMEOUT_NOT_SCHEDULED
  TRIGGER:    Session enters PENDING_RESOLUTION state without timeout being scheduled
  CONDITION:  state=PENDING_RESOLUTION AND timeout_scheduled_at is null
  SEVERITY:   HIGH
  ACTION:     Schedule timeout immediately. Log anomaly. (Session could otherwise be stuck forever)
  REFERENCES: T333, F921, IR-333-1
```

### Category 5: Impact Report & Decision Options

```
CF-418: FORCE_PROCEED_SHOWN_TO_UNAUTHORIZED
  TRIGGER:    Impact report rendered with FORCE_PROCEED option for actor without bfa:override permission
  CONDITION:  report.options contains FORCE_PROCEED AND actor.permissions ∌ bfa:override
  SEVERITY:   CRITICAL
  ACTION:     BUILD FAILURE. Regenerate report without FORCE_PROCEED. Log security event.
  REFERENCES: T334, SK-208, IR-334-2, DR-148

CF-419: PRECEDENT_SUGGESTION_THRESHOLD_NOT_MET
  TRIGGER:    Precedent suggestion shown with fewer than 3 matching historical decisions
  CONDITION:  precedent_suggestion shown AND matching_precedents.count < 3
  SEVERITY:   MEDIUM
  ACTION:     Remove precedent suggestion from report. Log to analytics.
  REFERENCES: T334, F929, DR-151
```

### Category 6: Decision Capture & Application

```
CF-420: INVALID_DECISION_VALUE
  TRIGGER:    Decision submitted with value not in {REFACTOR_FLOWS, REJECT_CHANGE, COMPAT_MODE, FORCE_PROCEED}
  CONDITION:  decision ∉ valid_decision_set
  SEVERITY:   CRITICAL
  ACTION:     Reject capture. Return DataProcessResult failure. Session remains PENDING_RESOLUTION.
  REFERENCES: T335, SK-215, IR-335-2

CF-421: FORCE_PROCEED_MISSING_RATIONALE
  TRIGGER:    FORCE_PROCEED decision submitted without required rationale
  CONDITION:  decision=FORCE_PROCEED AND (rationale is null OR rationale.length < min_length)
  SEVERITY:   CRITICAL
  ACTION:     BUILD FAILURE. Reject capture. Session remains PENDING_RESOLUTION.
  REFERENCES: T335, SK-215, DR-148, IR-335-2

CF-422: DUPLICATE_DECISION_IDEMPOTENCY
  TRIGGER:    Same session_id submits decision twice
  CONDITION:  SETNX key "decision:{session_id}" already exists
  SEVERITY:   INFO
  ACTION:     Return DataProcessResult Success=true with existing decision. No-op. (DNA-7)
  REFERENCES: T335, SK-215, DNA-7

CF-423: FORCE_PROCEED_LOG_BEFORE_PUBLISH
  TRIGGER:    Publish unblocked before override log written for FORCE_PROCEED decision
  CONDITION:  publish.approved emitted AND bfa_override_log.session_id not found
  SEVERITY:   CRITICAL
  ACTION:     BUILD FAILURE. Revert publish event. Write override log. Re-emit publish.
  REFERENCES: T336, SK-209, DR-147, IR-336-1

CF-424: REFACTOR_FLOWS_TASKS_NOT_QUEUED
  TRIGGER:    REFACTOR_FLOWS decision applied but no refactor tasks queued for affected flows
  CONDITION:  decision=REFACTOR_FLOWS AND affected_flows.count > 0 AND queued_tasks.count == 0
  SEVERITY:   CRITICAL
  ACTION:     Retry task queueing. If repeated failure → escalate to human (F922).
  REFERENCES: T336, SK-209, F934, IR-336-2

CF-425: COMPAT_MODE_NO_SUNSET_DATE
  TRIGGER:    Compat wrapper registered without sunset_date
  CONDITION:  compat_wrapper written to bfa_compat_registry AND sunset_date is null
  SEVERITY:   HIGH
  ACTION:     Set default sunset_date (now + 90 days from FREEDOM config). Log anomaly.
  REFERENCES: T336, SK-209, F935, IR-336-2
```

### Category 7: Audit Trail & Governance

```
CF-426: AUDIT_RECORD_MISSING_ON_CLOSE
  TRIGGER:    Arbitration session closes (RESOLVED/REJECTED/ERROR) without audit record written
  CONDITION:  session.state ∈ {resolved, rejected, error} AND bfa_tenant_audit_log has no record for session_id
  SEVERITY:   CRITICAL
  ACTION:     Block session close. Write audit record. Alert.
  REFERENCES: T337, SK-210, IR-337-1

CF-427: FORCE_PROCEED_SINGLE_LOG_ONLY
  TRIGGER:    FORCE_PROCEED audit written to tenant log but not to global override log (or vice versa)
  CONDITION:  decision=FORCE_PROCEED AND (only 1 of 2 logs has the record)
  SEVERITY:   CRITICAL
  ACTION:     Write missing log entry. Emit audit-gap alert. (DR-147: both logs mandatory)
  REFERENCES: T337, SK-210, DR-147, IR-337-2

CF-428: BFA_TENANT_NOT_PROVISIONED
  TRIGGER:    Arbitration pipeline invoked for tenant with no bfa_tenant_config record
  CONDITION:  bfa_tenant_config.tenant_id not found for incoming session
  SEVERITY:   CRITICAL
  ACTION:     Block arbitration. Return DataProcessResult failure. Emit provision-required alert.
  REFERENCES: T338, SK-212, IR-338-1

CF-429: ISOLATION_VALIDATOR_HEALTH_GAP
  TRIGGER:    Isolation validator last run > max_interval (FREEDOM: default 15m)
  CONDITION:  isolation_validator.last_run_at < now - max_interval
  SEVERITY:   HIGH
  ACTION:     Trigger immediate health check run. Alert platform admin.
  REFERENCES: T338, F939, SK-212

CF-430: CROSS_TENANT_GUARD_DATA_LEAK
  TRIGGER:    Cross-tenant guard output contains per-tenant identifiable data
  CONDITION:  T339 output document contains field matching pattern tenant_id OR tenant_name (non-aggregated)
  SEVERITY:   CRITICAL
  ACTION:     BUILD FAILURE. Block output. Audit. Alert platform admin.
  REFERENCES: T339, F937, SK-212, IR-339-1
```

---

## STRESS TESTS (ST-227 through ST-248)

### ST-227: Force Field Removal Into Multi-Flow Entity
```
SCENARIO:    Developer proposes removing UserProfile.billingAddress
             billingAddress is required=true
             2 flows (checkout-flow + subscription-flow) reference it
EXPECTED:    T327: parse ✓ | T328: blast radius = 2 flows ✓ | T329: CF-406 fires CRITICAL ✓
             T331: composite CRITICAL ✓ | T333: state → PENDING_RESOLUTION ✓
             T334: report shows both flows, FORCE_PROCEED option hidden (standard user) ✓
             T335: user selects REFACTOR_FLOWS | T336: refactor tasks queued for both flows ✓
             T337: audit record written ✓
FAIL_IF:     CF-412 not triggered | publish unblocks without decision | audit missing
```

### ST-228: Additive Field Addition — No Conflict
```
SCENARIO:    Developer adds optional UserProfile.preferredLanguage (new, not required)
EXPECTED:    T327: parse ✓ | T328: dependency query runs ✓ | T329: ADDITIVE_ONLY classification ✓
             T331: composite NONE ✓ | T333: state → SKIP_ARBITRATION ✓
             Publish proceeds immediately. No human interaction required.
FAIL_IF:     Human resolution triggered for additive change | CF-413 not applied
```

### ST-229: AI HIGH Finding Without Evidence — Downgrade
```
SCENARIO:    Static detection finds MEDIUM, AI returns HIGH with no evidence_links
EXPECTED:    T330: AI output fails F913 validation (evidence_links empty + HIGH) → CF-410 fires
             AI severity downgraded to LOW ✓
             T331: composite = MEDIUM (static takes precedence) ✓
             T334: report shows MEDIUM, not HIGH ✓
FAIL_IF:     AI HIGH without evidence escalates composite to HIGH
```

### ST-230: FORCE_PROCEED Without Rationale — BUILD FAILURE
```
SCENARIO:    Admin submits FORCE_PROCEED decision with 10-char rationale (below 50-char minimum)
EXPECTED:    T335: CF-421 fires ✓ | DataProcessResult failure ✓
             Session remains PENDING_RESOLUTION ✓ | Audit record NOT written (decision not captured) ✓
             User gets error: "Rationale must be at least 50 characters" ✓
FAIL_IF:     FORCE_PROCEED proceeds with short rationale | publish unblocked
```

### ST-231: Duplicate Decision Submission — Idempotency
```
SCENARIO:    Network retry causes same REFACTOR_FLOWS decision submitted twice for session s-123
EXPECTED:    First submission: SETNX succeeds → decision captured ✓
             Second submission: SETNX fails → DataProcessResult Success=true (existing decision returned) ✓
             No duplicate processing | no duplicate audit records ✓
FAIL_IF:     Second submission causes error | duplicate audit records created
```

### ST-232: FORCE_PROCEED Audit Log Gap — Both Logs Required
```
SCENARIO:    FORCE_PROCEED decision applied. PG write to tenant_audit_log succeeds.
             PG write to global override_log fails (simulated timeout).
EXPECTED:    CF-427 fires ✓ | F922 escalation triggered ✓
             Publish does NOT unblock (CF-423) ✓
             Retry writes override_log ✓ | Both logs verified before publish proceeds ✓
FAIL_IF:     Publish proceeds with only 1 of 2 logs written
```

### ST-233: Unprovisioned Tenant Arbitration Attempt
```
SCENARIO:    Flow change proposed for tenant-new with no bfa_tenant_config record
EXPECTED:    T338: CF-428 fires ✓ | DataProcessResult failure ✓
             Provision-required alert emitted ✓ | Session not created ✓
FAIL_IF:     Arbitration pipeline runs for unprovisioned tenant
```

### ST-234: Cross-Tenant Guard Data Leak
```
SCENARIO:    T339 cross-tenant guard output accidentally includes tenant_id=t-abc in result
EXPECTED:    CF-430 fires ✓ | BUILD FAILURE ✓ | Output blocked ✓ | Platform admin alert ✓
FAIL_IF:     Per-tenant data returned in cross-tenant guard output
```

### ST-235: State Machine Persist-Before-Emit Failure
```
SCENARIO:    PG write fails during state transition from DETECTING → SEVERITY_AGGREGATING
             Queue event is emitted before PG write completes
EXPECTED:    CF-416 fires ✓ | BUILD FAILURE ✓ | Rollback attempted ✓
             State recovered from last valid PG state (DETECTING) ✓
             Retry from DETECTING state ✓ | Full recovery < 60s ✓
FAIL_IF:     System enters split-brain (queue event sent but state lost in PG)
```

### ST-236: Blast Radius Circular Dependency
```
SCENARIO:    Flow-A depends on Entity-X → Flow-B depends on Flow-A → Flow-A somehow references Flow-B
             (Circular dependency in bfa_dependency_index)
EXPECTED:    T332: CF-415 fires (visited set detects cycle) ✓
             Traversal stops gracefully ✓ | circular_dependency_detected: true in report ✓
             No StackOverflow | No throw — DataProcessResult ✓
FAIL_IF:     Infinite loop | throw exception | system crashes
```

### ST-237: Context Bundle Cache Invalidation on Flow Publish
```
SCENARIO:    Context bundle cached for change-123 at T=0.
             At T=5m, checkout-flow is published (updated).
             At T=6m, change-123 arbitration retrieves context.
EXPECTED:    F928 cache invalid (flow_registry updated since cache write) ✓
             Fresh context bundle assembled with updated checkout-flow ✓
             Old cached bundle NOT used ✓ | DR-149 honoured ✓
FAIL_IF:     Stale context bundle used after flow registry update
```

### ST-238: Multi-Model Consensus Failure (No 2/3 Agreement)
```
SCENARIO:    T330 semantic analysis: Claude returns HIGH, OpenAI returns MEDIUM, Gemini returns LOW
             No 2/3 consensus on severity.
EXPECTED:    IR-330-3 applies: no consensus → AI result defaults to LOW ✓
             T331: composite severity based on static result (T329) not AI ✓
             AF-10 Merge log records disagreement ✓ | AF-11 Feedback stores quality issue ✓
FAIL_IF:     Deadlocked AI analysis blocks arbitration | HIGH accepted without consensus
```

### ST-239: COMPAT_MODE Sunset Date Missing
```
SCENARIO:    COMPAT_MODE decision applied. F935 registers compat wrapper with sunset_date=null
EXPECTED:    CF-425 fires ✓ | Default sunset_date set (now + 90 days from FREEDOM config) ✓
             Sunset alert scheduled ✓ | Log anomaly ✓
FAIL_IF:     Compat wrapper registered without sunset_date and no default applied
```

### ST-240: Transitive Blast Radius — 3-Hop Impact
```
SCENARIO:    UserProfile.email deleted.
             Direct: auth-flow (reads email)
             Hop 2: email-flow (depends on auth-flow)
             Hop 3: marketing-flow (depends on email-flow)
             max_hop_depth = 3 (FREEDOM config)
EXPECTED:    T332: all 3 hops traversed ✓
             blast_radius_report: { direct: 1, transitive: 2, total_unique_flows: 3, max_hop_reached: 3 } ✓
FAIL_IF:     Transitive flows missed | max_hop exceeded without stopping
```

### ST-241: Isolation Validator Health Check Gap
```
SCENARIO:    F939 isolation validator last ran 20 minutes ago (exceeds 15-min FREEDOM config threshold)
EXPECTED:    CF-429 fires ✓ | Immediate health check triggered ✓ | Platform admin alerted ✓
FAIL_IF:     Stale isolation validator not detected | No alert emitted
```

### ST-242: Simultaneous Changes to Same Entity — Race Condition
```
SCENARIO:    Two developers simultaneously propose changes to UserProfile entity.
             Session s-001 and s-002 created < 1 second apart.
EXPECTED:    Both sessions created with unique proposed_change_ids (CF-403 check) ✓
             Both arbitrations run independently with tenantId scope ✓
             No cross-session contamination ✓ | Both reach resolution independently ✓
FAIL_IF:     One session's conflict results contaminate the other | Race condition deadlock
```

### ST-243: API Contract Breaking Change — Endpoint Removal
```
SCENARIO:    change_type=API_CONTRACT. Endpoint DELETE /v1/users/{id} proposed for removal.
             billing-flow and admin-flow both call this endpoint.
EXPECTED:    F903: API surface extraction detects endpoint removal ✓
             F908: dependency query finds billing-flow, admin-flow ✓
             T329: CF-406 equivalent for API contracts fires ✓
             T331: composite CRITICAL ✓ | Arbitration triggered ✓
FAIL_IF:     API contract change not detected | Treated as non-breaking
```

### ST-244: Pattern Learning — Precedent Fast Path
```
SCENARIO:    Over 3 past months, same change (remove optional field from UserProfile) was
             resolved with COMPAT_MODE 4 times. Fifth time same change proposed.
EXPECTED:    F929: returns 4 matching precedents (count > 3 threshold) ✓
             T334: precedent suggestion shown: "Consider COMPAT_MODE (used 4/4 similar cases)" ✓
             User still required to make explicit decision (suggestion, not auto-apply) ✓
             DR-151: precedent_enabled=true for this tenant (FREEDOM config) ✓
FAIL_IF:     Precedent auto-applies without user confirmation | Suggestion shown with < 3 precedents
```

### ST-245: BFA Analytics — No Cross-Tenant Data Leak
```
SCENARIO:    F942 platform metrics service aggregates data from 50 tenants.
             Verify output contains no per-tenant identifiable information.
EXPECTED:    F942 output: { total_arbitrations: 450, total_blocks: 120, avg_resolution_time: 14.2min }
             No tenant_id, no tenant_name, no flow names per tenant ✓
             CF-430 equivalent for analytics verified ✓
FAIL_IF:     Platform metrics output contains any per-tenant row-level data
```

### ST-246: Session Recovery — Sub-60-Second Resumption
```
SCENARIO:    Arbitration session s-500 in state DETECTING when service crashes.
             Service restarts. Session rehydration tested.
EXPECTED:    F917: session rehydrated from PG in < 60 seconds ✓
             State restored to DETECTING (last persisted state) ✓
             Arbitration resumes from DETECTING → continues normally ✓
             No data loss | No duplicate processing ✓
FAIL_IF:     Rehydration takes > 60s | State corrupted | Session starts over from IDLE
```

### ST-247: FLOW_DAG Change — New Step Inserted
```
SCENARIO:    change_type=FLOW_DAG. New step S-15 inserted into checkout-flow DAG.
             S-15 calls IInventoryService (F166) which is already used by 3 other flows.
EXPECTED:    T327: DAG diff parsed ✓ | F903: API surface not affected ✓
             F908: dependency check — IInventoryService not in conflict (it's additive use) ✓
             T329: ADDITIVE_ONLY classification ✓ | T331: composite NONE ✓
             Publish proceeds without human intervention ✓
FAIL_IF:     Additive step insertion triggers false-positive CRITICAL conflict
```

### ST-248: Full FLOW-22 Backward Compatibility Verification
```
SCENARIO:    Execute representative transactions from FLOW-01 through FLOW-21.
             BFA FLOW-22 services active.
EXPECTED:    FLOW-01 (User Registration): all T47-T49 execute without BFA interference ✓
             FLOW-05 (Lesson Gamification): T44-T46 execute normally ✓
             FLOW-12 (Chat & Messaging): T159-T168 execute normally ✓
             FLOW-21 (Forms): T307-T326 execute normally ✓
             F1-F900: no modifications ✓
             BFA gate fires ONLY on proposed change submissions (not on normal flow execution) ✓
FAIL_IF:     Any FLOW-01 through FLOW-21 task type execution disrupted by FLOW-22 activation
```

---

## IRON RULES SUMMARY (FLOW-22 — Cross-Reference)

| IR Code | Rule | Task Type | Violation = |
|---------|------|-----------|-------------|
| IR-327-1 | Persist change to PG before any downstream event | T327 | Build Failure |
| IR-327-2 | diff_blob_ref must be content-addressed sha256 | T327 | Reject |
| IR-328-1 | Every ES query must include tenantId filter | T328 | Build Failure |
| IR-328-3 | Empty blast radius = NONE severity, must not escalate | T328 | Incorrect routing |
| IR-329-1 | Static detection before AI semantic analysis | T329 | Build Failure |
| IR-329-2 | Static CRITICAL = mandatory PENDING_RESOLUTION | T329 | Build Failure |
| IR-329-3 | Every conflict result must cite CF rule | T329 | High |
| IR-330-1 | AI output must validate against ImpactReport JSON schema | T330 | Reject + retry |
| IR-330-2 | AI result is advisory; static CRITICAL takes precedence | T330 | Build Failure |
| IR-330-3 | 2/3 model consensus required for AI severity acceptance | T330 | Downgrade to LOW |
| IR-331-1 | CRITICAL → PENDING_RESOLUTION (no skip) | T331 | Build Failure |
| IR-331-2 | NONE → SKIP_ARBITRATION (no human needed) | T331 | Incorrect blocking |
| IR-332-1 | Circular dependency detected → log, continue, no throw | T332 | No throw |
| IR-333-1 | Persist-before-emit on every state transition | T333 | Build Failure |
| IR-333-3 | Session rehydration from PG < 60 seconds | T333 | Performance |
| IR-334-2 | FORCE_PROCEED shown only with bfa:override permission | T334 | Build Failure |
| IR-335-1 | SETNX on session_id prevents duplicate decision | T335 | Idempotency |
| IR-335-2 | FORCE_PROCEED without rationale = DataProcessResult failure | T335 | Build Failure |
| IR-335-3 | Actor re-validated at capture time (not cached) | T335 | Security |
| IR-336-1 | Override log written before publish unblocked (FORCE_PROCEED) | T336 | Build Failure |
| IR-336-3 | Partial refactor failure → DataProcessResult partial + escalate | T336 | No throw |
| IR-337-1 | Audit records are INSERT-only (no UPDATE/DELETE) | T337 | Build Failure |
| IR-337-2 | FORCE_PROCEED in BOTH tenant + global logs | T337 | Build Failure |
| IR-338-1 | No arbitration for unprovisioned tenant | T338 | Build Failure |
| IR-339-1 | Cross-tenant guard output: aggregated only, no per-tenant data | T339 | Build Failure |
| IR-340-1 | Analytics emit must not block session close | T340 | Async |
| IR-340-2 | Tenant metrics must include tenantId | T340 | Scope violation |

---

## SAVE POINT: FLOW22:BFA_STRESS:COMPLETE ✅
## Next: UNIFIED_SOURCE_INDEX (DD-192–DD-204)
