# XIIGen UNIFIED SOURCE INDEX — FLOW-22 DELTA
# Business Flow Arbiter — Design Decisions DD-192 through DD-204, Cross-References
# Extends: UNIFIED_SOURCE_INDEX_MERGED.md (DD-1–DD-191, DR-1–DR-143)
# Status: FLOW-22 NEW ARTIFACTS ONLY

---

## SAVE POINT: FLOW22:UNIFIED_INDEX:START
## Entering at DD-192 (next after DD-191 — Forms MT inherits FLOW-08+FLOW-14)

---

## DESIGN DECISIONS (DD-192 through DD-204)

---

### DD-192: BFA as Cross-Flow Governance, Not a Business Domain
```
DECISION:   The Business Flow Arbiter is classified as an ENGINE EXTENSION (meta-layer),
            not a business domain flow like FLOW-05 (Gamification) or FLOW-12 (Chat).
            It sits between the engine's code generation pipeline and flow publication,
            acting as a governance gate.

ALTERNATIVES CONSIDERED:
  A. Standalone microservice — REJECTED: Creates tight coupling to engine; not fabric-first
  B. Plugin to existing flow orchestrator — REJECTED: Conflates orchestration with governance
  C. Engine extension (chosen): 7 factory families extending existing fabrics

RATIONALE:  BFA must be fabric-first and provider-agnostic. Implementing it as engine extension
            means the same DATABASE, QUEUE, AI ENGINE, and RAG fabrics serve it — no new
            infrastructure. Future engine versions can swap providers without touching BFA logic.

IMPACT:     47 new factories (F901-F947) all resolve through existing fabric interfaces.
            Zero new fabric interfaces introduced in FLOW-22.

CROSS-REFS: DR-144, basic_prompt.txt Layer 0, Layer 1
```

---

### DD-193: Hybrid Conflict Detection Architecture
```
DECISION:   BFA uses a two-layer detection architecture:
            Layer 1 (Primary): Static deterministic rules (CF rules engine — F909)
            Layer 2 (Advisory): AI semantic analysis via AiDispatcher (F912)
            CRITICAL severity can only come from Layer 1 or Layer 1 + Layer 2 with evidence.
            Layer 2 alone cannot block a publish.

ALTERNATIVES CONSIDERED:
  A. Pure static rules only — misses implicit semantic conflicts
  B. Pure AI analysis — probabilistic, non-deterministic; cannot be sole gate
  C. Hybrid (chosen): deterministic safety + semantic coverage

RATIONALE:  A publish-blocking governance gate requires 100% repeatability for CRITICAL blocks.
            AI output is probabilistic; same input may yield different severity on different calls.
            Static rules provide the reliable safety net; AI provides the semantic safety net.

IMPACT:     T329 (static) always runs first. T330 (AI) is advisory.
            IR-330-2: AI CRITICAL without static backing → composite = HIGH max.

CROSS-REFS: DR-145, T329, T330, T331, SK-203, SK-204, SK-205
```

---

### DD-194: Change Type Taxonomy (4 Types)
```
DECISION:   BFA supports exactly 4 proposed change types:
            1. ENTITY_SCHEMA — entity field additions, removals, type changes, constraint changes
            2. FLOW_DAG — flow definition modifications (step additions, removals, re-ordering)
            3. API_CONTRACT — API endpoint additions, removals, signature changes
            4. CODE_AST — direct code changes with AST diff (lower-level; used for generated services)

ALTERNATIVES CONSIDERED:
  - INFRA_CONFIG as 5th type — DEFERRED: infrastructure changes require separate governance model
  - FREE_TEXT as a type — REJECTED: unstructured changes cannot be analyzed deterministically

RATIONALE:  4 types covers >95% of business logic change scenarios. INFRA_CONFIG deferred because
            infrastructure governance requires a separate framework (security posture, not flow logic).

IMPACT:     CF-402 enforces the 4-type constraint. Any change outside this taxonomy is rejected at intake.

CROSS-REFS: T327, CF-402, SK-201, F901
```

---

### DD-195: ImpactReport as Output Contract (JSON Schema)
```
DECISION:   The ImpactReport is a formally defined JSON schema that ALL analysis outputs
            (both static and AI) must conform to before entering the arbitration pipeline.
            The schema is stored in Elasticsearch and versioned. Schema version is referenced
            in every ConflictReport document.

SCHEMA FIELDS (required):
  - proposed_change_id: string (UUID)
  - severity: enum [CRITICAL, HIGH, MEDIUM, LOW, NONE]
  - impacted_flows: array of { flow_id, flow_name, impact_type, details }
  - conflict_rules: array of { rule_id, rule_description, severity }
  - evidence_links: array of { doc_id, doc_type, excerpt_ref }
  - blast_radius: { direct: int, transitive: int, total: int }
  - analysis_method: enum [STATIC, SEMANTIC_AI, HYBRID]

RATIONALE:  Without a formal output schema, AI analysis can return free-text that is difficult
            to render consistently and impossible to validate programmatically. The schema
            constraint prevents hallucinated impact reports.

IMPACT:     F913 (SemanticOutputValidatorService) validates all AI output against this schema.
            F915 (ConflictReportAssemblerService) validates static output against same schema.

CROSS-REFS: T330, T331, SK-204, F913, CF-408, IR-330-1
```

---

### DD-196: 4-Option Decision Menu (MACHINE)
```
DECISION:   The user-facing decision menu always contains exactly 4 options:
            1. REFACTOR_FLOWS — auto-refactor dependent flows to accommodate the change
            2. REJECT_CHANGE — cancel the proposed change; keep existing flows intact
            3. COMPAT_MODE — keep old field/endpoint + mark obsolete + set sunset date
            4. FORCE_PROCEED — apply the change regardless (elevated permission + mandatory rationale)

            This set is MACHINE (not FREEDOM-configurable). Administrators cannot add or remove options.
            FORCE_PROCEED rendering is gated by bfa:override permission (FREEDOM: who gets the permission).

RATIONALE:  A fixed decision set enables consistent audit records, unambiguous resolution code paths,
            and clear user mental model. The 4 options cover the full decision space
            (fix forward, cancel, backward compat, override).

IMPACT:     F931 always builds exactly 4 options. CF-420 rejects any decision value outside this set.

CROSS-REFS: DD-197, T334, T335, F931, CF-420, DR-148
```

---

### DD-197: FORCE_PROCEED Accountability Model
```
DECISION:   FORCE_PROCEED is available but requires:
            1. Actor must have bfa:override permission (tenant admin or platform admin assigns)
            2. Rationale text: mandatory, minimum 50 chars (FREEDOM: configurable minimum)
            3. Both bfa_tenant_audit_log AND bfa_override_log must be written before publish unblocks
            4. Override alert triggered if same actor overrides same entity_class > 3 times / 30 days
               (FREEDOM: threshold configurable)
            5. FORCE_PROCEED audit is permanent and cannot be deleted (DR-147)

RATIONALE:  Complete prohibition of FORCE_PROCEED creates workflow deadlocks when business requires
            urgent deployment. But unlimited force-proceed erodes governance. The accountability model
            allows it but makes misuse visible and costly.

IMPACT:     CF-421, CF-423, CF-427. DR-148, DR-152.
            F943 (ForceOverrideTracker) monitors for threshold breaches.

CROSS-REFS: DD-196, T334, T335, T336, T337, SK-209, SK-210, F943, DR-148, DR-152
```

---

### DD-198: Arbitration Session as First-Class Durable Entity
```
DECISION:   Every BFA arbitration run is a "session" (not a transient in-memory operation).
            Sessions are persisted to PostgreSQL with full state machine state.
            Sessions support interruption and resumption in < 60 seconds.
            Sessions have a lifecycle: IDLE → ... → RESOLVED/REJECTED/ERROR (terminal states).
            Completed sessions are retained for 90 days (FREEDOM: GDPR-configurable per tenant).

ALTERNATIVES CONSIDERED:
  A. Stateless REST request/response — REJECTED: cannot support long human-in-loop pauses (hours/days)
  B. In-memory state machine — REJECTED: not resumable across service restarts
  C. Durable session (chosen): supports multi-hour/multi-day pending resolution windows

RATIONALE:  Human resolution requires the system to wait indefinitely for a decision.
            This is fundamentally a long-running workflow, not a request-response operation.
            Durable session pattern (from DR-146) enables all orchestration and recovery requirements.

IMPACT:     F916 + F917. T333. All state transitions use persist-before-emit (DNA-8).
            Session rehydration < 60 seconds enables fast recovery (DR-146).

CROSS-REFS: DR-146, DR-147, T333, T335, F916, F917, SK-207
```

---

### DD-199: Dependency Index as Source of Truth for Blast Radius
```
DECISION:   The bfa_dependency_index (Elasticsearch) is the primary source of truth for
            determining which flows are potentially impacted by a proposed change.
            The index is populated by F904 (IFlowDependencyIndexWriterService) after every
            flow publication. RAG vector search is supplementary — it may find implicit
            semantic dependencies not in the index, but the index determines the candidate set.

INDEX STRUCTURE:
  - flow_id: string
  - entity_name: string
  - access_type: enum [READ, WRITE, DELETE, CREATE]
  - field_paths: array of string (dot-notation paths: "profile.billing.address")
  - api_endpoints: array of string
  - tenant_id: string
  - updated_at: datetime
  - flow_version: int

RATIONALE:  A dependency index enables O(1) blast radius queries instead of O(n) full flow scans.
            Index freshness maintained by F904 on every flow publish event.
            CF-404 detects staleness and triggers async re-index.

IMPACT:     F904, F908, F910. T328, T332. SK-202, SK-206.

CROSS-REFS: DD-193, T328, T332, F904, F908, CF-404
```

---

### DD-200: Context Bundle Hybrid Retrieval Strategy
```
DECISION:   Context bundle for AI semantic analysis (T330) uses a hybrid retrieval approach:
            1. Deterministic: F908 dependency index query → direct impacted flows (high recall, exact)
            2. Semantic: F925 vector search over documentation → implicit related flows (high precision for
               business-meaning conflicts not captured in dependency index)
            3. Historical: F929 decision history → precedent context for AI
            4. Design constraints: F926 DR/DD entries → architectural constraints for AI reasoning

            All 4 retrieval paths run in parallel (AF-2 Planning decomposes them concurrently).

RATIONALE:  Dependency index alone misses "conceptually related" flows not linked by direct entity use.
            Vector search alone misses deterministic dependencies.
            Historical precedents help AI recognize patterns.
            Design records constrain AI from suggesting solutions that violate existing ADRs.

IMPACT:     F923-F927. T330. SK-211. Context bundle is the input to F912 (SemanticConflictAnalyzer).

CROSS-REFS: DD-193, DD-199, T330, F912, SK-211
```

---

### DD-201: COMPAT_MODE and Sunset Lifecycle
```
DECISION:   COMPAT_MODE decision creates a "compatibility wrapper" entry in bfa_compat_registry.
            The wrapper:
            1. Marks old field/endpoint as [Obsolete] in schema registry
            2. Creates mapping: old_field → new_field (or old_endpoint → new_endpoint)
            3. Sets sunset_date (default: now + 90 days, FREEDOM: configurable per tenant)
            4. Schedules sunset alert at sunset_date (via F921/F922 escalation mechanism)
            5. On sunset_date: triggers re-arbitration to force final resolution

            COMPAT_MODE is NOT permanent. It is a time-bounded backward compatibility bridge.

RATIONALE:  Allowing indefinite compatibility wrappers creates "compatibility debt" that becomes
            impossible to clean up. Mandatory sunset date ensures the debt is resolved.

IMPACT:     F935. T336. CF-425. SK-209.

CROSS-REFS: DD-196, T336, F935, CF-425
```

---

### DD-202: Multi-Tenant BFA Architecture
```
DECISION:   BFA multi-tenancy follows FLOW-08 (Payment Processing) + FLOW-14 (Warehouse) MT models.
            Three key isolation principles:
            1. Tenant conflict index: each tenant's dependency index is tenant-scoped (F936)
            2. Tenant audit trail: per-tenant immutable audit log with GDPR retention (F940)
            3. Tenant config: per-tenant BFA settings (F938) — enable/disable, thresholds, channels
            
            Cross-tenant guard (F937) operates at platform level — platform_admin role only.
            Never exposes per-tenant data across tenants (CF-430).

RATIONALE:  BFA deals with potentially sensitive business logic (entities, flows, data shapes).
            Strict tenant isolation prevents tenant-A from discovering tenant-B's flow architecture
            through conflict analysis outputs.

IMPACT:     F936-F941 (Family 133). T338, T339. SK-212.

CROSS-REFS: DR-150, T338, T339, F936, F937, F938, FLOW-08 MT, FLOW-14 MT
```

---

### DD-203: BFA Analytics and Pattern Learning
```
DECISION:   After every resolved arbitration session, BFA emits:
            1. Tenant metrics (F941) — arbitration KPIs per tenant
            2. Platform aggregates (F942) — cross-tenant aggregated only
            3. Learnable patterns (F945) — indexed to RAG for precedent suggestions
            4. OpenTelemetry spans (F946) — end-to-end trace correlation
            5. Decision quality retrospective (F944) — AI-powered post-decision quality scoring

            Retrospective quality scoring (F944): 30 days after resolution, check if the chosen
            resolution held (no regressions, no emergency overrides on same entity).
            Score stored and fed back to AF-11 for generation quality improvement.

RATIONALE:  BFA without feedback is a one-way gate. With analytics and learning, BFA becomes
            self-improving: common patterns get precedent suggestions, quality scores
            improve AI calibration, and platform metrics surface systemic issues.

IMPACT:     F941-F947 (Family 134). T340. SK-213.

CROSS-REFS: DR-153, T340, F944, F945, AF-11
```

---

### DD-204: BFA Backward Compatibility Guarantee
```
DECISION:   FLOW-22 (BFA) is purely additive. The following guarantees are maintained:
            1. F1-F900 factories: unchanged, no modifications
            2. T1-T326 task types: unchanged, no modifications
            3. CF-1-CF-401 BFA rules: unchanged, no modifications
            4. SK-1-SK-200 skills: unchanged, no modifications
            5. FLOW-01 through FLOW-21 DAGs: unchanged, no modifications
            6. DNA-1 through DNA-9: stable, no new DNA patterns in FLOW-22
            7. EP-1 through EP-5: stable, no new engine primitives

            BFA gate fires ONLY on proposed change submissions (event type: proposed_change.submitted).
            Normal flow execution (FLOW-01 through FLOW-21 task types) is NOT intercepted.

RATIONALE:  A governance gate that breaks existing flows contradicts its own purpose.
            BFA gates changes TO flows, not the execution of established flows.

IMPACT:     ST-248 (backward compatibility stress test) verifies this guarantee.

CROSS-REFS: SESSION_STATE_MERGE.md backward compatibility section, ST-248
```

---

## CROSS-REFERENCE INDEX (FLOW-22 NEW ARTIFACTS)

### Factory → Skill Cross-Reference
| Factory | Skill | Task Type |
|---------|-------|-----------|
| F901 | SK-201 | T327 |
| F902, F903 | SK-201, SK-202 | T328 |
| F904, F908 | SK-202 | T328 |
| F905, F906, F909, F910, F911 | SK-203, SK-206 | T329, T332 |
| F912, F913 | SK-204 | T330 |
| F914 | SK-205 | T331 |
| F915 | SK-205 | T331 |
| F916, F917, F921 | SK-207 | T333 |
| F918, F919 | SK-214, SK-215 | T335 |
| F920, F934, F935 | SK-209 | T336 |
| F923, F924, F925, F926, F927, F928, F929 | SK-211 | T330 |
| F930, F931 | SK-208 | T334 |
| F932, F933 | SK-214, SK-215 | T335 |
| F936–F941 | SK-212 | T338 |
| F940, F943 | SK-210 | T337 |
| F941–F947 | SK-213 | T340 |

### CF Rule → Task Type Cross-Reference
| CF Rule | Task Type | Severity |
|---------|-----------|----------|
| CF-402 | T327 | CRITICAL |
| CF-403 | T327 | HIGH |
| CF-404, CF-405 | T328 | MEDIUM / CRITICAL |
| CF-406, CF-407, CF-408, CF-409 | T329 | CRITICAL / HIGH |
| CF-410, CF-411 | T330 | HIGH |
| CF-412, CF-413 | T331 | CRITICAL / HIGH |
| CF-414, CF-415 | T332 | MEDIUM / LOW |
| CF-416, CF-417 | T333 | CRITICAL / HIGH |
| CF-418, CF-419 | T334 | CRITICAL / MEDIUM |
| CF-420, CF-421, CF-422 | T335 | CRITICAL / INFO |
| CF-423, CF-424, CF-425 | T336 | CRITICAL / HIGH |
| CF-426, CF-427 | T337 | CRITICAL |
| CF-428, CF-429 | T338 | CRITICAL / HIGH |
| CF-430 | T339 | CRITICAL |

### Design Decision → Design Record Cross-Reference
| Design Decision | Design Record(s) | Theme |
|----------------|-----------------|-------|
| DD-192 | DR-144 | BFA as engine extension |
| DD-193 | DR-145 | Hybrid detection |
| DD-198 | DR-146, DR-147 | Durable sessions + immutability |
| DD-197 | DR-147, DR-148, DR-152 | FORCE_PROCEED accountability |
| DD-199 | DR-149 | Dependency index + cache |
| DD-202 | DR-150 | Multi-tenant inheritance |
| DD-204 | DR-151 | Precedent fast path (opt-in) |
| DD-203 | DR-153 | Analytics read-only |

### Skill → DNA Pattern Cross-Reference
| Skill | DNA Patterns Enforced |
|-------|----------------------|
| SK-201 (ParseChange) | DNA-1, DNA-3, DNA-4 |
| SK-202 (DependencyIndex) | DNA-1, DNA-2, DNA-3, DNA-5 |
| SK-203 (StaticConflict) | DNA-1, DNA-2, DNA-3 |
| SK-204 (SemanticAI) | DNA-1, DNA-3, DNA-4 |
| SK-205 (SeverityClassifier) | DNA-1, DNA-3 |
| SK-206 (BlastRadius) | DNA-1, DNA-3 |
| SK-207 (StateMachine) | DNA-1, DNA-3, DNA-7, DNA-8 |
| SK-208 (ImpactReport) | DNA-1, DNA-3, DNA-6 |
| SK-209 (ResolutionApplier) | DNA-1, DNA-3, DNA-5 |
| SK-210 (AuditTrail) | DNA-1, DNA-3, DNA-5, DNA-9 |
| SK-211 (ContextAggregator) | DNA-1, DNA-2, DNA-3, DNA-5 |
| SK-212 (MTGuard) | DNA-1, DNA-3, DNA-5 |
| SK-213 (Analytics) | DNA-1, DNA-3, DNA-5 |
| SK-214 (Notification) | DNA-1, DNA-3 |
| SK-215 (DecisionCapture) | DNA-1, DNA-3, DNA-7 |

---

## SAVE POINT: FLOW22:UNIFIED_INDEX:COMPLETE ✅
## Next: MASTER_EXECUTION_PLAN (P0–P7)
