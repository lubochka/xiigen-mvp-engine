# XIIGen SKILLS, FACTORY PATTERNS & RAG INDEX — FLOW-22 DELTA
# Business Flow Arbiter — New Skills SK-201 through SK-215
# Extends: SKILLS_FACTORY_RAG_MERGED.md (SK-1–SK-200)
# Status: FLOW-22 NEW ARTIFACTS ONLY

---

## SAVE POINT: FLOW22:SKILLS:START
## Entering at SK-201 (next after SK-200 — Forms Audit Trail)

---

## SKILL REGISTRY (SK-201 through SK-215)

---

### SK-201: ProposedChangeParserService
```
SKILL ID:     SK-201
NAME:         ProposedChangeParserService
LAYER:        L3 (Impact Extraction)
PURPOSE:      Parse raw change payloads into canonical ProposedChange documents (Dictionary<string,object>)
FACTORY:      F901:IProposedChangeParserService
FABRIC:       DATABASE FABRIC (Skill 05 → Elasticsearch)

IMPLEMENTATION PROMPT:
  "Generate IProposedChangeParserService that:
   1. Accepts raw input as Dictionary<string,object> (NEVER typed ChangeRequest model — DNA-1)
   2. Detects diff_format from input (JSON_PATCH | SCHEMA_DIFF | FLOW_DAG_DIFF | CODE_AST)
   3. Normalizes to canonical ProposedChange document with fields:
      proposed_change_id (UUID v4), change_type, diff_format, diff_blob_ref (sha256 hash),
      actor, tenant_id, created_at
   4. Returns DataProcessResult<Dictionary<string,object>> (never throw — DNA-3)
   5. Extends MicroserviceBase (inherits 19 components — DNA-4)"

POSITIVE EXAMPLE:
  Input: { "op": "remove", "path": "/properties/billingAddress", "actor": "user-123", "tenant_id": "t-abc" }
  Output: DataProcessResult<Dictionary> { Success=true, Data={ "proposed_change_id": "uuid-v4",
           "change_type": "ENTITY_SCHEMA", "diff_format": "JSON_PATCH", "diff_blob_ref": "sha256:...",
           "actor": "user-123", "tenant_id": "t-abc", "created_at": "2026-02-27T..." } }

NEGATIVE EXAMPLE:
  ❌ class ProposedChange { string ChangeType { get; set; } }  // typed model — violates DNA-1
  ❌ throw new InvalidOperationException("Unknown diff format");  // violates DNA-3
  ❌ using JsonPatch.NetCore;  // direct provider import — always through fabric

AF-4 RETRIEVAL TAGS: [proposed-change, parser, diff-format, entity-schema, flow-dag-diff]
CROSS-REFS: F901, T327, DR-147, DNA-1, DNA-3
```

---

### SK-202: DependencyIndexService
```
SKILL ID:     SK-202
NAME:         DependencyIndexService
LAYER:        L3 (Impact Extraction)
PURPOSE:      Write and query the bfa_dependency_index: flow↔entity and flow↔API dependency records
FACTORY:      F904:IFlowDependencyIndexWriterService, F908:IDependencyIndexQueryService
FABRIC:       DATABASE FABRIC (Skill 05 → Elasticsearch)

IMPLEMENTATION PROMPT:
  "Generate IDependencyIndexQueryService that:
   1. Queries bfa_dependency_index using BuildSearchFilter (DNA-2: empty fields auto-skipped)
   2. ALWAYS includes tenantId in filter — DNA-5 Scope Isolation enforced
   3. Returns List<Dictionary<string,object>> of matching dependency records
   4. Returns DataProcessResult<T> (never throw — DNA-3)
   Generate IFlowDependencyIndexWriterService that:
   1. Writes dependency record: {flow_id, entity_name, access_type, field_paths, tenant_id, updated_at}
   2. Upserts on (flow_id, entity_name, tenant_id) composite key
   3. Called after every flow publication to keep index current"

POSITIVE EXAMPLE:
  Query: BuildSearchFilter({ entity_name: "UserProfile", access_type: "DELETE", tenant_id: "t-abc" })
  → Skips empty fields automatically
  → Returns flows that DELETE UserProfile for tenant t-abc

NEGATIVE EXAMPLE:
  ❌ var results = esClient.Search<FlowDependency>(...);  // direct ES import — use DATABASE FABRIC
  ❌ if (tenantId == null) { query all; }  // violates DNA-5

AF-4 RETRIEVAL TAGS: [dependency-index, flow-entity, blast-radius, scope-isolation, BuildSearchFilter]
CROSS-REFS: F904, F908, T328, DR-144, DNA-2, DNA-5
```

---

### SK-203: StaticConflictDetector
```
SKILL ID:     SK-203
NAME:         StaticConflictDetector
LAYER:        L4 (Conflict Detection)
PURPOSE:      Deterministic CF rule application against extracted entity references and blast radius.
              100% repeatable. No AI. Returns TRUE_CONFLICT | ADDITIVE_ONLY | NO_CONFLICT per candidate.
FACTORY:      F909:IStaticConflictRulesEngineService, F905:ISchemaDiffClassifierService, F906:IStateTransitionAnalyzerService
FABRIC:       DATABASE FABRIC (Skill 05 → Elasticsearch)

IMPLEMENTATION PROMPT:
  "Generate IStaticConflictRulesEngineService that:
   1. Reads CF rules from bfa_rules_index as List<Dictionary<string,object>> (ParseDocument — DNA-1)
   2. For each blast radius candidate, applies all matching CF rules
   3. Returns conflict classification: TRUE_CONFLICT (with rule_id) | ADDITIVE_ONLY | NO_CONFLICT
   4. Generates ISchemaDiffClassifierService:
      - required field removal → BREAKING
      - type change → BREAKING
      - new optional field → ADDITIVE
      - constraint tightening → BREAKING
   5. All returns DataProcessResult<T> — no throws (DNA-3)"

POSITIVE EXAMPLE:
  Rule CF-406 fires on: entity_change_type=ENTITY_SCHEMA AND field_change=field_removal AND field_was_required=true
  → classification: TRUE_CONFLICT, severity: CRITICAL, rule_id: "CF-406"

NEGATIVE EXAMPLE:
  ❌ if (change.FieldName == "billingAddress") → hardcoded entity name (use CF rule config from index)
  ❌ throw new ConflictException("...");  // violates DNA-3

AF-4 RETRIEVAL TAGS: [static-conflict, CF-rules, schema-diff, breaking-change, deterministic]
CROSS-REFS: F905, F906, F909, T329, DR-145
```

---

### SK-204: SemanticImpactAnalyzer
```
SKILL ID:     SK-204
NAME:         SemanticImpactAnalyzer
LAYER:        L4 (Conflict Detection — AI-Powered)
PURPOSE:      AI-powered semantic conflict analysis via AiDispatcher. Parallel multi-model.
              Output constrained to ImpactReport JSON schema. Advisory only.
FACTORY:      F912:ISemanticConflictAnalyzerService, F913:ISemanticOutputValidatorService
FABRIC:       AI ENGINE FABRIC (Skill 07 → AiDispatcher)

IMPLEMENTATION PROMPT:
  "Generate ISemanticConflictAnalyzerService that:
   1. Calls AiDispatcher.GenerateAsync() — NEVER calls claude.chat() or openai.chat() directly
   2. System prompt: 'You are a Business Logic Arbiter. Analyze the proposed change against
      the provided context. Detect logical collisions, broken dependencies, invalid state changes.
      Respond ONLY with valid ImpactReport JSON. Include evidence_links[] for any HIGH/CRITICAL finding.'
   3. Passes context bundle as document input (flow defs + schema + docs)
   4. Validates output against ImpactReport JSON schema via F913
   5. Returns DataProcessResult<Dictionary<string,object>> — AI result as parsed dict
   Generate ISemanticOutputValidatorService that:
   1. Validates AI JSON output against ImpactReport schema (severity, impacted_flows[], evidence_links[])
   2. Rejects if schema invalid → returns DataProcessResult with failure (triggers AI retry)
   3. Maximum 2 retries before returning LOW severity advisory result"

POSITIVE EXAMPLE:
  AiDispatcher runs Claude+OpenAI+Gemini in parallel.
  2/3 models return: { severity: 'HIGH', impacted_flows: [...], evidence_links: ['flow-id-123'] }
  → consensus HIGH with evidence → accepted

NEGATIVE EXAMPLE:
  ❌ var resp = await openAiClient.ChatAsync(...);  // direct provider — always use AI ENGINE FABRIC
  ❌ Accepting AI output without schema validation — IR-330-1 violation
  ❌ Using AI CRITICAL finding without evidence_links — CF-410 violation

AF-4 RETRIEVAL TAGS: [semantic-analysis, AI-dispatcher, multi-model, impact-report, advisory]
CROSS-REFS: F912, F913, T330, DR-145, CF-409, CF-410, CF-411
```

---

### SK-205: SeverityClassifier
```
SKILL ID:     SK-205
NAME:         SeverityClassifier
LAYER:        L4 (Conflict Detection)
PURPOSE:      Aggregate static + AI results into composite severity: CRITICAL|HIGH|MEDIUM|LOW|NONE
FACTORY:      F914:ISeverityAggregatorService
FABRIC:       DATABASE FABRIC (Skill 05 → Elasticsearch — severity rules config)

IMPLEMENTATION PROMPT:
  "Generate ISeverityAggregatorService that:
   1. Reads severity escalation rules from ES (FREEDOM config — never hardcoded)
   2. Composite rules:
      - any static CRITICAL → composite CRITICAL (regardless of AI)
      - no static conflict + AI CRITICAL with evidence → composite HIGH (advisory promotion cap)
      - all NONE (static) + all NONE (AI) → composite NONE (fast path to publish)
   3. Returns DataProcessResult<string> with composite severity value"

POSITIVE EXAMPLE:
  Static: TRUE_CONFLICT, rule CF-406, severity CRITICAL
  AI: HIGH with evidence
  → composite: CRITICAL (static CRITICAL takes precedence — DR-145)

NEGATIVE EXAMPLE:
  ❌ if (aiResult.Severity == "CRITICAL") → block publish  // AI alone cannot block — IR-330-2
  ❌ Hardcoding severity thresholds in service code // must read from FREEDOM config

AF-4 RETRIEVAL TAGS: [severity, aggregation, static-first, AI-advisory, composite-severity]
CROSS-REFS: F914, T331, DR-145, IR-329-2, IR-330-2
```

---

### SK-206: BlastRadiusCalculator
```
SKILL ID:     SK-206
NAME:         BlastRadiusCalculator
LAYER:        L4 (Conflict Detection)
PURPOSE:      Transitive dependency traversal: direct + N-hop impacts. BFS traversal with visited set.
FACTORY:      F910:IBlastRadiusCalculatorService
FABRIC:       DATABASE FABRIC (Skill 05 → Elasticsearch)

IMPLEMENTATION PROMPT:
  "Generate IBlastRadiusCalculatorService that:
   1. BFS traversal of bfa_dependency_index from initial entity references
   2. Tracks visited set to prevent infinite loops (circular dependency handling — DNA-3 not throw)
   3. Max depth read from FREEDOM config (default: 3 hops)
   4. Returns Dictionary<string,object>:
      { direct_impacts: [...], transitive_impacts: [...], total_unique_flows: N,
        max_hop_reached: 2, circular_dependency_detected: false }"

POSITIVE EXAMPLE:
  UserProfile deleted → direct: [checkout-flow, subscription-flow]
  checkout-flow also used by → [marketplace-flow]
  → transitive: [marketplace-flow]
  → total_unique_flows: 3

NEGATIVE EXAMPLE:
  ❌ Recursive depth-first without visited set → StackOverflow on circular deps
  ❌ Max depth hardcoded as 3 → must read from FREEDOM config

AF-4 RETRIEVAL TAGS: [blast-radius, transitive, BFS, circular-dependency, dependency-graph]
CROSS-REFS: F910, T332, DR-149
```

---

### SK-207: ArbitrationStateMachine
```
SKILL ID:     SK-207
NAME:         ArbitrationStateMachine
LAYER:        L5 (Arbitration)
PURPOSE:      8-state durable state machine for BFA arbitration lifecycle. Persist-before-emit (DNA-8).
FACTORY:      F916:IArbitrationStateMachineService, F917:IArbitrationSessionPersistenceService
FABRIC:       QUEUE FABRIC (Skill 04 → Redis Streams), DATABASE FABRIC (Skill 05 → PostgreSQL)

IMPLEMENTATION PROMPT:
  "Generate IArbitrationStateMachineService that:
   1. Implements persist-before-emit: write state to PG BEFORE emitting queue event (DNA-8)
   2. Valid states: idle|extracting|detecting|severity_aggregating|pending_resolution|
      skip_arbitration|applying_resolution|resolved|rejected|error
   3. Invalid state transitions return DataProcessResult failure (never throw — DNA-3)
   4. All state documents as Dictionary<string,object> (DNA-1)
   5. Idempotent transitions: same event received twice = no-op (DNA-7)
   Generate IArbitrationSessionPersistenceService:
   1. Stores session: {session_id, current_state, proposed_change_id, conflict_report_id,
      tenant_id, created_at, updated_at}
   2. Rehydration from PG in < 60s (resumability requirement)"

POSITIVE EXAMPLE:
  EXTRACTING → DETECTING:
  1. Write session state=DETECTING to PG [persist]
  2. Emit bfa.extracting.completed to Redis Streams [emit]
  3. Return DataProcessResult<T> Success=true

NEGATIVE EXAMPLE:
  ❌ Emit event THEN write to PG → loses state if PG write fails after emit
  ❌ throw new InvalidStateException("Can't transition") → violates DNA-3

AF-4 RETRIEVAL TAGS: [state-machine, persist-before-emit, arbitration, durable, resumable, DNA-8]
CROSS-REFS: F916, F917, T333, DR-146, DNA-7, DNA-8
```

---

### SK-208: ImpactReportGenerator
```
SKILL ID:     SK-208
NAME:         ImpactReportGenerator
LAYER:        L5 (Arbitration — Human-in-Loop)
PURPOSE:      Generate human-readable structured impact report from ConflictReport.
              Fabric-first: template-driven, no hardcoded channel values.
FACTORY:      F930:IImpactReportRendererService, F931:IDecisionOptionBuilderService
FABRIC:       DATABASE FABRIC (Skill 05 → Elasticsearch — impact report templates)

IMPLEMENTATION PROMPT:
  "Generate IImpactReportRendererService that:
   1. Reads report template from ES (FREEDOM: different templates per channel — Web/CLI/Chat)
   2. Populates template with: severity_badge, impacted_flows[] with descriptions,
      blast_radius_summary, evidence_links[], 4 decision options
   3. FORCE_PROCEED option only in output if actor has bfa:override permission
   4. Returns rendered report as Dictionary<string,object> (DNA-1)
   5. Template variables bound at render time — zero hardcoded platform values (fabric-first UI)"

POSITIVE EXAMPLE:
  Web template renders: { severity: '🚨 CRITICAL', impacted: ['checkout-flow', 'sub-flow'],
    options: [{ id: 'REFACTOR_FLOWS', label: 'Auto-refactor affected flows', ... }, ...] }
  CLI template renders: plain text version of same structure

NEGATIVE EXAMPLE:
  ❌ if (channel == "web") { return "<div>..." }  // hardcoded platform value
  ❌ Always show FORCE_PROCEED option // must check actor permission first (IR-334-2)

AF-4 RETRIEVAL TAGS: [impact-report, template, DynamicController, channel-agnostic, FORCE_PROCEED]
CROSS-REFS: F930, F931, T334, DR-148, DR-151
```

---

### SK-209: ResolutionApplier
```
SKILL ID:     SK-209
NAME:         ResolutionApplier
LAYER:        L5 (Arbitration)
PURPOSE:      Apply user decision: REFACTOR_FLOWS | REJECT_CHANGE | COMPAT_MODE | FORCE_PROCEED
FACTORY:      F920:IResolutionApplierService, F934:IAutoRefactorCoordinatorService, F935:ICompatibilityWrapperService
FABRIC:       FLOW ENGINE FABRIC (Skill 09), DATABASE FABRIC (Skill 05)

IMPLEMENTATION PROMPT:
  "Generate IResolutionApplierService that dispatches to correct resolution path:
   REJECT_CHANGE: mark proposed_change as rejected in PG (F907). Emit rejection event.
   REFACTOR_FLOWS: call F934.CoordinateRefactorAsync(affected_flows). Handle partial failure gracefully.
   COMPAT_MODE: call F935.RegisterWrapperAsync(entity, field, sunset_date).
   FORCE_PROCEED: validate bfa:override permission. Write to F943 override_log FIRST.
                  Then emit publish.approved event.
   All paths: DataProcessResult<T> (DNA-3). Scope Isolation (DNA-5)."

POSITIVE EXAMPLE:
  Decision = FORCE_PROCEED:
  1. Validate bfa:override permission ✓
  2. Write override_log { actor, rationale, session_id, ... } to PG (F943)
  3. Emit publish.approved event
  → DataProcessResult Success=true

NEGATIVE EXAMPLE:
  ❌ Emit publish.approved THEN write override_log → IR-336-1 violation (log must precede publish)
  ❌ Ignoring partial refactor failure → IR-336-3 violation (must handle partial success)

AF-4 RETRIEVAL TAGS: [resolution, FORCE_PROCEED, REFACTOR_FLOWS, COMPAT_MODE, override-log]
CROSS-REFS: F920, F934, F935, T336, DR-147, DR-148, IR-336-1
```

---

### SK-210: BFAAuditTrailService
```
SKILL ID:     SK-210
NAME:         BFAAuditTrailService
LAYER:        L6 (Governance)
PURPOSE:      Write immutable audit records for all BFA decisions. Per-field audit logging (DNA-9).
FACTORY:      F940:IBFATenantAuditTrailService, F943:IForceOverrideTrackerService
FABRIC:       DATABASE FABRIC (Skill 05 → PostgreSQL)

IMPLEMENTATION PROMPT:
  "Generate IBFATenantAuditTrailService that:
   1. Writes INSERT-only to bfa_tenant_audit_log (never UPDATE/DELETE — DR-147)
   2. Record: {session_id, tenant_id, decision, actor, timestamp, rationale, affected_flows[], change_type}
   3. Per-field audit logging (DNA-9): log each field change as separate audit_field entry
   4. GDPR retention: retention_days read from FREEDOM config (F938 tenant config)
   5. Returns DataProcessResult<string> with audit_record_id"

POSITIVE EXAMPLE:
  audit_record: { record_id: 'uuid', session_id: 's-123', tenant_id: 't-abc',
    decision: 'FORCE_PROCEED', actor: 'admin@co.com', rationale: 'Approved by CTO...',
    timestamp: '2026-02-27T...', affected_flows: ['checkout', 'subscription'] }

NEGATIVE EXAMPLE:
  ❌ UPDATE bfa_audit_log SET decision = 'REJECT' WHERE session_id = ...  // immutable — DR-147
  ❌ Storing rationale only on FORCE_PROCEED // must log rationale for all decisions

AF-4 RETRIEVAL TAGS: [audit-trail, immutable, INSERT-only, FORCE_PROCEED, DNA-9, GDPR]
CROSS-REFS: F940, F943, T337, DR-147, DR-152, DNA-9
```

---

### SK-211: BFAContextAggregator
```
SKILL ID:     SK-211
NAME:         BFAContextAggregator
LAYER:        L5 (Context Aggregation)
PURPOSE:      Hybrid context gathering: dependency index query + vector RAG search.
              Cache-backed (Redis, TTL: 1h). Powers AI semantic analysis (SK-204).
FACTORY:      F923-F928 (full context aggregation family)
FABRIC:       DATABASE FABRIC (ES+PG), RAG FABRIC (Skill 00b), CORE FABRIC (Skill 01 — cache)

IMPLEMENTATION PROMPT:
  "Generate IBFAContextBundlerService that:
   1. Checks cache (F928): key = sha256(change_id + entity_refs_sorted)
   2. On cache miss:
      a. F923 → retrieve impacted flow definitions from flow_registry
      b. F924 → retrieve entity schema versions (current + N-1)
      c. F925 → vector search for semantically related docs (RAG HYBRID strategy)
      d. F926 → retrieve relevant DR/DD entries (RAG TIERED strategy)
   3. Assembles context bundle: {flows[], schemas[], semantic_docs[], design_records[]}
   4. Writes bundle to cache (F928, TTL: 3600s)
   5. Returns DataProcessResult<Dictionary<string,object>>"

POSITIVE EXAMPLE:
  change_id=c-123, entities=[UserProfile]
  Cache miss → fetch 3 flows, 2 schema versions, 5 semantic docs, 2 DRs
  → context_bundle assembled → cached → returned

NEGATIVE EXAMPLE:
  ❌ Returning cached bundle when flow_registry was updated since cache write
     → must invalidate cache on flow.published event (DR-149)
  ❌ Context bundle with 0 flows for CRITICAL change → CF-411 violation

AF-4 RETRIEVAL TAGS: [context-aggregation, RAG, cache, vector-search, context-bundle]
CROSS-REFS: F923, F924, F925, F926, F927, F928, T330, DR-149
```

---

### SK-212: BFAMultiTenantGuard
```
SKILL ID:     SK-212
NAME:         BFAMultiTenantGuard
LAYER:        L7 (Multi-Tenant)
PURPOSE:      Tenant-scoped BFA operations. Provision, validate, isolate. Inherits FLOW-08+FLOW-14 MT.
FACTORY:      F936-F941 (BFA MT Extension family)
FABRIC:       DATABASE FABRIC (Skill 05 → ES + PG)

IMPLEMENTATION PROMPT:
  "Generate IBFATenantIsolationValidatorService that:
   1. Scans recent BFA query audit log for any query missing tenantId filter
   2. Runs every 15m (configurable via FREEDOM config)
   3. On violation: DataProcessResult with violation details + emit CRITICAL alert event
   Generate IBFATenantProvisionService that:
   1. Creates bfa_tenant_config record: {tenant_id, bfa_enabled, severity_threshold,
      resolution_channel, precedent_enabled, retention_days}
   2. BFA MUST NOT process arbitration for unconfigured tenant (IR-338-1)
   3. Inherits FLOW-08 MT provisioning pattern"

POSITIVE EXAMPLE:
  Provision: { tenant_id: 't-new', bfa_enabled: true, severity_threshold: 'HIGH',
    resolution_channel: 'web', precedent_enabled: false, retention_days: 365 }
  → BFA active for tenant t-new

NEGATIVE EXAMPLE:
  ❌ Processing arbitration for tenant with no bfa_tenant_config → IR-338-1 violation
  ❌ Isolation validator query scanning without tenantId scope on scan itself → meta-irony violation

AF-4 RETRIEVAL TAGS: [multi-tenant, tenant-isolation, BFA-provision, scope-isolation, DNA-5]
CROSS-REFS: F936, F937, F938, F939, F940, F941, T338, DR-150
```

---

### SK-213: BFAAnalyticsEmitter
```
SKILL ID:     SK-213
NAME:         BFAAnalyticsEmitter
LAYER:        L7 (Analytics)
PURPOSE:      Post-session analytics: tenant metrics, platform aggregates, pattern learning, telemetry.
FACTORY:      F941, F942, F945, F946
FABRIC:       DATABASE FABRIC (ES), RAG FABRIC (Skill 00b), QUEUE FABRIC (Skill 04)

IMPLEMENTATION PROMPT:
  "Generate analytics emission services that:
   1. IBFATenantMetricsService: writes to bfa_tenant_metrics ES index with tenantId (DNA-5)
   2. IBFAPlatformMetricsService: writes ONLY aggregated stats (no per-tenant data)
   3. IBFAPatternLearningService: indexes { change_type, entity_class, conflict_type, resolution, outcome }
      to RAG vector index (tenant-scoped)
   4. IBFAOpenTelemetryService: emits span bfa.session.closed with duration + final state
   All: async fire-and-forget acceptable (IR-340-1). DataProcessResult<T> (DNA-3)."

AF-4 RETRIEVAL TAGS: [analytics, telemetry, pattern-learning, metrics, OpenTelemetry]
CROSS-REFS: F941, F942, F945, F946, T340, DR-153
```

---

### SK-214: BFANotificationService
```
SKILL ID:     SK-214
NAME:         BFANotificationService
LAYER:        L5 (Human-in-Loop)
PURPOSE:      Route impact report to user's channel (Web/CLI/Chat/Webhook). Async notification.
              Channel determined by FREEDOM config per tenant.
FACTORY:      F918:IHumanResolutionRouterService, F933:IResolutionNotificationService
FABRIC:       QUEUE FABRIC (Skill 04 → Redis Streams)

IMPLEMENTATION PROMPT:
  "Generate IHumanResolutionRouterService that:
   1. Reads resolution_channel from bfa_tenant_config (FREEDOM — never hardcoded)
   2. Routes to: WEB (SSE/WebSocket event) | CLI (console stream) | CHAT (messaging fabric)
      | WEBHOOK (HTTP POST via F933)
   3. Never blocks arbitration thread — async enqueue to QUEUE FABRIC (DNA-3, no throw)
   Generate IResolutionNotificationService:
   1. Notifies: change proposer, impacted flow owners, tenant admin
   2. Includes: outcome, decision, audit_record_id, affected_flows[]
   3. Uses QUEUE FABRIC for delivery (Redis Streams)"

AF-4 RETRIEVAL TAGS: [notification, channel-routing, async, human-in-loop, web-cli-chat]
CROSS-REFS: F918, F933, T334, DR-150
```

---

### SK-215: BFADecisionCaptureService
```
SKILL ID:     SK-215
NAME:         BFADecisionCaptureService
LAYER:        L5 (Human-in-Loop)
PURPOSE:      Idempotent decision capture. Validates decision schema. FORCE_PROCEED permission check.
FACTORY:      F932:IDecisionCaptureService, F919:IUserDecisionReceiverService
FABRIC:       QUEUE FABRIC (Skill 04 → Redis Streams)

IMPLEMENTATION PROMPT:
  "Generate IDecisionCaptureService that:
   1. SETNX on session_id (Redis) — prevents duplicate processing (DNA-7)
   2. Validates decision ∈ {REFACTOR_FLOWS, REJECT_CHANGE, COMPAT_MODE, FORCE_PROCEED}
   3. If FORCE_PROCEED: validate bfa:override permission (auth context from MicroserviceBase)
   4. If FORCE_PROCEED: validate rationale ≥ FREEDOM config min_length (default: 50 chars)
   5. Emits bfa.decision.captured to QUEUE FABRIC on success
   6. Returns DataProcessResult failure (not throw) on invalid decision or missing permission"

POSITIVE EXAMPLE:
  Session s-123 received REFACTOR_FLOWS from actor user-456:
  SETNX "decision:s-123" → success (first capture)
  Validate: REFACTOR_FLOWS ∈ valid set ✓
  Emit: bfa.decision.captured → success

NEGATIVE EXAMPLE:
  ❌ Second call with same session_id → SETNX fails → return DataProcessResult Success=true
     with existing decision (idempotent — not error) (DNA-7)
  ❌ FORCE_PROCEED with 30-char rationale → DataProcessResult failure (IR-335-2)

AF-4 RETRIEVAL TAGS: [decision-capture, idempotency, SETNX, FORCE_PROCEED, permission-check, DNA-7]
CROSS-REFS: F919, F932, T335, DR-148, DNA-7, IR-335-1, IR-335-2, IR-335-3
```

---

## AF-4 RAG RETRIEVAL INDEX (FLOW-22 SKILLS)

| Search Query | Top Skills | Key Factories |
|---|---|---|
| "parse proposed change entity schema diff" | SK-201, SK-203 | F901, F905 |
| "dependency index flow entity relationship" | SK-202, SK-206 | F904, F908, F910 |
| "conflict detection static rules CF" | SK-203, SK-205 | F909, F911, F914 |
| "semantic AI impact analysis multi-model" | SK-204, SK-211 | F912, F925, F927 |
| "severity classification aggregation" | SK-205 | F914, F915 |
| "blast radius transitive dependency graph" | SK-206 | F910 |
| "arbitration state machine persist-before-emit" | SK-207 | F916, F917 |
| "impact report human-readable template" | SK-208, SK-214 | F930, F931, F918 |
| "resolution FORCE_PROCEED compat refactor" | SK-209 | F920, F934, F935 |
| "audit trail immutable decision record" | SK-210 | F940, F943 |
| "context bundle RAG vector hybrid" | SK-211 | F923, F924, F925, F926 |
| "multi-tenant BFA isolation tenant-scoped" | SK-212 | F936, F937, F938, F939 |
| "analytics metrics pattern learning telemetry" | SK-213 | F941, F942, F945, F946 |
| "notification channel routing web CLI chat" | SK-214 | F918, F933 |
| "decision capture idempotency SETNX session" | SK-215 | F919, F932 |

---

## SKILL DEPENDENCY MAP (FLOW-22 — Reading Order for AF-4)

```
Extraction Layer:
  SK-201 (ParseChange) → SK-202 (DependencyIndex) → SK-206 (BlastRadius)

Detection Layer:
  SK-203 (StaticConflict) + SK-204 (SemanticAI) → SK-205 (SeverityClassifier)
  SK-211 (ContextAggregator) feeds SK-204

Arbitration Layer:
  SK-207 (StateMachine) orchestrates all
  SK-208 (ImpactReport) → SK-214 (Notification) → SK-215 (DecisionCapture)
  SK-209 (ResolutionApplier) executes decision
  SK-210 (AuditTrail) closes every session

Governance Layer:
  SK-212 (MTGuard) enforces tenant isolation throughout
  SK-213 (Analytics) emits post-session metrics
```

---

## SAVE POINT: FLOW22:SKILLS:COMPLETE ✅
## Next: V62_BFA_STRESS_TEST (CF-402–CF-430, ST-227–ST-248)
