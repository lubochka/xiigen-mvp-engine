# XIIGen ENGINE ARCHITECTURE — FLOW-22 DELTA
# Business Flow Arbiter — Impact Analysis & Cross-Flow Governance Gate
# Extends: ENGINE_ARCHITECTURE_MERGED.md (F1–F900, Families 1–127)
# Status: FLOW-22 NEW ARTIFACTS ONLY

---

## SAVE POINT: FLOW22:ENGINE_ARCH:START

**System state entering FLOW-22:**
- Last factory: F900 (Family 127 — Forms MT Isolation)
- Next factory: F901 (Family 128)
- Last DR: DR-143
- Next DR: DR-144

---

## FACTORY REGISTRY DELTA — FLOW-22

### FAMILY 128 — Impact Extraction Layer (F901–F907)

**Purpose:** Parse proposed changes (entity edits, schema diffs, flow modifications, code ASTs),
extract entity/API references, classify CRUD intents, and write to the dependency index.
All services extend MicroserviceBase. All data as Dictionary<string,object>.

```
F901 : IProposedChangeParserService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — stores parsed change documents)
  FACTORY  → IExternalServiceFactory<IProposedChangeParserService>
  PURPOSE  → Ingests raw change payloads (JSON Patch, schema diffs, flow JSON diffs)
             Normalizes to canonical ProposedChange document (Dictionary<string,object>)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → diff_format field supports: JSON_PATCH, SCHEMA_DIFF, FLOW_DAG_DIFF, CODE_AST

F902 : IEntityReferenceExtractorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads entity schema registry)
  FACTORY  → IExternalServiceFactory<IEntityReferenceExtractorService>
  PURPOSE  → Extracts all entity/field references from parsed change document
             Tags each reference with access_type: READ | WRITE | DELETE | CREATE
  DNA      → ParseDocument, BuildSearchFilter (empty fields skipped), DataProcessResult<T>
  NOTES    → Deterministic extraction; no AI; output written to dependency_extractions index

F903 : IApiSurfaceExtractorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads API surface registry)
  FACTORY  → IExternalServiceFactory<IApiSurfaceExtractorService>
  PURPOSE  → Extracts API endpoint references from the proposed change
             Detects route/method/contract changes that may break dependent flows
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Works alongside F902; API changes can break flows even without entity changes

F904 : IFlowDependencyIndexWriterService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — writes to bfa_dependency_index)
  FACTORY  → IExternalServiceFactory<IFlowDependencyIndexWriterService>
  PURPOSE  → Writes/updates flow↔entity and flow↔API dependency records
             Called after every flow publication to keep index current
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → bfa_dependency_index: {flow_id, entity_name, access_type, field_paths, tenant_id}

F905 : ISchemaDiffClassifierService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads schema version history)
  FACTORY  → IExternalServiceFactory<ISchemaDiffClassifierService>
  PURPOSE  → Classifies schema changes as BREAKING | ADDITIVE | COMPATIBLE
             BREAKING = required field removal, type change, constraint tightening
             ADDITIVE = new optional field, new endpoint
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → Pure deterministic logic; output severity: CRITICAL | HIGH | MEDIUM | LOW

F906 : IStateTransitionAnalyzerService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads flow state machine specs)
  FACTORY  → IExternalServiceFactory<IStateTransitionAnalyzerService>
  PURPOSE  → Detects if proposed change removes or renames state transitions that
             existing flows depend on (e.g., flow expects Status:Pending but change skips it)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Cross-references bfa_flow_state_registry; critical for saga/orchestration flows

F907 : IChangeDocumentPersistenceService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — immutable change record store)
  FACTORY  → IExternalServiceFactory<IChangeDocumentPersistenceService>
  PURPOSE  → Persists the canonical ProposedChange document with content-addressed hash
             Immutable: write-once, read-many; referenced by all subsequent arbitration steps
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → PG chosen over ES for ACID guarantees on immutable change audit records
```

---

### FAMILY 129 — Conflict Detection Engine (F908–F915)

**Purpose:** Detect conflicts between proposed changes and existing flow definitions.
Hybrid approach: static deterministic rules first (F908-F911), then AI semantic analysis (F912-F913),
then severity aggregation (F914-F915).

```
F908 : IDependencyIndexQueryService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — queries bfa_dependency_index)
  FACTORY  → IExternalServiceFactory<IDependencyIndexQueryService>
  PURPOSE  → Given a set of extracted entity/API references, returns all flows that
             depend on those references (the "blast radius" candidate set)
  DNA      → ParseDocument, BuildSearchFilter, DataProcessResult<T>, Scope Isolation
  NOTES    → Returns List<Dictionary<string,object>> of impacted flow candidates

F909 : IStaticConflictRulesEngineService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads CF rules from bfa_rules_index)
  FACTORY  → IExternalServiceFactory<IStaticConflictRulesEngineService>
  PURPOSE  → Applies deterministic CF rules (CF-402 through CF-430+) against extracted
             entity references and blast radius candidate set
             Returns structured conflict list with CF rule reference
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, BuildSearchFilter
  NOTES    → Zero AI involved; 100% deterministic and repeatable

F910 : IBlastRadiusCalculatorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — multi-hop dependency traversal)
  FACTORY  → IExternalServiceFactory<IBlastRadiusCalculatorService>
  PURPOSE  → Traverses dependency graph transitively: if Flow-A depends on Entity-X
             and Flow-B depends on Flow-A, Flow-B is also in blast radius
             Returns { direct_impacts: [], transitive_impacts: [], total_count: N }
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter, Scope Isolation
  NOTES    → Graph traversal depth configurable via FREEDOM config (default: 3 hops)

F911 : IBreakingChangeValidatorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — queries live flow definitions)
  FACTORY  → IExternalServiceFactory<IBreakingChangeValidatorService>
  PURPOSE  → For each flow in blast radius, validates whether the proposed change
             actually breaks that flow's logic (required field missing, transition absent)
             vs. merely touching it (ADDITIVE change is not breaking)
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter, MicroserviceBase
  NOTES    → Reduces false positives; only truly broken flows escalate to AI analysis

F912 : ISemanticConflictAnalyzerService
  FABRIC   → AI ENGINE FABRIC (Skill 07 → AiDispatcher → Claude/OpenAI/Gemini parallel)
  FACTORY  → IExternalServiceFactory<ISemanticConflictAnalyzerService>
  PURPOSE  → Sends context bundle + proposed change to AiDispatcher for parallel multi-model
             semantic analysis. Detects hidden business logic conflicts not caught by static rules.
             Constrained output: must validate against ImpactReport JSON schema
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → ADVISORY only — static gate (F909/F911) takes precedence for CRITICAL severity
             Prompt: "You are a Business Logic Arbiter. Detect logical collisions..."

F913 : ISemanticOutputValidatorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads impact report JSON schema)
  FACTORY  → IExternalServiceFactory<ISemanticOutputValidatorService>
  PURPOSE  → Validates AI semantic analysis output against ImpactReport JSON schema
             Rejects or requests retry if output is malformed or lacks evidence links
             Prevents hallucinated impact reports from reaching arbitration
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → Critical guardrail: AI output is probabilistic; schema validation is deterministic

F914 : ISeverityAggregatorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads severity rules config)
  FACTORY  → IExternalServiceFactory<ISeverityAggregatorService>
  PURPOSE  → Aggregates static conflict results + validated AI results into a single
             composite severity: CRITICAL | HIGH | MEDIUM | LOW | NONE
             CRITICAL = any static CRITICAL finding OR any AI CRITICAL finding with evidence
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → Severity escalation rules stored as FREEDOM config (admin-configurable)

F915 : IConflictReportAssemblerService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — persists assembled conflict report)
  FACTORY  → IExternalServiceFactory<IConflictReportAssemblerService>
  PURPOSE  → Assembles final ConflictReport document:
             { proposed_change_id, severity, impacted_flows[], conflict_rules[], evidence[], tenant_id }
             Persists to PG bfa_conflict_reports table (immutable)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → This is the payload sent to arbitration state machine (Family 130)
```

---

### FAMILY 130 — Arbitration Orchestrator (F916–F922)

**Purpose:** State machine that drives the full arbitration lifecycle:
IDLE → EXTRACTING → DETECTING → PENDING_RESOLUTION → APPLYING_RESOLUTION → RESOLVED/REJECTED/ERROR

```
F916 : IArbitrationStateMachineService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — publishes state transition events)
  FACTORY  → IExternalServiceFactory<IArbitrationStateMachineService>
  PURPOSE  → Orchestrates the BFA pipeline as a durable state machine
             Each state transition is persisted before event is emitted (persist-before-emit)
             Supports interruption and resumption (sub-60-second recovery)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, DNA-8 Outbox
  NOTES    → State: idle|extracting|detecting|pending_resolution|applying|resolved|rejected|error

F917 : IArbitrationSessionPersistenceService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_sessions table)
  FACTORY  → IExternalServiceFactory<IArbitrationSessionPersistenceService>
  PURPOSE  → Stores complete arbitration session state for resumability
             { session_id, proposed_change_id, current_state, conflict_report_id, tenant_id, created_at }
             Updated atomically on each state transition
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Recovery: any service reading session can resume from last persisted state

F918 : IHumanResolutionRouterService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — routes to notification channel)
  FACTORY  → IExternalServiceFactory<IHumanResolutionRouterService>
  PURPOSE  → When state = PENDING_RESOLUTION, routes structured impact report to the
             appropriate channel: CLI, Web Editor, Chat Service, or API webhook
             Channel determined by FREEDOM config (admin-selects per tenant)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Never blocks the arbitration thread; uses async notification pattern

F919 : IUserDecisionReceiverService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — receives decision event)
  FACTORY  → IExternalServiceFactory<IUserDecisionReceiverService>
  PURPOSE  → Receives user decision from any channel, validates decision schema,
             and enqueues to arbitration state machine for processing
             Decision options: REFACTOR_FLOWS | REJECT_CHANGE | COMPAT_MODE | FORCE_PROCEED
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, DNA-7 Idempotency
  NOTES    → SETNX dedup prevents duplicate decision processing (idempotency key: session_id)

F920 : IResolutionApplierService
  FABRIC   → FLOW ENGINE FABRIC (Skill 09 → FlowOrchestrator — triggers downstream actions)
  FACTORY  → IExternalServiceFactory<IResolutionApplierService>
  PURPOSE  → Applies the user decision:
             REFACTOR_FLOWS → queues auto-refactor tasks for affected flows
             REJECT_CHANGE → marks proposed change as rejected, unblocks original flow
             COMPAT_MODE → marks fields obsolete, adds backward compat wrapper
             FORCE_PROCEED → logs privileged override, proceeds with publish
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → FORCE_PROCEED requires elevated permission (checked via Auth context from MSB)

F921 : IArbitrationTimeoutService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — delayed message for timeout)
  FACTORY  → IExternalServiceFactory<IArbitrationTimeoutService>
  PURPOSE  → Schedules timeout for PENDING_RESOLUTION state (default: 24h, FREEDOM config)
             On timeout: escalates to admin, optionally auto-rejects (FREEDOM config)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Prevents stuck arbitration sessions from blocking flow publication indefinitely

F922 : IArbitrationEscalationService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — escalation event)
  FACTORY  → IExternalServiceFactory<IArbitrationEscalationService>
  PURPOSE  → Handles escalation scenarios: timeout reached, unresolvable conflict,
             repeated FORCE_PROCEED by same actor on same entity
             Routes to platform admin (or tenant admin) via notification fabric
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Escalation threshold configurable via FREEDOM config
```

---

### FAMILY 131 — Context Aggregation Service (F923–F929)

**Purpose:** Gather all relevant context (flows, documentation, schemas) needed for
semantic analysis. Hybrid approach: deterministic dependency index query + vector RAG search.

```
F923 : IFlowRegistryReaderService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads bfa_flow_registry index)
  FACTORY  → IExternalServiceFactory<IFlowRegistryReaderService>
  PURPOSE  → Retrieves complete flow definitions for all flows in blast radius
             Returns flow JSON (DAG) documents as Dictionary<string,object>[]
  DNA      → ParseDocument, BuildSearchFilter, DataProcessResult<T>, Scope Isolation
  NOTES    → bfa_flow_registry mirrors flow definitions from FLOW ENGINE FABRIC

F924 : ISchemaRegistryReaderService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads bfa_schema_registry index)
  FACTORY  → IExternalServiceFactory<ISchemaRegistryReaderService>
  PURPOSE  → Retrieves current and historical entity schema versions for impacted entities
             Supports change-over-time analysis (schema version N vs N-1)
  DNA      → ParseDocument, BuildSearchFilter, DataProcessResult<T>
  NOTES    → Schema versions are immutable once published (content-addressed by hash)

F925 : IDocumentationVectorSearchService
  FABRIC   → RAG FABRIC (Skill 00b → IRagService → Hybrid strategy)
  FACTORY  → IExternalServiceFactory<IDocumentationVectorSearchService>
  PURPOSE  → Semantic vector search over flow documentation, design records, and
             skill descriptions to find conceptually related context not caught by
             deterministic dependency index
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Strategy: Hybrid (deterministic recall + dense vector semantic similarity)

F926 : IDesignRecordContextService
  FABRIC   → RAG FABRIC (Skill 00b → IRagService → Tiered strategy)
  FACTORY  → IExternalServiceFactory<IDesignRecordContextService>
  PURPOSE  → Retrieves relevant design records (DR-*) and design decisions (DD-*)
             that constrain the proposed change domain
             Provides architectural rationale to AI semantic analyzer
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → Tiered RAG: exact DR/DD match first, then semantic similarity fallback

F927 : IBFAContextBundlerService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — writes context bundle cache)
  FACTORY  → IExternalServiceFactory<IBFAContextBundlerService>
  PURPOSE  → Assembles final context bundle from F923-F926 outputs:
             { impacted_flows[], entity_schemas[], semantic_docs[], design_records[] }
             Writes to short-lived cache (TTL: 1h) to avoid redundant retrieval
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Context bundle is the input to F912 (SemanticConflictAnalyzer)

F928 : IBFAContextCacheService
  FABRIC   → DATABASE FABRIC (Skill 05 → Redis — short-lived context cache)
  FACTORY  → IExternalServiceFactory<IBFAContextCacheService>
  PURPOSE  → Redis-backed context cache: get/set/invalidate context bundles
             Key: sha256(change_id + entity_refs_hash), TTL: 3600s
             Avoids re-running expensive vector search for duplicate change proposals
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Cache invalidated on flow registry update or schema registry update

F929 : IBFAHistoricalDecisionService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — reads bfa_decision_history)
  FACTORY  → IExternalServiceFactory<IBFAHistoricalDecisionService>
  PURPOSE  → Retrieves past arbitration decisions for similar changes (same entity,
             same change type) to provide precedent context to AI analyzer
             Enables learning: similar changes resolved same way get accelerated path
  DNA      → ParseDocument, BuildSearchFilter, DataProcessResult<T>, Scope Isolation
  NOTES    → Precedent-based fast path: if same change+entity+resolution seen 3+ times,
             offer auto-suggest (FREEDOM config: enable/disable precedent suggestions)
```

---

### FAMILY 132 — Human-in-Loop Resolution UI Fabric (F930–F935)

**Purpose:** Render structured impact reports, capture user decisions, apply resolutions.
Fabric-first UI: zero platform-specific values. Interfaces work via Web, CLI, Chat, API webhook.

```
F930 : IImpactReportRendererService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads impact report template index)
  FACTORY  → IExternalServiceFactory<IImpactReportRendererService>
  PURPOSE  → Renders structured ConflictReport as human-readable impact report
             Outputs: { summary, severity_badge, impacted_flows[], options[], evidence_links[] }
             Template-driven (FREEDOM): admin selects report template per channel
  DNA      → ParseDocument, DataProcessResult<T>, DynamicController
  NOTES    → UI fabric-first: never hardcodes platform values; DynamicController serves report

F931 : IDecisionOptionBuilderService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — reads resolution option configs)
  FACTORY  → IExternalServiceFactory<IDecisionOptionBuilderService>
  PURPOSE  → Builds the decision option set for the user prompt:
             Always: [REFACTOR_FLOWS, REJECT_CHANGE, COMPAT_MODE, FORCE_PROCEED]
             FORCE_PROCEED shown only if actor has elevated permission
             Options enriched with estimated impact per choice (FREEDOM config: enable/disable)
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → MACHINE: 4-option set is fixed. FREEDOM: option descriptions and hints are configurable

F932 : IDecisionCaptureService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — emits decision captured event)
  FACTORY  → IExternalServiceFactory<IDecisionCaptureService>
  PURPOSE  → Captures user decision (choice + optional rationale text)
             Validates decision is one of the 4 allowed options
             Emits bfa.decision.captured event to arbitration state machine
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, DNA-7 Idempotency
  NOTES    → Idempotency: SETNX on session_id prevents double-capture

F933 : IResolutionNotificationService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — resolution outcome notification)
  FACTORY  → IExternalServiceFactory<IResolutionNotificationService>
  PURPOSE  → Notifies all interested parties of arbitration resolution outcome:
             change proposer, flow owners of impacted flows, tenant admin
             Includes: outcome, decision, audit reference, affected flow list
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Notification channel: same FREEDOM config as F918 routing

F934 : IAutoRefactorCoordinatorService
  FABRIC   → FLOW ENGINE FABRIC (Skill 09 → FlowOrchestrator — triggers refactor sub-flow)
  FACTORY  → IExternalServiceFactory<IAutoRefactorCoordinatorService>
  PURPOSE  → When decision = REFACTOR_FLOWS: coordinates automatic refactoring of
             affected flows to accommodate the proposed change
             Generates refactor tasks, queues via FlowOrchestrator, tracks completion
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Refactor tasks are themselves factory-backed (use existing flow's task types)
             If auto-refactor fails, escalates back to human for manual resolution

F935 : ICompatibilityWrapperService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — writes compat wrapper registry)
  FACTORY  → IExternalServiceFactory<ICompatibilityWrapperService>
  PURPOSE  → When decision = COMPAT_MODE: registers backward compatibility wrapper:
             old field/endpoint remains accessible, marked [Obsolete], new field added
             Wrapper entry stored in bfa_compat_registry with sunset date (FREEDOM config)
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter, Scope Isolation
  NOTES    → Sunset date triggers auto-escalation when reached (via F922)
```

---

### FAMILY 133 — BFA Multi-Tenant Extension (F936–F941)

**Purpose:** Tenant-scoped conflict detection. Inherits patterns from FLOW-08 (Payment MT)
and FLOW-14 (Warehouse MT). Each tenant sees only their own flow conflict index.
Platform-level conflicts (cross-tenant factory clashes) detected by global guard.

```
F936 : IBFATenantConflictIndexService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — tenant-scoped bfa_dependency_index)
  FACTORY  → IExternalServiceFactory<IBFATenantConflictIndexService>
  PURPOSE  → Tenant-scoped conflict dependency index: all queries include tenantId filter
             Each tenant's flow definitions indexed independently
             Index: bfa_dependency_index_{tenantId} or shared index with RLS
  DNA      → ParseDocument, BuildSearchFilter, DataProcessResult<T>, Scope Isolation (DNA-5)
  NOTES    → Scope isolation enforced at query level AND at index level (dual enforcement)

F937 : ICrossTenantConflictGuardService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — platform-level conflict index)
  FACTORY  → IExternalServiceFactory<ICrossTenantConflictGuardService>
  PURPOSE  → Detects conflicts in shared infrastructure components (factory interfaces,
             global schema definitions, platform-level event types) that cross tenant boundaries
             Platform admin only; never exposes tenant-specific data across tenants
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → Cross-tenant guard has no tenantId filter (platform-level); access = platform_admin role

F938 : IBFATenantProvisionService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_tenant_config table)
  FACTORY  → IExternalServiceFactory<IBFATenantProvisionService>
  PURPOSE  → Provisions BFA capabilities per tenant:
             - Enable/disable BFA gate (FREEDOM config)
             - Set severity threshold for auto-block vs warn-only
             - Configure resolution channels per tenant
             - Set precedent learning window (days)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Inherits FLOW-08 MT provisioning pattern + FLOW-14 config model

F939 : IBFATenantIsolationValidatorService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — validates index isolation)
  FACTORY  → IExternalServiceFactory<IBFATenantIsolationValidatorService>
  PURPOSE  → Validates that BFA dependency index queries are correctly tenant-scoped
             Part of the DNA-5 enforcement layer: audits every query for tenantId presence
             Health check: scans for any unscoped queries in recent audit log
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter, Scope Isolation
  NOTES    → Runs as periodic health check (every 15m) and on-demand

F940 : IBFATenantAuditTrailService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_tenant_audit_log table)
  FACTORY  → IExternalServiceFactory<IBFATenantAuditTrailService>
  PURPOSE  → Tenant-scoped audit trail for all BFA decisions:
             { session_id, tenant_id, proposed_change_id, decision, actor, timestamp, rationale }
             Immutable append-only log; GDPR-compliant retention config (FREEDOM)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation, DNA-9
  NOTES    → Per-field audit logging (DNA-9); tenant can export their own audit trail

F941 : IBFATenantMetricsService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — bfa_tenant_metrics index)
  FACTORY  → IExternalServiceFactory<IBFATenantMetricsService>
  PURPOSE  → Per-tenant BFA metrics: arbitration_rate, block_rate, override_rate,
             avg_time_to_decision, most_conflicted_entities, most_impacted_flows
             Exposed via DynamicController for admin dashboard
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter, Scope Isolation
  NOTES    → Metrics aggregated on 1m, 1h, 1d windows (FREEDOM: configurable window sizes)
```

---

### FAMILY 134 — BFA Analytics & Observability (F942–F947)

**Purpose:** Platform-level BFA analytics, override tracking, decision quality monitoring.

```
F942 : IBFAPlatformMetricsService
  FABRIC   → DATABASE FABRIC (Skill 05 → Elasticsearch — platform metrics index)
  FACTORY  → IExternalServiceFactory<IBFAPlatformMetricsService>
  PURPOSE  → Platform-wide BFA metrics aggregated across all tenants (no cross-tenant data leak):
             total_arbitrations, total_blocks, total_overrides, avg_resolution_time
             Platform admin only; data is aggregated — no per-tenant data exposed
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter
  NOTES    → Aggregation pipeline runs on ES; no raw tenant data in output

F943 : IForceOverrideTrackerService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_override_log table)
  FACTORY  → IExternalServiceFactory<IForceOverrideTrackerService>
  PURPOSE  → Tracks every FORCE_PROCEED decision with full context:
             actor, proposed_change_id, impacted_flows, rationale, timestamp, tenant_id
             Triggers alert if same actor force-overrides same entity class > N times (FREEDOM: N)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation, DNA-9
  NOTES    → Immutable; FORCE_PROCEED without rationale = BUILD FAILURE (IR-336-1)

F944 : IBFADecisionQualityService
  FABRIC   → AI ENGINE FABRIC (Skill 07 → AiDispatcher → quality scoring)
  FACTORY  → IExternalServiceFactory<IBFADecisionQualityService>
  PURPOSE  → Retrospective quality scoring: after change ships, checks if decision was correct
             (did refactored flows break? did compat wrappers hold? did force overrides cause regressions?)
             Feeds quality scores back to AF-11 Feedback for continuous learning
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Implements the BFA equivalent of AF-11 feedback loop for arbitration quality

F945 : IBFAPatternLearningService
  FABRIC   → RAG FABRIC (Skill 00b → IRagService → vector indexing for decision patterns)
  FACTORY  → IExternalServiceFactory<IBFAPatternLearningService>
  PURPOSE  → Indexes resolved arbitration decisions as learnable patterns:
             { change_type, entity_class, conflict_type, resolution_chosen, outcome }
             Powers precedent-based fast path in F929 (historical decision service)
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase, Scope Isolation
  NOTES    → Patterns are tenant-scoped; platform aggregate patterns available as "global wisdom"

F946 : IBFAOpenTelemetryService
  FABRIC   → QUEUE FABRIC (Skill 04 → Redis Streams — telemetry event stream)
  FACTORY  → IExternalServiceFactory<IBFAOpenTelemetryService>
  PURPOSE  → Emits OpenTelemetry-compatible trace spans and metrics for every BFA operation:
             Span: bfa.impact_extraction, bfa.conflict_detection, bfa.arbitration, bfa.decision
             Correlates with parent flow execution trace for end-to-end observability
  DNA      → ParseDocument, DataProcessResult<T>, MicroserviceBase
  NOTES    → Trace context propagated through all BFA state transitions

F947 : IBFAReportExportService
  FABRIC   → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_export_jobs table)
  FACTORY  → IExternalServiceFactory<IBFAReportExportService>
  PURPOSE  → Exports BFA audit trail and decision history for compliance reporting
             Formats: JSON, CSV (FREEDOM config)
             Tenant-scoped export only; never cross-tenant
  DNA      → ParseDocument, DataProcessResult<T>, BuildSearchFilter, Scope Isolation
  NOTES    → Export jobs are async; signed URL delivery via file fabric (refs FLOW-11 F309)
```

---

## FAMILY SUMMARY (FLOW-22)

| Family | Name | Factories | Count |
|--------|------|-----------|-------|
| 128 | Impact Extraction Layer | F901–F907 | 7 |
| 129 | Conflict Detection Engine | F908–F915 | 8 |
| 130 | Arbitration Orchestrator | F916–F922 | 7 |
| 131 | Context Aggregation Service | F923–F929 | 7 |
| 132 | Human-in-Loop Resolution UI Fabric | F930–F935 | 6 |
| 133 | BFA Multi-Tenant Extension | F936–F941 | 6 |
| 134 | BFA Analytics & Observability | F942–F947 | 6 |
| **TOTAL** | | **F901–F947** | **47** |

---

## DESIGN RECORDS (DR-144 through DR-153)

```
DR-144: BFA as Engine Extension, Not Service
  Decision: BFA is not a standalone microservice. It is an engine extension — 7 families of
            factory interfaces extending the existing engine fabric, resolving through
            existing IDatabaseService, IQueueService, IAiProvider, IRagService.
  Rationale: Standalone service would create coupling; fabric-first keeps BFA swappable
  Constraint: All 47 factories MUST resolve through existing fabric interfaces

DR-145: Hybrid Conflict Detection (Static First, AI Second)
  Decision: Static deterministic rules (F909, F910, F911) run BEFORE AI semantic analysis (F912).
            AI result is ADVISORY unless static gate finds CRITICAL.
  Rationale: Probabilistic AI output cannot be the sole gate for a publish-blocking system.
             Static rules are 100% repeatable; AI adds semantic coverage for implicit conflicts.
  Constraint: CRITICAL severity block = static rule finding only OR AI CRITICAL + evidence link

DR-146: Persist-Before-Emit for Arbitration State Machine
  Decision: Every state transition in F916 (ArbitrationStateMachine) persists state to PG
            BEFORE emitting the transition event to the queue.
  Rationale: Ensures recovery; if queue fails after persist, state can be recovered and event re-emitted.
  Constraint: Implements DNA-8 Outbox pattern. No state transition without prior PG write.

DR-147: Immutable Change + Decision Records
  Decision: ProposedChange (F907) and ArbitrationDecision (F940) records are write-once in PG.
            No UPDATE or DELETE on these tables. FORCE_PROCEED cannot be retroactively removed.
  Rationale: Audit integrity. Compliance. Forensic traceability.
  Constraint: PG tables use INSERT-only patterns. Corrections via new records (supersedes_id FK).

DR-148: FORCE_PROCEED Requires Elevated Permission + Mandatory Rationale
  Decision: FORCE_PROCEED option (F931/F932) is only shown to actors with platform:bfa:override permission.
            Rationale field is mandatory (min 50 chars). Submitted to F943 override tracker.
  Rationale: Prevents routine abuse of the override path. Creates accountability.
  Constraint: IR-336-1: FORCE_PROCEED without rationale = BUILD FAILURE (arbitration rejects)

DR-149: Context Bundle Cache with Invalidation
  Decision: F927/F928 cache context bundles in Redis (TTL: 1h) keyed by sha256(change_id+entity_refs).
            Cache invalidated on: flow registry update, schema registry publish, explicit flush.
  Rationale: Vector search is expensive; caching avoids redundant retrieval for duplicate proposals.
  Constraint: Cache is a performance optimization ONLY. F927 reads live data on cache miss.

DR-150: BFA Multi-Tenant Inherits FLOW-08 + FLOW-14 Models
  Decision: Family 133 (BFA MT) inherits provisioning patterns from FLOW-08 (Payment Processing MT)
            and configuration model from FLOW-14 (Warehouse MT). No new MT patterns introduced.
  Rationale: Proven patterns. Reduces cognitive overhead. Backward-compatible MT model.
  Constraint: F938 MUST reference F900 (Forms MT) and FLOW-08/FLOW-14 MT services.

DR-151: Precedent-Based Fast Path (Optional)
  Decision: F929 may suggest auto-resolution based on historical decisions for identical
            change_type + entity_class combinations (3+ matching precedents).
            Fast path is SUGGESTION ONLY — never auto-applies without user confirmation.
  Rationale: Reduces decision fatigue for common, well-understood change patterns.
  Constraint: FREEDOM config: enable/disable per tenant. Disabled by default.

DR-152: FORCE_PROCEED Alert Threshold
  Decision: F943 triggers escalation alert if same actor overrides same entity_class > 3 times
            in 30 days (FREEDOM: configurable). Alert routed to tenant admin + platform admin.
  Rationale: Pattern of repeated overrides indicates either broken conflict rules or circumvention.
  Constraint: Alert threshold must be a FREEDOM config value; cannot be hardcoded (MACHINE).

DR-153: BFA Analytics Are Read-Only Aggregations
  Decision: F942-F947 analytics services never write to source of truth tables.
            They read from bfa_conflict_reports, bfa_sessions, bfa_override_log via read replicas.
  Rationale: Analytics must not interfere with arbitration pipeline throughput.
  Constraint: Analytics services resolved through DATABASE FABRIC read-replica provider config.
```

---

## FABRIC RESOLUTION MAP (FLOW-22 Summary)

| Factory Range | Fabric | Provider | Skill |
|---------------|--------|----------|-------|
| F901, F902, F903, F904, F905, F906 | DATABASE FABRIC | Elasticsearch | Skill 05 |
| F907, F911, F915, F917, F923, F924 | DATABASE FABRIC | PostgreSQL | Skill 05 |
| F908, F909, F910, F913, F914 | DATABASE FABRIC | Elasticsearch | Skill 05 |
| F916, F918, F919, F921, F922 | QUEUE FABRIC | Redis Streams | Skill 04 |
| F912 | AI ENGINE FABRIC | AiDispatcher (Claude/OpenAI/Gemini) | Skill 07 |
| F925, F926, F945 | RAG FABRIC | IRagService (Hybrid/Tiered/Vector) | Skill 00b |
| F920, F934 | FLOW ENGINE FABRIC | FlowOrchestrator | Skill 09 |
| F928, F946 | DATABASE FABRIC / QUEUE FABRIC | Redis | Skill 04/05 |
| F929, F936, F937, F938, F939, F940, F941, F942, F943, F947 | DATABASE FABRIC | PG/ES | Skill 05 |
| F944 | AI ENGINE FABRIC | AiDispatcher | Skill 07 |

---

## DNA COMPLIANCE (FLOW-22)

| DNA Pattern | Enforcement in FLOW-22 |
|------------|----------------------|
| DNA-1 ParseDocument | All 47 factories use Dictionary<string,object>. No typed models. |
| DNA-2 BuildSearchFilter | All ES queries via BuildSearchFilter; empty fields auto-skipped |
| DNA-3 DataProcessResult<T> | All factory methods return DPR<T>; no business-logic throws |
| DNA-4 MicroserviceBase | All generated services extend MicroserviceBase (19 components) |
| DNA-5 Scope Isolation | tenantId on every tenant-scoped query; F939 validates compliance |
| DNA-6 DynamicController | F930 impact report served via DynamicController; no entity controllers |
| DNA-7 Idempotency | F919 and F932: SETNX dedup on session_id (decision capture) |
| DNA-8 Outbox | F916: persist-before-emit on every state transition (DR-146) |
| DNA-9 Extended | F940 and F943: per-field audit logging for all decisions and overrides |

---

## SAVE POINT: FLOW22:ENGINE_ARCH:COMPLETE ✅
## Next: TASK_TYPES_CATALOG (T327–T340, Templates 67–69)
