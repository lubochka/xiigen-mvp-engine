# XIIGen TASK TYPES CATALOG — FLOW-22 DELTA
# Business Flow Arbiter — Task Type Engine Contracts
# Extends: TASK_TYPES_CATALOG_MERGED.md (T1–T326, Templates 1–66)
# Status: FLOW-22 NEW ARTIFACTS ONLY

---

## SAVE POINT: FLOW22:TASK_TYPES:START
## Entering task types: T327 (next after T326 — Form Tenant Provision Gate)

---

## NEW ARCHETYPES (FLOW-22)

| Archetype | Description | Task Types |
|-----------|-------------|------------|
| IMPACT_ANALYSIS | Extract, classify, and score proposed change impact | T327, T328, T329, T330, T331 |
| ARBITRATION | Orchestrate human-in-loop decision lifecycle | T333, T335, T336 |
| GOVERNANCE | Enforce platform-level policies and audit | T337, T338, T339, T340 |
| BLAST_RADIUS | Calculate transitive dependency impact | T332 |

---

## ENGINE CONTRACTS (T327–T340)

---

### TASK TYPE: T327 — Proposed Change Intake Gate
```
ARCHETYPE:          INGESTION
ENTRY:              Fires on proposed change submission (entity/schema/flow/code change)
PURPOSE:            Parse raw change payload, normalize to canonical ProposedChange document,
                    persist immutably, emit parsed.change event to arbitration pipeline
DISTINCT FROM:      T308 (Form Submission Intake) — this is engine-level, not form-level
FACTORY DEPS:       F901:IProposedChangeParserService
                    F907:IChangeDocumentPersistenceService
FABRIC RESOLUTION:  F901 → DATABASE FABRIC (Skill 05 → Elasticsearch — diff normalization)
                    F907 → DATABASE FABRIC (Skill 05 → PostgreSQL — immutable change store)
AF CONFIGURATION:
  AF-1 Genesis:     Generates IProposedChangeParserService per supported diff_format
  AF-7 Compliance:  Validates DNA-1 (Dictionary, not typed ProposedChange class)
  AF-9 Judge:       Checks: canonical change doc has required fields (change_type, diff, actor, tenant_id)
BFA VALIDATION:     CF-402: change_type must be one of: ENTITY_SCHEMA | FLOW_DAG | API_CONTRACT | CODE_AST
                    CF-403: proposed_change_id must be globally unique (UUID v4)
MACHINE/FREEDOM:
  MACHINE:          4 supported change types (fixed). Immutability of persisted record.
  FREEDOM:          Supported diff formats per change_type (admin-configurable)
IRON RULES:
  IR-327-1: ProposedChange document MUST be persisted to PG BEFORE any downstream event is emitted
  IR-327-2: diff_blob_ref MUST be content-addressed (sha256 hash) — no mutable blob references
  IR-327-3: actor field MUST be validated against auth context (from MicroserviceBase)
QUALITY GATES (AF-9):
  - canonical change doc validates against JSON schema
  - diff_format is one of the supported set
  - immutable PG record written successfully
  - parsed.change event emitted to QUEUE FABRIC
```

---

### TASK TYPE: T328 — Dependency Index Query Gate
```
ARCHETYPE:          IMPACT_ANALYSIS
ENTRY:              Fires after parsed.change event; reads from bfa_dependency_index
PURPOSE:            Query dependency index for all flows/entities/APIs that overlap with
                    the extracted entity/API references in the proposed change.
                    Returns blast radius candidate set (not yet validated for true conflict).
DISTINCT FROM:      T108 (Search & Discovery — entity search); this is BFA-internal governance
FACTORY DEPS:       F902:IEntityReferenceExtractorService
                    F903:IApiSurfaceExtractorService
                    F908:IDependencyIndexQueryService
FABRIC RESOLUTION:  F902 → DATABASE FABRIC (Skill 05 → Elasticsearch)
                    F903 → DATABASE FABRIC (Skill 05 → Elasticsearch)
                    F908 → DATABASE FABRIC (Skill 05 → Elasticsearch → bfa_dependency_index)
AF CONFIGURATION:
  AF-2 Planning:    Decomposes extraction into entity refs + API surface refs in parallel
  AF-4 RAG:         Searches SK-201, SK-202 for entity extraction patterns
  AF-7 Compliance:  Validates BuildSearchFilter usage (DNA-2: empty field skipping)
  AF-9 Judge:       Validates blast radius candidate set is non-null (even if empty = no conflict)
BFA VALIDATION:     CF-404: dependency_index MUST be current (last updated < flow_registry last publish)
                    CF-405: tenant_id MUST be present on all index queries (Scope Isolation)
MACHINE/FREEDOM:
  MACHINE:          Entity/API reference extraction logic (deterministic)
  FREEDOM:          Max blast radius candidate set size (default: 500, admin-configurable)
IRON RULES:
  IR-328-1: Every ES query MUST include tenantId filter (DNA-5 Scope Isolation)
  IR-328-2: BuildSearchFilter MUST skip empty entity_class and empty access_type fields (DNA-2)
  IR-328-3: Empty blast radius candidate set = NONE severity path; MUST NOT escalate further
QUALITY GATES (AF-9):
  - entity references extracted for all supported change types
  - dependency index queried with tenantId scope
  - blast radius candidate set written to session state (F917)
  - candidate set size within FREEDOM config limit
```

---

### TASK TYPE: T329 — Static Conflict Detection Gate
```
ARCHETYPE:          IMPACT_ANALYSIS
ENTRY:              Fires after blast radius candidate set is ready
PURPOSE:            Apply deterministic CF rules against extracted entity references and
                    blast radius candidates. Classify each candidate as: TRUE_CONFLICT |
                    ADDITIVE_ONLY | NO_CONFLICT. No AI involved — 100% repeatable.
DISTINCT FROM:      T330 (Semantic Analysis — AI-powered, advisory); T329 is deterministic and primary
FACTORY DEPS:       F909:IStaticConflictRulesEngineService
                    F910:IBlastRadiusCalculatorService
                    F911:IBreakingChangeValidatorService
                    F905:ISchemaDiffClassifierService
                    F906:IStateTransitionAnalyzerService
FABRIC RESOLUTION:  F909 → DATABASE FABRIC (Skill 05 → Elasticsearch — bfa_rules_index)
                    F910 → DATABASE FABRIC (Skill 05 → Elasticsearch — multi-hop graph traversal)
                    F911 → DATABASE FABRIC (Skill 05 → Elasticsearch — live flow definitions)
                    F905 → DATABASE FABRIC (Skill 05 → Elasticsearch — schema version history)
                    F906 → DATABASE FABRIC (Skill 05 → Elasticsearch — flow state machine specs)
AF CONFIGURATION:
  AF-1 Genesis:     Generates IStaticConflictRulesEngineService with current CF rule set
  AF-4 RAG:         Searches SK-203 (StaticConflictDetector patterns)
  AF-7 Compliance:  Validates no typed conflict models (DNA-1)
  AF-9 Judge:       Validates: every blast radius candidate has explicit TRUE_CONFLICT | NO_CONFLICT classification
BFA VALIDATION:     CF-406: schema field removal classified as BREAKING before validation step
                    CF-407: state transition removal classified as BREAKING before validation step
                    CF-408: static conflict result MUST reference specific CF rule that triggered it
MACHINE/FREEDOM:
  MACHINE:          Classification logic (BREAKING/ADDITIVE/COMPATIBLE) — fixed CF rules
  FREEDOM:          Severity overrides for specific entity classes (admin-configurable)
IRON RULES:
  IR-329-1: Static conflict detection MUST complete before AI semantic analysis begins (T329 → T330 ordering)
  IR-329-2: If any static result = CRITICAL, arbitration MUST proceed to PENDING_RESOLUTION
             regardless of AI advisory result
  IR-329-3: Every conflict result MUST cite the specific CF rule(s) that triggered it
QUALITY GATES (AF-9):
  - all blast radius candidates classified
  - CRITICAL findings cite CF rule number
  - transitive impact calculated (min 1 hop, max = FREEDOM config)
  - schema diff classification completed for ENTITY_SCHEMA change type
```

---

### TASK TYPE: T330 — Semantic Impact Analysis Gate
```
ARCHETYPE:          IMPACT_ANALYSIS
ENTRY:              Fires after static conflict detection completes (T329 result = non-NONE)
PURPOSE:            Send context bundle + proposed change to AiDispatcher for parallel
                    multi-model semantic analysis. Detect hidden business logic conflicts
                    not caught by static rules. Output must validate against ImpactReport schema.
DISTINCT FROM:      T329 (Static Detection — deterministic); T330 is advisory AI analysis
FACTORY DEPS:       F912:ISemanticConflictAnalyzerService
                    F913:ISemanticOutputValidatorService
                    F923:IFlowRegistryReaderService
                    F924:ISchemaRegistryReaderService
                    F925:IDocumentationVectorSearchService
                    F927:IBFAContextBundlerService
FABRIC RESOLUTION:  F912 → AI ENGINE FABRIC (Skill 07 → AiDispatcher → Claude/OpenAI/Gemini parallel)
                    F913 → DATABASE FABRIC (Skill 05 → Elasticsearch — ImpactReport JSON schema)
                    F923 → DATABASE FABRIC (Skill 05 → Elasticsearch — flow registry)
                    F924 → DATABASE FABRIC (Skill 05 → Elasticsearch — schema registry)
                    F925 → RAG FABRIC (Skill 00b → IRagService → Hybrid strategy)
                    F927 → DATABASE FABRIC (Skill 05 → Elasticsearch — context bundle cache)
AF CONFIGURATION:
  AF-3 Prompt:      Retrieves BFA arbiter system prompt from prompt library
                    "You are a Business Logic Arbiter. Proposed change: {diff}. Context: {bundle}.
                     Detect logical collisions, broken dependencies, invalid state changes.
                     Output ONLY valid ImpactReport JSON."
  AF-5 Multi-model: Runs Claude + OpenAI + Gemini in parallel; AiDispatcher aggregates
  AF-6 Code Review: Validates semantic output is not hallucinated (evidence links must be real)
  AF-10 Merge:      Merges multi-model outputs; consensus-based severity scoring
  AF-11 Feedback:   Stores generation quality score for retrospective review (F944)
  AF-9 Judge:       Validates ImpactReport JSON schema compliance + evidence link presence
BFA VALIDATION:     CF-409: semantic analysis MUST only run after static detection (T329) completes
                    CF-410: AI output without evidence links = LOW severity maximum (no HIGH/CRITICAL from AI alone)
                    CF-411: context bundle MUST include at least 1 impacted flow definition
MACHINE/FREEDOM:
  MACHINE:          ImpactReport JSON schema (output contract — fixed)
  FREEDOM:          AI model selection and weights (admin-configures provider priority)
  FREEDOM:          Max context bundle size tokens (default: 100k, admin-configurable)
IRON RULES:
  IR-330-1: AI output MUST validate against ImpactReport JSON schema before acceptance
  IR-330-2: Semantic analysis result is ADVISORY; static gate (T329) CRITICAL takes precedence
  IR-330-3: If 2/3 models agree on severity level, that severity is accepted; otherwise → LOW
  IR-330-4: AI analysis MUST NOT access live production databases directly
             (context bundle is the only input — no direct DB calls from AI fabric)
QUALITY GATES (AF-9):
  - ImpactReport JSON schema validation passed
  - multi-model consensus reached (2/3 models)
  - evidence links present for any HIGH/CRITICAL AI finding
  - context bundle was complete (all 4 context categories: flows, schemas, docs, design records)
```

---

### TASK TYPE: T331 — Conflict Severity Classification Gate
```
ARCHETYPE:          IMPACT_ANALYSIS
ENTRY:              Fires after T329 (static) and T330 (semantic) both complete
PURPOSE:            Aggregate static + AI results into single composite severity.
                    Apply severity escalation rules. Final severity determines arbitration path.
DISTINCT FROM:      T329/T330 (individual analysis steps); T331 is the aggregation step
FACTORY DEPS:       F914:ISeverityAggregatorService
                    F915:IConflictReportAssemblerService
FABRIC RESOLUTION:  F914 → DATABASE FABRIC (Skill 05 → Elasticsearch — severity rules config)
                    F915 → DATABASE FABRIC (Skill 05 → PostgreSQL — conflict report store)
AF CONFIGURATION:
  AF-9 Judge:       Validates composite severity is one of: CRITICAL|HIGH|MEDIUM|LOW|NONE
                    NONE → skip arbitration, publish directly
                    CRITICAL → mandatory PENDING_RESOLUTION (no auto-proceed)
BFA VALIDATION:     CF-412: CRITICAL composite severity MUST block publish until resolution
                    CF-413: NONE composite severity MUST unblock publish path immediately
MACHINE/FREEDOM:
  MACHINE:          CRITICAL always blocks (non-negotiable)
  FREEDOM:          HIGH/MEDIUM/LOW block vs warn-only (per-tenant FREEDOM config via F938)
IRON RULES:
  IR-331-1: Composite severity CRITICAL → state machine MUST transition to PENDING_RESOLUTION
  IR-331-2: Composite severity NONE → state machine MUST skip arbitration, proceed to publish
  IR-331-3: ConflictReport document MUST be persisted to PG before state transition event
QUALITY GATES (AF-9):
  - composite severity is one of 5 valid values
  - ConflictReport persisted to PG with all required fields
  - severity escalation rules applied from FREEDOM config (not hardcoded)
```

---

### TASK TYPE: T332 — Blast Radius Calculation Gate
```
ARCHETYPE:          BLAST_RADIUS
ENTRY:              Fires in parallel with T329/T330 (can run concurrently)
PURPOSE:            Calculate transitive dependency impact: direct flows + flows that depend
                    on those flows (up to N hops, FREEDOM config). Produces blast_radius_report:
                    { direct_impacts, transitive_impacts, total_unique_flows, max_hop_reached }
DISTINCT FROM:      T328 (direct dependency query); T332 traverses the full dependency graph
FACTORY DEPS:       F910:IBlastRadiusCalculatorService
FABRIC RESOLUTION:  F910 → DATABASE FABRIC (Skill 05 → Elasticsearch — graph traversal)
AF CONFIGURATION:
  AF-2 Planning:    Plans traversal strategy (BFS vs DFS) based on graph density
  AF-9 Judge:       Validates blast radius report includes hop count and total unique flows
BFA VALIDATION:     CF-414: blast radius traversal depth MUST respect FREEDOM config max (default: 3)
                    CF-415: circular dependency detection MUST be implemented (visited set)
MACHINE/FREEDOM:
  MACHINE:          Circular dependency detection (fixed — prevents infinite loops)
  FREEDOM:          Max traversal depth (default: 3), max unique flows threshold (default: 1000)
IRON RULES:
  IR-332-1: If circular dependency detected, log and continue (do not throw) — DataProcessResult<T>
  IR-332-2: Blast radius report MUST be attached to ConflictReport before assembly (T331)
QUALITY GATES (AF-9):
  - blast radius report includes direct_impacts count
  - transitive_impacts count
  - circular dependency detection ran
  - hop depth <= FREEDOM config max
```

---

### TASK TYPE: T333 — Arbitration State Machine Gate
```
ARCHETYPE:          ARBITRATION
ENTRY:              Fires on every state transition event from arbitration lifecycle
PURPOSE:            Orchestrate the BFA state machine:
                    IDLE → EXTRACTING → DETECTING → SEVERITY_AGGREGATING →
                    PENDING_RESOLUTION | SKIP_ARBITRATION → APPLYING_RESOLUTION →
                    RESOLVED | REJECTED | ERROR
                    Persist state BEFORE emitting next event (DNA-8 Outbox).
DISTINCT FROM:      T319 (Recipe Trigger Evaluation — FLOW-21); T333 is BFA-specific orchestration
FACTORY DEPS:       F916:IArbitrationStateMachineService
                    F917:IArbitrationSessionPersistenceService
                    F921:IArbitrationTimeoutService
FABRIC RESOLUTION:  F916 → QUEUE FABRIC (Skill 04 → Redis Streams — state transition events)
                    F917 → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_sessions table)
                    F921 → QUEUE FABRIC (Skill 04 → Redis Streams — delayed timeout message)
AF CONFIGURATION:
  AF-1 Genesis:     Generates state machine implementation from state transition spec
  AF-7 Compliance:  Validates DNA-8 (Outbox) pattern on every transition
  AF-9 Judge:       Validates all 8 valid states are reachable; no orphan states
BFA VALIDATION:     CF-416: state MUST be persisted to PG before queue event emitted
                    CF-417: timeout MUST be scheduled on PENDING_RESOLUTION entry (default: 24h)
MACHINE/FREEDOM:
  MACHINE:          8-state machine with fixed valid transitions
  FREEDOM:          Timeout duration (24h default), auto-reject on timeout (enable/disable)
IRON RULES:
  IR-333-1: State machine MUST implement persist-before-emit (DNA-8) on every transition
  IR-333-2: Invalid state transitions MUST return DataProcessResult<T> failure (no throw)
  IR-333-3: Resumable: any session can be rehydrated from last persisted state in < 60s
QUALITY GATES (AF-9):
  - all 8 valid states covered in contract
  - persist-before-emit verified on each transition
  - timeout scheduled correctly
  - recovery test: session rehydration from PG state < 60s
```

---

### TASK TYPE: T334 — Impact Report Generation Gate
```
ARCHETYPE:          SYNTHESIS
ENTRY:              Fires when state = PENDING_RESOLUTION and ConflictReport assembled
PURPOSE:            Generate human-readable structured impact report from ConflictReport document.
                    Report includes: severity badge, impacted flows list with descriptions,
                    blast radius summary, 4-option decision menu, evidence links.
DISTINCT FROM:      T330 (AI semantic analysis); T334 generates the USER-FACING report
FACTORY DEPS:       F930:IImpactReportRendererService
                    F931:IDecisionOptionBuilderService
                    F929:IBFAHistoricalDecisionService
FABRIC RESOLUTION:  F930 → DATABASE FABRIC (Skill 05 → Elasticsearch — impact report templates)
                    F931 → DATABASE FABRIC (Skill 05 → Elasticsearch — resolution option configs)
                    F929 → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_decision_history)
AF CONFIGURATION:
  AF-3 Prompt:      Retrieves impact report rendering prompt (human-readable description of impacts)
  AF-9 Judge:       Validates: report has severity_badge, impacted_flows[] (min 1 if CRITICAL),
                    options[] (exactly 4), evidence_links[] if HIGH/CRITICAL
BFA VALIDATION:     CF-418: FORCE_PROCEED option MUST be hidden unless actor has bfa:override permission
                    CF-419: precedent suggestion shown only if F929 returns 3+ matching precedents
MACHINE/FREEDOM:
  MACHINE:          4 decision options (fixed). Severity badge schema (fixed).
  FREEDOM:          Report template per channel (Web/CLI/Chat — admin-configurable)
                    Precedent suggestion enable/disable (per tenant)
IRON RULES:
  IR-334-1: Report MUST include at least 1 impacted flow for CRITICAL/HIGH severity
  IR-334-2: FORCE_PROCEED option MUST only be rendered for actors with bfa:override permission
  IR-334-3: Evidence links MUST reference real flow/schema document IDs (no fabricated references)
QUALITY GATES (AF-9):
  - report renders in all 3 channels: Web, CLI, Chat
  - FORCE_PROCEED hidden for standard actor
  - FORCE_PROCEED visible for override actor
  - precedent suggestion appears when 3+ matching historical decisions found
```

---

### TASK TYPE: T335 — Human Resolution Capture Gate
```
ARCHETYPE:          ARBITRATION
ENTRY:              Fires when user submits decision (from any channel)
PURPOSE:            Receive and validate user decision. Idempotent capture (SETNX on session_id).
                    Validate decision is one of 4 allowed options. If FORCE_PROCEED,
                    validate elevated permission and mandatory rationale.
                    Emit bfa.decision.captured event to state machine.
DISTINCT FROM:      T322 (Connector Auth Gate — FLOW-21); T335 is BFA decision capture
FACTORY DEPS:       F932:IDecisionCaptureService
                    F919:IUserDecisionReceiverService
FABRIC RESOLUTION:  F932 → QUEUE FABRIC (Skill 04 → Redis Streams — decision captured event)
                    F919 → QUEUE FABRIC (Skill 04 → Redis Streams — decision receiver)
AF CONFIGURATION:
  AF-7 Compliance:  Validates DNA-7 (Idempotency) — SETNX on session_id
  AF-8 Security:    Validates actor permission for FORCE_PROCEED
  AF-9 Judge:       Validates decision is one of 4 valid options + rationale present for FORCE_PROCEED
BFA VALIDATION:     CF-420: decision MUST be one of: REFACTOR_FLOWS | REJECT_CHANGE | COMPAT_MODE | FORCE_PROCEED
                    CF-421: FORCE_PROCEED MUST have rationale (min 50 chars) — IR-336-1
                    CF-422: duplicate decision submission for same session = idempotent no-op (not error)
MACHINE/FREEDOM:
  MACHINE:          4 valid decision options (fixed). Idempotency SETNX (fixed).
  FREEDOM:          Rationale minimum length (default: 50 chars, admin-configurable)
IRON RULES:
  IR-335-1: SETNX on session_id MUST prevent duplicate decision processing (DNA-7)
  IR-335-2: FORCE_PROCEED without rationale MUST return DataProcessResult failure (CF-421)
  IR-335-3: Actor identity MUST be re-validated against auth context (not cached from report rendering)
QUALITY GATES (AF-9):
  - idempotency tested: duplicate submission returns success with existing decision
  - FORCE_PROCEED blocked without rationale
  - FORCE_PROCEED blocked without bfa:override permission
  - decision event emitted to state machine after capture
```

---

### TASK TYPE: T336 — Resolution Application Gate
```
ARCHETYPE:          ARBITRATION
ENTRY:              Fires when bfa.decision.captured event received by state machine
PURPOSE:            Apply the user's decision:
                    REFACTOR_FLOWS → queue refactor tasks for affected flows (via FlowOrchestrator)
                    REJECT_CHANGE → mark proposed change rejected, unblock original publish flow
                    COMPAT_MODE → register compat wrapper, mark fields obsolete, set sunset date
                    FORCE_PROCEED → log privileged override to F943, proceed with publish
DISTINCT FROM:      T320 (Recipe Step Execution — FLOW-21); T336 is BFA resolution application
FACTORY DEPS:       F920:IResolutionApplierService
                    F934:IAutoRefactorCoordinatorService
                    F935:ICompatibilityWrapperService
                    F943:IForceOverrideTrackerService
FABRIC RESOLUTION:  F920 → FLOW ENGINE FABRIC (Skill 09 → FlowOrchestrator)
                    F934 → FLOW ENGINE FABRIC (Skill 09 → FlowOrchestrator — refactor sub-flow)
                    F935 → DATABASE FABRIC (Skill 05 → Elasticsearch — bfa_compat_registry)
                    F943 → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_override_log)
AF CONFIGURATION:
  AF-1 Genesis:     Generates resolution application service from decision schema
  AF-8 Security:    Double-validates FORCE_PROCEED actor permission at application time
  AF-9 Judge:       Validates correct resolution path executed per decision type
BFA VALIDATION:     CF-423: FORCE_PROCEED MUST write to bfa_override_log before publish unblocks
                    CF-424: REFACTOR_FLOWS MUST queue refactor tasks before state transitions to RESOLVED
                    CF-425: COMPAT_MODE MUST write compat wrapper to bfa_compat_registry with sunset_date
MACHINE/FREEDOM:
  MACHINE:          4-path resolution logic (fixed per decision type)
  FREEDOM:          Compat mode sunset period (default: 90 days, admin-configurable per entity)
IRON RULES:
  IR-336-1: FORCE_PROCEED without rationale in override log = BUILD FAILURE
  IR-336-2: All 4 resolution paths MUST complete before state transitions to RESOLVED/REJECTED
  IR-336-3: REFACTOR_FLOWS must handle partial failure gracefully (some flows refactored, some not)
             → DataProcessResult with partial success, trigger escalation for failed flows
QUALITY GATES (AF-9):
  - all 4 resolution paths tested independently
  - FORCE_PROCEED writes to override log atomically with publish unblock
  - COMPAT_MODE sunset date set and sunset alert scheduled
  - REFACTOR_FLOWS partial failure handled (DataProcessResult partial success)
```

---

### TASK TYPE: T337 — Decision Audit Trail Gate
```
ARCHETYPE:          GOVERNANCE
ENTRY:              Fires on every arbitration resolution (any decision type)
PURPOSE:            Write immutable audit trail record to both tenant audit log (F940)
                    and global override log if FORCE_PROCEED (F943).
                    Emit compliance event to observability pipeline (F946).
DISTINCT FROM:      T312 (Entry Persistence — FLOW-21); T337 is BFA-specific governance audit
FACTORY DEPS:       F940:IBFATenantAuditTrailService
                    F943:IForceOverrideTrackerService (if FORCE_PROCEED)
                    F946:IBFAOpenTelemetryService
FABRIC RESOLUTION:  F940 → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_tenant_audit_log)
                    F943 → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_override_log)
                    F946 → QUEUE FABRIC (Skill 04 → Redis Streams — telemetry event stream)
AF CONFIGURATION:
  AF-7 Compliance:  Validates DNA-9 (per-field audit logging) for all decision fields
  AF-9 Judge:       Validates audit record contains all required fields
BFA VALIDATION:     CF-426: audit record MUST be written before arbitration session closes
                    CF-427: FORCE_PROCEED audit MUST be written to BOTH tenant log AND global log
MACHINE/FREEDOM:
  MACHINE:          Audit record schema (fixed). Immutability (fixed).
  FREEDOM:          Audit retention period (GDPR-configurable per tenant via F938)
IRON RULES:
  IR-337-1: Audit record MUST be immutable (INSERT-only, no UPDATE/DELETE on audit tables)
  IR-337-2: FORCE_PROCEED MUST appear in both tenant audit log AND global override log
  IR-337-3: Audit record MUST include: session_id, tenant_id, decision, actor, timestamp, rationale, affected_flows[]
QUALITY GATES (AF-9):
  - audit record written to PG successfully
  - FORCE_PROCEED appears in both logs
  - all required fields present
  - telemetry span emitted for end-to-end trace correlation
```

---

### TASK TYPE: T338 — BFA Multi-Tenant Isolation Gate
```
ARCHETYPE:          GOVERNANCE
ENTRY:              Fires on BFA tenant provision request AND as periodic health check
PURPOSE:            Provision BFA capabilities per tenant (F938). Validate that all
                    BFA dependency index queries are tenant-scoped (F939).
                    Periodic health check scans for any unscoped queries.
DISTINCT FROM:      T326 (Form Tenant Provision — FLOW-21); T338 is BFA-specific MT governance
FACTORY DEPS:       F938:IBFATenantProvisionService
                    F939:IBFATenantIsolationValidatorService
                    F936:IBFATenantConflictIndexService
FABRIC RESOLUTION:  F938 → DATABASE FABRIC (Skill 05 → PostgreSQL — bfa_tenant_config)
                    F939 → DATABASE FABRIC (Skill 05 → Elasticsearch — audit log scan)
                    F936 → DATABASE FABRIC (Skill 05 → Elasticsearch — tenant conflict index)
AF CONFIGURATION:
  AF-7 Compliance:  Validates DNA-5 (Scope Isolation) on all tenant-scoped BFA queries
  AF-9 Judge:       Validates tenant provision record complete, isolation validator reports 0 unscoped queries
BFA VALIDATION:     CF-428: tenant provision MUST set severity threshold and resolution channel before BFA enabled
                    CF-429: isolation validator health check MUST run every 15m (configurable)
MACHINE/FREEDOM:
  MACHINE:          tenantId required on all BFA queries (non-negotiable)
  FREEDOM:          BFA enable/disable per tenant, severity threshold, resolution channel
IRON RULES:
  IR-338-1: BFA MUST NOT process arbitration for unconfigured tenant (F938 config required first)
  IR-338-2: Any unscoped query detected by F939 = CRITICAL alert + auto-disable BFA for that query path
QUALITY GATES (AF-9):
  - tenant provision record includes all required config fields
  - isolation validator detects 0 unscoped queries in test scenario
  - health check scheduled and executing
```

---

### TASK TYPE: T339 — Cross-Tenant Conflict Guard Gate
```
ARCHETYPE:          GOVERNANCE
ENTRY:              Fires on platform-level changes affecting shared factory interfaces or global schemas
PURPOSE:            Detect conflicts in shared platform components (factory registries, global
                    event types, platform-level BFA rules) that could affect multiple tenants.
                    Platform admin only. Never exposes per-tenant data.
DISTINCT FROM:      T329 (Static Conflict Detection — tenant-scoped); T339 is platform-level cross-tenant guard
FACTORY DEPS:       F937:ICrossTenantConflictGuardService
FABRIC RESOLUTION:  F937 → DATABASE FABRIC (Skill 05 → Elasticsearch — platform-level conflict index)
AF CONFIGURATION:
  AF-8 Security:    Validates actor has platform_admin role before any cross-tenant analysis
  AF-9 Judge:       Validates no per-tenant data is included in cross-tenant analysis output
BFA VALIDATION:     CF-430: cross-tenant guard analysis output MUST be aggregated (no per-tenant data)
MACHINE/FREEDOM:
  MACHINE:          platform_admin role requirement (non-negotiable)
  FREEDOM:          Platform-level CF rule set (platform admin can add rules, not remove)
IRON RULES:
  IR-339-1: Cross-tenant guard MUST NOT return any tenant-specific data in its output
  IR-339-2: Actor MUST have platform_admin role (checked via MicroserviceBase auth context)
QUALITY GATES (AF-9):
  - output contains only aggregated platform metrics (no tenant-specific rows)
  - platform_admin role validated
```

---

### TASK TYPE: T340 — BFA Analytics Emit Gate
```
ARCHETYPE:          GOVERNANCE
ENTRY:              Fires after every arbitration session closes (RESOLVED/REJECTED/ERROR)
PURPOSE:            Emit analytics events to BFA metrics pipeline:
                    - tenant metrics (F941): arbitration_rate, block_rate, resolution_time
                    - platform metrics (F942): aggregated platform-wide
                    - pattern learning (F945): index resolved decision as learnable pattern
                    - telemetry (F946): emit final span for closed arbitration session
DISTINCT FROM:      T337 (Audit Trail — persistence); T340 is analytics and learning
FACTORY DEPS:       F941:IBFATenantMetricsService
                    F942:IBFAPlatformMetricsService
                    F945:IBFAPatternLearningService
                    F946:IBFAOpenTelemetryService
FABRIC RESOLUTION:  F941 → DATABASE FABRIC (Skill 05 → Elasticsearch — tenant metrics index)
                    F942 → DATABASE FABRIC (Skill 05 → Elasticsearch — platform metrics index)
                    F945 → RAG FABRIC (Skill 00b → IRagService → vector indexing)
                    F946 → QUEUE FABRIC (Skill 04 → Redis Streams — telemetry stream)
AF CONFIGURATION:
  AF-11 Feedback:   Stores analytics data for generation quality improvement (F944)
  AF-9 Judge:       Validates all 4 metric paths executed; no cross-tenant data in tenant metrics
MACHINE/FREEDOM:
  MACHINE:          Metrics schema (fixed)
  FREEDOM:          Aggregation window sizes (1m/1h/1d — admin-configurable per tenant)
IRON RULES:
  IR-340-1: Analytics emit MUST NOT block arbitration session close (async, fire-and-forget acceptable)
  IR-340-2: Tenant metrics MUST be tenant-scoped (tenantId on all index writes)
  IR-340-3: Pattern learning MUST be tenant-scoped (patterns not shared across tenants by default)
QUALITY GATES (AF-9):
  - all 4 metric paths emit successfully
  - tenant metrics contain tenantId
  - telemetry span closed with final state
  - pattern indexed in RAG fabric
```

---

## FLOW TEMPLATES (FLOW-22)

### Template 67: bfa-entity-change-arbitration-v1
```json
{
  "template_id": "67",
  "name": "bfa-entity-change-arbitration-v1",
  "trigger": "proposed_change.entity_schema submitted",
  "description": "Full BFA arbitration pipeline for entity schema changes",
  "flow_definition": {
    "steps": [
      { "id": "s1", "task_type": "T327", "factory": "F901", "fabric": "DATABASE_FABRIC" },
      { "id": "s2", "task_type": "T328", "factory": "F908", "fabric": "DATABASE_FABRIC", "depends_on": ["s1"] },
      { "id": "s3a", "task_type": "T329", "factory": "F909", "fabric": "DATABASE_FABRIC", "depends_on": ["s2"] },
      { "id": "s3b", "task_type": "T332", "factory": "F910", "fabric": "DATABASE_FABRIC", "depends_on": ["s2"], "parallel": true },
      { "id": "s4", "task_type": "T330", "factory": "F912", "fabric": "AI_ENGINE_FABRIC", "depends_on": ["s3a"] },
      { "id": "s5", "task_type": "T331", "factory": "F914", "fabric": "DATABASE_FABRIC", "depends_on": ["s3a", "s4", "s3b"] },
      { "id": "s6", "task_type": "T333", "factory": "F916", "fabric": "QUEUE_FABRIC", "depends_on": ["s5"] },
      { "id": "s7", "task_type": "T334", "factory": "F930", "fabric": "DATABASE_FABRIC", "depends_on": ["s6"], "condition": "severity != NONE" },
      { "id": "s8", "task_type": "T335", "factory": "F932", "fabric": "QUEUE_FABRIC", "depends_on": ["s7"] },
      { "id": "s9", "task_type": "T336", "factory": "F920", "fabric": "FLOW_ENGINE_FABRIC", "depends_on": ["s8"] },
      { "id": "s10", "task_type": "T337", "factory": "F940", "fabric": "DATABASE_FABRIC", "depends_on": ["s9"] },
      { "id": "s11", "task_type": "T340", "factory": "F941", "fabric": "DATABASE_FABRIC", "depends_on": ["s10"] }
    ]
  }
}
```

### Template 68: bfa-flow-publication-gate-v1
```json
{
  "template_id": "68",
  "name": "bfa-flow-publication-gate-v1",
  "trigger": "flow.version.publish requested",
  "description": "BFA gate inserted before flow publication — checks for cross-flow conflicts",
  "flow_definition": {
    "steps": [
      { "id": "s1", "task_type": "T327", "factory": "F901", "fabric": "DATABASE_FABRIC" },
      { "id": "s2", "task_type": "T328", "factory": "F908", "fabric": "DATABASE_FABRIC", "depends_on": ["s1"] },
      { "id": "s3", "task_type": "T329", "factory": "F909", "fabric": "DATABASE_FABRIC", "depends_on": ["s2"] },
      { "id": "s4", "task_type": "T331", "factory": "F914", "fabric": "DATABASE_FABRIC", "depends_on": ["s3"] },
      { "id": "s5", "task_type": "T338", "factory": "F939", "fabric": "DATABASE_FABRIC", "depends_on": ["s4"] },
      { "id": "s6", "task_type": "T333", "factory": "F916", "fabric": "QUEUE_FABRIC", "depends_on": ["s5"],
        "branching": {
          "NONE": "emit flow.publication.approved",
          "CRITICAL|HIGH|MEDIUM|LOW": "continue to T334"
        }
      },
      { "id": "s7", "task_type": "T334", "factory": "F930", "fabric": "DATABASE_FABRIC", "depends_on": ["s6"] },
      { "id": "s8", "task_type": "T335", "factory": "F932", "fabric": "QUEUE_FABRIC", "depends_on": ["s7"] },
      { "id": "s9", "task_type": "T336", "factory": "F920", "fabric": "FLOW_ENGINE_FABRIC", "depends_on": ["s8"] },
      { "id": "s10", "task_type": "T337", "factory": "F940", "fabric": "DATABASE_FABRIC", "depends_on": ["s9"] }
    ]
  }
}
```

### Template 69: bfa-cross-tenant-platform-guard-v1
```json
{
  "template_id": "69",
  "name": "bfa-cross-tenant-platform-guard-v1",
  "trigger": "platform.factory_registry.change proposed (platform_admin)",
  "description": "Platform-level cross-tenant conflict guard for factory registry changes",
  "actor_requirement": "platform_admin role",
  "flow_definition": {
    "steps": [
      { "id": "s1", "task_type": "T327", "factory": "F901", "fabric": "DATABASE_FABRIC" },
      { "id": "s2", "task_type": "T339", "factory": "F937", "fabric": "DATABASE_FABRIC", "depends_on": ["s1"] },
      { "id": "s3", "task_type": "T331", "factory": "F914", "fabric": "DATABASE_FABRIC", "depends_on": ["s2"] },
      { "id": "s4", "task_type": "T333", "factory": "F916", "fabric": "QUEUE_FABRIC", "depends_on": ["s3"] },
      { "id": "s5", "task_type": "T337", "factory": "F940", "fabric": "DATABASE_FABRIC", "depends_on": ["s4"] },
      { "id": "s6", "task_type": "T340", "factory": "F942", "fabric": "DATABASE_FABRIC", "depends_on": ["s5"] }
    ]
  }
}
```

---

## AF STATION MAPPING SUMMARY (FLOW-22)

| AF Station | Role in FLOW-22 |
|------------|----------------|
| AF-1 Genesis | Generates IProposedChangeParserService, IStaticConflictRulesEngineService, IArbitrationStateMachineService from specs |
| AF-2 Planning | Decomposes extraction (entity refs + API surface refs in parallel); plans BFS/DFS traversal |
| AF-3 Prompt | Retrieves BFA arbiter system prompt for T330 semantic analysis |
| AF-4 RAG | Searches SK-201/SK-202 (extraction), SK-203 (static conflict), SK-207 (state machine) patterns |
| AF-5 Multi-model | T330: runs Claude/OpenAI/Gemini in parallel for semantic analysis; consensus scoring |
| AF-6 Code Review | Validates AI output not hallucinated; evidence links real |
| AF-7 Compliance | Validates DNA-1 through DNA-9 on all generated BFA services |
| AF-8 Security | Double-validates FORCE_PROCEED permission at T335 capture AND T336 application |
| AF-9 Judge | Validates iron rules for each of T327-T340; quality gate checklist |
| AF-10 Merge | Merges multi-model semantic analysis outputs (T330); consensus-based severity |
| AF-11 Feedback | Stores arbitration decision quality scores for retrospective improvement (F944) |

---

## SAVE POINT: FLOW22:TASK_TYPES:COMPLETE ✅
## Next: SKILLS_FACTORY_RAG (SK-201–SK-215)
