# XIIGen — FLOW-32 MASTER EXECUTION PLAN
## Flow: First RAG Initialization — Production Bootstrap
## Date: 2026-03-01 | Duration: 4 Weeks
## Objective: Launch production-grade RAG on Day 1 using existing skills, task types, and source docs

---

# SECTION 1 — EXECUTION OVERVIEW

## Guiding Principles
1. **Coverage-first launch** — index highest-impact sources for highest-frequency task types first
2. **Measure from day zero** — evaluation harness and OTel instrumentation before first customer query
3. **Fabric-always** — every service generated goes through fabric interfaces, never direct provider calls
4. **Staged promotion** — GENERATED → INJECTED → MINIMAL → CORE per promotion ladder
5. **Safe fallback** — abstention + citations when confidence below threshold; never hallucinate

---

# SECTION 2 — PHASED EXECUTION PLAN

## WEEK 1 — Foundation (Schema + Index + Ingestion)

### P0 — Schema Registry Initialization (Day 1, ~2h)
**Task Type:** T397  
**Factories:** F1094, F1084, F1085, F1097

**Steps:**
1. AF-1 Genesis generates IMetadataSchemaRegistryService from SK-254 pattern
2. Register skill-metadata.schema.json, task-type-metadata.schema.json, source-metadata.schema.json
3. Register chunk-metadata.schema.json (lineage + semantics + governance + freshness + quality fields)
4. Validate schemas pass AF-7 (DNA patterns), AF-8 (security: tenantId on every field)
5. Store validated schemas in Elasticsearch `rag-schema-registry-{tenantId}` index

**Iron Rules check (AF-9):**
- Schema registry must exist before ANY ingestion begins (CF-511)
- BM25 and vector index must declare same embedding dimension (CF-515)

**Save point:** `rag-schema-registry-v1` index populated. F1094 health check green.

---

### P1 — Cold Start Seeder (Days 1–2, ~4h)
**Task Type:** T396  
**Factories:** F1120, F1121, F1122, F1082, F1075, F1080

**Steps:**
1. Identify high-frequency task types from existing T1–T388 catalog (priority: top-20 by usage)
2. For each priority task type, identify top 3 source documents
3. AF-2 Planning decomposes: source-catalog → seed-queue → ingest → manifest-verify
4. F1121.EnqueueBatchAsync() pushes seed items to Redis Streams queue
5. F1082 orchestrates ingestion pipeline:
   - F1075: Ingest raw document
   - F1076: Chunk (configurable: 512/1024/2048 tokens)
   - F1077: Enrich (title, keywords, doc-type via LLM — AF ENGINE FABRIC)
   - F1078: Embed (generate vectors — AI ENGINE FABRIC → embedding model)
   - F1079: Deduplicate (hash-based exact dedup against existing index)
   - F1080: Record to manifest
6. F1122.ValidateMinimumCoverageAsync() — must hit configured threshold before proceeding

**Freedom config (admin-adjustable):**
- `cold_start.chunk_size_tokens`: 512 | 1024 | 2048
- `cold_start.seed_batch_quota`: max chunks per seed run
- `cold_start.min_coverage_task_types`: minimum % of top-20 task types covered

**Save point:** Manifest index shows seed batch complete. Cold start validator green.

---

### P2 — Production Ingestion Pipeline (Days 3–5, ~8h)
**Task Type:** T389  
**Factories:** F1075–F1082, F1094–F1098

**Steps:**
1. Register all source corpora in F1081.ISourceCatalogService
2. AF-1 Genesis generates full ingestion service per SK-251 pattern
3. Ingestion pipeline per source: chunk → enrich → embed → dedup → persist → manifest
4. F1095 tracks lineage (source_id, document_id, chunk_id, offset, version_hash)
5. F1096 registers freshness TTL per source cadence (hourly/daily/weekly)
6. F1097 propagates ACL labels per tenant access model
7. F1098 enriches chunk metadata (headings path, keywords, confidence score)

**Compliance gates (AF-7):**
- No typed models anywhere (Dictionary<string,object> only — DNA-1)
- No direct ElasticsearchClient import (always IDatabaseService — DNA-4)
- tenantId on every StoreDocument call (DNA-5)

**Save point:** All source corpora ingested. Manifest 100% complete. BM25 + vector indices built.

---

## WEEK 2 — Retrieval Stack (Hybrid + Rerank + Routing)

### P3 — Hybrid Recall Setup (Days 6–7, ~6h)
**Task Type:** T390  
**Factories:** F1083–F1089

**Steps:**
1. AF-1 Genesis generates IHybridRecallService from SK-252 pattern
2. Configure BM25 lexical retrieval on `rag-bm25-{tenantId}` index (F1084)
3. Configure HNSW vector retrieval on `rag-vector-{tenantId}` index (F1085)
4. Implement RRF fusion (k=60 default) in F1086.FuseAsync()
5. Wire F1087 metadata filter: always inject tenantId + ACL labels BEFORE returning results (CF-519)
6. Implement query expansion via F1088.ExpandAsync() — synonym + HyDE via AI ENGINE FABRIC
7. Layer retrieval cache in F1089 with tenantId-scoped keys (CF-516)

**Iron Rules (AF-9):**
- BM25 and vector calls MUST be parallel (Task.WhenAll) — never sequential (ST-314 pattern)
- RRF fusion, NOT raw score averaging
- Security trim (F1087) executes BEFORE results returned to any caller (CF-519)

**Save point:** Hybrid recall service returns results for test queries. RRF verified in eval.

---

### P4 — Neural Rerank & Confidence Gate (Days 8–9, ~4h)
**Task Type:** T392  
**Factories:** F1090–F1093, F1104, F1108

**Steps:**
1. AF-5 Multi-model: run competing reranker models (cross-encoder variants)
2. AF-10 Merge: select winning reranker by AF-9 precision@5 gate
3. Generate INeuralRerankerService (F1090) via SK-253 pattern
4. F1091 enforces latency budget: rerank top-N must complete within 200ms
5. F1092 caches rerank results per {query_hash + tenantId}
6. F1104 computes confidence score: max_rerank_score vs configurable threshold
7. F1108 builds citations list from chunk metadata (source_id, title, offset)

**Freedom config:**
- `rerank.top_n`: 10–50 (default 20)
- `rerank.confidence_threshold`: 0.0–1.0 (default 0.6)
- `rerank.latency_budget_ms`: max 400ms P95

**Save point:** Rerank pipeline integrated. Confidence scores computed. Citations attached.

---

### P5 — Task-Type Router & Query Planner (Days 10–11, ~4h)
**Task Type:** T391  
**Factories:** F1099–F1103

**Steps:**
1. AF-1 Genesis generates ITaskTypeRouterService from SK-255 pattern
2. F1099 classifies incoming query → task type using LLM classifier (AI ENGINE FABRIC)
3. F1100 maps classified task type → preferred skills and source bindings
4. F1101 generates subquery plan for agentic queries (multi-hop decomposition)
5. F1102 selects retrieval strategy per task type (vector-only / hybrid / graph — RAG FABRIC)
6. F1103 handles degraded mode: if router unavailable, apply default strategy + fire alert (CF-517)

**Save point:** Router classifies sample queries correctly (>80% accuracy on golden set).

---

## WEEK 3 — Safety + Evaluation

### P6 — Abstention & Safe Fallback (Days 12–13, ~3h)
**Task Type:** T398  
**Factories:** F1104–F1108

**Steps:**
1. AF-1 Genesis generates IAbstentionPolicyService from SK-256 pattern
2. If F1104 confidence < threshold: F1106 triggers ABSTAIN
3. ABSTAIN response: citations of nearest docs + safe deflection message (NO generated facts)
4. F1105 generates fallback message via AI ENGINE FABRIC (non-factual, hedged)
5. F1107 audits every abstention: reason, confidence score, tenantId, timestamp
6. Iron Rule enforced by AF-9: ABSTAIN response MUST NOT contain any generated factual claims

**Iron Rules:**
- Fallback responses must not be indexed into retrieval corpora (CF-525)
- Every ABSTAIN logged before response emitted (CF-520)

**Save point:** Abstention triggers at correct threshold. Fallback audited. No facts in abstention.

---

### P7 — Retrieval Evaluation Harness (Days 14–16, ~8h)
**Task Types:** T393, T394  
**Factories:** F1109–F1114

**Steps:**
1. AF-1 Genesis generates IEvalDatasetService (F1109), ISyntheticQueryGeneratorService (F1110)
2. Golden set assembly:
   - Import curated {query, expected_chunks, expected_answer} triples from spec
   - Generate synthetic queries per T394: F1110 creates queries from indexed chunks
   - Mark all synthetic with is_synthetic=true (iron rule — ST-312 pattern)
3. Offline eval run (T393):
   - F1111 runs recall pipeline on golden set
   - F1112 computes: precision@5, recall@10, MRR, NDCG
   - Threshold gates: precision@5 ≥ 0.70, recall@10 ≥ 0.80, latency P95 ≤ 800ms
4. F1114 compares new eval run vs baseline — flag regression if delta > 0.05
5. F1113 schedules recurring eval runs (daily baseline, weekly golden refresh)

**Iron Rules:**
- Eval harness uses isolated `rag-eval-{tenantId}` index, NOT production index (CF-521)
- Synthetic queries never promoted to production golden set without human review

**Save point:** Eval harness running. Baseline metrics recorded. Scheduler active.

---

## WEEK 4 — Observability + Canary Launch

### P8 — OTel GenAI Observability (Days 17–18, ~4h)
**Task Type:** T395  
**Factories:** F1115–F1119

**Steps:**
1. Generate IOtelSpanService (F1115) per SK-258 pattern
2. Instrument every fabric call with OTel GenAI semantic conventions:
   - Span: `gen_ai.system`, `gen_ai.request.model`, `gen_ai.usage.input_tokens`, `gen_ai.usage.output_tokens`
   - Span: `rag.retrieval.top_k`, `rag.retrieval.strategy`, `rag.recall.precision_at_5`
3. F1116 emits Prometheus metrics: `rag_retrieval_latency_p95`, `rag_confidence_score`, `rag_abstention_rate`
4. F1117 logs semantic events to Elasticsearch for post-hoc analysis
5. F1118 tracks LLM token costs per tenant, per task type, per skill
6. F1119 fires Redis Streams alerts for: latency breach, precision drop, cost spike, index error

**Freedom config:**
- `observability.retention_days`: log retention
- `observability.cost_alert_threshold_usd`: per-day budget alert
- `observability.latency_p95_ms_threshold`: alert if exceeded

**Save point:** Dashboards showing live metrics. Alerts configured and tested.

---

### P9 — Canary Launch & Promotion (Days 19–21, ~4h)
**Task Types:** T389 (canary phase)  
**Factories:** F1122, F1123

**Steps:**
1. F1122 final validation: all quality gates pass?
   - Coverage: ≥ minimum task types seeded (F1122)
   - Eval: precision@5 ≥ 0.70, recall@10 ≥ 0.80 (F1112)
   - Abstention rate: < configured max (F1107)
   - Latency P95: ≤ 800ms (F1091, F1115)
2. F1123 ICanaryRolloutService executes traffic ramp:
   - 0% → 5% → 25% → 50% → 100% over 5 days
   - Each step: measure precision, recall, latency, cost
   - If any gate breached: automatic rollback + F1119 alert (ST-315 pattern)
3. Rollback procedure always includes F1119.FireAlertAsync() — no silent rollbacks
4. Post-canary: promote generated services to INJECTED stage on promotion ladder

**Iron Rules:**
- Canary MUST NOT start unless F1122 passes (CF-513)
- Every rollback MUST fire alert via F1119 (T389 iron rule)
- Traffic split routing must include tenantId scope (DNA-5)

**Save point:** Full traffic at 100%. All quality gates passing. Services promoted to INJECTED.

---

### P10 — Promotion to MINIMAL/CORE (Days 22–28, ~ongoing)
**Task:** Evaluate generated services for promotion up the ladder

**Promotion criteria:**
| Stage | Requirement |
|-------|-------------|
| INJECTED | AF-7 (DNA compliance) + AF-8 (security scan) pass |
| MINIMAL | 7-day production run, all quality gates sustained |
| CORE | Team review + PR approval + regression test suite passes |

**Families promoted first:** 154 (Ingestion), 155 (Hybrid Recall), 162 (Cold Start)  
**Families promoted later:** 156 (Rerank), 158 (Router), 160 (Eval Harness)  
**OTel (Family 161) and Safety (Family 159):** Fast-track to CORE as infrastructure

---

# SECTION 3 — WEEK-BY-WEEK SUMMARY

| Week | Focus | Key Deliverable | Success Metric |
|------|-------|-----------------|----------------|
| 1 | Foundation | Schema registry + cold start + full ingestion | All sources in manifest. Indices built. |
| 2 | Retrieval | Hybrid recall + rerank + routing | precision@5 ≥ 0.60 (pre-tuning) |
| 3 | Safety + Eval | Abstention gate + eval harness + golden set | precision@5 ≥ 0.70. Eval scheduled. |
| 4 | Launch | OTel + canary ramp to 100% | All quality gates passing at full traffic |

---

# SECTION 4 — QUALITY GATE SUMMARY

| Gate | Metric | Threshold | Owner |
|------|--------|-----------|-------|
| Post-ingestion | Manifest 100% complete | 100% | F1080 |
| Pre-retrieval | Cold start coverage | ≥ configured min | F1122 |
| Retrieval quality | precision@5 | ≥ 0.70 | F1112 + AF-9 |
| Retrieval quality | recall@10 | ≥ 0.80 | F1112 + AF-9 |
| Latency | P95 end-to-end | ≤ 800ms | F1091 + F1115 |
| Safety | Abstention rate | < configured max | F1107 |
| Canary | Per-step precision drop | < 0.05 | F1114 + F1123 |
| Canary | Rollback alerting | 100% (no silent) | F1119 |

---

# SECTION 5 — RISK REGISTER

| Risk | Mitigation | Owner |
|------|------------|-------|
| Embedding model changes break index | Version-gate embedding model (CF-511) | F1094 |
| Cross-tenant data leak via cache | Cache key isolation with tenantId (CF-516) | F1089 |
| RAG index name conflict with FLOW-09 | BFA CF-510 blocks at code-gen time | BFA |
| Canary launches too early | F1122 hard gate before F1123 (CF-513) | F1122 |
| Fallback response indexed as real content | CF-525 blocks at BFA level | BFA |
| Silent canary rollback | T389 iron rule: always fire F1119 alert | AF-9 |
| Cold start chunk quota exceeded | CF-523 + configurable quota | F1121 |

---

# SECTION 6 — DEPENDENCIES ON EXISTING FLOWS

| Dependency | Flow | Factory/Service | Risk if absent |
|------------|------|-----------------|----------------|
| Tenant provisioning | FLOW-15 | F483 (ITenantRegistryService) | Cannot scope indices by tenant |
| Multi-tenant identity | FLOW-15 | F484 (ITenantContextService) | No tenantId available |
| Search index management | FLOW-09 | ES index infrastructure | Index conflicts |
| AI provider | FLOW-13 | F-AI dispatcher | No embedding or enrichment |
| Queue infrastructure | FLOW-04 | F-IQueueService | No async ingestion |

**All FLOW-15, FLOW-09, FLOW-13, FLOW-04 must be deployed before FLOW-32 bootstrap runs.**

---

# SECTION 7 — AF STATION ALLOCATION BY PHASE

| Phase | AF-1 | AF-2 | AF-4 | AF-7 | AF-8 | AF-9 | AF-11 |
|-------|------|------|------|------|------|------|-------|
| P0 Schema | ✓ | — | SK-254 | ✓ | ✓ | coverage gate | ✓ |
| P1 Cold Start | ✓ | ✓ | SK-260 | ✓ | ✓ | manifest gate | ✓ |
| P2 Ingestion | ✓ | ✓ | SK-251 | ✓ | ✓ | — | ✓ |
| P3 Hybrid Recall | ✓ | — | SK-252 | ✓ | ✓ | parallel gate | ✓ |
| P4 Rerank | ✓ | — | SK-253 | ✓ | ✓ | precision@5 gate | ✓ |
| P5 Router | ✓ | — | SK-255 | ✓ | ✓ | degraded-mode gate | ✓ |
| P6 Abstention | ✓ | — | SK-256 | ✓ | ✓ | no-facts gate | ✓ |
| P7 Eval | ✓ | ✓ | SK-257, SK-259 | ✓ | ✓ | precision@5, recall@10 | ✓ |
| P8 OTel | ✓ | — | SK-258 | ✓ | ✓ | — | ✓ |
| P9 Canary | — | — | — | ✓ | ✓ | all gates | ✓ |

---

# SECTION 8 — OUTPUT ARTIFACTS (what the ENGINE produces for FLOW-32)

| Output | Type | Stored in |
|--------|------|-----------|
| rag-bootstrap-v1.json | Flow definition DAG | Elasticsearch flow-definitions index |
| rag-schema-registry-{tenantId} | Config documents | Elasticsearch |
| rag-manifest-{tenantId} | Config documents | Elasticsearch |
| rag-source-catalog-{tenantId} | Config documents | Elasticsearch |
| rag-bm25-{tenantId} | Search index | Elasticsearch |
| rag-vector-{tenantId} | Vector index | Elasticsearch (HNSW) |
| rag-eval-{tenantId} | Eval index | Elasticsearch (isolated) |
| rag-observability-{tenantId} | Log index | Elasticsearch |
| 9 generated service classes | Services | Extending MicroserviceBase, fabric-only |
| BFA registrations | Entity/event/API index | BFA registry (CF-510–CF-525) |
| Freedom config documents | Admin-adjustable values | Elasticsearch freedom-config index |

---

*FLOW-32 MASTER EXECUTION PLAN — Generated 2026-03-01*
*All 7 FLOW-32 documents complete. Next: FLOW-33 starts at F1124 / T399 / CF-526.*
