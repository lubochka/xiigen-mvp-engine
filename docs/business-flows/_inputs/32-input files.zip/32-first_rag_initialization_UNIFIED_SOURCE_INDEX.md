# XIIGen — FLOW-32 UNIFIED SOURCE INDEX
## Flow: First RAG Initialization — Production Bootstrap
## Date: 2026-03-01 | Status: COMPLETE
## Extends: FLOW-01 through FLOW-25 (unchanged)

---

# SECTION 1 — ARTIFACT REGISTRY

## 1.1 Factory Families

| Family | Name | Factories | Task Types | Skills |
|--------|------|-----------|------------|--------|
| 154 | RAG Bootstrap Ingestion Pipeline | F1075–F1082 | T389, T396 | SK-251 |
| 155 | Hybrid Retrieval & RRF Fusion | F1083–F1089 | T390 | SK-252 |
| 156 | Neural Reranking | F1090–F1093 | T392 | SK-253 |
| 157 | RAG Metadata Schema Registry | F1094–F1098 | T389, T394, T397 | SK-254 |
| 158 | Task-Type Routing & Skill Mapping | F1099–F1103 | T391 | SK-255 |
| 159 | Confidence Gating & Fallback | F1104–F1108 | T392, T398 | SK-256 |
| 160 | RAG Evaluation Harness | F1109–F1114 | T393, T394 | SK-257, SK-259 |
| 161 | OTel GenAI Observability | F1115–F1119 | T395 | SK-258 |
| 162 | Cold Start Coverage Seeder | F1120–F1123 | T396 | SK-260 |

---

## 1.2 Factory Index (F1075–F1123)

| Factory | Interface | Family | Task Types | Fabric | Provider |
|---------|-----------|--------|------------|--------|----------|
| F1075 | IDocumentIngestionService | 154 | T389, T396 | DATABASE FABRIC | Elasticsearch |
| F1076 | IChunkingService | 154 | T389 | CORE FABRIC | In-process |
| F1077 | IDocumentEnrichmentService | 154 | T389 | AI ENGINE FABRIC | LLM (Skill 06) |
| F1078 | IEmbeddingService | 154 | T389 | AI ENGINE FABRIC | Embedding model |
| F1079 | IDeduplicationService | 154 | T389 | DATABASE FABRIC | Elasticsearch |
| F1080 | IIngestionManifestService | 154 | T389, T396, T397 | DATABASE FABRIC | Elasticsearch |
| F1081 | ISourceCatalogService | 154 | T389 | DATABASE FABRIC | Elasticsearch |
| F1082 | IIngestionPipelineOrchestrator | 154 | T389, T396 | QUEUE FABRIC + FLOW ENGINE FABRIC | Redis Streams + DAG |
| F1083 | IHybridRecallService | 155 | T390 | RAG FABRIC | Hybrid strategy (Skill 00b) |
| F1084 | IBm25IndexService | 155 | T390, T397 | DATABASE FABRIC | Elasticsearch (BM25) |
| F1085 | IVectorIndexService | 155 | T390, T397 | DATABASE FABRIC | Elasticsearch (HNSW) |
| F1086 | IRrfFusionService | 155 | T390 | CORE FABRIC | In-process |
| F1087 | IMetadataFilterService | 155 | T390 | DATABASE FABRIC | Elasticsearch filter |
| F1088 | IQueryExpansionService | 155 | T390 | AI ENGINE FABRIC | LLM (Skill 06) |
| F1089 | IRetrievalCacheService | 155 | T390 | DATABASE FABRIC | Redis |
| F1090 | INeuralRerankerService | 156 | T392 | AI ENGINE FABRIC | Cross-encoder (Skill 07) |
| F1091 | ILatencyBudgetService | 156 | T392 | CORE FABRIC | In-process |
| F1092 | IRerankCacheService | 156 | T392 | DATABASE FABRIC | Redis |
| F1093 | IRerankScoreExplainerService | 156 | T392 | AI ENGINE FABRIC | LLM (Skill 06) |
| F1094 | IMetadataSchemaRegistryService | 157 | T389, T394, T397 | DATABASE FABRIC | Elasticsearch |
| F1095 | ILineageTrackerService | 157 | T389 | DATABASE FABRIC | Elasticsearch |
| F1096 | IFreshnessTrackerService | 157 | T389 | QUEUE FABRIC | Redis Streams |
| F1097 | IAclPropagationService | 157 | T389, T397 | DATABASE FABRIC | Elasticsearch |
| F1098 | IChunkMetadataEnricherService | 157 | T389 | AI ENGINE FABRIC | LLM (Skill 06) |
| F1099 | ITaskTypeRouterService | 158 | T391 | AI ENGINE FABRIC | LLM classifier (Skill 07) |
| F1100 | ISkillMappingService | 158 | T391 | DATABASE FABRIC | Elasticsearch |
| F1101 | IQueryPlannerService | 158 | T391 | AI ENGINE FABRIC | LLM (Skill 06) |
| F1102 | IRetrievalStrategyService | 158 | T391 | RAG FABRIC | Strategy selection (Skill 00b) |
| F1103 | IRoutingFallbackService | 158 | T391 | DATABASE FABRIC | Elasticsearch |
| F1104 | IConfidenceGateService | 159 | T392, T398 | CORE FABRIC | In-process |
| F1105 | IFallbackGeneratorService | 159 | T398 | AI ENGINE FABRIC | LLM (Skill 06) |
| F1106 | IAbstentionPolicyService | 159 | T398 | CORE FABRIC | In-process |
| F1107 | IFallbackAuditService | 159 | T398 | DATABASE FABRIC | Elasticsearch |
| F1108 | ICitationBuilderService | 159 | T392, T398 | CORE FABRIC | In-process |
| F1109 | IEvalDatasetService | 160 | T393, T394 | DATABASE FABRIC | Elasticsearch |
| F1110 | ISyntheticQueryGeneratorService | 160 | T394 | AI ENGINE FABRIC | LLM (Skill 07) |
| F1111 | IRetrievalEvalRunnerService | 160 | T393 | CORE FABRIC | In-process |
| F1112 | IQualityMetricsService | 160 | T393, T394 | DATABASE FABRIC | Elasticsearch |
| F1113 | IEvalSchedulerService | 160 | T393 | QUEUE FABRIC | Redis Streams |
| F1114 | IEvalComparisonService | 160 | T393 | DATABASE FABRIC | Elasticsearch |
| F1115 | IOtelSpanService | 161 | T395 | CORE FABRIC | OpenTelemetry (in-process) |
| F1116 | IPrometheusMetricsService | 161 | T395 | CORE FABRIC | Prometheus (in-process) |
| F1117 | IGenAiSemanticLogService | 161 | T395 | DATABASE FABRIC | Elasticsearch |
| F1118 | ICostTrackerService | 161 | T395 | DATABASE FABRIC | Elasticsearch |
| F1119 | IObservabilityAlertService | 161 | T395 | QUEUE FABRIC | Redis Streams |
| F1120 | ICoverageSeedService | 162 | T396 | DATABASE FABRIC | Elasticsearch |
| F1121 | ISeedQueueService | 162 | T396 | QUEUE FABRIC | Redis Streams |
| F1122 | IColdStartValidatorService | 162 | T396 | DATABASE FABRIC | Elasticsearch |
| F1123 | ICanaryRolloutService | 162 | T389, T396 | QUEUE FABRIC + DATABASE FABRIC | Redis Streams + Redis |

---

## 1.3 Task Type Index (T389–T398)

| Task Type | Name | Archetype | Factories | Skills | BFA Rules |
|-----------|------|-----------|-----------|--------|-----------|
| T389 | RAG Bootstrap Initialization Gate | ORCHESTRATION | F1075, F1080–F1082, F1094, F1123 | SK-251, SK-260 | CF-510–CF-513 |
| T390 | Hybrid Recall Orchestration | RETRIEVAL | F1083–F1089 | SK-252 | CF-512, CF-515–CF-516 |
| T391 | Task-Type Router & Query Planner | ROUTING | F1099–F1103 | SK-255 | CF-517, CF-511 |
| T392 | Neural Rerank & Confidence Gate | JUDGMENT | F1090–F1093, F1104, F1108 | SK-253, SK-256 | CF-515, CF-518 |
| T393 | Retrieval Eval Runner | EVALUATION | F1109, F1111–F1114 | SK-257, SK-259 | CF-519–CF-521 |
| T394 | Synthetic Query Eval Generator | EVALUATION | F1094, F1109–F1112 | SK-257 | CF-521 |
| T395 | OTel GenAI Observability Emitter | OBSERVABILITY | F1115–F1119 | SK-258 | CF-522, CF-510 |
| T396 | Cold Start Coverage Seeder | INGESTION | F1075, F1080, F1082, F1120–F1123 | SK-260, SK-251 | CF-513, CF-523 |
| T397 | Index Schema Registration | REGISTRY | F1084–F1085, F1094, F1097 | SK-254 | CF-511, CF-515 |
| T398 | Abstention & Safe Fallback Gate | SAFETY | F1104–F1108 | SK-256 | CF-524–CF-525 |

---

## 1.4 Skill Index (SK-251–SK-260)

| Skill | Name | Serves | Fabric Touchpoints |
|-------|------|--------|--------------------|
| SK-251 | RAG Bootstrap & Pipeline Orchestration | T389, T396 | DATABASE + QUEUE + FLOW ENGINE |
| SK-252 | Hybrid Retrieval (BM25 + Vector + RRF) | T390 | RAG + DATABASE |
| SK-253 | Neural Reranking Patterns | T392 | AI ENGINE + DATABASE |
| SK-254 | RAG Metadata Schema Registry | T397 | DATABASE |
| SK-255 | Task-Type Routing & Query Planning | T391 | AI ENGINE + DATABASE + RAG |
| SK-256 | Confidence Gating & Safe Abstention | T392, T398 | CORE + AI ENGINE + DATABASE |
| SK-257 | Retrieval Evaluation Harness | T393, T394 | DATABASE + AI ENGINE + QUEUE |
| SK-258 | OTel GenAI Observability | T395 | CORE (OTel) + DATABASE + QUEUE |
| SK-259 | Golden Set Management & Drift Detection | T393 | DATABASE + QUEUE |
| SK-260 | Cold Start Coverage Seeder | T396 | DATABASE + QUEUE |

---

## 1.5 BFA Conflict Rules (CF-510–CF-525)

| Rule | Description | Severity | Flows Protected |
|------|-------------|----------|-----------------|
| CF-510 | RAG index names must not collide with FLOW-09 search indices | CRITICAL | FLOW-09 |
| CF-511 | Embedding model must be registered before index build | CRITICAL | FLOW-32 internal |
| CF-512 | Tenant provisioning must precede RAG bootstrap | CRITICAL | FLOW-15 |
| CF-513 | Canary ramp requires passing bootstrap validation | CRITICAL | FLOW-32 internal |
| CF-514 | RAG metadata schema must be versioned before source ingestion | HIGH | FLOW-32 internal |
| CF-515 | BM25 and vector indices must share same embedding dimension | CRITICAL | FLOW-32 internal |
| CF-516 | Cache keys must include tenantId (isolation) | CRITICAL | FLOW-15 |
| CF-517 | Routing model unavailability must trigger degraded-mode + alert | HIGH | FLOW-32 internal |
| CF-518 | Rerank must not increase top-K beyond retrieval budget | HIGH | FLOW-32 internal |
| CF-519 | Security trim must execute before results returned to caller | CRITICAL | FLOW-15 |
| CF-520 | Eval audit log must be written before response sent to requester | HIGH | FLOW-32 internal |
| CF-521 | Eval harness must use isolated eval index (not production index) | HIGH | FLOW-32 internal |
| CF-522 | LLM token costs must be tracked in F1118 (not inlined) | MEDIUM | FLOW-13 |
| CF-523 | Cold start seed batch must not exceed configured chunk quota | MEDIUM | FLOW-32 internal |
| CF-524 | Cross-tenant index alias must be blocked at BFA level | CRITICAL | FLOW-15 |
| CF-525 | Fallback responses must not be indexed into retrieval corpora | MEDIUM | FLOW-09 |

---

## 1.6 Stress Tests (ST-300–ST-315)

| Test | Rule Tested | Scenario | Verdict |
|------|-------------|----------|---------|
| ST-300 | CF-513 | Bootstrap launches without validation passing | ✅ PASS |
| ST-301 | CF-510 | RAG index name collides with FLOW-09 production index | ✅ PASS |
| ST-302 | CF-515 | Vector dimension mismatch between BM25 and HNSW index | ✅ PASS |
| ST-303 | CF-516 | Cache key missing tenantId — cross-tenant bleed | ✅ PASS |
| ST-304 | CF-519 | Security trim called after results returned | ✅ PASS |
| ST-305 | CF-520 | Eval audit skipped before response emitted | ✅ PASS |
| ST-306 | CF-513 | Canary ramp starts during partial bootstrap | ✅ PASS |
| ST-307 | CF-524 | Cross-tenant alias accepted without BFA rejection | ✅ PASS |
| ST-308 | CF-521 | Eval runner writes to production index | ✅ PASS |
| ST-309 | CF-522 | LLM cost inlined in response object instead of F1118 | ✅ PASS |
| ST-310 | CF-525 | Fallback response indexed into retrieval corpus | ✅ PASS |
| ST-311 | CF-517 | Router fails silently without degraded-mode alert | ✅ PASS |
| ST-312 | T394 Iron Rule | Synthetic queries lack is_synthetic=true flag | ✅ BUILD FAIL detected |
| ST-313 | T398 Iron Rule | ABSTAIN response contains generated facts | ✅ BUILD FAIL detected |
| ST-314 | T390 Iron Rule | BM25 and vector called sequentially not in parallel | ✅ BUILD FAIL detected |
| ST-315 | T389 Iron Rule | Canary rollback silent — no alert fired | ✅ BUILD FAIL detected |

---

## 1.7 Flow DAG Template

| Template # | Name | Task Types | Stored in |
|------------|------|------------|-----------|
| Template 50 | rag-bootstrap-v1 | T389, T396, T397, T390, T391, T392, T393, T394, T395, T398 | Elasticsearch flow-definitions index |

---

# SECTION 2 — CROSS-REFERENCE MAP

## 2.1 Fabric → Factory → Task Type

| Fabric | Factories | Task Types |
|--------|-----------|------------|
| DATABASE FABRIC (ES) | F1075, F1079–F1081, F1084–F1085, F1087, F1089, F1092, F1094–F1095, F1097, F1100, F1103, F1107, F1109, F1112, F1114, F1117–F1118, F1120, F1122 | All T389–T398 |
| DATABASE FABRIC (Redis cache) | F1089, F1092, F1123 | T390, T392, T389, T396 |
| QUEUE FABRIC (Redis Streams) | F1082, F1096, F1113, F1119, F1121, F1123 | T389, T393, T395, T396 |
| AI ENGINE FABRIC (LLM) | F1077, F1088, F1093, F1098–F1101, F1105, F1110 | T389–T392, T394, T398 |
| AI ENGINE FABRIC (Embedding) | F1078 | T389 |
| AI ENGINE FABRIC (Cross-encoder) | F1090 | T392 |
| RAG FABRIC | F1083, F1102 | T390, T391 |
| CORE FABRIC | F1076, F1086, F1091, F1104, F1106, F1108, F1111, F1115–F1116 | T389–T392, T393, T395, T398 |
| FLOW ENGINE FABRIC | F1082 | T389, T396 |

## 2.2 AF Station → Task Type

| AF Station | Role | Task Types |
|------------|------|------------|
| AF-1 Genesis | Generates service code from engine contracts | T389–T398 |
| AF-2 Planning | Decomposes bootstrap into ordered pipeline steps | T389, T396 |
| AF-3 Prompt Library | Retrieves RAG-domain prompts | T389–T398 |
| AF-4 RAG | Retrieves SK-251–SK-260 patterns | T389–T398 |
| AF-5 Multi-model | Runs competing models for rerank scoring | T392 |
| AF-6 Code review | Reviews generated pipeline code | T389, T390, T396 |
| AF-7 Compliance | Validates DNA patterns 1–9 on all generated code | T389–T398 |
| AF-8 Security | Scans for direct provider imports, bare tenantId leaks | T389–T398 |
| AF-9 Judge | Validates quality gates (precision@K, latency, coverage) | T390, T392, T393 |
| AF-10 Merge | Combines multi-model rerank outputs | T392 |
| AF-11 Feedback | Stores generation quality metrics for improvement | T389–T398 |

## 2.3 Dependency Chain (critical path)

```
T396 (Cold Start Seeder)
  └─► T397 (Index Schema Registration)
        └─► T389 (Bootstrap Init Gate)
              ├─► T390 (Hybrid Recall)
              │     └─► T391 (Router & Query Planner)
              │           └─► T392 (Rerank & Confidence Gate)
              │                 └─► T398 (Abstention & Fallback)
              ├─► T393 (Eval Runner)
              │     └─► T394 (Synthetic Query Generator)
              └─► T395 (OTel Observability Emitter)  [runs parallel]
```

---

# SECTION 3 — SOURCE DOCUMENT TRACEABILITY

| Artifact | Source Specification | Key Section |
|----------|---------------------|-------------|
| F1075–F1082 | 32-first rag initialization.md | §Ingestion pipeline |
| F1083–F1089 | 32-first rag initialization.md | §Two-stage retrieval, Hybrid BM25+vector |
| F1090–F1093 | 32-first rag initialization.md | §Neural reranking of top candidates |
| F1094–F1098 | 32-first rag initialization.md | §Metadata fields that matter in practice |
| F1099–F1103 | 32-first rag initialization.md | §Task types — routing hints |
| F1104–F1108 | 32-first rag initialization.md | §Cold-start coverage-first launch, abstention |
| F1109–F1114 | 32-first rag initialization.md | §Evaluation harness (offline + online) |
| F1115–F1119 | 32-first rag initialization.md | §OpenTelemetry GenAI semantic conventions |
| F1120–F1123 | 32-first rag initialization.md | §Coverage-first launch |
| T389–T398 | ENGINE_ARCHITECTURE_MERGED.md | Task type full engine contract format |
| SK-251–SK-260 | SKILLS_FACTORY_RAG_MERGED.md | Skill pattern structure |
| CF-510–CF-525 | V62_BFA_STRESS_TEST_MERGED.md | BFA conflict rule format |
| Template 50 | ENGINE_ARCHITECTURE_MERGED.md | Flow DAG JSON format |

---

# SECTION 4 — NUMBERS SUMMARY (FLOW-32 ADDITIONS ONLY)

| Artifact Type | Pre-FLOW-32 | FLOW-32 Adds | Post-FLOW-32 |
|---------------|-------------|--------------|---------------|
| Factories | F1–F1074 | F1075–F1123 (49) | F1–F1123 |
| Families | 1–153 | 154–162 (9) | 1–162 |
| Task Types | T1–T388 | T389–T398 (10) | T1–T398 |
| Skills | SK-1–SK-250 | SK-251–SK-260 (10) | SK-1–SK-260 |
| BFA Rules | CF-1–CF-509 | CF-510–CF-525 (16) | CF-1–CF-525 |
| Stress Tests | ST-1–ST-299 | ST-300–ST-315 (16) | ST-1–ST-315 |
| Templates | 1–49 | 50 (1) | 1–50 |

---

# SECTION 5 — BACKWARD COMPATIBILITY DECLARATION

- **F1–F1074**: UNCHANGED
- **T1–T388**: UNCHANGED
- **CF-1–CF-509**: UNCHANGED
- **ST-1–ST-299**: UNCHANGED
- **SK-1–SK-250**: UNCHANGED
- **Templates 1–49**: UNCHANGED
- **FLOW-01 through FLOW-25**: No modification whatsoever
- FLOW-32 is **additive-only**. Zero breaking changes.

---

*FLOW-32 UNIFIED SOURCE INDEX — Generated 2026-03-01*
*Next flow: FLOW-33 starts at F1124 / Family 163 / T399 / CF-526 / ST-316 / SK-261 / Template 51*
