# XIIGen TASK TYPES CATALOG — FLOW-19: Visual Editor Extended
## Delta File — T269–T288 only (20 new task types, 6 new templates)
## Extends: TASK_TYPES_CATALOG_MERGED.md (T1–T268, Templates 1–55)

---

## FLOW-19 TASK TYPE SUMMARY

| Range | Archetype | Domain |
|-------|-----------|--------|
| T269–T273 | TRANSFORMATION | Visual Canvas Core (node tree ops) |
| T274–T277 | ORCHESTRATION | Layout Engine (solver, breakpoints) |
| T278–T281 | INTEGRATION | Data Binding Bridge |
| T282–T284 | GUARDRAIL | Multi-Tenant Hardening |
| T285–T288 | GENERATION | Code Export & Deployment |

---

## TASK TYPE: T269 — Canvas Node Tree Composition Gate

**ARCHETYPE:** TRANSFORMATION
**ENTRY:** Fires when a flow definition targets `CANVAS_NODE_TREE` as output type
**PURPOSE:** Compose, persist, and version a UI node tree (Pages→Sections→Containers→Elements) for a given tenant. Enforces DNA-1 (no typed models) and DNA-5 (scope isolation) on all node documents.
**DISTINCT FROM:** T247 (FLOW-18 visual flow editor — logic nodes, not UI layout nodes)

**FACTORY DEPENDENCIES:** F697, F698, F703, F701 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F697 → DATABASE FABRIC (Skill 05) → Elasticsearch (node tree documents)
- F698 → DATABASE FABRIC (Skill 05) → Redis (hot canvas state)
- F703 → DATABASE FABRIC (Skill 05) → Elasticsearch (layer tree index)
- F701 → DATABASE FABRIC (Skill 05) → PostgreSQL (version history)

**AF CONFIGURATION:**
- AF-2 (Planning): decompose node tree into section/container/element subtasks
- AF-4 (RAG): retrieve SK-161 (NodeTreeService patterns), SK-162 (LayoutSolverService)
- AF-7 (Compliance): verify DNA-1 (Dictionary), DNA-5 (tenantId on every ES query)
- AF-9 (Judge): validate `schemaVersion` present; no `NodeTreeDocument` class; `BuildSearchFilter` used

**BFA VALIDATION:**
- CF-329: check canvas node IDs do not collide with FLOW-02 content node IDs
- CF-330: check `tenantId` scoping does not cross FLOW-01 user registration tenant boundary

**MACHINE (fixed):**
- Node persistence via `StoreDocument(Dictionary<string,object>)` — DNA-1
- `tenantId` always injected into every query — DNA-5
- `schemaVersion` field required on every node document

**FREEDOM (configurable):**
- Default layout mode (FLEX_VERTICAL / GRID / ABSOLUTE) — admin-settable
- Max node depth (default: 10 levels)
- Version retention policy (default: 30 versions)

**IRON RULES:**
1. Node tree documents MUST use `Dictionary<string,object>` — no typed DTOs
2. Every database query MUST include `tenantId` filter — BUILD FAILURE if absent
3. `StoreDocument` return type MUST be `DataProcessResult<T>` — never throw for business logic
4. `ParseDocument` called on every retrieved document — no direct cast

**QUALITY GATES (AF-9):**
- Node tree roundtrip: store → retrieve → validate schema integrity
- Version history: create 3 versions → verify rollback to v1
- Tenant isolation: two tenants → verify zero cross-tenant node visibility

---

## TASK TYPE: T270 — Symbol Library Reuse Gate

**ARCHETYPE:** TRANSFORMATION
**ENTRY:** Fires when a canvas node references a Symbol (reusable section: header, footer, blog card)
**PURPOSE:** Resolve, materialize, and scope symbol instances across the canvas. Symbols are stored once in F699, instantiated per tenant context. Changes to the symbol propagate to all instances.
**DISTINCT FROM:** T269 (raw node tree composition — no symbol resolution)

**FACTORY DEPENDENCIES:** F699, F700, F697, F704 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F699 → DATABASE FABRIC (Skill 05) → Elasticsearch (symbol library index)
- F700 → DATABASE FABRIC (Skill 05) → Elasticsearch (component variants)
- F697 → DATABASE FABRIC (Skill 05) → Elasticsearch (node tree, materialized instances)
- F704 → QUEUE FABRIC (Skill 04) → Redis Streams (symbol update propagation events)

**AF CONFIGURATION:**
- AF-4 (RAG): SK-161 (NodeTree patterns), SK-163 (ComponentConstraintService)
- AF-7 (Compliance): DNA-1, DNA-5 scoping on symbol library queries
- AF-9 (Judge): symbol instance count consistency; propagation event verified

**BFA VALIDATION:**
- CF-331: symbol names must not conflict with FLOW-02 content template names
- CF-332: symbol update events via F704 must not collide with FLOW-04 notification events on same Redis Stream group

**MACHINE:** Symbol definition → instance materialization → propagation via Queue Fabric
**FREEDOM:** Symbol scope (global / tenant / project); propagation delay (sync/async)

**IRON RULES:**
1. Symbol definitions stored as `Dictionary<string,object>` — DNA-1
2. Symbol instances carry `symbolId` + `tenantId` + `instanceId` — DNA-5
3. Propagation MUST go through QUEUE FABRIC — never direct HTTP push to canvas clients
4. `DataProcessResult<T>` on all symbol resolve operations

**QUALITY GATES (AF-9):**
- Update symbol → verify all instances receive propagation event within SLA
- Tenant isolation: Symbol from Tenant A not visible to Tenant B
- Variant resolution: 3 variants (featured/compact/hero) correctly resolved

---

## TASK TYPE: T271 — UI Layout Composition Gate

**ARCHETYPE:** TRANSFORMATION
**ENTRY:** Fires after T269 completes node tree; layout solver calculates bounding boxes, alignment candidates, and Flex/Grid constraints
**PURPOSE:** Deterministically resolve layout for a node tree given its `layoutMode`, padding, gap, and children constraints. Output is a resolved layout document stored back via DATABASE FABRIC.
**DISTINCT FROM:** T269 (persistence), T272 (breakpoint responsive overrides)

**FACTORY DEPENDENCIES:** F705, F708, F709, F710 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F705 → CORE FABRIC (Skill 01) → MicroserviceBase (pure layout computation)
- F708 → CORE FABRIC (Skill 01) → MicroserviceBase (alignment math)
- F709 → DATABASE FABRIC (Skill 05) → Elasticsearch (constraint documents)
- F710 → CORE FABRIC (Skill 01) → MicroserviceBase (snap guide calculation)

**AF CONFIGURATION:**
- AF-2 (Planning): decompose node tree into layout subtasks per container level
- AF-4 (RAG): SK-162 (LayoutSolverService patterns)
- AF-7 (Compliance): DNA-3 (DataProcessResult); DNA-4 (MicroserviceBase)
- AF-9 (Judge): layout idempotency; constraint evaluation correctness

**BFA VALIDATION:**
- CF-333: layout solver output doc IDs must not overwrite FLOW-09 search result documents
- CF-334: snap guide events must not collide with FLOW-12 chat event stream keys

**MACHINE:** Flex/Grid layout math is deterministic — fixed algorithm
**FREEDOM:** Snap threshold (px), grid column defaults, alignment snap tolerance

**IRON RULES:**
1. Layout solver MUST extend MicroserviceBase — no standalone class
2. Layout result MUST be `DataProcessResult<Dictionary<string,object>>`
3. Constraint evaluation fetched via F709 (DATABASE FABRIC) — no hardcoded constraint map
4. `BuildSearchFilter` used with `tenantId` + `nodeId` — DNA-2 + DNA-5

**QUALITY GATES (AF-9):**
- Flex container with 5 children → correct bounding box calculation
- Constraint `lockLayout:true` → layout changes rejected by evaluator
- Snap guide: two nodes within threshold → snap transform applied

---

## TASK TYPE: T272 — Responsive Breakpoint Override Gate

**ARCHETYPE:** TRANSFORMATION
**ENTRY:** Fires when a designer switches breakpoint mode or when layout solver completes (T271)
**PURPOSE:** Apply per-breakpoint style patches on top of base node styles. Stores base style + override patches. Rendering picks correct patch at runtime. AI-assisted override suggestion via F706.
**DISTINCT FROM:** T271 (base layout solver, no breakpoint awareness)

**FACTORY DEPENDENCIES:** F706, F707, F705 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F706 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (AI responsive suggestions)
- F707 → DATABASE FABRIC (Skill 05) → Elasticsearch (breakpoint patch documents)
- F705 → CORE FABRIC (Skill 01) → MicroserviceBase (base layout reference)

**AF CONFIGURATION:**
- AF-5 (Multi-model): AI models compete on best responsive layout suggestion for each breakpoint
- AF-9 (Judge): verify patch application order; verify base + patch = valid merged style
- AF-11 (Feedback): store model quality scores for responsive suggestion per breakpoint scenario

**BFA VALIDATION:**
- CF-335: breakpoint patch documents must not conflict with FLOW-13 AI content pipeline style documents

**MACHINE:** Base style + patch merge algorithm is deterministic
**FREEDOM:** Breakpoint definitions (desktop/tablet/mobile or custom px values); AI suggestion acceptance threshold

**IRON RULES:**
1. Breakpoint patches stored as `Dictionary<string,object>` — DNA-1
2. Patch document MUST carry `tenantId` + `nodeId` + `breakpoint` key — DNA-5
3. AI suggestion is advisory — human or AF-9 approval required before storing
4. Merging base + patch MUST return `DataProcessResult<T>`

**QUALITY GATES (AF-9):**
- Desktop → tablet → mobile: correct patch applied per breakpoint
- AI suggestion score ≥ 0.7 for acceptance threshold
- Invalid patch (removes required field) → rejected by constraint evaluator

---

## TASK TYPE: T273 — Canvas Version Control Gate

**ARCHETYPE:** ORCHESTRATION
**ENTRY:** Fires on canvas save, publish, or rollback command
**PURPOSE:** Manage canvas version history. Store immutable version snapshots in PostgreSQL via F701. Support rollback to any version. Diff between versions. Tag versions for publishing.
**DISTINCT FROM:** T269 (write path), T270 (symbol propagation — separate versioning concern)

**FACTORY DEPENDENCIES:** F701, F697, F704 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F701 → DATABASE FABRIC (Skill 05) → PostgreSQL (version history — ACID transactions)
- F697 → DATABASE FABRIC (Skill 05) → Elasticsearch (node tree current state)
- F704 → QUEUE FABRIC (Skill 04) → Redis Streams (version change events)

**AF CONFIGURATION:**
- AF-7 (Compliance): DNA-5 tenant scoping on all version queries
- AF-9 (Judge): version immutability; rollback correctness; diff accuracy

**BFA VALIDATION:**
- CF-336: version IDs must not collide with FLOW-18 flow version IDs

**MACHINE:** Version snapshot is immutable once created
**FREEDOM:** Max version retention count; auto-tag on publish

**IRON RULES:**
1. Version documents stored in PostgreSQL via DATABASE FABRIC — never direct Postgres import
2. Rollback MUST be atomic — `DataProcessResult<T>` wraps the transaction
3. Version event published to QUEUE FABRIC after commit — not before

**QUALITY GATES (AF-9):**
- Create 5 versions → rollback to v2 → verify canvas state matches v2 snapshot
- Version event arrives in Redis Streams within 500ms of commit

---

## TASK TYPE: T274 — Multi-Model Layout Advisor Gate

**ARCHETYPE:** ORCHESTRATION
**ENTRY:** Fires when designer requests AI layout advice or when F706 generates responsive suggestions
**PURPOSE:** Run competing AI models (Claude, OpenAI, Gemini) to suggest optimal layout configurations. AF-10 merges outputs. AF-9 judges against design token constraints and iron rules.
**DISTINCT FROM:** T272 (applies a specific breakpoint patch), T271 (deterministic layout solver — no AI)

**FACTORY DEPENDENCIES:** F706, F729, F714 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F706 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (multi-model orchestration)
- F729 → DATABASE FABRIC (Skill 05) → Elasticsearch (design token constraints)
- F714 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (content fallback generation)

**AF CONFIGURATION:**
- AF-5 (Multi-model): 3+ models run in parallel on layout suggestion prompt
- AF-10 (Merge): aggregate layout suggestions; pick highest-scoring per quality criteria
- AF-9 (Judge): verify suggested layout respects `lockLayout` constraints and design token bounds
- AF-11 (Feedback): store winning model + score for layout advisory quality improvement

**BFA VALIDATION:**
- CF-337: AI layout advisor output must not inject new factory dependencies not in F697–F733

**MACHINE:** Model selection, parallel run, merge algorithm
**FREEDOM:** Model set (which AI providers compete), scoring weights, acceptance threshold

**IRON RULES:**
1. AI models called via `IAiProvider.GenerateAsync()` — never `openai.chat()` directly
2. Layout suggestion output stored as `Dictionary<string,object>` — DNA-1
3. Suggestions treated as FREEDOM layer (advisory) — designer confirmation required for MACHINE changes

**QUALITY GATES (AF-9):**
- 3 models produce suggestions → AF-10 merges → score ≥ 0.7 layout accepted
- Model producing layout violating `lockLayout` constraint → rejected by AF-9

---

## TASK TYPE: T275 — Design Token Synchronization Gate

**ARCHETYPE:** TRANSFORMATION
**ENTRY:** Fires when global design tokens (colors, fonts, spacing, radii) are updated by admin
**PURPOSE:** Propagate updated design tokens to all canvas nodes, component variants, and running applications via F729. Ensures token changes are reflected without code deployment.
**DISTINCT FROM:** T271 (layout solver uses tokens, does not update them)

**FACTORY DEPENDENCIES:** F729, F700, F704, F697 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F729 → DATABASE FABRIC (Skill 05) → Elasticsearch (design token index)
- F700 → DATABASE FABRIC (Skill 05) → Elasticsearch (component variants that reference tokens)
- F704 → QUEUE FABRIC (Skill 04) → Redis Streams (token update events)
- F697 → DATABASE FABRIC (Skill 05) → Elasticsearch (node tree token reference update)

**AF CONFIGURATION:**
- AF-7 (Compliance): DNA-2 (BuildSearchFilter for empty token fields skipped); DNA-5 tenant scope
- AF-9 (Judge): verify token propagation completeness — all nodes referencing changed token updated

**BFA VALIDATION:**
- CF-338: token update events on F704 must not collide with FLOW-13 AI content style events

**MACHINE:** Token document schema; propagation event format
**FREEDOM:** Token inheritance rules (component overrides global); propagation scope (global/tenant/project)

**IRON RULES:**
1. Token documents stored as `Dictionary<string,object>` — DNA-1
2. Token propagation MUST go through QUEUE FABRIC (F704) — never direct HTTP sync
3. `BuildSearchFilter` used for token queries — skips empty token fields — DNA-2

**QUALITY GATES (AF-9):**
- Update primary color token → verify 100% of referencing nodes receive update event
- Component override token takes precedence over global token

---

## TASK TYPE: T276 — Alignment and Snapping Validation Gate

**ARCHETYPE:** GUARDRAIL
**ENTRY:** Fires during interactive canvas editing when nodes are moved or resized
**PURPOSE:** Real-time calculation of smart guides, edge/center snapping candidates, and distribution alignment. Ensures design consistency without locking the designer into rigid grids.
**DISTINCT FROM:** T271 (full layout solve — expensive), T276 is lightweight real-time guardrail

**FACTORY DEPENDENCIES:** F708, F710, F711 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F708 → CORE FABRIC (Skill 01) → MicroserviceBase (alignment math — pure computation)
- F710 → CORE FABRIC (Skill 01) → MicroserviceBase (snap guide calculation)
- F711 → DATABASE FABRIC (Skill 05) → Redis (z-index state — hot path)

**AF CONFIGURATION:**
- AF-9 (Judge): snap guide accuracy; z-index conflict detection

**BFA VALIDATION:**
- CF-339: z-index updates in F711 must not collide with FLOW-18 layer ordering documents

**MACHINE:** Snap threshold math; bounding box intersection detection
**FREEDOM:** Snap threshold (px); guide color; snap-to-grid vs snap-to-element toggle

**IRON RULES:**
1. Snap calculation MUST return `DataProcessResult<T>` — never throw on near-miss
2. Z-index operations via F711 (Redis via DATABASE FABRIC) — never direct Redis import

**QUALITY GATES (AF-9):**
- Node within 4px of another node's edge → snap guide displayed, transform applied
- Z-index conflict (two nodes same z-index in same container) → warning emitted, not error

---

## TASK TYPE: T277 — Constraint Enforcement Gate

**ARCHETYPE:** GUARDRAIL
**ENTRY:** Fires before any node property update when `constraints.lockLayout` or role restrictions apply
**PURPOSE:** Enforce designer/editor role boundary. If `lockLayout:true`, reject layout changes from content-editor role. If `allowContentEdit:true`, allow text/image edits regardless of lock status.
**DISTINCT FROM:** T276 (visual snapping — no permission check), T282 (tenant-level isolation)

**FACTORY DEPENDENCIES:** F709, F719 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F709 → DATABASE FABRIC (Skill 05) → Elasticsearch (constraint documents per node)
- F719 → CORE FABRIC (Skill 01) → MicroserviceBase (tenant isolation enforcer — role context)

**AF CONFIGURATION:**
- AF-8 (Security): verify constraint enforcement not bypassable via API
- AF-9 (Judge): role boundary validation; constraint document integrity

**BFA VALIDATION:**
- CF-340: constraint rules must not conflict with FLOW-01 permission model for user roles

**MACHINE:** `lockLayout` → reject layout change; `allowContentEdit` → allow text/image
**FREEDOM:** Role names (designer/editor/admin) — configurable via FREEDOM layer; constraint inheritance (parent → child)

**IRON RULES:**
1. Constraint evaluation MUST happen before every write — never post-hoc
2. Role context from F719 (MicroserviceBase auth context) — never from request body
3. Constraint violation returns `DataProcessResult.Failure` — never throws

**QUALITY GATES (AF-9):**
- Editor role + `lockLayout:true` → padding change rejected
- Editor role + `allowContentEdit:true` → text change accepted
- Designer role + any constraint → all changes accepted

---

## TASK TYPE: T278 — CMS Data Binding Gate

**ARCHETYPE:** INTEGRATION
**ENTRY:** Fires when a node has `bindings` properties referencing CMS fields (e.g., `$.skill_05.latest_post.title`)
**PURPOSE:** Resolve binding paths to actual CMS content records via DATABASE FABRIC. Populate node with live data. Handle missing/null fields via F714 fallback.
**DISTINCT FROM:** T273 (canvas versioning), T280 (repeater loop execution)

**FACTORY DEPENDENCIES:** F712, F714, F718, F717 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F712 → DATABASE FABRIC (Skill 05) → Elasticsearch (CMS content documents)
- F714 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (AI fallback content generation)
- F718 → CORE FABRIC (Skill 01) → MicroserviceBase (field formatting: date, clamp, truncate)
- F717 → RAG FABRIC (Skill 00b) → Hybrid strategy (binding validation patterns)

**AF CONFIGURATION:**
- AF-4 (RAG): SK-164 (DataBindingBridgeService patterns) via F717
- AF-7 (Compliance): DNA-1, DNA-5; binding paths must carry tenantId context
- AF-9 (Judge): field resolution accuracy; fallback trigger conditions; format correctness

**BFA VALIDATION:**
- CF-341: CMS binding queries via F712 must not conflict with FLOW-02 content management queries on same ES index
- CF-342: AI fallback via F714 must not collide with FLOW-13 AI content pipeline jobs

**MACHINE:** JSONPath binding resolution algorithm; null field → trigger fallback
**FREEDOM:** Fallback strategy (AI/static/empty); field format rules (date locale, clamp length); null handling policy

**IRON RULES:**
1. Binding resolution MUST use `SearchDocuments` via F712 DATABASE FABRIC — no direct ES query
2. Missing CMS field → F714 AI fallback or configured static fallback — never raw null in rendered output
3. All field formatting via F718 `DataProcessResult<T>` — no format exceptions propagate to canvas
4. Binding document carries `tenantId` — DNA-5

**QUALITY GATES (AF-9):**
- Post with 200-char title → clamp applied correctly
- Missing `coverImage` field → AI fallback or placeholder rendered
- Two tenants: binding resolves to own-tenant content only

---

## TASK TYPE: T279 — Template Mode Preview Gate

**ARCHETYPE:** INTEGRATION
**ENTRY:** Fires when designer activates "Template Mode" on a page template
**PURPOSE:** Switch canvas context from static design to live content preview. Fetch real content records via F713. Bind to page template. Preview with multiple content records (short/long titles, missing cover). Exit preview returns to design state.
**DISTINCT FROM:** T278 (runtime binding at render time), T279 is design-time preview only

**FACTORY DEPENDENCIES:** F713, F712, F716, F698 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F713 → DATABASE FABRIC (Skill 05) → Elasticsearch (template mode context documents)
- F712 → DATABASE FABRIC (Skill 05) → Elasticsearch (real content records)
- F716 → QUEUE FABRIC (Skill 04) → Redis Streams (data context propagation to canvas clients)
- F698 → DATABASE FABRIC (Skill 05) → Redis (canvas hot state — preview mode flag)

**AF CONFIGURATION:**
- AF-4 (RAG): SK-165 (BreakpointResolverService) for responsive preview
- AF-9 (Judge): preview mode does not mutate production canvas state

**BFA VALIDATION:**
- CF-343: template mode preview context must not write to FLOW-02 production content indices

**MACHINE:** Preview reads real content; writes are session-isolated, not persisted to production
**FREEDOM:** Sample content set (latest/random/specific record); number of preview records

**IRON RULES:**
1. Template Mode is READ-ONLY against production content — no write via F712 in preview mode
2. Preview state stored in Redis hot state (F698) — isolated from production canvas state (F697 ES)
3. Canvas clients notified of mode change via QUEUE FABRIC (F716) — never direct WebSocket call

**QUALITY GATES (AF-9):**
- Preview 10 posts with varying title lengths → layout holds for all
- Exit preview → canvas returns exactly to pre-preview design state
- Preview does not modify F712 content documents

---

## TASK TYPE: T280 — Repeater Loop Execution Gate

**ARCHETYPE:** TRANSFORMATION
**ENTRY:** Fires when a canvas section has `type: REPEATER` with a content query binding
**PURPOSE:** Execute the repeater block: run content query via F715, paginate results, render card template for each item, handle empty-state rendering.
**DISTINCT FROM:** T278 (single-field binding), T279 (template preview — no pagination logic)

**FACTORY DEPENDENCIES:** F715, F712, F716, F718 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F715 → DATABASE FABRIC (Skill 05) → Elasticsearch (repeater content queries with pagination)
- F712 → DATABASE FABRIC (Skill 05) → Elasticsearch (content records per item)
- F716 → QUEUE FABRIC (Skill 04) → Redis Streams (rendered item events)
- F718 → CORE FABRIC (Skill 01) → MicroserviceBase (field formatting per item)

**AF CONFIGURATION:**
- AF-2 (Planning): decompose repeater into pagination steps
- AF-7 (Compliance): DNA-2 (BuildSearchFilter for query — empty fields skipped); DNA-5 tenant scope
- AF-9 (Judge): pagination consistency; empty-state handling; total count accuracy

**BFA VALIDATION:**
- CF-344: repeater query via F715 must not conflict with FLOW-09 search discovery queries on same ES index

**MACHINE:** Query → paginate → render card → next page loop
**FREEDOM:** Page size; sort order; filter fields; empty-state template

**IRON RULES:**
1. Repeater queries use `BuildSearchFilter` — empty filter fields auto-skipped — DNA-2
2. Rendered items carry `tenantId` — DNA-5
3. Pagination cursor stored as `DataProcessResult<T>` — no exception on last page

**QUALITY GATES (AF-9):**
- 50 content items, page size 10 → 5 pages rendered correctly
- Zero items → empty-state template rendered (not null/error)
- Tenant A repeater never returns Tenant B items

---

## TASK TYPE: T281 — Binding Validation Gate

**ARCHETYPE:** GUARDRAIL
**ENTRY:** Fires before a binding path is saved to a node document
**PURPOSE:** Validate binding paths (`$.skill_XX.field`) against known skill output schemas via RAG FABRIC. Prevent broken bindings from reaching production canvas.
**DISTINCT FROM:** T278 (runtime resolution), T281 is pre-save validation guardrail

**FACTORY DEPENDENCIES:** F717, F712 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F717 → RAG FABRIC (Skill 00b) → Hybrid strategy (skill schema validation patterns)
- F712 → DATABASE FABRIC (Skill 05) → Elasticsearch (binding validation against live CMS schema)

**AF CONFIGURATION:**
- AF-4 (RAG): SK-171 (FlowStateMachineService — binding state transitions)
- AF-9 (Judge): binding path validity; schema compatibility

**BFA VALIDATION:**
- CF-345: binding validator must recognize all skill output paths from FLOW-01–FLOW-18

**MACHINE:** JSONPath syntax validation; skill output schema registry
**FREEDOM:** Strict vs lenient binding validation; unknown skill warnings vs errors

**IRON RULES:**
1. Invalid binding path → `DataProcessResult.Failure` with clear error — never silent null
2. Validation uses RAG FABRIC — never hardcoded skill schema map

**QUALITY GATES (AF-9):**
- Valid path `$.skill_05.post.title` → accepted
- Invalid path `$.skill_99.nonexistent.field` → rejected with descriptive error
- Cross-tenant binding attempt → rejected

---

## TASK TYPE: T282 — Tenant Isolation Enforcement Gate

**ARCHETYPE:** GUARDRAIL
**ENTRY:** Fires at the start of EVERY canvas operation (before T269–T281)
**PURPOSE:** Enforce tenant boundary on all canvas operations. Validate `tenantId` in request context matches authenticated user's tenant. Block cross-tenant access. Enforce quota limits.
**DISTINCT FROM:** T277 (role/constraint enforcement within a tenant), T282 is cross-tenant boundary

**FACTORY DEPENDENCIES:** F719, F720, F722 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F719 → CORE FABRIC (Skill 01) → MicroserviceBase (auth context, tenantId extraction)
- F720 → DATABASE FABRIC (Skill 05) → Redis (quota counters — rate limit hot path)
- F722 → DATABASE FABRIC (Skill 05) → Redis (idempotency store)

**AF CONFIGURATION:**
- AF-8 (Security): OWASP API1 (BOLA/IDOR) check; OWASP API4 (quota abuse) check
- AF-9 (Judge): zero cross-tenant leakage; quota enforcement accuracy

**BFA VALIDATION:**
- CF-346: tenant isolation gate must precede ALL FLOW-19 task type executions
- CF-347: quota limits must not conflict with FLOW-15 DevOps quotas on same tenant

**MACHINE:** tenantId validation; quota check; idempotency key deduplication
**FREEDOM:** Quota limits per tenant tier (pool/silo/bridge); idempotency TTL

**IRON RULES:**
1. Missing or mismatched `tenantId` → immediate `DataProcessResult.Failure` — BUILD FAILURE
2. Quota exceeded → `DataProcessResult.Failure(QuotaExceeded)` — never silent pass
3. Duplicate idempotency key → return cached result — never re-execute side effect

**QUALITY GATES (AF-9):**
- Tenant A token → cannot access Tenant B canvas node
- Quota at limit → next request rejected with quota error
- Duplicate `Idempotency-Key` → returns first result, no duplicate stored

---

## TASK TYPE: T283 — CloudEvents Envelope Gate

**ARCHETYPE:** GUARDRAIL
**ENTRY:** Fires before any inter-service canvas event is published to QUEUE FABRIC
**PURPOSE:** Wrap all canvas async events in CloudEvents envelope with `tenantId`, `specversion`, `type`, `source`, `id`, and `time` attributes. Enforce deduplication via idempotency store.
**DISTINCT FROM:** T282 (synchronous isolation check), T283 wraps async events

**FACTORY DEPENDENCIES:** F721, F722, F704 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F721 → QUEUE FABRIC (Skill 04) → Redis Streams (CloudEvents envelope publisher)
- F722 → DATABASE FABRIC (Skill 05) → Redis (idempotency deduplication store)
- F704 → QUEUE FABRIC (Skill 04) → Redis Streams (canvas event bus)

**AF CONFIGURATION:**
- AF-8 (Security): verify CloudEvents envelope integrity; `tenantId` extension attribute present
- AF-9 (Judge): envelope schema validity; dedupe correctness

**BFA VALIDATION:**
- CF-348: CloudEvents from canvas must use distinct `source` prefix from FLOW-15 DevOps events

**MACHINE:** CloudEvents v1.0 envelope schema; deduplication on `id` + `tenantId`
**FREEDOM:** Event retention TTL; dead-letter queue behavior

**IRON RULES:**
1. Every canvas async event MUST carry CloudEvents envelope — no raw queue messages
2. `tenantId` MUST be a CloudEvents extension attribute — never in payload only
3. Duplicate event `id` + `tenantId` → acknowledged without re-processing — idempotent

**QUALITY GATES (AF-9):**
- 1000 events published → zero missing `tenantId` extension attributes
- Duplicate event ID → deduplicated; consumer receives exactly once

---

## TASK TYPE: T284 — Tenant Tiering & Restore Gate

**ARCHETYPE:** ORCHESTRATION
**ENTRY:** Fires when tenant tier graduation criteria met or restore request received
**PURPOSE:** Graduate tenant from shared schema (pool) → separate schema (bridge) → separate database (silo). Execute tenant-scoped restore from PITR snapshot. Verify RLS policies post-migration.
**DISTINCT FROM:** T282 (runtime isolation check), T284 is infrastructure-level tier migration

**FACTORY DEPENDENCIES:** F723, F725, F726 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F723 → DATABASE FABRIC (Skill 05) → PostgreSQL (tenant tier registry — ACID migrations)
- F725 → DATABASE FABRIC (Skill 05) → PostgreSQL (PITR restore operations)
- F726 → CORE FABRIC (Skill 01) → MicroserviceBase (OTLP telemetry on migration events)

**AF CONFIGURATION:**
- AF-9 (Judge): post-migration isolation verification; RLS policy correctness; restore completeness

**BFA VALIDATION:**
- CF-346: tier migration must not disrupt active canvas operations on same tenant
- CF-347: restore point must not overwrite FLOW-18 visual flow definitions in same DB

**MACHINE:** Migration steps are atomic (ACID); rollback plan defined before execution
**FREEDOM:** Graduation criteria (compliance, SLA, workload intensity); restore RPO/RTO targets

**IRON RULES:**
1. Migration MUST be atomic — `DataProcessResult<T>` wraps full migration transaction
2. No migration without verified backup snapshot
3. Post-migration RLS policy verification MUST pass before tenant resumes operations

**QUALITY GATES (AF-9):**
- Pool → bridge migration: zero cross-tenant data exposure post-migration
- Restore to T-24h: canvas state matches snapshot; no data newer than restore point

---

## TASK TYPE: T285 — UI Code Export Gate

**ARCHETYPE:** GENERATION
**ENTRY:** Fires when designer triggers "Export to Code" from canvas
**PURPOSE:** Transform node tree into production-ready frontend code using AiDispatcher multi-model consensus. Output: React/Tailwind, Angular, or Vue — configurable via FREEDOM layer. AF-6 code review + AF-7 DNA compliance check before export.
**DISTINCT FROM:** T274 (layout advisor — suggestions), T285 generates deployable code

**FACTORY DEPENDENCIES:** F727, F728, F730, F731 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F727 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (multi-model code generation)
- F728 → AI ENGINE FABRIC (Skill 06) → IAiProvider (framework-specific adapter)
- F730 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (AF-6 code review + AF-9 quality gate)
- F731 → DATABASE FABRIC (Skill 05) → Elasticsearch (artifact registry — generated code versions)

**AF CONFIGURATION:**
- AF-1 (Genesis): generate code from node tree spec
- AF-5 (Multi-model): 3 models compete on framework output quality
- AF-6 (Code Review): automated review of generated code
- AF-7 (Compliance): DNA-1/3/4 compliance on generated service code
- AF-9 (Judge): validate generated code compiles; no direct provider imports; MicroserviceBase extended
- AF-10 (Merge): combine best-scoring code segments per AF-9
- AF-11 (Feedback): store generation quality for improvement

**BFA VALIDATION:**
- CF-348: generated artifact IDs must not collide with FLOW-18 code injection artifacts

**MACHINE:** Code generation pipeline (AF-1 → AF-5 → AF-6 → AF-7 → AF-9 → AF-10)
**FREEDOM:** Target framework (React/Angular/Vue); styling system (Tailwind/CSS Modules/SCSS); export format (component/page/full-app)

**IRON RULES:**
1. Generated service code MUST extend MicroserviceBase — DNA-4
2. No direct framework imports hardcoded — F728 framework adapter resolves via config
3. Generated code stored in artifact registry (F731) via DATABASE FABRIC — never on filesystem
4. AF-9 quality gate MUST PASS before export available to designer

**QUALITY GATES (AF-9):**
- Generated code compiles without errors
- No typed models in generated service layer — `Dictionary<string,object>` only
- MicroserviceBase extended in all service classes
- AF-9 quality score ≥ 0.8 before export enabled

---

## TASK TYPE: T286 — Design Token Export Gate

**ARCHETYPE:** GENERATION
**ENTRY:** Fires alongside T285 or when admin triggers "Sync Design Tokens to Production"
**PURPOSE:** Export design tokens (colors, fonts, spacing, radii, shadows) from Elasticsearch index (F729) to framework-specific token files (CSS custom properties, Tailwind config, style-dictionary JSON). Sync to running applications without code deploy.
**DISTINCT FROM:** T275 (canvas-internal token propagation), T286 targets external code/app output

**FACTORY DEPENDENCIES:** F729, F728, F732 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F729 → DATABASE FABRIC (Skill 05) → Elasticsearch (design token source of truth)
- F728 → AI ENGINE FABRIC (Skill 06) → IAiProvider (framework adapter for token format conversion)
- F732 → QUEUE FABRIC (Skill 04) → Redis Streams (deployment pipeline dispatch)

**AF CONFIGURATION:**
- AF-7 (Compliance): token document DNA-1 compliance; tenant scope
- AF-9 (Judge): token export completeness; no platform-specific values hardcoded

**BFA VALIDATION:**
- CF-338: token sync events on F732 must not collide with FLOW-15 DevOps deployment events

**MACHINE:** Token source → format converter → deployment pipeline dispatch
**FREEDOM:** Target format (CSS vars/Tailwind/style-dictionary); deployment trigger (manual/auto on token change)

**IRON RULES:**
1. Token export MUST use F729 (DATABASE FABRIC) as source — never hardcoded token values
2. Deployment dispatch via F732 (QUEUE FABRIC) — never direct HTTP to CI/CD

**QUALITY GATES (AF-9):**
- All 50 design tokens exported correctly to CSS custom properties
- Token update in ES → deployment event dispatched within 2 seconds

---

## TASK TYPE: T287 — Artifact Registry & Rollback Gate

**ARCHETYPE:** ORCHESTRATION
**ENTRY:** Fires after T285 export completes or on rollback request
**PURPOSE:** Manage versioned artifact registry (F731) for all exported code. Support rollback to previous export version. Diff between artifact versions.
**DISTINCT FROM:** T273 (canvas design version control), T287 manages generated code artifact versions

**FACTORY DEPENDENCIES:** F731, F733, F732 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F731 → DATABASE FABRIC (Skill 05) → Elasticsearch (artifact registry index)
- F733 → DATABASE FABRIC (Skill 05) → PostgreSQL (rollback transaction — ACID)
- F732 → QUEUE FABRIC (Skill 04) → Redis Streams (deployment pipeline events)

**AF CONFIGURATION:**
- AF-9 (Judge): rollback completeness; artifact integrity; deployment event correctness

**BFA VALIDATION:**
- CF-348: artifact IDs must not conflict with FLOW-18 injection artifacts

**MACHINE:** Artifact immutability; rollback is atomic PostgreSQL transaction
**FREEDOM:** Artifact retention count; auto-rollback trigger conditions

**IRON RULES:**
1. Artifacts stored as `Dictionary<string,object>` in Elasticsearch — DNA-1
2. Rollback MUST be atomic via F733 (PostgreSQL via DATABASE FABRIC)
3. Post-rollback deployment event dispatched via QUEUE FABRIC

**QUALITY GATES (AF-9):**
- Store 3 artifact versions → rollback to v1 → deployment event dispatched
- Artifact integrity hash verified before rollback executed

---

## TASK TYPE: T288 — Full Visual Editor Flow DAG Execution Gate

**ARCHETYPE:** ORCHESTRATION
**ENTRY:** Fires when the FlowOrchestrator (Skill 09) executes a FLOW-19 flow definition
**PURPOSE:** Orchestrate the full Visual Editor flow: T282 (tenant isolation) → T269 (node tree) → T271 (layout) → T272 (breakpoints) → T278 (data binding) → T277 (constraints) → T285 (code export) → T287 (artifact registry). State machine: Designing → Review → Published.
**DISTINCT FROM:** All individual task types above (T288 orchestrates them as a complete DAG)

**FACTORY DEPENDENCIES:** F697, F705, F712, F719, F727, F701 — resolved via `CreateAsync()`

**FABRIC RESOLUTION:**
- F697 → DATABASE FABRIC (Skill 05) → Elasticsearch (node tree state)
- F705 → CORE FABRIC (Skill 01) → MicroserviceBase (layout solver)
- F712 → DATABASE FABRIC (Skill 05) → Elasticsearch (CMS data binding)
- F719 → CORE FABRIC (Skill 01) → MicroserviceBase (tenant isolation)
- F727 → AI ENGINE FABRIC (Skill 07) → AiDispatcher (code export)
- F701 → DATABASE FABRIC (Skill 05) → PostgreSQL (flow state machine — version/publish)

**AF CONFIGURATION:**
- AF-2 (Planning): decompose full canvas flow into DAG steps
- AF-4 (RAG): all SK-161–SK-172 patterns available
- AF-9 (Judge): full flow execution completeness; state machine transition correctness
- AF-11 (Feedback): store full flow generation quality score

**BFA VALIDATION:**
- CF-329 through CF-348: all FLOW-19 conflict rules checked before DAG execution
- FLOW-01–FLOW-18 backward compatibility verified

**MACHINE:** DAG step order; state machine transitions (Designing→Review→Published)
**FREEDOM:** State machine guard conditions; publish approval workflow (auto/manual)

**IRON RULES:**
1. T282 (tenant isolation) MUST be first step — BUILD FAILURE if skipped
2. T285 (code export) MUST pass AF-9 before state machine advances to Published
3. All intermediate step results wrapped in `DataProcessResult<T>`
4. Full DAG stored as flow-definition JSON in Elasticsearch via FlowOrchestrator (Skill 09)

**QUALITY GATES (AF-9):**
- Full flow execution: Designing → Review → Published in under 60 seconds for typical canvas
- T282 failure → entire DAG aborts (no partial canvas corruption)
- Published canvas: generated code artifact stored + deployment event dispatched

---

## FLOW TEMPLATES — FLOW-19

### Template 56: Simple Blog Page Canvas
```json
{
  "templateId": 56,
  "name": "Simple Blog Page Canvas",
  "flowType": "VISUAL_CANVAS",
  "steps": [
    { "stepId": 1, "taskType": "T282", "factory": "F719", "fabric": "CORE" },
    { "stepId": 2, "taskType": "T269", "factory": "F697", "fabric": "DATABASE_ES" },
    { "stepId": 3, "taskType": "T271", "factory": "F705", "fabric": "CORE" },
    { "stepId": 4, "taskType": "T278", "factory": "F712", "fabric": "DATABASE_ES" },
    { "stepId": 5, "taskType": "T277", "factory": "F709", "fabric": "DATABASE_ES" }
  ],
  "stateMachine": { "states": ["Designing","Review","Published"], "initial": "Designing" }
}
```

### Template 57: Blog Card Component with Variants
```json
{
  "templateId": 57,
  "name": "Blog Card Component with Variants",
  "flowType": "VISUAL_CANVAS",
  "steps": [
    { "stepId": 1, "taskType": "T282", "factory": "F719", "fabric": "CORE" },
    { "stepId": 2, "taskType": "T269", "factory": "F697", "fabric": "DATABASE_ES" },
    { "stepId": 3, "taskType": "T270", "factory": "F699", "fabric": "DATABASE_ES" },
    { "stepId": 4, "taskType": "T278", "factory": "F712", "fabric": "DATABASE_ES" },
    { "stepId": 5, "taskType": "T280", "factory": "F715", "fabric": "DATABASE_ES" }
  ],
  "stateMachine": { "states": ["Designing","Published"], "initial": "Designing" }
}
```

### Template 58: Responsive Multi-Breakpoint Layout
```json
{
  "templateId": 58,
  "name": "Responsive Multi-Breakpoint Layout",
  "flowType": "VISUAL_CANVAS",
  "steps": [
    { "stepId": 1, "taskType": "T282", "factory": "F719", "fabric": "CORE" },
    { "stepId": 2, "taskType": "T269", "factory": "F697", "fabric": "DATABASE_ES" },
    { "stepId": 3, "taskType": "T271", "factory": "F705", "fabric": "CORE" },
    { "stepId": 4, "taskType": "T272", "factory": "F706", "fabric": "AI_ENGINE" },
    { "stepId": 5, "taskType": "T274", "factory": "F706", "fabric": "AI_ENGINE" }
  ],
  "stateMachine": { "states": ["Designing","Review","Published"], "initial": "Designing" }
}
```

### Template 59: AI-Assisted Layout + Code Export
```json
{
  "templateId": 59,
  "name": "AI-Assisted Layout + Code Export",
  "flowType": "VISUAL_CANVAS_EXPORT",
  "steps": [
    { "stepId": 1, "taskType": "T282", "factory": "F719", "fabric": "CORE" },
    { "stepId": 2, "taskType": "T269", "factory": "F697", "fabric": "DATABASE_ES" },
    { "stepId": 3, "taskType": "T271", "factory": "F705", "fabric": "CORE" },
    { "stepId": 4, "taskType": "T274", "factory": "F706", "fabric": "AI_ENGINE" },
    { "stepId": 5, "taskType": "T285", "factory": "F727", "fabric": "AI_ENGINE" },
    { "stepId": 6, "taskType": "T287", "factory": "F731", "fabric": "DATABASE_ES" }
  ],
  "stateMachine": { "states": ["Designing","CodeReview","Exported"], "initial": "Designing" }
}
```

### Template 60: Multi-Tenant Enterprise Canvas
```json
{
  "templateId": 60,
  "name": "Multi-Tenant Enterprise Canvas",
  "flowType": "VISUAL_CANVAS_ENTERPRISE",
  "steps": [
    { "stepId": 1, "taskType": "T282", "factory": "F719", "fabric": "CORE" },
    { "stepId": 2, "taskType": "T283", "factory": "F721", "fabric": "QUEUE" },
    { "stepId": 3, "taskType": "T284", "factory": "F723", "fabric": "DATABASE_PG" },
    { "stepId": 4, "taskType": "T269", "factory": "F697", "fabric": "DATABASE_ES" },
    { "stepId": 5, "taskType": "T271", "factory": "F705", "fabric": "CORE" },
    { "stepId": 6, "taskType": "T278", "factory": "F712", "fabric": "DATABASE_ES" }
  ],
  "stateMachine": { "states": ["Provisioning","Designing","Review","Published"], "initial": "Provisioning" }
}
```

### Template 61: Full Visual Editor Flow (T288 DAG)
```json
{
  "templateId": 61,
  "name": "Full Visual Editor Flow",
  "flowType": "VISUAL_CANVAS_FULL",
  "steps": [
    { "stepId": 1,  "taskType": "T282", "factory": "F719", "fabric": "CORE" },
    { "stepId": 2,  "taskType": "T283", "factory": "F721", "fabric": "QUEUE" },
    { "stepId": 3,  "taskType": "T269", "factory": "F697", "fabric": "DATABASE_ES" },
    { "stepId": 4,  "taskType": "T270", "factory": "F699", "fabric": "DATABASE_ES" },
    { "stepId": 5,  "taskType": "T271", "factory": "F705", "fabric": "CORE" },
    { "stepId": 6,  "taskType": "T272", "factory": "F706", "fabric": "AI_ENGINE" },
    { "stepId": 7,  "taskType": "T275", "factory": "F729", "fabric": "DATABASE_ES" },
    { "stepId": 8,  "taskType": "T277", "factory": "F709", "fabric": "DATABASE_ES" },
    { "stepId": 9,  "taskType": "T278", "factory": "F712", "fabric": "DATABASE_ES" },
    { "stepId": 10, "taskType": "T280", "factory": "F715", "fabric": "DATABASE_ES" },
    { "stepId": 11, "taskType": "T285", "factory": "F727", "fabric": "AI_ENGINE" },
    { "stepId": 12, "taskType": "T287", "factory": "F731", "fabric": "DATABASE_ES" },
    { "stepId": 13, "taskType": "T288", "factory": "F697", "fabric": "DATABASE_ES" }
  ],
  "stateMachine": { "states": ["Designing","Review","Published"], "initial": "Designing" }
}
```

---

## SAVE POINT: FLOW19:TASK_TYPES_CATALOG ✅
## Next: SKILLS_FACTORY_RAG delta (SK-161–SK-172)
