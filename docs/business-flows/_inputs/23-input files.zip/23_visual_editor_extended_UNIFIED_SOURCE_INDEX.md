# XIIGen UNIFIED SOURCE INDEX — FLOW-19: Visual Editor Extended
## Delta File — DD-149–DD-163 (15 design decisions), DR-111–DR-122 (12 design records)
## Extends: UNIFIED_SOURCE_INDEX_MERGED.md (DD-1–DD-148, DR-1–DR-110)

---

## DESIGN DECISIONS — FLOW-19 (DD-149–DD-163)

### DD-149 — UI Fabric-First: Zero Platform-Specific Values in Canvas Layer
**Decision:** The canvas UI layer contains no platform-specific values. All database providers, queue endpoints, AI model names, and framework identifiers are resolved through fabric interfaces via config. The canvas service never imports `ElasticsearchClient`, `StackExchange.Redis`, `OpenAI`, or `ReactDOM` directly.
**Alternatives Considered:**
- Platform-specific: faster initial dev, but locks architecture to single provider stack
- Partial abstraction: some direct imports for "known" providers
**Rationale:** Consistent with V39/V40 engine philosophy. Any canvas deployment swaps providers via config without code change. UI = fabric-first, no exceptions.
**Impact:** All 37 FLOW-19 factories resolve via `IExternalServiceFactory<TService>.CreateAsync()`. No direct imports anywhere.
**Binding Sources:** basic_prompt.txt Layer 0; V39 ENGINE DESIGN; DR-111
**Status:** APPROVED ✅

---

### DD-150 — Node Tree Storage: Elasticsearch + Redis Tiered Architecture
**Decision:** Canvas node trees stored in two tiers: Redis (hot state, sub-100ms writes/reads for active editing) and Elasticsearch (durable cold state, full-text search across node properties).
**Alternatives Considered:**
- ES only: simpler, but too slow for real-time collaborative editing (target: < 50ms round-trip)
- PostgreSQL only: ACID but poor search performance for node property queries
- Redis only: too volatile; no durability guarantee for published canvas states
**Rationale:** Redis hot path enables interactive editing latency. ES provides searchable, durable, versioned node tree storage. Pattern matches FLOW-12 (Chat) hot/cold architecture.
**Impact:** F697 (ES) + F698 (Redis) — two factory interfaces, both through DATABASE FABRIC (Skill 05)
**Binding Sources:** DR-112; 23-visual-editor-extended-deep-search-engine.md
**Status:** APPROVED ✅

---

### DD-151 — Canvas Collaboration: Queue Fabric, Not WebSocket Direct
**Decision:** All real-time collaborative canvas events (node moves, edits, presence) are published through QUEUE FABRIC (Skill 04 Redis Streams consumer groups). Canvas clients subscribe to their stream. No direct WebSocket connections between canvas service instances.
**Alternatives Considered:**
- Direct WebSocket hub: lower latency for single-instance, but breaks at multi-instance scale
- Server-Sent Events: one-way; not suitable for bidirectional collaboration
**Rationale:** DNA compliance — inter-service communication via Queue Fabric only. Redis Streams consumer groups provide fan-out, replay, consumer group isolation per tenant.
**Impact:** F702 + F704 handle all collaboration events. SK-171 implements consumer group pattern.
**Binding Sources:** basic_prompt.txt Layer 0 (QUEUE FABRIC); DR-113
**Status:** APPROVED ✅

---

### DD-152 — Layout Solver: Pure Computation on MicroserviceBase, No AI
**Decision:** The layout solver (F705) is deterministic pure computation extending MicroserviceBase. It does not call any AI provider. Flex/Grid bounding box math is algorithmically stable and must produce identical output for identical input.
**Alternatives Considered:**
- AI-assisted layout solving: would introduce non-determinism; breaks idempotency requirement
- External layout engine library: breaks fabric-first philosophy; direct import
**Rationale:** Layout correctness requires determinism. AI is used for advisory suggestions only (T274) — never for the deterministic solve. Designers need confidence that re-running layout produces the same result.
**Impact:** F705 → CORE FABRIC (MicroserviceBase), not AI ENGINE FABRIC. AF-5 (multi-model) not used in T271.
**Binding Sources:** basic_prompt.txt Layer 2 (MACHINE/FREEDOM); DR-114
**Status:** APPROVED ✅

---

### DD-153 — Data Binding: JSONPath `$.skill_XX.field` Convention
**Decision:** All canvas data bindings use JSONPath convention `$.skill_XX.field` where XX is the skill number that produces the content. This creates explicit cross-skill dependency declarations on every canvas node.
**Alternatives Considered:**
- Custom binding DSL: more expressive but requires custom parser
- Template string interpolation `{{skill_05.post.title}}`: less standard, harder to validate
**Rationale:** JSONPath is industry-standard; parseable by existing libraries; binding validator (F717) can cross-reference against skill output schemas registered in BFA.
**Impact:** All binding paths in node documents use `$.skill_XX.field`. SK-164 implements resolution. CF-345 enforces cross-flow skill schema validation.
**Binding Sources:** 23-visual-editor-extended.md node schema; DR-116
**Status:** APPROVED ✅

---

### DD-154 — Template Mode: Read-Only Against Production Content
**Decision:** Template Mode (F713) is strictly read-only against FLOW-02 production content indices. Preview state is stored in Redis session-isolated keys. No preview write ever reaches production Elasticsearch.
**Alternatives Considered:**
- Draft copies in separate ES index: adds index management overhead; risks stale data
- In-memory only: not recoverable on browser refresh; poor UX
**Rationale:** Designers must see real production content to validate layouts. But preview interactions must never corrupt live content. Redis TTL-based preview state is self-cleaning.
**Impact:** CF-341, CF-343 BFA rules enforce this. ST-188 stress test verifies.
**Binding Sources:** 23-visual-editor-extended-deep-search-engine.md Template Mode section; DR-117
**Status:** APPROVED ✅

---

### DD-155 — Multi-Tenant Model: Hybrid Pool/Silo/Bridge
**Decision:** FLOW-19 implements the hybrid isolation portfolio. Default = shared schema (pool) with `tenantId` on every row. Enterprise tenants graduate to separate schema (bridge) or separate database (silo) based on compliance and contractual criteria.
**Alternatives Considered:**
- Pool only: insufficient for regulated enterprise tenants
- Silo only: too expensive for small tenants; poor unit economics
- Fixed two-tier: not flexible enough for varying compliance needs
**Rationale:** Industry SaaS guidance recommends bridge model for flow engines serving mixed-compliance tenant bases. Pool for SMB, bridge/silo for enterprise.
**Impact:** F723 (ITenantTieringService) manages graduation. T284 orchestrates migration. CF-346 enforces isolation gate.
**Binding Sources:** 23-visual-editor-extended-engine-multi-tenant.md §Tenant storage models; DR-119
**Status:** APPROVED ✅

---

### DD-156 — CloudEvents Envelopes Required for All Async Canvas Events
**Decision:** Every asynchronous canvas event published to QUEUE FABRIC must be wrapped in a CloudEvents v1.0 envelope with `tenantId` as an extension attribute.
**Alternatives Considered:**
- Raw JSON payload: simpler but no standard tenant propagation mechanism
- Custom envelope: non-standard; harder to integrate with observability tools
**Rationale:** CloudEvents provides standardized event metadata. OTLP trace context can be carried in envelope. Tenant context propagation across async boundaries is explicitly solved by CloudEvents extension attributes.
**Impact:** F721 wraps all events. CF-332, CF-334, CF-348 verify stream key namespacing. SK-170 implements envelope creation.
**Binding Sources:** 23-multi-tenant.md §CloudEvents; IETF Idempotency-Key; DR-120
**Status:** APPROVED ✅

---

### DD-157 — Code Export: Multi-Model Consensus via AiDispatcher
**Decision:** UI code export (T285) uses AiDispatcher (F727) to run 3+ competing AI models in parallel and merge outputs via AF-10. No single model generates the final code. AF-9 quality gate (score ≥ 0.8) required before export available to designer.
**Alternatives Considered:**
- Single best model: faster but less robust; model updates can silently degrade quality
- Sequential refinement: slower; better for complex code but insufficient for canvas export latency
**Rationale:** Consistent with V40 ENGINE-FABRIC-FIRST multi-model pattern. Framework adapter (F728) via IAiProvider ensures no model is hardcoded. AF-11 feedback loop improves model selection over time.
**Impact:** T285 AF CONFIGURATION includes AF-1, AF-5, AF-6, AF-7, AF-9, AF-10, AF-11.
**Binding Sources:** basic_prompt.txt Layer 3 (AF Stations); DR-121
**Status:** APPROVED ✅

---

### DD-158 — Design Tokens: Elasticsearch Single Source of Truth
**Decision:** Design tokens (colors, fonts, spacing, radii, shadows) are stored in a dedicated Elasticsearch index per tenant via F729. All canvas nodes, component variants, and exported code reference token keys, never raw values.
**Alternatives Considered:**
- Hardcoded in component definitions: violates FREEDOM principle; requires code deploy to change
- Per-canvas token sets: causes token divergence across canvases; admin nightmare
**Rationale:** Single ES index = single source of truth. Token updates propagate via QUEUE FABRIC to all referencing nodes without code deployment. This is the Freedom Machine philosophy applied to design.
**Impact:** F729, F700, F704 implement token sync. T275, T286 execute propagation. CF-338 prevents stream collision.
**Binding Sources:** 23-visual-editor-extended.md §Theme tokens; Freedom Machine philosophy; DR-122
**Status:** APPROVED ✅

---

### DD-159 — Canvas State Machine: Designing → Review → Published
**Decision:** Every canvas flow has an explicit state machine with states: `Designing`, `Review`, `Published`. Transitions guarded by: designer approval (Designing→Review), AF-9 quality gate pass (Review→Published). Rollback supported from any state.
**Alternatives Considered:**
- No state machine: ad-hoc publish buttons; no audit trail; no approval workflow
- More states (Draft/Beta/Staging/Prod): valuable for enterprise but increases complexity
**Rationale:** Three-state machine captures the essential design lifecycle. FREEDOM layer allows extending states via config (e.g., adding `Staging` for enterprise tenants) without changing MACHINE logic.
**Impact:** SK-168 (FlowStateMachineService), F701 (PostgreSQL state store), T288 orchestrates transitions.
**Binding Sources:** 23-visual-editor-extended-deep-search-engine.md §State Machine Engine; DR-119
**Status:** APPROVED ✅

---

### DD-160 — Idempotency: IETF Idempotency-Key Semantics
**Decision:** Canvas "start flow run" and all external side-effect steps use `Idempotency-Key` header semantics via F722. Duplicate keys within TTL return cached result without re-executing side effects.
**Alternatives Considered:**
- At-least-once semantics only: simpler but requires all consumers to be idempotent
- Transaction IDs only: similar but not standardized; harder for external integrators
**Rationale:** IETF Idempotency-Key draft provides standard semantics. Critical for canvas operations under network retry (CF-190 pattern). OWASP API6 sensitive flow abuse defense.
**Impact:** F722 implements idempotency store (Redis). T282 checks key before every canvas operation.
**Binding Sources:** 23-multi-tenant.md §Idempotency; IETF draft; DR-120
**Status:** APPROVED ✅

---

### DD-161 — Role Extraction: Auth Context Only, Never Request Body
**Decision:** User role in canvas constraint enforcement is always extracted from MicroserviceBase auth context (`_authContext.GetClaim("role")`). Never from request body, URL parameter, or client-provided header.
**Alternatives Considered:**
- Role in request body: simpler client code but trivially exploitable (OWASP API1)
- Role in X-Custom-Header: non-standard; not protected by auth middleware
**Rationale:** OWASP API1 (BOLA) requires server-side role validation. MicroserviceBase auth context is JWT-validated. Prevents privilege escalation by forged request body.
**Impact:** SK-167 (RoleLockService), F724 (OIDC/SCIM), T277 (Constraint Gate). CF-340 verifies FLOW-01 role alignment.
**Binding Sources:** basic_prompt.txt Layer 4 (DNA-5 scope isolation); OWASP API1; DR-119
**Status:** APPROVED ✅

---

### DD-162 — Sandbox Isolation: Redis Hot State, Never ES Production
**Decision:** Canvas sandbox execution uses Redis hot state (F698) exclusively. Sandbox results never reach production Elasticsearch (F697) until explicit promotion via `PromoteSandboxToProduction`.
**Alternatives Considered:**
- Separate ES index for sandbox: ES overhead for transient execution state is too high
- In-memory only: not persistent; browser refresh loses sandbox
**Rationale:** Redis TTL-based sandbox state is ephemeral by default. Only explicit promotion writes to ES. This provides a safe preview environment matching Promotion Ladder pattern (GENERATED → INJECTED → MINIMAL → CORE).
**Impact:** SK-172 (FlowSandboxService), F698 (Redis), T279 (Template Mode), T288 (Full DAG).
**Binding Sources:** basic_prompt.txt Layer 4 (Promotion Ladder); DR-112
**Status:** APPROVED ✅

---

### DD-163 — OTLP Telemetry: Tenant Labels at Controlled Cardinality
**Decision:** All FLOW-19 telemetry (metrics, traces, logs) emitted with `tenantId` label via F726 OTLP pipeline. Cardinality controlled: `tenantId` used as label, not individual user IDs, to keep metrics cardinality manageable.
**Alternatives Considered:**
- No tenant labels: cheaper but impossible to diagnose per-tenant performance issues
- User-level labels: full observability but cardinality explosion at scale (millions of users)
**Rationale:** `tenantId` label enables per-tenant SLA monitoring, noisy-neighbor detection, and billing metering without cardinality explosion. W3C trace context propagated through all async events.
**Impact:** F726 (OTLP MicroserviceBase wrapper), SK-170 (TenantIsolationHardeningService), T283 (CloudEvents envelope carries trace context).
**Binding Sources:** 23-multi-tenant.md §Observability; W3C Trace Context; DR-120
**Status:** APPROVED ✅

---

## DESIGN RECORDS — FLOW-19 (DR-111–DR-122)
*(Referenced in ENGINE_ARCHITECTURE — repeated here for unified index completeness)*

| DR # | Decision | Source DD |
|------|----------|-----------|
| DR-111 | Node tree stored as `Dictionary<string,object>` in Elasticsearch | DD-149 |
| DR-112 | Canvas hot state Redis + cold state ES tiered architecture | DD-150, DD-162 |
| DR-113 | Collaboration events via Redis Streams consumer groups | DD-151 |
| DR-114 | Layout solver pure computation, no AI | DD-152 |
| DR-115 | AI-assisted breakpoint resolution via AiDispatcher | DD-152 (AI for suggestions only) |
| DR-116 | Binding paths use `$.skill_XX.field` JSONPath convention | DD-153 |
| DR-117 | Template Mode READ-ONLY against production content | DD-154 |
| DR-118 | Content fallback via AiDispatcher when CMS field null | DD-154 |
| DR-119 | Multi-tenant hybrid pool/silo/bridge model | DD-155, DD-159, DD-161 |
| DR-120 | CloudEvents + idempotency + OTLP telemetry | DD-156, DD-160, DD-163 |
| DR-121 | Code export multi-model consensus + AF-9 gate | DD-157 |
| DR-122 | Design tokens in Elasticsearch, single source of truth | DD-158 |

---

## CROSS-REFERENCE INDEX — FLOW-19

| Artifact | FLOW-19 Range | Source Files |
|----------|---------------|-------------|
| Factories | F697–F733 | ENGINE_ARCHITECTURE delta |
| Families | 94–98 | ENGINE_ARCHITECTURE delta |
| Task Types | T269–T288 | TASK_TYPES_CATALOG delta |
| Templates | 56–61 | TASK_TYPES_CATALOG delta |
| BFA Rules | CF-329–CF-348 | V62_BFA_STRESS_TEST delta |
| Stress Tests | ST-184–ST-198 | V62_BFA_STRESS_TEST delta |
| Skills | SK-161–SK-172 | SKILLS_FACTORY_RAG delta |
| Design Decisions | DD-149–DD-163 | This file |
| Design Records | DR-111–DR-122 | This file + ENGINE_ARCHITECTURE |
| DNA Patterns | DNA-1–DNA-9 | Unchanged (stable) |
| Engine Primitives | EP-1–EP-5 | Unchanged (stable) |

---

## SOURCE INPUT DOCUMENTS — FLOW-19

| File | Domain | Key Contributions |
|------|--------|-------------------|
| 23 - visual editor extended.md | Canvas editor, layout, data binding | Node tree schema, layout primitives, binding bridge, role constraints |
| 23 - visual editor extended deep search engine.md | Flow engine for visual composition | State machine, event bus, API contracts, node graph, DAG orchestration |
| 23 - visual editor extended engine multi tenant.md | Multi-tenant hardening | Pool/silo/bridge model, CloudEvents, idempotency, quotas, OIDC/SCIM, OTLP |
| basic_prompt.txt | Engine architecture invariants | Fabric-first, factory pattern, DNA compliance, AF stations, promotion ladder |
| SESSION_STATE_MERGE.md | System state post FLOW-18 | Starting numbers: F697, T269, CF-329, SK-161, etc. |

---

## SAVE POINT: FLOW19:UNIFIED_SOURCE_INDEX ✅
## Next: MASTER_EXECUTION_PLAN delta
