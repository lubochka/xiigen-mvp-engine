# XIIGen MASTER EXECUTION PLAN — FLOW-19: Visual Editor Extended
## Delta File — P0–P7 execution phases for FLOW-19 only
## Extends: MASTER_EXECUTION_PLAN_MERGED.md (FLOW-01–FLOW-18 plans)

---

## FLOW-19 EXECUTION OVERVIEW

**Goal:** Extend the XIIGen engine to generate visual UI composition flows — a fabric-first Wix/Webflow-style canvas engine — built on top of the existing skill library and fabric interfaces.

**Output:** 7 canonical delta files (this set)
**Starting Numbers:** F697, T269, CF-329, ST-184, SK-161, DD-149, DR-111, Template 56, Family 94
**Ending Numbers:** F733, T288, CF-348, ST-198, SK-172, DD-163, DR-122, Template 61, Family 98

---

## P0 — RAG ORIENTATION & ANCHOR ESTABLISHMENT ✅
**Duration:** ~5 minutes
**Goal:** Read all source documents; extract system state; lock FLOW-19 starting numbers

**Steps:**
1. Read SESSION_STATE_MERGE.md → confirm F697/T269/CF-329 starting anchors
2. Read basic_prompt.txt → internalize DNA rules, factory pattern, AF stations
3. Read 23-visual-editor-extended.md → extract canvas editor, layout, binding requirements
4. Read 23-visual-editor-extended-deep-search-engine.md → extract state machine, API, DAG architecture
5. Read 23-visual-editor-extended-engine-multi-tenant.md → extract tenant isolation requirements
6. Build RAG index: map requirements to existing skills SK-1–SK-160 for reuse candidates
7. Identify reuse: SK-26 (WebFlowEditor), SK-17 (CodeGenerator), SK-21 (Permissions) as integration points

**Save Point:** P0_ANCHORS_LOCKED
```
Anchors confirmed:
  Factory: F697  Family: 94
  Task Type: T269
  Template: 56
  BFA Rule: CF-329
  Stress Test: ST-184
  Skill: SK-161
  Design Decision: DD-149
  Design Record: DR-111
```
**Recovery:** "Load SESSION_STATE_MERGE.md — confirm F697/T269/CF-329 anchors"

---

## P1 — ENGINE_ARCHITECTURE DELTA ✅
**Duration:** ~20 minutes
**Goal:** Define 5 new factory families (94–98), 37 factories (F697–F733), fabric resolution map, design records

**Steps:**
1. Define Family 94 (Visual Canvas Core): F697–F704, fabric mappings, DNA compliance notes
2. Define Family 95 (Layout Engine): F705–F711, pure computation vs AI-assisted distinction
3. Define Family 96 (Data Binding Bridge): F712–F718, JSONPath binding, CMS integration
4. Define Family 97 (Multi-Tenant Hardening): F719–F726, CloudEvents, idempotency, OTLP
5. Define Family 98 (Code Export & Deployment): F727–F733, multi-model export, artifact registry
6. Write full fabric resolution map (37 entries)
7. Write node tree schema contract (Dictionary pattern)
8. Write DR-111–DR-122 design records
9. Write promotion ladder for FLOW-19 services

**Deliverable:** `23_visual_editor_extended_ENGINE_ARCHITECTURE.md`
**Save Point:** FLOW19:ENGINE_ARCHITECTURE ✅
**Recovery:** "Load 23_visual_editor_extended_ENGINE_ARCHITECTURE.md — F697–F733 defined"

---

## P2 — TASK_TYPES_CATALOG DELTA ✅
**Duration:** ~25 minutes
**Goal:** Define T269–T288 (20 task types) with full engine contract format; 6 flow templates (56–61)

**Steps:**
1. T269–T273: Visual Canvas Core task types (node tree, symbols, layout, breakpoints, versioning)
2. T274–T276: Layout Engine orchestration (multi-model advisor, token sync, alignment gate)
3. T277–T281: Data Binding + Constraints (constraint gate, CMS binding, template mode, repeater, validator)
4. T282–T284: Multi-Tenant Guardrails (isolation gate, CloudEvents envelope, tier graduation)
5. T285–T288: Code Export + Full DAG (UI export, token export, artifact registry, full orchestration)
6. For each task type: ARCHETYPE, ENTRY, PURPOSE, DISTINCT FROM, FACTORY DEPENDENCIES, FABRIC RESOLUTION, AF CONFIGURATION, BFA VALIDATION, MACHINE/FREEDOM, IRON RULES, QUALITY GATES
7. Templates 56–61: DAG JSON flow definitions for each flow variant

**Deliverable:** `23_visual_editor_extended_TASK_TYPES_CATALOG.md`
**Save Point:** FLOW19:TASK_TYPES_CATALOG ✅
**Recovery:** "Load 23_visual_editor_extended_TASK_TYPES_CATALOG.md — T269–T288 defined"

---

## P3 — SKILLS_FACTORY_RAG DELTA ✅
**Duration:** ~15 minutes
**Goal:** Define SK-161–SK-172 (12 new skills) with full method signatures, DNA-compliant patterns, AF-4 RAG index

**Steps:**
1. SK-161: NodeTreeService — Dictionary persistence, ES + Redis tiered
2. SK-162: LayoutSolverService — pure computation, MicroserviceBase
3. SK-163: ComponentConstraintService — lockLayout/allowContentEdit evaluation
4. SK-164: DataBindingBridgeService — JSONPath resolution, Template Mode, fallback
5. SK-165: BreakpointResolverService — patch management, AI suggestions
6. SK-166: ThemeTokenService — ES token store, QUEUE FABRIC propagation
7. SK-167: RoleLockService — OIDC role, auth context extraction
8. SK-168: FlowStateMachineService — Designing→Review→Published, guard conditions
9. SK-169: UICodeExportService — AiDispatcher, AF-9 gate, artifact registry
10. SK-170: TenantIsolationHardeningService — full OWASP compliance suite
11. SK-171: CanvasCollaborationService — Redis Streams consumer groups
12. SK-172: FlowSandboxService — Redis sandbox, promotion to production
13. Build AF-4 RAG Index table for all 12 skills

**Deliverable:** `23_visual_editor_extended_SKILLS_FACTORY_RAG.md`
**Save Point:** FLOW19:SKILLS_FACTORY_RAG ✅
**Recovery:** "Load 23_visual_editor_extended_SKILLS_FACTORY_RAG.md — SK-161–SK-172 defined"

---

## P4 — V62_BFA_STRESS_TEST DELTA ✅
**Duration:** ~15 minutes
**Goal:** Define CF-329–CF-348 (20 BFA conflict rules) and ST-184–ST-198 (15 stress tests)

**Steps:**
1. Map all cross-flow risk points: FLOW-19 vs FLOW-01, 02, 04, 09, 12, 13, 15, 18
2. CF-329–CF-333: Node ID/stream key namespacing collisions (FLOW-02, 04, 09, 12, 13)
3. CF-334–CF-340: Layout, constraint, token, role conflicts (FLOW-12, 13, 18, 01)
4. CF-341–CF-345: Data binding, Template Mode, repeater, skill schema (FLOW-02, 13, 09)
5. CF-346–CF-348: Tenant isolation gate ordering, quota namespacing, artifact IDs (FLOW-15, 18)
6. ST-184–ST-198: One stress test per major risk scenario
   - Concurrent multi-tenant, node ID collision, layout determinism, breakpoint stack
   - Template Mode isolation, quota enforcement, CloudEvents dedup, role lock
   - Symbol propagation, code export quality gate, tenant tier graduation
   - Binding path validation, collaborative conflict, sandbox isolation, token cascade

**Deliverable:** `23_visual_editor_extended_V62_BFA_STRESS_TEST.md`
**Save Point:** FLOW19:BFA_STRESS_TEST ✅
**Recovery:** "Load 23_visual_editor_extended_V62_BFA_STRESS_TEST.md — CF-329–CF-348, ST-184–ST-198"

---

## P5 — UNIFIED_SOURCE_INDEX DELTA ✅
**Duration:** ~10 minutes
**Goal:** Define DD-149–DD-163 (15 design decisions), DR-111–DR-122 (cross-reference), full source document map

**Steps:**
1. DD-149: UI Fabric-First (zero platform-specific values)
2. DD-150: Node tree tiered storage (ES + Redis)
3. DD-151: Collaboration via QUEUE FABRIC only
4. DD-152: Layout solver pure computation (no AI)
5. DD-153: JSONPath binding convention
6. DD-154: Template Mode read-only
7. DD-155: Multi-tenant hybrid pool/silo/bridge
8. DD-156: CloudEvents envelopes required
9. DD-157: Code export multi-model consensus
10. DD-158: Design tokens ES single source of truth
11. DD-159: Canvas state machine (Designing→Review→Published)
12. DD-160: IETF Idempotency-Key semantics
13. DD-161: Role from auth context only (never request body)
14. DD-162: Sandbox Redis isolation
15. DD-163: OTLP tenant labels at controlled cardinality
16. Cross-reference index table (all FLOW-19 artifact ranges)
17. Source input document map

**Deliverable:** `23_visual_editor_extended_UNIFIED_SOURCE_INDEX.md`
**Save Point:** FLOW19:UNIFIED_SOURCE_INDEX ✅
**Recovery:** "Load 23_visual_editor_extended_UNIFIED_SOURCE_INDEX.md — DD-149–DD-163 defined"

---

## P6 — MASTER_EXECUTION_PLAN DELTA ✅
**Duration:** ~10 minutes
**Goal:** Document this execution plan with all phases, save points, and recovery commands

**Steps:**
1. Write P0–P7 phase descriptions with goals, steps, durations
2. Document all save points and recovery commands
3. Write implementation readiness checklist
4. Write engine state verification procedure for FLOW-19

**Deliverable:** `23_visual_editor_extended_MASTER_EXECUTION_PLAN.md`
**Save Point:** FLOW19:MASTER_EXECUTION_PLAN ✅
**Recovery:** "Load 23_visual_editor_extended_MASTER_EXECUTION_PLAN.md — all 7 phases documented"

---

## P7 — SESSION_STATE DELTA ✅
**Duration:** ~5 minutes
**Goal:** Create SESSION_STATE delta with updated number anchors, FLOW-19 registry entry, next-flow anchors

**Steps:**
1. Confirm final counts: F733, T288, CF-348, ST-198, SK-172, DD-163, DR-122, Template 61, Family 98
2. Write FLOW-19 registry entry
3. Write FLOW-20 starting anchors
4. Write recovery commands for FLOW-19 reload

**Deliverable:** `23_visual_editor_extended_SESSION_STATE.md`
**Save Point:** FLOW19:ALL_DELTA_FILES_COMPLETE ✅

---

## IMPLEMENTATION READINESS CHECKLIST

Before any generated code ships, verify all of the following pass:

### Engine Contract Verification
- [ ] All 37 factories (F697–F733) registered in factory registry
- [ ] All 37 factories have fabric resolution declared (no "TBD" entries)
- [ ] All 20 task types (T269–T288) have complete engine contract (all 9 fields)
- [ ] All 6 templates (56–61) have valid DAG JSON with step 1 = T282

### DNA Compliance Verification
- [ ] DNA-1: All node documents use `Dictionary<string,object>` — no typed DTO classes
- [ ] DNA-2: All ES queries use `BuildSearchFilter` — empty fields auto-skipped
- [ ] DNA-3: All methods return `DataProcessResult<T>` — no business logic exceptions thrown
- [ ] DNA-4: All services extend MicroserviceBase — no standalone classes
- [ ] DNA-5: tenantId on every database query — verified by AF-7 compliance check
- [ ] DNA-6: DynamicController used — no canvas-entity-specific controllers
- [ ] DNA-7–9: Check against extended DNA patterns in SK-1–SK-160

### BFA Conflict Clearance
- [ ] CF-329–CF-348 all checked against existing FLOW-01–FLOW-18 artifacts
- [ ] No node ID / stream key / artifact ID collisions detected
- [ ] T282 (Tenant Isolation Gate) is step 1 in all Templates 56–61
- [ ] CF-341/CF-343 (Template Mode read-only) verified by AF-8 security scan

### AF Station Coverage
- [ ] AF-1 (Genesis): FLOW-19 services generated by AF-1 on top of F697–F733
- [ ] AF-4 (RAG): SK-161–SK-172 indexed in AF-4 retrieval index
- [ ] AF-7 (Compliance): DNA-1/2/3/4/5 compliance on all generated code
- [ ] AF-8 (Security): OWASP API1/4/6/7 checks on T282/T283/T285
- [ ] AF-9 (Judge): all quality gates defined; T285 export requires score ≥ 0.8
- [ ] AF-11 (Feedback): quality scores stored for SK-165 (breakpoint), SK-169 (code export)

### Backward Compatibility
- [ ] FLOW-01–FLOW-18 factory interfaces F1–F696 unchanged
- [ ] FLOW-01–FLOW-18 task types T1–T268 unchanged
- [ ] FLOW-01–FLOW-18 templates 1–55 unchanged
- [ ] BFA rules CF-1–CF-328 unchanged
- [ ] All stress tests ST-1–ST-183 still pass

---

## RECOVERY COMMANDS — FLOW-19

```bash
# Full FLOW-19 reload
"Load all 7 FLOW-19 delta files — Visual Editor Extended complete"

# Load specific delta
"Load 23_visual_editor_extended_ENGINE_ARCHITECTURE — F697–F733"
"Load 23_visual_editor_extended_TASK_TYPES_CATALOG — T269–T288"
"Load 23_visual_editor_extended_SKILLS_FACTORY_RAG — SK-161–SK-172"
"Load 23_visual_editor_extended_V62_BFA_STRESS_TEST — CF-329–CF-348"
"Load 23_visual_editor_extended_UNIFIED_SOURCE_INDEX — DD-149–DD-163"
"Load 23_visual_editor_extended_MASTER_EXECUTION_PLAN"
"Load 23_visual_editor_extended_SESSION_STATE"

# Continue from specific save point
"Resume FLOW-19 from FLOW19:ENGINE_ARCHITECTURE — all factories defined"
"Resume FLOW-19 from FLOW19:TASK_TYPES_CATALOG — T269–T288 complete"
"Resume FLOW-19 from FLOW19:BFA_STRESS_TEST — CF-329–CF-348 complete"

# Start next flow
"Start FLOW-20 from F734, T289, CF-349, SK-173, DD-164, DR-123, Template 62, Family 99"
```

---

## SAVE POINT: FLOW19:MASTER_EXECUTION_PLAN ✅
## Next: SESSION_STATE delta
