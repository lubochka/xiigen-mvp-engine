# XIIGen SKILLS FACTORY RAG — FLOW-19: Visual Editor Extended
## Delta File — SK-161–SK-172 only (12 new skills)
## Extends: SKILLS_FACTORY_RAG_MERGED.md (SK-1–SK-160)

---

## FLOW-19 SKILLS SUMMARY

| Skill ID | Name | Factory Backed | Fabric | Task Types |
|----------|------|----------------|--------|------------|
| SK-161 | NodeTreeService | F697, F698, F703 | DATABASE FABRIC (ES + Redis) | T269, T270, T273, T288 |
| SK-162 | LayoutSolverService | F705, F708, F710 | CORE FABRIC | T271, T274, T276 |
| SK-163 | ComponentConstraintService | F709, F719 | DATABASE FABRIC (ES) + CORE FABRIC | T270, T277, T282 |
| SK-164 | DataBindingBridgeService | F712, F713, F714, F718 | DATABASE FABRIC + AI ENGINE | T278, T279, T280 |
| SK-165 | BreakpointResolverService | F706, F707 | AI ENGINE FABRIC + DATABASE FABRIC | T272, T279 |
| SK-166 | ThemeTokenService | F729, F700, F704 | DATABASE FABRIC (ES) + QUEUE FABRIC | T275, T286 |
| SK-167 | RoleLockService | F709, F719, F724 | DATABASE FABRIC + CORE FABRIC | T277, T282 |
| SK-168 | FlowStateMachineService | F701, F704, F716 | DATABASE FABRIC (PG) + QUEUE FABRIC | T273, T284, T288 |
| SK-169 | UICodeExportService | F727, F728, F730, F731 | AI ENGINE FABRIC + DATABASE FABRIC | T285, T286, T287 |
| SK-170 | TenantIsolationHardeningService | F719, F720, F721, F722, F723, F725, F726 | CORE + DATABASE + QUEUE FABRIC | T282, T283, T284 |
| SK-171 | CanvasCollaborationService | F702, F704 | QUEUE FABRIC (Redis Streams) | T269, T270 |
| SK-172 | FlowSandboxService | F698, F716, F713 | DATABASE FABRIC (Redis) + QUEUE FABRIC | T279, T288 |

---

## SKILL: SK-161 — NodeTreeService

**Purpose:** Persist, retrieve, version, and search UI node trees as dynamic `Dictionary<string,object>` documents in Elasticsearch. Manage canvas hot state in Redis. Expose layer tree index.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1 (Dictionary), DNA-2 (BuildSearchFilter), DNA-3 (DataProcessResult), DNA-4 (MicroserviceBase), DNA-5 (tenantId scope)

**Key Methods:**
```
StoreNodeTree(tenantId, canvasId, nodeTree: Dictionary<string,object>) → DataProcessResult<string>
GetNodeTree(tenantId, canvasId) → DataProcessResult<Dictionary<string,object>>
SearchNodes(tenantId, filters: Dictionary<string,object>) → DataProcessResult<List<Dictionary<string,object>>>
GetLayerTree(tenantId, canvasId) → DataProcessResult<Dictionary<string,object>>
PutCanvasHotState(tenantId, canvasId, state: Dictionary<string,object>) → DataProcessResult<bool>
```

**Pattern (DNA-1 compliant):**
```csharp
// CORRECT — ParseDocument, never typed model
var nodeTree = ParseDocument(rawDocument); // Dictionary<string,object>
var filter = BuildSearchFilter(new { tenantId, canvasId }); // empty fields skipped — DNA-2
var result = await _db.SearchDocuments(filter); // via DATABASE FABRIC
return DataProcessResult<Dictionary<string,object>>.Success(result);

// WRONG — BUILD FAILURE
// var node = new NodeTreeDocument { NodeId = "x" }; // typed model — violates DNA-1
```

**AF-4 RAG Retrieval Tags:** `#node-tree`, `#canvas-persistence`, `#elasticsearch`, `#dictionary-pattern`

**Promotion Status:** GENERATED → targeted for CORE after FLOW-19 complete

---

## SKILL: SK-162 — LayoutSolverService

**Purpose:** Deterministically compute Flex/Grid layout bounding boxes, alignment candidates, and constraint evaluations for a canvas node tree. Pure computation extending MicroserviceBase. No AI, no external provider.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
SolveLayout(tenantId, nodeTree: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
CalculateBoundingBox(node: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
EvaluateFlexConstraints(container: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
EvaluateGridConstraints(container: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
MergeLayoutResult(base: Dictionary<string,object>, patch: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
```

**Pattern:**
```csharp
// CORRECT — pure computation, MicroserviceBase, DataProcessResult
public class LayoutSolverService : MicroserviceBase, ILayoutSolverService
{
    public async Task<DataProcessResult<Dictionary<string,object>>> SolveLayout(
        string tenantId, Dictionary<string,object> nodeTree)
    {
        var mode = nodeTree.GetValueOrDefault("layoutMode", "FLEX_VERTICAL");
        // ... compute bounding boxes deterministically
        return DataProcessResult<Dictionary<string,object>>.Success(resolved);
    }
}

// WRONG
// public class LayoutSolver { ... } // must extend MicroserviceBase
```

**AF-4 RAG Retrieval Tags:** `#layout-solver`, `#flex-grid`, `#bounding-box`, `#pure-computation`

---

## SKILL: SK-163 — ComponentConstraintService

**Purpose:** Evaluate `lockLayout` / `allowContentEdit` node constraints. Enforce designer vs editor role boundaries. Fetch constraint documents from Elasticsearch via DATABASE FABRIC.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-2, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
GetConstraints(tenantId, nodeId) → DataProcessResult<Dictionary<string,object>>
EvaluateWrite(tenantId, nodeId, role, changeType) → DataProcessResult<bool>
StoreConstraints(tenantId, nodeId, constraints: Dictionary<string,object>) → DataProcessResult<string>
InheritConstraints(parentNodeId, childNodeId) → DataProcessResult<Dictionary<string,object>>
```

**Pattern:**
```csharp
// CORRECT — constraint document is Dictionary, role from auth context (not request body)
var constraints = await _constraintSvc.GetConstraints(tenantId, nodeId);
var role = _authContext.GetRole(); // from MicroserviceBase auth context — DNA-4
var canWrite = constraints["lockLayout"] as bool? == true && role != "DESIGNER"
    ? DataProcessResult<bool>.Failure("Layout locked")
    : DataProcessResult<bool>.Success(true);
```

**AF-4 RAG Retrieval Tags:** `#constraint-evaluation`, `#role-lock`, `#lock-layout`, `#permission-gate`

---

## SKILL: SK-164 — DataBindingBridgeService

**Purpose:** Resolve JSONPath binding paths to CMS content via DATABASE FABRIC. Manage Template Mode context. Execute content fallback via AI ENGINE FABRIC. Format fields (date, clamp, truncate).

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-2, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
ResolveBinding(tenantId, bindingPath: string, contentContext: Dictionary<string,object>) → DataProcessResult<object>
ActivateTemplateMode(tenantId, canvasId, contentType) → DataProcessResult<Dictionary<string,object>>
DeactivateTemplateMode(tenantId, canvasId) → DataProcessResult<bool>
ApplyFallback(tenantId, field: string, fallbackStrategy: string) → DataProcessResult<object>
FormatField(value: object, formatRule: Dictionary<string,object>) → DataProcessResult<string>
```

**Pattern:**
```csharp
// CORRECT — binding resolution via DATABASE FABRIC, null → AI fallback
var content = await _db.SearchDocuments(BuildSearchFilter(new { tenantId, contentId }));
var value = ResolveJsonPath(content.Data, bindingPath);
if (value == null)
    value = await _aiProvider.GenerateAsync(fallbackPrompt); // via AI ENGINE FABRIC (F714)
return DataProcessResult<object>.Success(FormatValue(value, formatRule));

// WRONG
// var post = db.Posts.First(p => p.TenantId == tenantId); // typed model, direct DB
```

**AF-4 RAG Retrieval Tags:** `#data-binding`, `#jsonpath`, `#template-mode`, `#cms-integration`, `#content-fallback`

---

## SKILL: SK-165 — BreakpointResolverService

**Purpose:** Store and apply per-breakpoint style patch documents. Use AiDispatcher for AI-assisted responsive suggestions. Merge base style + breakpoint overrides.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-2, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
StoreBreakpointPatch(tenantId, nodeId, breakpoint, patch: Dictionary<string,object>) → DataProcessResult<string>
ApplyBreakpointOverrides(tenantId, nodeId, activeBreakpoint) → DataProcessResult<Dictionary<string,object>>
SuggestBreakpointOverrides(tenantId, baseStyle: Dictionary<string,object>) → DataProcessResult<List<Dictionary<string,object>>>
MergeBaseAndPatch(base: Dictionary<string,object>, patch: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
```

**Pattern:**
```csharp
// CORRECT — patch is Dictionary, merge returns DataProcessResult
var basePatch = await GetBreakpointPatch(tenantId, nodeId, "desktop");
var mobilePatch = await GetBreakpointPatch(tenantId, nodeId, "mobile");
var merged = MergeBaseAndPatch(basePatch.Data, mobilePatch.Data);
return DataProcessResult<Dictionary<string,object>>.Success(merged.Data);
```

**AF-4 RAG Retrieval Tags:** `#breakpoint`, `#responsive-design`, `#style-patches`, `#ai-layout-suggestion`

---

## SKILL: SK-166 — ThemeTokenService

**Purpose:** Manage global design tokens (colors, fonts, spacing) in Elasticsearch. Propagate token changes to all referencing nodes via QUEUE FABRIC. Sync tokens to external applications.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-2, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
StoreToken(tenantId, tokenKey, value: Dictionary<string,object>) → DataProcessResult<string>
GetToken(tenantId, tokenKey) → DataProcessResult<Dictionary<string,object>>
GetAllTokens(tenantId) → DataProcessResult<List<Dictionary<string,object>>>
PropagateTokenUpdate(tenantId, tokenKey) → DataProcessResult<int> // returns affected node count
ExportTokensToFormat(tenantId, format: string) → DataProcessResult<string> // CSS/Tailwind/style-dictionary
```

**Pattern:**
```csharp
// CORRECT — token stored via DATABASE FABRIC, propagation via QUEUE FABRIC
await _db.StoreDocument(BuildSearchFilter(new { tenantId, tokenKey }), tokenDoc);
await _queue.EnqueueAsync("token-updates", CloudEventsEnvelope(tenantId, "TOKEN_UPDATED", tokenDoc));

// WRONG
// const colors = { primary: "#007bff" }; // hardcoded values — BUILD FAILURE
```

**AF-4 RAG Retrieval Tags:** `#design-tokens`, `#theme-sync`, `#css-variables`, `#token-propagation`

---

## SKILL: SK-167 — RoleLockService

**Purpose:** Enforce designer/editor/admin role boundaries on canvas operations. Integrate with OIDC/SCIM tenant identity via F724. Role context comes from MicroserviceBase auth context only.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
GetUserRole(tenantId, userId) → DataProcessResult<string>
CanEditLayout(tenantId, userId, nodeId) → DataProcessResult<bool>
CanEditContent(tenantId, userId, nodeId) → DataProcessResult<bool>
CanPublish(tenantId, userId) → DataProcessResult<bool>
EnforceRoleOnWrite(tenantId, userId, nodeId, changeType) → DataProcessResult<bool>
```

**Pattern:**
```csharp
// CORRECT — role from auth context, never from request body
var role = _authContext.GetClaim("role"); // MicroserviceBase auth context
var constraint = await _constraintSvc.GetConstraints(tenantId, nodeId);
if ((bool)constraint["lockLayout"] && role != "DESIGNER")
    return DataProcessResult<bool>.Failure("Unauthorized: layout locked");
return DataProcessResult<bool>.Success(true);
```

**AF-4 RAG Retrieval Tags:** `#role-based-access`, `#lock-layout`, `#designer-editor-boundary`, `#oidc`

---

## SKILL: SK-168 — FlowStateMachineService

**Purpose:** Manage canvas flow state machine lifecycle (Designing → Review → Published). Store state in PostgreSQL via DATABASE FABRIC. Emit state transition events via QUEUE FABRIC. Enforce guard conditions.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
GetCurrentState(tenantId, flowId) → DataProcessResult<string>
TransitionState(tenantId, flowId, event: string, guards: Dictionary<string,object>) → DataProcessResult<string>
GetAllowedTransitions(tenantId, flowId) → DataProcessResult<List<string>>
EmitTransitionEvent(tenantId, flowId, fromState, toState) → DataProcessResult<bool>
RollbackState(tenantId, flowId) → DataProcessResult<string>
```

**Pattern:**
```csharp
// CORRECT — state stored via DATABASE FABRIC (PG), events via QUEUE FABRIC
var current = await _db.SearchDocuments(BuildSearchFilter(new { tenantId, flowId }));
if (!IsTransitionAllowed(currentState, targetEvent, guards))
    return DataProcessResult<string>.Failure("Transition not allowed in current state");
await _db.StoreDocument(stateDoc); // PostgreSQL via DATABASE FABRIC
await _queue.EnqueueAsync("flow-state", CloudEventsEnvelope(tenantId, "STATE_TRANSITIONED", event));
```

**AF-4 RAG Retrieval Tags:** `#state-machine`, `#flow-lifecycle`, `#transitions`, `#guard-conditions`

---

## SKILL: SK-169 — UICodeExportService

**Purpose:** Transform node tree to production-ready React/Angular/Vue/Tailwind code using AiDispatcher multi-model consensus. Run AF-6 code review and AF-7 DNA compliance. Store in artifact registry via DATABASE FABRIC.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
ExportToFramework(tenantId, canvasId, framework: string) → DataProcessResult<Dictionary<string,object>>
ReviewGeneratedCode(tenantId, artifactId) → DataProcessResult<Dictionary<string,object>>
StoreArtifact(tenantId, artifact: Dictionary<string,object>) → DataProcessResult<string>
RollbackArtifact(tenantId, artifactId, targetVersion) → DataProcessResult<bool>
ExportDesignTokens(tenantId, format: string) → DataProcessResult<string>
```

**Pattern:**
```csharp
// CORRECT — AI via IAiProvider, framework via F728 adapter (config-driven)
var codeResult = await _aiProvider.GenerateAsync(BuildExportPrompt(nodeTree, framework));
// framework = config["export.framework"], never hardcoded "React"
var reviewed = await _reviewSvc.ReviewCode(codeResult);
if (reviewed.QualityScore < 0.8)
    return DataProcessResult<Dictionary<string,object>>.Failure("Quality gate not met");
await _db.StoreDocument(BuildArtifactDoc(tenantId, codeResult));

// WRONG
// var code = OpenAI.Chat("generate react code..."); // direct provider import
```

**AF-4 RAG Retrieval Tags:** `#code-export`, `#react`, `#tailwind`, `#multi-model-generation`, `#artifact-registry`

---

## SKILL: SK-170 — TenantIsolationHardeningService

**Purpose:** Full multi-tenant hardening suite. Tenant ID validation, quota enforcement, CloudEvents envelopes, idempotency store, tier graduation (pool/silo/bridge), OIDC/SCIM, PITR restore, OTLP telemetry.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-2, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
ValidateTenantContext(tenantId, requestContext: Dictionary<string,object>) → DataProcessResult<bool>
EnforceQuota(tenantId, quotaType: string) → DataProcessResult<bool>
WrapInCloudEventsEnvelope(tenantId, eventType, payload: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
CheckIdempotencyKey(tenantId, key: string) → DataProcessResult<bool>
GraduateTenantTier(tenantId, targetTier: string) → DataProcessResult<bool>
EmitTenantTelemetry(tenantId, metric: Dictionary<string,object>) → DataProcessResult<bool>
```

**OWASP Compliance:**
- API1 (BOLA/IDOR): `ValidateTenantContext` checks on every object-ID endpoint
- API4 (Resource Abuse): `EnforceQuota` blocks over-limit requests
- API6 (Sensitive Flow Abuse): quota types include `CANVAS_NODES`, `FLOW_RUNS`, `EXPORTS`
- API7 (SSRF): URL-fetching steps use allowlist via MicroserviceBase config

**AF-4 RAG Retrieval Tags:** `#multi-tenant`, `#quota-enforcement`, `#cloud-events`, `#idempotency`, `#owasp`, `#tenant-tiering`

---

## SKILL: SK-171 — CanvasCollaborationService

**Purpose:** Real-time multi-user canvas collaboration via QUEUE FABRIC (Redis Streams consumer groups). Publish/subscribe to canvas operation events. Conflict resolution for concurrent edits. Presence tracking.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
JoinCanvas(tenantId, canvasId, userId) → DataProcessResult<string> // consumer group registration
PublishOperation(tenantId, canvasId, operation: Dictionary<string,object>) → DataProcessResult<bool>
SubscribeOperations(tenantId, canvasId) → DataProcessResult<List<Dictionary<string,object>>>
ResolveConflict(tenantId, op1: Dictionary<string,object>, op2: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
TrackPresence(tenantId, canvasId, userId) → DataProcessResult<bool>
```

**Pattern:**
```csharp
// CORRECT — collaboration via QUEUE FABRIC (Redis Streams), never WebSocket directly
await _queue.EnqueueAsync($"canvas-ops-{canvasId}", CloudEventsEnvelope(tenantId, "NODE_MOVED", op));
// WRONG
// WebSocketHub.Broadcast(userId, op); // direct socket — violates QUEUE FABRIC pattern
```

**AF-4 RAG Retrieval Tags:** `#real-time-collaboration`, `#redis-streams`, `#canvas-events`, `#conflict-resolution`, `#presence`

---

## SKILL: SK-172 — FlowSandboxService

**Purpose:** Provide isolated sandbox execution for generated canvas flows. Run flows in tenant-scoped sandbox before promotion. Sandbox state in Redis hot state. Results never contaminate production canvas.

**Extends:** MicroserviceBase (DNA-4)
**Returns:** `DataProcessResult<T>` always (DNA-3)
**DNA Compliance:** DNA-1, DNA-3, DNA-4, DNA-5

**Key Methods:**
```
CreateSandbox(tenantId, canvasId) → DataProcessResult<string> // sandboxId
ExecuteInSandbox(tenantId, sandboxId, flowDefinition: Dictionary<string,object>) → DataProcessResult<Dictionary<string,object>>
GetSandboxResult(tenantId, sandboxId) → DataProcessResult<Dictionary<string,object>>
PromoteSandboxToProduction(tenantId, sandboxId, canvasId) → DataProcessResult<bool>
DestroySandbox(tenantId, sandboxId) → DataProcessResult<bool>
```

**Pattern:**
```csharp
// CORRECT — sandbox state in Redis (F698), never writes to production ES (F697)
var sandboxState = await _redis.GetAsync($"sandbox:{tenantId}:{sandboxId}");
var result = await ExecuteFlow(flowDef, sandboxState); // isolated execution
await _redis.SetAsync($"sandbox-result:{tenantId}:{sandboxId}", result);
// Production only updated on explicit promotion
```

**AF-4 RAG Retrieval Tags:** `#sandbox`, `#flow-testing`, `#isolation`, `#promotion-ladder`, `#canvas-preview`

---

## AF-4 RAG INDEX — FLOW-19 ADDITIONS

| Tag | Skills | Task Types | Use When |
|-----|--------|------------|----------|
| `#node-tree` | SK-161 | T269, T273 | Persisting or querying canvas node hierarchies |
| `#layout-solver` | SK-162 | T271, T276 | Computing Flex/Grid bounding boxes |
| `#constraint-evaluation` | SK-163 | T277 | Enforcing lock/allow constraints on nodes |
| `#data-binding` | SK-164 | T278, T280 | Binding CMS fields to canvas nodes |
| `#template-mode` | SK-164 | T279 | Design-time live content preview |
| `#breakpoint` | SK-165 | T272, T274 | Responsive style patch management |
| `#design-tokens` | SK-166 | T275, T286 | Global design token propagation |
| `#role-based-access` | SK-167 | T277, T282 | Designer/editor role enforcement |
| `#state-machine` | SK-168 | T288 | Flow lifecycle (Designing→Published) |
| `#code-export` | SK-169 | T285, T286, T287 | AI-generated frontend code from node tree |
| `#multi-tenant` | SK-170 | T282, T283, T284 | Tenant isolation, quotas, CloudEvents |
| `#real-time-collaboration` | SK-171 | T269, T270 | Multi-user canvas editing |
| `#sandbox` | SK-172 | T279, T288 | Safe flow testing before production |

---

## SAVE POINT: FLOW19:SKILLS_FACTORY_RAG ✅
## Next: V62_BFA_STRESS_TEST delta (CF-329–CF-348, ST-184–ST-198)
