# XIIGen V62 BFA STRESS TEST — FLOW-19: Visual Editor Extended
## Delta File — CF-329–CF-348 (20 conflict rules), ST-184–ST-198 (15 stress tests)
## Extends: V62_BFA_STRESS_TEST_MERGED.md (CF-1–CF-328, ST-1–ST-183)

---

## FLOW-19 BFA CONFLICT RULES (CF-329–CF-348)

### CF-329 — Canvas Node ID vs FLOW-02 Content Template ID Collision
**Rule:** Canvas node IDs (F697 Elasticsearch documents) must not collide with FLOW-02 content template document IDs.
**Detection:** BFA compares `nodeId` prefix format against FLOW-02 `templateId` prefix. Canvas uses `canvas_<tenantId>_<uuid>`. FLOW-02 uses `template_<tenantId>_<uuid>`.
**Resolution:** Enforce prefix namespacing at F697 StoreDocument call. Reject node documents without `canvas_` prefix.
**Severity:** HIGH — collision would cause content template to be overwritten by canvas node
**Flows Affected:** FLOW-02, FLOW-19
**Guardrail:** T282 (tenant isolation gate) checks prefix before T269 executes

---

### CF-330 — tenantId Canvas Queries vs FLOW-01 User Registration Tenant Boundary
**Rule:** Canvas queries via F697/F698 must use the same `tenantId` scope as FLOW-01 user registration. A user authenticated in FLOW-01 must not access another tenant's canvas.
**Detection:** BFA validates that `tenantId` in canvas operations matches the JWT claim `tenantId` from FLOW-01 auth context.
**Resolution:** F719 (`ITenantIsolationEnforcerService`) extracts `tenantId` from MicroserviceBase auth context — never from request body.
**Severity:** CRITICAL — cross-tenant canvas exposure is OWASP API1 (BOLA)
**Flows Affected:** FLOW-01, FLOW-19
**Guardrail:** T282 IRON RULE 1 — BUILD FAILURE if tenantId missing or mismatched

---

### CF-331 — Symbol Name vs FLOW-02 Content Template Name Collision
**Rule:** Symbol library names (F699) must not share names with FLOW-02 content template names. Both stored in Elasticsearch and queried by name.
**Detection:** BFA indexes all FLOW-02 template names and all FLOW-19 symbol names. Alerts on exact name match.
**Resolution:** Symbol names prefixed with `sym_`. Content templates prefixed with `tpl_`.
**Severity:** MEDIUM — name collision causes wrong template/symbol resolution in mixed queries
**Flows Affected:** FLOW-02, FLOW-19
**Guardrail:** T270 validation before symbol store

---

### CF-332 — Symbol Update Events vs FLOW-04 Notification Events — Redis Stream Collision
**Rule:** Symbol update events published to Redis Streams via F704 must use a distinct consumer group key from FLOW-04 notification pipeline events.
**Detection:** BFA scans Redis Stream group names. FLOW-04 uses `notifications-*`. FLOW-19 must use `canvas-ops-*`.
**Resolution:** F704 stream key: `canvas-ops-{canvasId}`. F702 collaboration stream: `canvas-collab-{canvasId}`. FLOW-04 stream: `notifications-{userId}`.
**Severity:** HIGH — stream key collision causes notification events routed to canvas consumer
**Flows Affected:** FLOW-04, FLOW-19
**Guardrail:** T283 CloudEvents envelope gate verifies stream key prefix

---

### CF-333 — Layout Solver Output vs FLOW-09 Search Result Documents
**Rule:** Layout solver result documents (F705 → F697 ES) must not use document IDs that match FLOW-09 search result document IDs.
**Detection:** Layout results stored with prefix `layout_result_<canvasId>`. FLOW-09 search results stored with `search_result_<queryId>`.
**Resolution:** Enforce prefix namespacing at layout result StoreDocument.
**Severity:** MEDIUM — overwriting search results with layout data would corrupt FLOW-09
**Flows Affected:** FLOW-09, FLOW-19

---

### CF-334 — Snap Guide Events vs FLOW-12 Chat Event Stream Keys
**Rule:** Canvas snap/alignment events (F710 via QUEUE FABRIC) must not collide with FLOW-12 chat event stream keys.
**Detection:** BFA compares Redis Stream key prefixes. Canvas uses `canvas-align-*`. Chat uses `chat-events-*`.
**Resolution:** T276 validation confirms stream key namespace before publishing.
**Severity:** LOW — collision would mix layout events with chat events; detectable but noisy
**Flows Affected:** FLOW-12, FLOW-19

---

### CF-335 — Breakpoint Patch Documents vs FLOW-13 AI Content Style Documents
**Rule:** Breakpoint patch documents (F707 Elasticsearch) must not share index names with FLOW-13 AI content pipeline style documents.
**Detection:** F707 writes to `canvas-breakpoints-{tenantId}` index. FLOW-13 writes to `ai-content-style-{tenantId}` index.
**Resolution:** Enforce index naming convention at F707 StoreDocument.
**Severity:** MEDIUM — index name collision causes breakpoint patches to overwrite AI content styles
**Flows Affected:** FLOW-13, FLOW-19

---

### CF-336 — Canvas Version IDs vs FLOW-18 Flow Version IDs
**Rule:** Canvas version IDs (F701 PostgreSQL) must not collide with FLOW-18 visual flow version IDs.
**Detection:** BFA cross-references PostgreSQL version tables. Canvas version: `cv_<canvasId>_<int>`. FLOW-18 version: `fv_<flowId>_<int>`.
**Resolution:** Enforce prefix at F701 StoreDocument. FLOW-18 prefix: `fv_`. FLOW-19 prefix: `cv_`.
**Severity:** HIGH — version ID collision would corrupt rollback operations in both flows
**Flows Affected:** FLOW-18, FLOW-19

---

### CF-337 — AI Layout Advisor Output vs Factory Dependency Injection
**Rule:** AI layout advisor (F706 / T274) must not inject new factory dependencies not registered in F697–F733 into generated canvas services.
**Detection:** AF-9 Judge scans AI layout suggestions for factory interface references. Any interface not in F697–F733 or F1–F696 registry → BUILD FAILURE.
**Resolution:** Layout advisor prompts include explicit factory registry constraint. AF-9 rejects suggestions with unregistered factories.
**Severity:** CRITICAL — unregistered factory would bypass fabric resolution and import providers directly
**Flows Affected:** FLOW-19 (internal)

---

### CF-338 — Token Sync Events vs FLOW-13 AI Content Style Events — Redis Stream Collision
**Rule:** Design token propagation events (F704 Redis Streams) must not collide with FLOW-13 AI content pipeline style events.
**Detection:** Token events use stream `canvas-tokens-{tenantId}`. FLOW-13 uses `ai-content-{tenantId}`.
**Resolution:** F729 token sync events published to `canvas-tokens-*` stream group only.
**Severity:** MEDIUM
**Flows Affected:** FLOW-13, FLOW-19

---

### CF-339 — Z-Index State vs FLOW-18 Layer Ordering Documents
**Rule:** Z-index state documents in Redis (F711) must not overwrite FLOW-18 layer ordering documents.
**Detection:** F711 uses Redis key `canvas-zindex-{canvasId}-{nodeId}`. FLOW-18 uses `flow-layer-{flowId}-{nodeId}`.
**Resolution:** Enforce key prefix namespacing in F711.
**Severity:** MEDIUM
**Flows Affected:** FLOW-18, FLOW-19

---

### CF-340 — Constraint Rules vs FLOW-01 Permission Model for User Roles
**Rule:** Canvas constraint role names (designer/editor/admin) must align with FLOW-01 user registration role definitions.
**Detection:** BFA compares role enum values in FLOW-01 user role registry against FLOW-19 constraint role values.
**Resolution:** Canvas role values sourced from FLOW-01 role registry — no custom role string literals in FLOW-19.
**Severity:** HIGH — role name mismatch would make constraint enforcement silently fail
**Flows Affected:** FLOW-01, FLOW-19

---

### CF-341 — CMS Binding Queries vs FLOW-02 Content Management Queries — ES Index Collision
**Rule:** F712 CMS binding queries must not target the same ES index as FLOW-02 content management service.
**Detection:** BFA checks Elasticsearch index names used by F712. Must be read-only access to FLOW-02 content index. No writes from FLOW-19 data binding service.
**Resolution:** F712 is READ-ONLY against FLOW-02 content indices. Template Mode (F713) also read-only.
**Severity:** HIGH — FLOW-19 writes to FLOW-02 content index would corrupt content management
**Flows Affected:** FLOW-02, FLOW-19
**Guardrail:** T279 IRON RULE 1 — Template Mode READ-ONLY

---

### CF-342 — AI Fallback Jobs vs FLOW-13 AI Content Pipeline Jobs — Queue Collision
**Rule:** AI content fallback jobs (F714 via AI ENGINE FABRIC) must not collide with FLOW-13 AI content pipeline jobs on the same AiDispatcher queue.
**Detection:** F714 jobs carry `jobType: CANVAS_FALLBACK`. FLOW-13 jobs carry `jobType: CONTENT_PIPELINE`. AiDispatcher routes by jobType.
**Resolution:** AiDispatcher routing config registers `CANVAS_FALLBACK` as FLOW-19 job type. FLOW-13 types: `CONTENT_PIPELINE`, `BLOG_GENERATION`.
**Severity:** MEDIUM — job type collision could route fallback responses to content pipeline consumers
**Flows Affected:** FLOW-13, FLOW-19

---

### CF-343 — Template Mode Preview vs FLOW-02 Production Content Indices
**Rule:** Template Mode (F713) must never write to FLOW-02 production content ES indices. Preview state is session-isolated in Redis (F698).
**Detection:** AF-8 Security scan traces all write operations from F713. Any write to `content-*` ES index → BUILD FAILURE.
**Resolution:** F713 operations: read from FLOW-02 content index; write preview state to Redis `canvas-preview-*` key only.
**Severity:** CRITICAL — preview writes to production would corrupt live content
**Flows Affected:** FLOW-02, FLOW-19

---

### CF-344 — Repeater Queries vs FLOW-09 Search Discovery Queries — ES Index Collision
**Rule:** Repeater executor (F715) queries must not conflict with FLOW-09 search & discovery queries on the same Elasticsearch index.
**Detection:** F715 repeater queries target `content-{tenantId}` index (read-only). FLOW-09 also reads `content-{tenantId}`. Conflict possible if both modify `_source` or `sort` in incompatible ways.
**Resolution:** F715 uses dedicated query template with `BuildSearchFilter`. No index-altering operations. No field mappings changes.
**Severity:** LOW — performance conflict possible; data integrity not at risk if both read-only
**Flows Affected:** FLOW-09, FLOW-19

---

### CF-345 — Binding Validator vs Unknown Skill Output Paths from FLOW-01–FLOW-18
**Rule:** Binding validator (F717) must recognize all skill output paths registered in FLOW-01–FLOW-18. Any `$.skill_XX.field` path where XX is from a completed flow must resolve against that flow's output schema.
**Detection:** BFA maintains skill output schema registry from FLOW-01–FLOW-18. F717 validates against this registry.
**Resolution:** Skill output schema registry updated as part of each FLOW delta. FLOW-19 registers SK-161–SK-172 output schemas.
**Severity:** HIGH — unrecognized binding path returns silent null; AF-9 catches but designer experience degrades
**Flows Affected:** All FLOW-01–FLOW-19

---

### CF-346 — Tenant Isolation Gate Must Precede ALL FLOW-19 Task Type Executions
**Rule:** T282 (Tenant Isolation Enforcement Gate) must be the first step in every FLOW-19 DAG execution. No T269–T288 may execute before T282 passes.
**Detection:** BFA validates flow template step ordering. Step 1 must always be T282.
**Resolution:** FlowOrchestrator enforces T282 as pre-condition hook for all FLOW-19 templates (56–61).
**Severity:** CRITICAL — missing T282 means tenant isolation not enforced; OWASP API1 exposure
**Flows Affected:** FLOW-19 (internal)
**Guardrail:** T288 IRON RULE 1

---

### CF-347 — FLOW-19 Quotas vs FLOW-15 DevOps Quotas — Same Tenant
**Rule:** FLOW-19 canvas quotas (F720) and FLOW-15 DevOps pipeline quotas must not double-count against the same tenant's resource limit.
**Detection:** BFA checks quota counter keys. F720 uses `quota:canvas:{tenantId}:{type}`. FLOW-15 uses `quota:devops:{tenantId}:{type}`. No shared counter key.
**Resolution:** Quota counter keys namespaced by flow domain. Total quota = sum of domain quotas. No shared counter.
**Severity:** MEDIUM — double-counting would unfairly throttle tenants using both FLOW-15 and FLOW-19
**Flows Affected:** FLOW-15, FLOW-19

---

### CF-348 — FLOW-19 Artifact IDs vs FLOW-18 Code Injection Artifacts
**Rule:** FLOW-19 code export artifact IDs (F731 Elasticsearch) must not collide with FLOW-18 code injection artifact IDs.
**Detection:** BFA compares artifact ID prefixes. FLOW-18: `inject_artifact_<flowId>_<uuid>`. FLOW-19: `canvas_artifact_<canvasId>_<uuid>`.
**Resolution:** F731 enforces `canvas_artifact_` prefix at StoreDocument.
**Severity:** HIGH — artifact ID collision would cause wrong code version deployed from rollback
**Flows Affected:** FLOW-18, FLOW-19

---

## STRESS TESTS — FLOW-19 (ST-184–ST-198)

### ST-184 — Concurrent Multi-Tenant Canvas Operations
**Scenario:** 100 concurrent users from 10 different tenants all editing their canvases simultaneously.
**Test Steps:**
1. 100 threads, each with unique `tenantId`, each executing T288 full flow DAG
2. All threads access same Elasticsearch cluster via F697
3. Assert: zero cross-tenant node visibility
4. Assert: all T282 tenant isolation gates pass independently
5. Assert: Redis hot state (F698) keys correctly namespaced per tenant
**Expected Result:** All 100 operations succeed independently; zero cross-tenant leakage
**BFA Rules Exercised:** CF-330, CF-346

---

### ST-185 — Canvas Node ID Collision Attack
**Scenario:** Malicious request attempts to create a canvas node with FLOW-02 content template ID format.
**Test Steps:**
1. POST canvas node with `nodeId: "template_tenant_abc_1234"` (FLOW-02 format)
2. T282 → T269 pipeline executes
3. Assert: F697 StoreDocument rejects document without `canvas_` prefix
4. Assert: `DataProcessResult.Failure` returned; no document written
**Expected Result:** CF-329 protection rejects the malicious ID
**BFA Rules Exercised:** CF-329

---

### ST-186 — Layout Solver Determinism Under 1000 Node Tree
**Scenario:** Node tree with 1000 nested nodes (10 levels × 10 children).
**Test Steps:**
1. Create canvas with 1000-node tree via F697
2. Execute T271 layout solver 5 times with identical input
3. Assert: all 5 outputs are byte-identical (deterministic)
4. Assert: `DataProcessResult<T>` returned; no exceptions
5. Measure: execution time < 5 seconds
**Expected Result:** Deterministic layout; performance acceptable
**BFA Rules Exercised:** CF-333 (layout output IDs correct)

---

### ST-187 — Breakpoint Override Stack: 10 Breakpoints
**Scenario:** Node with 10 custom breakpoint overrides; resolve for each breakpoint.
**Test Steps:**
1. Store node with base style + 10 breakpoint patches via F707
2. Resolve for each breakpoint
3. Assert: correct patch applied at each breakpoint
4. Assert: patches do not bleed between breakpoints
5. Assert: AI suggestion via F706 invoked when suggestion requested
**Expected Result:** Correct patch per breakpoint; no cross-breakpoint contamination
**BFA Rules Exercised:** CF-335

---

### ST-188 — Template Mode Preview: Does Not Contaminate Production
**Scenario:** Designer activates Template Mode, edits preview content, deactivates.
**Test Steps:**
1. Activate Template Mode via F713; fetch 5 live posts from FLOW-02 content index
2. Simulate editing post title in preview
3. Assert: edit stored in Redis `canvas-preview-*` key only
4. Assert: FLOW-02 content ES index unchanged
5. Deactivate Template Mode; assert canvas returns to pre-preview state
**Expected Result:** Zero production content mutation
**BFA Rules Exercised:** CF-341, CF-343

---

### ST-189 — Quota Enforcement: Canvas Node Limit
**Scenario:** Tenant at node quota limit attempts to add one more node.
**Test Steps:**
1. Set tenant `quota:canvas:{tenantId}:CANVAS_NODES` = limit
2. Execute T269 node tree composition (add one node)
3. Assert: T282 quota check returns `DataProcessResult.Failure(QuotaExceeded)`
4. Assert: no node written to F697
5. Assert: idempotency key registered for this attempt
**Expected Result:** Hard quota rejection; no partial write
**BFA Rules Exercised:** CF-347 (quota not shared with FLOW-15)

---

### ST-190 — CloudEvents Envelope: Deduplication Under Retry
**Scenario:** Canvas operation event published 3 times with same `Idempotency-Key` (network retry scenario).
**Test Steps:**
1. Publish canvas event with `Idempotency-Key: abc123` via F721
2. Publish same event twice more (simulating retries)
3. Assert: consumer receives exactly 1 event
4. Assert: F722 idempotency store has key `abc123` with TTL
5. Assert: side effects (node update) executed exactly once
**Expected Result:** Exactly-once semantics; no duplicate side effects
**BFA Rules Exercised:** CF-332, CF-348

---

### ST-191 — Role Lock Enforcement: Editor Cannot Modify Locked Layout
**Scenario:** Content editor attempts to modify padding on a node with `lockLayout:true`.
**Test Steps:**
1. Create node with `constraints.lockLayout: true` via F697
2. Authenticated as EDITOR role (from MicroserviceBase auth context)
3. Attempt padding change via T277 constraint gate
4. Assert: `DataProcessResult.Failure("Layout locked")` returned
5. Assert: node document in ES unchanged
6. Switch to DESIGNER role; same padding change
7. Assert: change accepted and stored
**Expected Result:** Strict role boundary enforced
**BFA Rules Exercised:** CF-340

---

### ST-192 — Symbol Propagation: 500 Instances
**Scenario:** Update a shared Symbol (blog card) that has 500 instances across 10 canvases.
**Test Steps:**
1. Create symbol with 500 instance references via F699
2. Update symbol title binding via T270
3. Assert: propagation event published to `canvas-ops-*` stream via F704
4. Assert: all 500 instances receive update event within 10 seconds
5. Assert: FLOW-04 notification stream not polluted
**Expected Result:** Full propagation; no FLOW-04 stream collision
**BFA Rules Exercised:** CF-331, CF-332

---

### ST-193 — Code Export Quality Gate Failure
**Scenario:** AI generates code with a typed model (violates DNA-1). AF-9 must reject.
**Test Steps:**
1. Prime AiDispatcher to return code containing `public class NodeDTO { string NodeId; }`
2. Execute T285 code export pipeline
3. AF-7 DNA compliance check runs
4. Assert: AF-9 rejects with quality score < 0.8
5. Assert: artifact not stored in F731
6. Assert: `DataProcessResult.Failure("DNA-1 violation: typed model detected")` returned
**Expected Result:** DNA-1 violation caught before artifact storage
**BFA Rules Exercised:** CF-337, CF-348

---

### ST-194 — Tenant Tier Graduation: Pool → Bridge
**Scenario:** Tenant graduates from shared schema to separate schema (bridge model).
**Test Steps:**
1. Tenant `tenant_enterprise_001` at pool tier; active canvas operations running
2. Trigger tier graduation via T284 (F723)
3. Assert: in-flight canvas operations complete before migration lock
4. Assert: all canvas data migrated to tenant-specific schema
5. Assert: post-migration T282 validation passes with new schema
6. Assert: zero cross-tenant data exposure post-migration
**Expected Result:** Zero-downtime migration; isolation improved post-graduation
**BFA Rules Exercised:** CF-346, CF-347

---

### ST-195 — Binding Path Validation: Cross-Flow Skill References
**Scenario:** Designer enters binding path `$.skill_05.latest_post.title` (valid FLOW-02 CMS output).
**Test Steps:**
1. Submit binding path to T281 binding validator via F717
2. F717 queries RAG FABRIC for skill output schema
3. Assert: path `$.skill_05.latest_post.title` recognized as valid FLOW-02 output
4. Submit invalid path `$.skill_99.nonexistent.field`
5. Assert: rejected with descriptive error, `DataProcessResult.Failure`
**Expected Result:** Valid cross-flow skill paths accepted; invalid paths rejected
**BFA Rules Exercised:** CF-345

---

### ST-196 — Collaborative Editing: Concurrent Node Move Conflict
**Scenario:** Two designers move the same node simultaneously; conflict must resolve deterministically.
**Test Steps:**
1. Two users join same canvas via F702
2. Both submit `NODE_MOVED` operations for `node_abc` at same timestamp
3. Assert: SK-171 conflict resolution picks last-writer-wins or merge strategy
4. Assert: resolved state stored in F697 via DATABASE FABRIC
5. Assert: both users receive the resolved state via F704 stream
**Expected Result:** Conflict resolved deterministically; no divergent canvas states
**BFA Rules Exercised:** CF-332, CF-334

---

### ST-197 — Sandbox Flow Execution: Does Not Contaminate Production
**Scenario:** Flow executed in sandbox; result promoted to production.
**Test Steps:**
1. Create sandbox via SK-172 (F698 Redis)
2. Execute T288 full flow DAG in sandbox
3. Assert: no writes to F697 production Elasticsearch during sandbox execution
4. Assert: sandbox result stored in `canvas-preview-*` Redis key
5. Promote sandbox to production via `PromoteSandboxToProduction`
6. Assert: promoted canvas state correctly written to F697 production index
**Expected Result:** Sandbox fully isolated until explicit promotion
**BFA Rules Exercised:** CF-343, CF-346

---

### ST-198 — Design Token Update: Cascading Propagation Accuracy
**Scenario:** Update primary color token; verify all 1000 referencing nodes receive update.
**Test Steps:**
1. Store 1000 canvas nodes all referencing `token:primary-color` via F697
2. Update `primary-color` token value via F729
3. T275 design token sync executes
4. Assert: propagation event published to `canvas-tokens-{tenantId}` stream
5. Assert: all 1000 node documents updated within 30 seconds
6. Assert: FLOW-13 AI content style stream not polluted (CF-338)
7. Assert: F728 framework adapter generates correct CSS variable output
**Expected Result:** Complete, accurate token propagation; no stream collisions
**BFA Rules Exercised:** CF-338

---

## SAVE POINT: FLOW19:BFA_STRESS_TEST ✅
## Next: UNIFIED_SOURCE_INDEX delta (DD-149–DD-163, DR-111–DR-122)
