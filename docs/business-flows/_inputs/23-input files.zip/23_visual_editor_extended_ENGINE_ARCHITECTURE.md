# XIIGen ENGINE ARCHITECTURE — FLOW-19: Visual Editor Extended
## Delta File — FLOW-19 only (F697–F733, Families 94–98, DR-111–DR-122)
## Extends: ENGINE_ARCHITECTURE_MERGED.md (F1–F696, Families 1–93)

---

## FLOW-19 OVERVIEW

| Field | Value |
|-------|-------|
| Flow ID | FLOW-19 |
| Domain | Visual Editor Extended — UI Composition, Layout Engine, Data Binding, Multi-Tenant Hardening, Code Export |
| Factories | F697–F733 (37 factories) |
| Families | 94–98 (5 new families) |
| Task Types | T269–T288 (see TASK_TYPES_CATALOG delta) |
| Skills | SK-161–SK-172 (see SKILLS_FACTORY_RAG delta) |
| Design Records | DR-111–DR-122 |
| Backward Compatibility | FLOW-01–FLOW-18 fully preserved |

---

## FACTORY REGISTRY — FLOW-19

### FAMILY 94 — Visual Canvas Core
**Fabric Anchor:** DATABASE FABRIC (Skill 05) + FLOW ENGINE FABRIC (Skills 08/09)
**Purpose:** Node tree persistence, canvas state management, symbol library, component variants, versioning, collaboration, layer management, canvas event bus

| Factory ID | Interface | Fabric Resolution | Provider |
|------------|-----------|-------------------|----------|
| F697 | INodeTreeService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F698 | ICanvasStateService | DATABASE FABRIC (Skill 05) | Redis (hot state) |
| F699 | ISymbolLibraryService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F700 | IComponentVariantService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F701 | ICanvasVersionService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F702 | ICanvasCollaborationService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F703 | ILayerTreeService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F704 | ICanvasEventBusService | QUEUE FABRIC (Skill 04) | Redis Streams |

**Family 94 Fabric Notes:**
- F697 stores node trees as `Dictionary<string,object>` documents — DNA-1 enforced
- F698 uses Redis as hot-path canvas state; falls back to ES on miss
- F702/F704 use Redis Streams consumer groups for real-time collaboration events
- ALL CreateAsync() resolutions use config-first routing — never import ES/Redis directly

---

### FAMILY 95 — Layout Engine
**Fabric Anchor:** CORE FABRIC (Skill 01) + AI ENGINE FABRIC (Skills 06/07)
**Purpose:** Flex/Grid layout solving, breakpoint resolution, responsive override management, alignment/snapping calculation, constraint evaluation, z-index management, overflow rules

| Factory ID | Interface | Fabric Resolution | Provider |
|------------|-----------|-------------------|----------|
| F705 | ILayoutSolverService | CORE FABRIC (Skill 01) | MicroserviceBase |
| F706 | IBreakpointResolverService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F707 | IResponsiveOverrideService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F708 | IAlignmentCalculatorService | CORE FABRIC (Skill 01) | MicroserviceBase |
| F709 | IConstraintEvaluatorService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F710 | ISnapGuideService | CORE FABRIC (Skill 01) | MicroserviceBase |
| F711 | IZIndexManagerService | DATABASE FABRIC (Skill 05) | Redis |

**Family 95 Fabric Notes:**
- F705 layout solver runs as pure computation on top of MicroserviceBase — no external provider
- F706 uses AiDispatcher for AI-assisted responsive layout suggestions (multi-model consensus)
- F707 stores breakpoint patch documents as `Dictionary<string,object>` — base style + per-breakpoint override patches
- F709 evaluates `lockLayout` / `allowContentEdit` constraint flags stored in ES

---

### FAMILY 96 — Data Binding Bridge
**Fabric Anchor:** DATABASE FABRIC (Skill 05) + RAG FABRIC (Skills 00a/00b) + AI ENGINE FABRIC (Skill 07)
**Purpose:** CMS field binding to UI nodes, template mode / preview mode, content fallback handling, repeater/loop execution, data context propagation, binding validation

| Factory ID | Interface | Fabric Resolution | Provider |
|------------|-----------|-------------------|----------|
| F712 | IDataBindingService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F713 | ITemplateModeService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F714 | IContentFallbackService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F715 | IRepeaterExecutorService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F716 | IDataContextPropagatorService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F717 | IBindingValidatorService | RAG FABRIC (Skill 00b) | Hybrid strategy |
| F718 | IFieldFormatterService | CORE FABRIC (Skill 01) | MicroserviceBase |

**Family 96 Fabric Notes:**
- F712 maps binding paths (`$.skill_05.latest_post.title`) to ES documents; path resolution is dynamic — no typed model
- F713 switches page context to "Template Mode": fetches real content records from DATABASE FABRIC, binds to node tree
- F714 uses AiDispatcher to generate intelligent fallback content when CMS fields are empty/null
- F715 executes repeater blocks: query → paginate → render card template per item
- F716 propagates data context (tenant + content record) through the canvas event stream

---

### FAMILY 97 — Multi-Tenant Flow Hardening
**Fabric Anchor:** CORE FABRIC (Skill 01) + DATABASE FABRIC (Skill 05) + QUEUE FABRIC (Skill 04)
**Purpose:** Tenant isolation enforcement, quota management, CloudEvents envelopes, idempotency store, tenant tiering (pool/silo/bridge), OIDC/SCIM integration, per-tenant restore, tenant-aware observability

| Factory ID | Interface | Fabric Resolution | Provider |
|------------|-----------|-------------------|----------|
| F719 | ITenantIsolationEnforcerService | CORE FABRIC (Skill 01) | MicroserviceBase |
| F720 | IQuotaEnforcementService | DATABASE FABRIC (Skill 05) | Redis (rate limits) |
| F721 | ICloudEventsEnvelopeService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F722 | IIdempotencyStoreService | DATABASE FABRIC (Skill 05) | Redis |
| F723 | ITenantTieringService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F724 | ITenantOidcScimService | CORE FABRIC (Skill 01) | MicroserviceBase |
| F725 | ITenantRestoreService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F726 | ITenantObservabilityService | CORE FABRIC (Skill 01) | MicroserviceBase (OTLP) |

**Family 97 Fabric Notes:**
- F719 enforces tenantId on every canvas query — DNA-5 (Scope Isolation). BUILD FAILURE if tenantId missing
- F720 enforces per-tenant quotas for flow runs, step concurrency, canvas nodes, and artifacts; OWASP API4/API6 defense
- F721 wraps all async step dispatch in CloudEvents envelopes with `tenantId` extension attribute
- F722 provides idempotency-key semantics for "start flow run" and all external side-effect steps
- F723 manages isolation tier graduation: shared schema → separate schema → separate DB — bridge model
- F726 emits W3C trace context + OTLP telemetry with tenant labels at controlled cardinality

---

### FAMILY 98 — Code Export & Deployment
**Fabric Anchor:** AI ENGINE FABRIC (Skills 06/07) + DATABASE FABRIC (Skill 05) + QUEUE FABRIC (Skill 04)
**Purpose:** Node tree → production code generation, framework adapters (React/Angular/Vue/Tailwind), design token sync, code review, deployment pipeline integration, artifact registry, rollback

| Factory ID | Interface | Fabric Resolution | Provider |
|------------|-----------|-------------------|----------|
| F727 | IUICodeExportService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F728 | IFrameworkAdapterService | AI ENGINE FABRIC (Skill 06) | IAiProvider |
| F729 | IDesignTokenSyncService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F730 | IExportReviewService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F731 | IArtifactRegistryService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F732 | IDeploymentPipelineService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F733 | IExportRollbackService | DATABASE FABRIC (Skill 05) | PostgreSQL |

**Family 98 Fabric Notes:**
- F727 uses AiDispatcher (multi-model consensus) to generate React/Tailwind/Angular code from node tree
- F728 resolves to specific framework adapters via config — never hardcodes React or Vue imports
- F729 synchronizes global design tokens (colors, spacing, radii) from ES index to running applications
- F730 runs AF-6 code review + AF-7 DNA compliance check on all exported code
- F732 dispatches deployment jobs through QUEUE FABRIC — never direct HTTP to CI/CD system

---

## FABRIC RESOLUTION MAP — FLOW-19

```
F697  INodeTreeService            → DATABASE FABRIC(Skill 05)     → Elasticsearch
F698  ICanvasStateService         → DATABASE FABRIC(Skill 05)     → Redis
F699  ISymbolLibraryService       → DATABASE FABRIC(Skill 05)     → Elasticsearch
F700  IComponentVariantService    → DATABASE FABRIC(Skill 05)     → Elasticsearch
F701  ICanvasVersionService       → DATABASE FABRIC(Skill 05)     → PostgreSQL
F702  ICanvasCollaborationService → QUEUE FABRIC(Skill 04)        → Redis Streams
F703  ILayerTreeService           → DATABASE FABRIC(Skill 05)     → Elasticsearch
F704  ICanvasEventBusService      → QUEUE FABRIC(Skill 04)        → Redis Streams
F705  ILayoutSolverService        → CORE FABRIC(Skill 01)         → MicroserviceBase
F706  IBreakpointResolverService  → AI ENGINE FABRIC(Skill 07)    → AiDispatcher
F707  IResponsiveOverrideService  → DATABASE FABRIC(Skill 05)     → Elasticsearch
F708  IAlignmentCalculatorService → CORE FABRIC(Skill 01)         → MicroserviceBase
F709  IConstraintEvaluatorService → DATABASE FABRIC(Skill 05)     → Elasticsearch
F710  ISnapGuideService           → CORE FABRIC(Skill 01)         → MicroserviceBase
F711  IZIndexManagerService       → DATABASE FABRIC(Skill 05)     → Redis
F712  IDataBindingService         → DATABASE FABRIC(Skill 05)     → Elasticsearch
F713  ITemplateModeService        → DATABASE FABRIC(Skill 05)     → Elasticsearch
F714  IContentFallbackService     → AI ENGINE FABRIC(Skill 07)    → AiDispatcher
F715  IRepeaterExecutorService    → DATABASE FABRIC(Skill 05)     → Elasticsearch
F716  IDataContextPropagatorService → QUEUE FABRIC(Skill 04)      → Redis Streams
F717  IBindingValidatorService    → RAG FABRIC(Skill 00b)         → Hybrid strategy
F718  IFieldFormatterService      → CORE FABRIC(Skill 01)         → MicroserviceBase
F719  ITenantIsolationEnforcerService → CORE FABRIC(Skill 01)     → MicroserviceBase
F720  IQuotaEnforcementService    → DATABASE FABRIC(Skill 05)     → Redis
F721  ICloudEventsEnvelopeService → QUEUE FABRIC(Skill 04)        → Redis Streams
F722  IIdempotencyStoreService    → DATABASE FABRIC(Skill 05)     → Redis
F723  ITenantTieringService       → DATABASE FABRIC(Skill 05)     → PostgreSQL
F724  ITenantOidcScimService      → CORE FABRIC(Skill 01)         → MicroserviceBase
F725  ITenantRestoreService       → DATABASE FABRIC(Skill 05)     → PostgreSQL
F726  ITenantObservabilityService → CORE FABRIC(Skill 01)         → MicroserviceBase
F727  IUICodeExportService        → AI ENGINE FABRIC(Skill 07)    → AiDispatcher
F728  IFrameworkAdapterService    → AI ENGINE FABRIC(Skill 06)    → IAiProvider
F729  IDesignTokenSyncService     → DATABASE FABRIC(Skill 05)     → Elasticsearch
F730  IExportReviewService        → AI ENGINE FABRIC(Skill 07)    → AiDispatcher
F731  IArtifactRegistryService    → DATABASE FABRIC(Skill 05)     → Elasticsearch
F732  IDeploymentPipelineService  → QUEUE FABRIC(Skill 04)        → Redis Streams
F733  IExportRollbackService      → DATABASE FABRIC(Skill 05)     → PostgreSQL
```

---

## DESIGN RECORDS — FLOW-19

| DR # | Decision | Rationale |
|------|----------|-----------|
| DR-111 | Node tree stored as `Dictionary<string,object>` in Elasticsearch | DNA-1: no typed models; ES provides full-text search on node properties |
| DR-112 | Canvas hot state in Redis, cold state in Elasticsearch | Sub-100ms canvas response; ES for durability and search |
| DR-113 | Collaboration events via Redis Streams consumer groups (F702/F704) | QUEUE FABRIC pattern; never direct WebSocket between service instances |
| DR-114 | Layout solver runs on CORE FABRIC (MicroserviceBase) without external provider | Pure computation; no AI required for deterministic Flex/Grid math |
| DR-115 | AI-assisted breakpoint resolution via AiDispatcher (F706) | Multi-model consensus improves responsive layout suggestions; provider-agnostic |
| DR-116 | Binding paths use `$.skill_XX.field` JSONPath convention | Consistent with existing skill output schema; enables cross-skill binding |
| DR-117 | Template Mode uses DATABASE FABRIC to fetch real content; no mock data service | Avoids test-data divergence; designer sees actual production content |
| DR-118 | Content fallback via AiDispatcher (F714) | AI generates contextually appropriate fallbacks; configurable via FREEDOM layer |
| DR-119 | Multi-tenant isolation uses hybrid pool/silo/bridge model | OWASP API1/API4 compliance; enterprise tenants graduate to dedicated schema/DB |
| DR-120 | CloudEvents envelopes required for all async canvas events (F721) | Standardized tenant context propagation; idempotency key in envelope |
| DR-121 | Code export uses AiDispatcher multi-model consensus (F727) | No single AI model dominates framework preference; output reviewed by AF-6/AF-9 |
| DR-122 | Design tokens stored in Elasticsearch index; synced via F729 | Single source of truth; fabric-first; admin can update tokens without code deploy |

---

## NODE TREE SCHEMA CONTRACT

Every canvas node stored via F697 follows this `Dictionary<string,object>` structure:

```json
{
  "nodeId": "card_post_001",
  "tenantId": "tenant_abc",
  "type": "CONTAINER",
  "layoutMode": "FLEX_VERTICAL",
  "style": {
    "padding": "20px",
    "gap": "12px",
    "borderRadius": "8px"
  },
  "bindings": {
    "title": "$.skill_05.latest_post.title",
    "coverImage": "$.skill_11.processed_media.url"
  },
  "constraints": {
    "lockLayout": true,
    "allowContentEdit": true
  },
  "breakpointOverrides": {
    "tablet": { "padding": "12px", "gap": "8px" },
    "mobile": { "padding": "8px", "layoutMode": "FLEX_VERTICAL" }
  },
  "children": [],
  "schemaVersion": "1.0"
}
```

**IRON RULE:** No `NodeTreeDocument` class. No typed DTO. All parsing via `ParseDocument(Dictionary<string,object>)` — DNA-1.

---

## PROMOTION LADDER — FLOW-19 SERVICES

```
GENERATED  → Canvas service code generated by AF-1 on top of F697-F733
INJECTED   → Passes AF-6 code review + AF-7 DNA compliance + AF-8 security scan
MINIMAL    → Passes AF-9 quality gate; BFA conflict checks CF-329–CF-348 pass
CORE       → Tenant isolation (F719) verified; quota enforcement (F720) active; telemetry (F726) live
```

---

## SAVE POINT: FLOW19:ENGINE_ARCHITECTURE ✅
## Next: TASK_TYPES_CATALOG delta (T269–T288)
