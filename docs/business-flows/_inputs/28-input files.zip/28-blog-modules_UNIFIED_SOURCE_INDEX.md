# XIIGen UNIFIED SOURCE INDEX — FLOW-26: Blog/CMS Modules Platform
## Date: 2026-03-01 | Status: COMPLETE ✅
## Purpose: Cross-reference of ALL FLOW-26 artifacts for RAG retrieval and session recovery

---

## HOW TO USE THIS INDEX

This document is the **single lookup table** for all FLOW-26 artifacts. When recovering a session
or when AF-4 (RAG Task Context) searches for relevant patterns, this index provides:
- Which document contains a given artifact
- Which artifacts belong to a given functional domain
- Cross-references between factories, task types, skills, and BFA rules
- Fabric resolution quick-lookup

---

## SECTION 1: FACTORY QUICK-LOOKUP (F1075–F1121)

| Factory | Interface | Family | Document | Skill Pattern | BFA Rules |
|---------|-----------|--------|----------|---------------|-----------|
| F1075 | IContentRepository | 154 | ENGINE_ARCH §Family154 | SK-251 | CF-510, CF-513, CF-522, CF-525, CF-534 |
| F1076 | IRevisionService | 154 | ENGINE_ARCH §Family154 | SK-251 | CF-526 |
| F1077 | ITaxonomyService | 154 | ENGINE_ARCH §Family154 | SK-252 | CF-517, CF-528 |
| F1078 | ISlugResolver | 154 | ENGINE_ARCH §Family154 | SK-252 | CF-517, CF-533 |
| F1079 | IContentPublisher | 154 | ENGINE_ARCH §Family154 | SK-259 | CF-511, CF-515, CF-526 |
| F1080 | IEditorSessionService | 155 | ENGINE_ARCH §Family155 | SK-251 | CF-512 |
| F1081 | IMediaUploadService | 155 | ENGINE_ARCH §Family155 | SK-254 | CF-513, CF-523, CF-543 |
| F1082 | IMediaTransformer | 155 | ENGINE_ARCH §Family155 | SK-254 | CF-532 |
| F1083 | IMediaLibraryService | 155 | ENGINE_ARCH §Family155 | SK-254 | CF-513 |
| F1084 | IMediaVariantService | 155 | ENGINE_ARCH §Family155 | SK-254 | CF-532 |
| F1085 | IThemeRenderer | 156 | ENGINE_ARCH §Family156 | SK-258 | — |
| F1086 | ITemplateEngine | 156 | ENGINE_ARCH §Family156 | SK-258 | — |
| F1087 | IPageCacheService | 156 | ENGINE_ARCH §Family156 | SK-255, SK-258 | CF-524, CF-525 |
| F1088 | IRouteResolver | 156 | ENGINE_ARCH §Family156 | SK-252, SK-258 | CF-517, CF-530 |
| F1089 | ILayoutComposer | 156 | ENGINE_ARCH §Family156 | SK-258 | — |
| F1090 | IHookRegistry | 157 | ENGINE_ARCH §Family157 | SK-253 | CF-515 |
| F1091 | IPluginLoader | 157 | ENGINE_ARCH §Family157 | SK-253 | CF-527, CF-537 |
| F1092 | IHookExecutor | 157 | ENGINE_ARCH §Family157 | SK-253 | CF-515, CF-527 |
| F1093 | IWebhookDispatcher | 157 | ENGINE_ARCH §Family157 | SK-253 | CF-520, CF-535 |
| F1094 | IExtensionSandbox | 157 | ENGINE_ARCH §Family157 | SK-253 | CF-527 |
| F1095 | IContentIndexer | 158 | ENGINE_ARCH §Family158 | SK-251 | CF-518, CF-534 |
| F1096 | ISearchQueryBuilder | 158 | ENGINE_ARCH §Family158 | — | CF-518 |
| F1097 | ICacheInvalidator | 158 | ENGINE_ARCH §Family158 | SK-255 | CF-524 |
| F1098 | ISitemapGenerator | 158 | ENGINE_ARCH §Family158 | — | CF-519, CF-530 |
| F1099 | IRelatedContentFinder | 158 | ENGINE_ARCH §Family158 | SK-257 | — |
| F1100 | ICommentRepository | 159 | ENGINE_ARCH §Family159 | — | CF-521 |
| F1101 | ISpamDetector | 159 | ENGINE_ARCH §Family159 | SK-256 | CF-514, CF-521 |
| F1102 | IModerationQueue | 159 | ENGINE_ARCH §Family159 | SK-261 | CF-536 |
| F1103 | ICommentNotifier | 159 | ENGINE_ARCH §Family159 | SK-259 | — |
| F1104 | IAiSeoAnalyzer | 160 | ENGINE_ARCH §Family160 | SK-257 | CF-529 |
| F1105 | IAiTagSuggester | 160 | ENGINE_ARCH §Family160 | SK-257 | CF-529 |
| F1106 | IAiContentSummarizer | 160 | ENGINE_ARCH §Family160 | SK-257 | CF-529 |
| F1107 | IAiImageAltTextGenerator | 160 | ENGINE_ARCH §Family160 | SK-257 | CF-529 |
| F1108 | IAiRelatedPostsRanker | 160 | ENGINE_ARCH §Family160 | SK-257 | — |
| F1109 | IScheduledPublisher | 161 | ENGINE_ARCH §Family161 | SK-259 | CF-519, CF-526 |
| F1110 | IPublishApprovalGate | 161 | ENGINE_ARCH §Family161 | SK-261 | CF-516, CF-536 |
| F1111 | IPublishEventEmitter | 161 | ENGINE_ARCH §Family161 | SK-259 | CF-511 |
| F1112 | IFeedGenerator | 161 | ENGINE_ARCH §Family161 | — | CF-524 |
| F1113 | ICanonicalUrlService | 161 | ENGINE_ARCH §Family161 | — | CF-533 |
| F1114 | IContentPermissionService | 162 | ENGINE_ARCH §Family162 | SK-260 | CF-525, CF-316 |
| F1115 | IEditorialRoleService | 162 | ENGINE_ARCH §Family162 | SK-260 | CF-538 |
| F1116 | IAuthorProfileService | 162 | ENGINE_ARCH §Family162 | SK-260 | CF-538 |
| F1117 | IContentOwnershipService | 162 | ENGINE_ARCH §Family162 | SK-260 | — |
| F1118 | ISiteConfigService | 163 | ENGINE_ARCH §Family163 | SK-262 | CF-522 |
| F1119 | IPermalinkConfigService | 163 | ENGINE_ARCH §Family163 | SK-262 | CF-533 |
| F1120 | IPluginConfigService | 163 | ENGINE_ARCH §Family163 | SK-262 | CF-537 |
| F1121 | IMaintenanceModeService | 163 | ENGINE_ARCH §Family163 | SK-262 | — |

---

## SECTION 2: TASK TYPE QUICK-LOOKUP (T389–T406)

| Task Type | Name | Archetype | Document | Primary Skill | BFA Rules | Stress Tests |
|-----------|------|-----------|----------|---------------|-----------|--------------|
| T389 | Content Lifecycle Orchestrator | ORCHESTRATION | TASK_TYPES §T389 | SK-251, SK-260 | CF-510, CF-511 | ST-300, ST-307 |
| T390 | Draft Autosave Loop | EVENT_PROCESSING | TASK_TYPES §T390 | SK-251 | CF-512 | ST-301 |
| T391 | Content Publish Gate | ORCHESTRATION | TASK_TYPES §T391 | SK-259, SK-260 | CF-515, CF-516, CF-525, CF-526 | ST-300, ST-308 |
| T392 | Scheduled Content Publisher | ORCHESTRATION | TASK_TYPES §T392 | SK-259 | CF-526 | ST-320 |
| T393 | Content Archive Flow | EVENT_PROCESSING | TASK_TYPES §T393 | SK-251 | CF-544 | — |
| T394 | Media Upload Pipeline | ORCHESTRATION | TASK_TYPES §T394 | SK-254 | CF-513, CF-523, CF-543 | ST-302, ST-314 |
| T395 | Media Variant Generator | EVENT_PROCESSING | TASK_TYPES §T395 | SK-254 | CF-532 | ST-302 |
| T396 | Public Page Request | READ_PATTERN | TASK_TYPES §T396 | SK-258, SK-260 | CF-525, CF-534 | ST-303, ST-307 |
| T397 | Search Index Cascade | EVENT_PROCESSING | TASK_TYPES §T397 | SK-251 | CF-518, CF-534 | ST-306, ST-318 |
| T398 | Page Cache Invalidation | EVENT_PROCESSING | TASK_TYPES §T398 | SK-255 | CF-524 | ST-303, ST-306 |
| T399 | Hook Fan-Out Executor | ORCHESTRATION | TASK_TYPES §T399 | SK-253 | CF-515, CF-527 | ST-304, ST-312 |
| T400 | Webhook Dispatcher | EVENT_PROCESSING | TASK_TYPES §T400 | SK-253 | CF-520, CF-535 | ST-309 |
| T401 | Comment Submission Gateway | ORCHESTRATION | TASK_TYPES §T401 | SK-256, SK-260 | CF-514, CF-521, CF-531 | ST-305 |
| T402 | Comment Moderation Flow | ORCHESTRATION | TASK_TYPES §T402 | SK-261 | CF-536 | ST-305, ST-321 |
| T403 | Taxonomy Propagation | EVENT_PROCESSING | TASK_TYPES §T403 | SK-252 | CF-528 | ST-310 |
| T404 | AI Content Enhancement | ORCHESTRATION | TASK_TYPES §T404 | SK-257 | CF-529, CF-539 | ST-311 |
| T405 | Sitemap Rebuild Service | EVENT_PROCESSING | TASK_TYPES §T405 | — | CF-519, CF-530 | ST-306 |
| T406 | Rate Limiting Pre-Gate | PATTERN | TASK_TYPES §T406 | SK-260 | CF-531 | ST-305 |

---

## SECTION 3: SKILL QUICK-LOOKUP (SK-251–SK-262)

| Skill | Name | Promotion | Factories | Task Types | Document |
|-------|------|-----------|-----------|------------|---------|
| SK-251 | Content Repository Pattern | MINIMAL | F1075, F1076, F1095 | T389, T390, T393, T397 | SKILLS §SK-251 |
| SK-252 | Taxonomy & Slug Resolver | INJECTED | F1077, F1078 | T396, T403 | SKILLS §SK-252 |
| SK-253 | Hook Fan-Out Executor | MINIMAL | F1090, F1091, F1092, F1093, F1094 | T399, T400 | SKILLS §SK-253 |
| SK-254 | Media Upload & Transform | INJECTED | F1081, F1082, F1083, F1084 | T394, T395 | SKILLS §SK-254 |
| SK-255 | Page Cache Service | INJECTED | F1087, F1097 | T396, T398 | SKILLS §SK-255 |
| SK-256 | AI Spam Detection Gate | INJECTED | F1101 | T401 | SKILLS §SK-256 |
| SK-257 | AI Content Enhancement | INJECTED | F1104–F1108 | T404 | SKILLS §SK-257 |
| SK-258 | Cache-First Read Pattern | MINIMAL → CORE candidate | F1085–F1089 | T396 | SKILLS §SK-258 |
| SK-259 | CloudEvent Publisher | INJECTED | F1079, F1109, F1111 | T391, T392 | SKILLS §SK-259 |
| SK-260 | Content Permission Service | MINIMAL | F1114–F1117 | T389, T391, T394, T396, T401, T406 | SKILLS §SK-260 |
| SK-261 | Human-In-Loop Approval | INJECTED | F1110, F1102 | T391, T402 | SKILLS §SK-261 |
| SK-262 | Site Config & Permalink Manager | INJECTED | F1118–F1121 | — (config layer) | SKILLS §SK-262 |

---

## SECTION 4: BFA CONFLICT RULE QUICK-LOOKUP (CF-510–CF-544)

| Rule | Severity | Domain | Flows Involved | Key Iron Rule | Document |
|------|----------|--------|----------------|---------------|---------|
| CF-510 | ERROR | Entity collision | FLOW-26 vs FLOW-02 | `blog.*` namespace mandatory | BFA §CF-510 |
| CF-511 | WARNING | Event namespace | FLOW-26 vs FLOW-04 | Fine-grained event names | BFA §CF-511 |
| CF-512 | WARNING | Redis session keys | FLOW-26 vs FLOW-22/23 | `blog:session:` prefix | BFA §CF-512 |
| CF-513 | ERROR | Media entity | FLOW-26 vs FLOW-11 | `blog_media_asset` distinct | BFA §CF-513 |
| CF-514 | WARNING | AI budget | FLOW-26 vs FLOW-07 | Budget pre-check before AI call | BFA §CF-514 |
| CF-515 | WARNING | Queue saturation | FLOW-26 vs FLOW-04 | maxFanout iron rule | BFA §CF-515 |
| CF-516 | ERROR | DLQ ownership | FLOW-26 vs FLOW-04 | No auto-retry for approvals | BFA §CF-516 |
| CF-517 | ERROR | URL routing | FLOW-26 vs FLOW-08 | Blog base path prefix | BFA §CF-517 |
| CF-518 | WARNING | ES index writes | FLOW-26 vs FLOW-09 | Separate index names | BFA §CF-518 |
| CF-519 | WARNING | Sitemap rate | FLOW-26 vs FLOW-13 | Debounce iron rule | BFA §CF-519 |
| CF-520 | ERROR-SEC | SSRF webhook | FLOW-26 vs FLOW-08 | URL allowlist before dispatch | BFA §CF-520 |
| CF-521 | ERROR-SEC | XSS comment | FLOW-26 vs FLOW-08 | Sanitize before storage | BFA §CF-521 |
| CF-522 | ERROR | Config tenant bleed | FLOW-26 vs FLOW-05 | tenantId on every config read | BFA §CF-522 |
| CF-523 | WARNING | Storage quota | FLOW-26 vs FLOW-12 | Quota check pre-upload | BFA §CF-523 |
| CF-524 | WARNING | RSS/page cache | FLOW-26 internal | Same invalidation tag set | BFA §CF-524 |
| CF-525 | ERROR-SEC | BOLA content | FLOW-26 vs FLOW-01 | Status filter mandatory | BFA §CF-525 |
| CF-526 | WARNING | Publish race | FLOW-26 internal | Optimistic lock mandatory | BFA §CF-526 |
| CF-527 | ERROR-SEC | Plugin sandbox | FLOW-26 vs FLOW-08 | Restricted execution | BFA §CF-527 |
| CF-528 | WARNING | Taxonomy orphan | FLOW-26 internal | Idempotency key required | BFA §CF-528 |
| CF-529 | WARNING | AI feedback runaway | FLOW-26 vs FLOW-07 | Circuit breaker per model | BFA §CF-529 |
| CF-530 | WARNING | Sitemap routing | FLOW-26 vs FLOW-08 | Register sitemap with FLOW-08 | BFA §CF-530 |
| CF-531 | WARNING | Rate limit double | FLOW-26 vs FLOW-01 | userId OR IP, never both | BFA §CF-531 |
| CF-532 | WARNING | CDN URL signing | FLOW-26 vs FLOW-12 | Check signing policy | BFA §CF-532 |
| CF-533 | ERROR | Canonical cache | FLOW-26 internal | Flush on permalink change | BFA §CF-533 |
| CF-534 | ERROR-SEC | Draft in search | FLOW-26 internal | Publish event filter strict | BFA §CF-534 |
| CF-535 | WARNING | Webhook retry storm | FLOW-26 vs FLOW-04 | Exponential backoff + cap | BFA §CF-535 |
| CF-536 | ERROR | Moderation deadlock | FLOW-26 internal | Separate reviewer pools | BFA §CF-536 |
| CF-537 | WARNING | Plugin namespacing | FLOW-26 internal | `{pluginId}:` prefix required | BFA §CF-537 |
| CF-538 | WARNING | SCIM conflict | FLOW-26 vs FLOW-05 | FLOW-05 authoritative | BFA §CF-538 |
| CF-539 | WARNING | Per-tenant AI model | FLOW-26 internal | Per-tenant config resolution | BFA §CF-539 |
| CF-540 | WARNING | Comment threading | FLOW-26 internal | maxDepth enforced | BFA §CF-540 |
| CF-541 | WARNING | Schema evolution | FLOW-26 internal | Dictionary ensures readability | BFA §CF-541 |
| CF-542 | WARNING | Editor takeover | FLOW-26 internal | Active session owner tracked | BFA §CF-542 |
| CF-543 | WARNING | Virus scan | FLOW-26 internal | Optional hook before commit | BFA §CF-543 |
| CF-544 | WARNING | Archive retention | FLOW-26 internal | Retention period FREEDOM config | BFA §CF-544 |

---

## SECTION 5: STRESS TEST QUICK-LOOKUP (ST-300–ST-323)

| Test | Name | Task Types | Key Success Criteria | Severity |
|------|------|------------|---------------------|----------|
| ST-300 | 1000 Concurrent Publishes | T391, T389 | All complete in 30s; zero cross-tenant bleed | HIGH |
| ST-301 | High-Frequency Autosave | T390 | P99 < 50ms; no session key collisions | MEDIUM |
| ST-302 | 500 Concurrent Media Uploads | T394, T395 | All accepted in 5s (async); all variants in 120s | HIGH |
| ST-303 | Page Cache Hit Rate | T396, T398 | >95% cache hit for repeat URLs; P99 cached < 10ms | HIGH |
| ST-304 | Hook Handler Isolation | T399 | Buggy handler terminated; others unaffected | HIGH |
| ST-305 | Comment Spam Throughput | T401, T402 | 2000 comments/60s; AI budget checked; XSS blocked | HIGH |
| ST-306 | Cache Invalidation Cascade | T397, T398 | 500 bulk publish invalidations in 30s; 1 sitemap job | HIGH |
| ST-307 | Cross-Tenant Isolation | T389, T391, T396 | Zero cross-tenant data in 10,000 operations | CRITICAL |
| ST-308 | Approval Timeout & DLQ | T391, F1110 | 100 timeouts → approval DLQ; no auto-retry | HIGH |
| ST-309 | Webhook Retry Storm | T400 | Exponential backoff; no storm on recovery | MEDIUM |
| ST-310 | Taxonomy Propagation Scale | T403 | 10,000 docs updated in 5 min; no orphans | MEDIUM |
| ST-311 | AI Parallel Models | T404 | 100 analyses in 20s; circuit breaker triggers | MEDIUM |
| ST-312 | Plugin Load Test | T399, F1094 | 50 plugins, 1000 events; sandbox isolation | HIGH |
| ST-313 | Permalink Migration | F1119, F1113 | 10,000 canonicals flushed; zero stale served | HIGH |
| ST-314 | Media Security Gauntlet | T394 | ZERO adversarial files accepted | CRITICAL |
| ST-315 | Maintenance Mode Toggle | F1121 | In-flight complete; new → 503 immediately | MEDIUM |
| ST-316 | Permission Cache Invalidation | F1114 | Role change reflected in < 5s | HIGH |
| ST-317 | RSS Under Load | F1112 | 100K req/min; >99% cache hit | MEDIUM |
| ST-318 | Full Tenant Reindex | F1095 | 100K posts reindexed < 30 min; no read downtime | MEDIUM |
| ST-319 | Comment Threading Depth | T401 | Depth > maxDepth rejected; no DB write | LOW |
| ST-320 | Scheduled Publish Backlog | T392 | 1000 posts same time; all within 10 min; fair | MEDIUM |
| ST-321 | Concurrent Moderation + Appeal | T402 | Optimistic lock prevents double-decision | MEDIUM |
| ST-322 | FREEDOM Config Hot Reload | F1118, F1121 | Config change propagated within 30s | MEDIUM |
| ST-323 | Plugin Hook Priority Race | T399 | Deterministic order; stable across restarts | LOW |

---

## SECTION 6: FABRIC RESOLUTION MATRIX

| Fabric | FLOW-26 Factories | Default Provider |
|--------|------------------|-----------------|
| DATABASE FABRIC (ES) | F1075, F1077, F1083, F1086, F1088, F1090, F1091, F1095, F1096, F1100, F1112, F1115, F1116, F1118, F1120 | Elasticsearch 8 |
| DATABASE FABRIC (PG) | F1076, F1084, F1117 | PostgreSQL (JSONB) |
| DATABASE FABRIC (Redis) | F1078, F1080, F1081, F1087, F1097, F1113, F1119, F1121 | Redis 7+ |
| QUEUE FABRIC | F1079, F1082, F1092, F1093, F1098, F1102, F1103, F1109, F1110, F1111 | Redis Streams |
| AI ENGINE FABRIC | F1101, F1104, F1105, F1106, F1107, F1108 | Claude (haiku/sonnet) + Gemini |
| RAG FABRIC | F1099, F1104, F1108 | Hybrid (ES vector + keyword) |
| CORE FABRIC | F1085, F1086, F1089, F1094, F1114 | MicroserviceBase |

---

## SECTION 7: DOCUMENT MAP

| Document | Contains | Lines (approx) |
|----------|---------|----------------|
| 28-blog-modules_ENGINE_ARCHITECTURE.md | F1075–F1121, Families 154–163, DNA compliance, example generated code | ~580 |
| 28-blog-modules_TASK_TYPES_CATALOG.md | T389–T406 full contracts (18 × full format), Templates 83–88 | ~750 |
| 28-blog-modules_SKILLS_FACTORY_RAG.md | SK-251–SK-262 (12 skills with code patterns, promotion status) | ~850 |
| 28-blog-modules_V62_BFA_STRESS_TEST.md | CF-510–CF-544 (35 rules), ST-300–ST-323 (24 tests) | ~500 |
| 28-blog-modules_SESSION_STATE.md | All counters, recovery instructions, flow history | ~230 |
| 28-blog-modules_MASTER_EXECUTION_PLAN.md | P0–P3 full execution plan, risk register, design decisions | ~380 |
| 28-blog-modules_UNIFIED_SOURCE_INDEX.md | Cross-reference tables (this file) | ~250 |

---

## SECTION 8: DNA PATTERN CROSS-REFERENCE

| DNA | Pattern Name | Applied In FLOW-26 | Enforced By | BFA Rules |
|-----|-------------|-------------------|-------------|-----------|
| DNA-1 | ParseDocument (Dictionary) | All 47 factory return types | AF-7 scan | CF-541 |
| DNA-2 | BuildQueryFilters (empty skip) | ContentFilter, TaxonomyFilter, CommentFilter, MediaFilter | AF-7 scan | CF-522 |
| DNA-3 | DataProcessResult<T> | All 47 factory method signatures | AF-9 judge | — |
| DNA-4 | MicroserviceBase | All 10 generated service classes | AF-7 compliance | — |
| DNA-5 | Scope Isolation (tenantId) | Every factory method, every ES/Redis query | AF-7 + CF-522, CF-512 | CF-512, CF-522, CF-507 |
| DNA-6 | DynamicController | No IContentController, ICommentController etc. | AF-7 scan | — |

---

## SECTION 9: CLOUDFLOWS → TEMPLATES MAPPING

| Template | Name | Trigger Event | Steps | Generated Services |
|----------|------|---------------|-------|--------------------|
| Template-83 | Content Lifecycle DAG | ContentLifecycleRequest | T389→[T391/T392/T393] | ContentLifecycleService, ContentPublishingService |
| Template-84 | Public Page Render DAG | HTTP GET /{blogBasePath}/{slug} | T396 + async(T397, T398) | PublicPageService, SearchIndexCascadeService, PageCacheInvalidationService |
| Template-85 | Media Upload DAG | MediaUploadRequest | T394→T395 | MediaUploadService, MediaVariantService |
| Template-86 | Extension Hook DAG | HookFireEvent | T399→T400 | HookExecutorService, WebhookDispatcherService |
| Template-87 | Comment Flow DAG | CommentSubmitRequest | T401→T402 | CommentSubmissionGateway, CommentModerationFlow |
| Template-88 | AI Enhancement DAG | ContentEnhancementRequest | T404 + async(T403, T405) | AiContentEnhancementService, TaxonomyPropagationService, SitemapRebuildService |

---

## SECTION 10: AF STATION USAGE SUMMARY

| AF Station | Used For | Primary Task Types |
|------------|----------|--------------------|
| AF-1 Genesis | Generates all 10 service classes | T389–T406 |
| AF-2 Planning | Decomposes T389, T391, T394, T399 orchestration steps | T389, T391, T394, T399 |
| AF-3 Prompt Library | Retrieves CMS-domain prompts (content lifecycle, CMS patterns) | T389, T391, T396 |
| AF-4 RAG Task Context | Retrieves SK-251–SK-262 patterns; reuse-first | All |
| AF-5 Multi-model | Claude-sonnet + Gemini-2.5-Pro parallel for complex orchestration | T389, T391, T396, T404 |
| AF-6 Code Review | State machine edge cases, debounce logic review | T389, T390, T392 |
| AF-7 Compliance | DNA-1 through DNA-6 scan on all generated code | All (mandatory) |
| AF-8 Security | BOLA (CF-525), XSS (CF-521), SSRF (CF-520), sandbox (CF-527) | T394, T396, T400, T401 |
| AF-9 Judge | Iron rules, quality gates for all 18 task types | All (mandatory) |
| AF-10 Merge | Multi-model output combination for T391 and T404 | T391, T404 |
| AF-11 Feedback | Generation quality stored; seeded during P1/P2 | T389, T391, T396, T404 (priority) |

---

## STATE SAVE CHECKPOINT

```
FILE: 28-blog-modules_UNIFIED_SOURCE_INDEX.md
STATUS: COMPLETE ✅
ALL 7 FLOW-26 DOCUMENTS: COMPLETE ✅

FLOW-26 SESSION COMPLETE. NEXT: FLOW-27
Next factory: F1122 | Next task type: T407 | Next family: 164
```
