# XIIGen BFA & STRESS TESTS — FLOW-26: Blog/CMS Modules Platform
## Date: 2026-03-01 | BFA Rules: CF-510–CF-544 | Stress Tests: ST-300–ST-323
## Status: COMPLETE ✅

---

## BUSINESS FLOW ARBITER — NEW CONFLICT RULES

### CROSS-FLOW REGISTRATION

FLOW-26 registers the following entities and events in the BFA global index:

**New Entities (FLOW-26)**
- `blog_content` — primary content document (tenantId-scoped)
- `blog_revision` — immutable snapshot per status transition
- `taxonomy_term` — category/tag entity
- `media_asset` — uploaded media, all variants
- `hook_registration` — plugin hook endpoint record
- `editor_session` — ephemeral autosave session (Redis, TTL-bound)
- `publish_approval` — human-in-loop decision record
- `blog_comment` — user-submitted comment pending or approved

**New CloudEvents (FLOW-26)**
- `blog.content.published` — fires after T391 completes
- `blog.content.archived` — fires after T393 completes
- `blog.content.scheduled` — fires when T392 schedules a publish job
- `blog.content.status_changed` — fires on every T389 transition
- `blog.comment.submitted` — fires on T401 entry
- `blog.comment.approved` — fires on T402 approve decision
- `blog.media.uploaded` — fires after T394 commit
- `blog.media.variants_ready` — fires after T395 all variants complete
- `blog.hook.fired` — fires on T399 entry
- `blog.search.indexed` — fires after T397 index complete

---

## BFA CONFLICT RULES — CF-510 TO CF-544

---

### CF-510 — Content Entity Ownership Conflict

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 (blog_content) vs FLOW-02 (content ownership)
**CONFLICT**: FLOW-02 uses a generic `content` entity. FLOW-26 adds `blog_content`. BFA must ensure no event listener in FLOW-02 silently captures `blog.content.*` events and applies FLOW-02 logic.
**DETECTION**: BFA scans event bus registrations for wildcard subscriptions to `content.*` or `*.content.*`. Flags any FLOW-02 handler that would consume FLOW-26 events.
**RESOLUTION**: FLOW-26 uses the fully-qualified `blog.content.*` namespace. FLOW-02 handlers must be scoped to `generic.content.*`. CF-510 fires if namespace overlap detected.
**IRON RULE**: BUILD FAILURE if FLOW-02 handlers subscribe to `blog.*` namespace.

---

### CF-511 — Status Event Conflicts with Notification Pipeline

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (blog.content.status_changed) vs FLOW-04 (notification pipeline)
**CONFLICT**: FLOW-04 may already subscribe to broad status change events and send duplicate notifications when blog content changes status.
**DETECTION**: BFA checks FLOW-04 event subscriptions. If FLOW-04 handler matches `*.status_changed`, flag for review.
**RESOLUTION**: FLOW-26 emits fine-grained events (`blog.content.published`, not generic status_changed for notifications). CF-511 warns if FLOW-04 would double-notify.
**AF VALIDATION**: AF-7 must verify notification deduplication key includes flowId prefix.

---

### CF-512 — Editor Session Conflicts with Visual Editor (FLOW-22/23)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (editor_session via F1080) vs FLOW-22/23 (visual flow editor sessions)
**CONFLICT**: Both use Redis session stores with similar key patterns. Risk of key collision if prefix discipline is not enforced.
**DETECTION**: BFA scans Redis key schema registrations. CF-512 fires if FLOW-26 key pattern `{tenantId}:{sessionId}:{contentId}` could match FLOW-22 pattern.
**RESOLUTION**: FLOW-26 MUST use prefix `blog:session:{tenantId}:{sessionId}:{contentId}`. FLOW-22 uses `flow:session:*`. Validated at build time.
**IRON RULE**: Key prefix MUST be `blog:` for all FLOW-26 Redis keys — BUILD FAILURE otherwise.

---

### CF-513 — Media Asset ID Collision with Asset Management (FLOW-11)

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 (media_asset via F1081/F1083) vs FLOW-11 (digital asset management)
**CONFLICT**: Both systems manage uploaded files. If FLOW-11 already has a `media_asset` entity registered in BFA, FLOW-26 addition is a duplicate entity registration.
**DETECTION**: BFA checks entity registry. If `media_asset` already registered by another flow, CF-513 fires.
**RESOLUTION**: FLOW-26 registers `blog_media_asset` as a distinct entity. Uses `blog:media:*` index prefix in Elasticsearch. FLOW-11's `media_asset` remains unchanged.
**AF VALIDATION**: AF-7 ensures all FLOW-26 media services query only `blog-media` ES index, never the FLOW-11 `dam-media` index.

---

### CF-514 — Comment Spam AI vs General AI Budget (FLOW-07)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1101 ISpamDetector via AI ENGINE FABRIC) vs FLOW-07 (AI budget controller)
**CONFLICT**: FLOW-07 enforces tenant-level AI token budgets. FLOW-26 spam detection fires on every comment submission. High-volume sites could exhaust AI budgets silently.
**DETECTION**: BFA checks AI usage patterns. CF-514 fires if F1101 calls per hour exceed configured threshold without budget check.
**RESOLUTION**: F1101 MUST check FLOW-07 AI budget before calling IAiProvider. If budget exhausted, fall back to rule-based spam filter. Config: `comments.spam.fallback=rule-based`.
**AF VALIDATION**: AF-8 validates F1101 implementation includes budget pre-check.

---

### CF-515 — Hook Fan-Out and Queue Saturation (FLOW-04)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1092 IHookExecutor fan-out) vs FLOW-04 (queue saturation limits)
**CONFLICT**: A single `blog.content.published` event could fan-out to N plugin handlers simultaneously. If N is large, FLOW-04 queue saturation rules may throttle legitimate events.
**DETECTION**: BFA scans hook registry per tenant. CF-515 fires if registered handler count > 50 for a single hook name without rate limit config.
**RESOLUTION**: F1092 MUST apply per-tenant fan-out limits (FREEDOM config: `extensions.hooks.maxFanout`, default 20). Excess handlers queued with backpressure.
**IRON RULE**: Fan-out MUST be bounded — BUILD FAILURE if no maxFanout check before FireHookAsync.

---

### CF-516 — Publish Approval Timeout and DLQ Ownership

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 (F1110 IPublishApprovalGate) vs FLOW-04 (DLQ processing)
**CONFLICT**: Timed-out approval requests land in DLQ. FLOW-04 may have a generic DLQ consumer that auto-retries — which would incorrectly retry human-approval requests.
**DETECTION**: BFA checks DLQ consumer registrations. CF-516 fires if FLOW-04 DLQ consumer would consume `publish-approvals` DLQ messages.
**RESOLUTION**: Approval DLQ messages MUST carry `requiresHumanReview: true` header. FLOW-04 DLQ consumer MUST filter these out and route to admin notification.
**IRON RULE**: Approval timeout messages MUST NOT be auto-retried — BUILD FAILURE if FLOW-04 DLQ handler lacks filter.

---

### CF-517 — Taxonomy Slug Collision with URL Router (FLOW-08)

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 (F1077/F1078 taxonomy + slug resolver) vs FLOW-08 (URL routing)
**CONFLICT**: FLOW-08 owns the global URL routing table. FLOW-26 registers slug→contentId mappings that may conflict with FLOW-08 routes.
**DETECTION**: BFA scans route registrations. CF-517 fires if FLOW-26 slug pattern overlaps with a FLOW-08 reserved route prefix.
**RESOLUTION**: FLOW-26 slugs MUST be scoped under tenant-configured base paths (FREEDOM: `routing.blogBasePath`, default `/blog/`). FLOW-08 reserves `/api/`, `/admin/`, `/auth/`.
**IRON RULE**: Slug resolver MUST reject slugs matching FLOW-08 reserved prefixes — BUILD FAILURE if missing.

---

### CF-518 — Search Index Cascade and FLOW-09 Indexer Conflict

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1095 IContentIndexer) vs FLOW-09 (search platform indexer)
**CONFLICT**: Both FLOW-26 and FLOW-09 write to Elasticsearch. If both index the same document under the same ID, last-write-wins creates inconsistency.
**DETECTION**: BFA checks ES index write registrations. CF-518 fires if both flows register write access to overlapping ES index names.
**RESOLUTION**: FLOW-26 writes ONLY to `blog-content-{tenantId}` index. FLOW-09 writes to `search-{tenantId}`. FLOW-26 emits `blog.search.indexed` event; FLOW-09 can subscribe if cross-flow search needed.
**AF VALIDATION**: AF-7 validates no FLOW-26 service writes to `search-*` indices directly.

---

### CF-519 — Sitemap Generation and Rate Limiting (FLOW-13)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1098 ISitemapGenerator via queue) vs FLOW-13 (rate limiting)
**CONFLICT**: Large-scale publish events trigger multiple concurrent sitemap regeneration jobs. FLOW-13 rate limits may block sitemap queue consumers.
**DETECTION**: CF-519 fires if sitemap-gen consumer group exceeds FLOW-13 limits during peak publish windows.
**RESOLUTION**: Sitemap jobs MUST be debounced (FREEDOM: `search.sitemap.debounceMs`, default 30000ms). Only one sitemap job queued per tenant per debounce window. Idempotency key: `sitemap:{tenantId}:{timestamp/window}`.

---

### CF-520 — Webhook SSRF Risk (FLOW-08 Security Boundary)

**SEVERITY**: ERROR — SECURITY
**FLOWS INVOLVED**: FLOW-26 (F1093 IWebhookDispatcher) vs FLOW-08 (network security boundary)
**CONFLICT**: Webhook URLs submitted by plugin authors could target internal services (SSRF). FLOW-08 manages the network egress allowlist.
**DETECTION**: AF-8 static analysis. CF-520 fires if IWebhookDispatcher.DispatchAsync() calls outbound without URL validation pre-flight.
**RESOLUTION**: MUST validate webhook URL against allowlist BEFORE dispatch. Check: not RFC1918, not localhost, not metadata endpoints. Allowlist config: `extensions.webhooks.allowedHosts`.
**IRON RULE**: Webhook dispatch without URL validation = BUILD FAILURE (security).

---

### CF-521 — Comment XSS via Editor Passthrough

**SEVERITY**: ERROR — SECURITY
**FLOWS INVOLVED**: FLOW-26 (T401 CommentSubmission, F1100) vs FLOW-08 (XSS protection)
**CONFLICT**: Comment body stored and rendered on page. If sanitization not applied before storage, XSS vectors persist in database.
**DETECTION**: AF-8 checks T401 code path. CF-521 fires if comment body stored without sanitization step.
**RESOLUTION**: Comment body MUST pass through HTML sanitizer (allowlist: `<b>`, `<i>`, `<a>` only) before `ICommentRepository.StoreAsync()`. No raw HTML from untrusted input.
**IRON RULE**: Unsanitized comment storage = BUILD FAILURE (security).

---

### CF-522 — Multi-Tenant Config Bleed (FREEDOM Layer)

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 (F1118 ISiteConfigService) vs FLOW-05 (multi-tenant isolation)
**CONFLICT**: ISiteConfigService reads config from Elasticsearch. If tenantId scope is not enforced on every read, one tenant's site config bleeds to another.
**DETECTION**: AF-7 compliance scan. CF-522 fires if any ISiteConfigService call lacks tenantId filter in BuildSearchFilter.
**RESOLUTION**: All FREEDOM config reads MUST include tenantId in BuildSearchFilter. ES index partition: `site-config-{tenantId}` OR tenantId field in `site-config` with filter.
**IRON RULE**: Config read without tenantId = BUILD FAILURE (tenant isolation).

---

### CF-523 — Media Upload Quota vs FLOW-12 Storage Limits

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1081 IMediaUploadService) vs FLOW-12 (storage quota service)
**CONFLICT**: FLOW-12 enforces tenant storage quotas. FLOW-26 media uploads must check quotas before accepting upload.
**DETECTION**: CF-523 fires if F1081 does not call FLOW-12 quota check before accepting file bytes.
**RESOLUTION**: IMediaUploadService MUST check FLOW-12 quota via factory-resolved IStorageQuotaService before streaming bytes. Quota config: `media.upload.maxTenantGb` (FREEDOM).

---

### CF-524 — RSS Feed Cache Inconsistency with Page Cache (FLOW-26 Internal)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 internal — F1112 (IFeedGenerator) vs F1087 (IPageCacheService)
**CONFLICT**: Page cache may serve stale RSS feed after new content is published if feed is cached separately from page fragments.
**DETECTION**: CF-524 fires if F1112 feed cache TTL > F1087 page cache TTL (inconsistent staleness).
**RESOLUTION**: Both caches MUST be invalidated by the same `blog.content.published` event via T398 (PageCacheInvalidationService). RSS feed cache key MUST be included in invalidation tag set.

---

### CF-525 — BOLA Risk on Content Read (Authorization)

**SEVERITY**: ERROR — SECURITY
**FLOWS INVOLVED**: FLOW-26 (T396 PublicPageService, F1075 IContentRepository) vs FLOW-01 (auth)
**CONFLICT**: A tenant's private/draft content could be accessed by unauthenticated requests if T396 doesn't check content visibility status before serving.
**DETECTION**: AF-8 checks T396 code path. CF-525 fires if content is returned from F1075 without visibility/status check.
**RESOLUTION**: T396 MUST filter: `status = published AND visibility = public` OR caller has editor permissions. Status check via BuildSearchFilter (DNA-2).
**IRON RULE**: Draft content readable via public endpoint = BUILD FAILURE (BOLA).

---

### CF-526 — Scheduled Publish Race with Manual Publish

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 internal — T391 (manual publish) vs T392 (scheduled publish)
**CONFLICT**: If a scheduled publish job fires while an editor manually publishes the same content, both paths may race to update status, creating duplicate publish events.
**DETECTION**: CF-526 fires in integration tests when T391 and T392 run concurrently for same contentId.
**RESOLUTION**: Publish gate (F1079, F1110) MUST use optimistic locking on content revision. If `currentRevision != expectedRevision`, job must abort with `PUBLISH_CONFLICT` status.
**IRON RULE**: No publish transaction without revision-based optimistic lock — BUILD FAILURE if missing.

---

### CF-527 — Plugin Sandbox Escape

**SEVERITY**: ERROR — SECURITY
**FLOWS INVOLVED**: FLOW-26 (F1094 IExtensionSandbox, T399 HookExecutor) vs FLOW-08 (security boundary)
**CONFLICT**: Plugin code running in hook handlers could attempt to access inter-service APIs, database connections, or environment variables outside their sandbox.
**DETECTION**: AF-8 static analysis of hook handler execution path. CF-527 fires if F1094 does not enforce resource restrictions.
**RESOLUTION**: IExtensionSandbox MUST restrict: no direct network calls, no env var access, execution time limit (FREEDOM: `extensions.sandbox.timeoutMs`, max 5000). All plugin I/O through declared fabric interfaces only.
**IRON RULE**: Hook handler with unrestricted execution = BUILD FAILURE (security).

---

### CF-528 — Taxonomy Propagation Orphan Risk

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 internal — T403 (TaxonomyPropagationService) vs T389 (ContentLifecycle)
**CONFLICT**: If a taxonomy term is deleted while T403 is propagating it to content documents, orphaned taxonomy references remain in ES.
**DETECTION**: CF-528 fires if T403 does not use transaction-like idempotency pattern (check-then-update with revision lock).
**RESOLUTION**: T403 propagation MUST be event-sourced: each propagation step is a queue event with idempotency key `taxonomy-prop:{termId}:{contentId}:{revision}`. Orphan cleanup job runs nightly.

---

### CF-529 — AI Enhancement Feedback Loop Runaway

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (T404 AiContentEnhancement, F1104/F1105) vs FLOW-07 (AF-11 feedback)
**CONFLICT**: AF-11 feedback loop stores quality scores for AI generations. If T404 AI calls fail repeatedly, AF-11 may accumulate negative scores that cause model blacklisting, breaking AI enhancement for a tenant.
**DETECTION**: CF-529 fires if AF-11 score for a model drops below threshold without escalation to admin.
**RESOLUTION**: T404 MUST include circuit-breaker per AI provider per tenant. If score < 0.3 for > 10 consecutive calls, emit admin alert and fall back to next model in AiDispatcher priority list.

---

### CF-530 — Sitemap and Robots.txt Conflict (FLOW-08)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (T405 SitemapRebuildService, F1098) vs FLOW-08 (URL routing)
**CONFLICT**: FLOW-08 serves `/sitemap.xml` and `/robots.txt` from its route table. FLOW-26 T405 generates sitemap content. If routes are not coordinated, FLOW-08 may serve a stale static sitemap ignoring FLOW-26's dynamically generated one.
**DETECTION**: CF-530 fires if FLOW-08 has a static route for `/sitemap.xml` without FLOW-26 integration.
**RESOLUTION**: FLOW-26 registers its sitemap endpoint with FLOW-08 route table at initialization. FLOW-08 proxies `/sitemap.xml` to FLOW-26 ISitemapGenerator via F1098.

---

### CF-531 — Comment Rate Limiting and User Session Conflict

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (T406 RateLimitingPreGate) vs FLOW-01 (auth/session)
**CONFLICT**: Rate limiting on comments is applied per-user or per-IP. If user session from FLOW-01 is available, rate limit should use userId. If anonymous, fall back to IP. Conflict: rate limiter may double-count authenticated users.
**DETECTION**: CF-531 fires if T406 applies BOTH userId AND IP rate limits to the same request.
**RESOLUTION**: T406 MUST use userId rate limit (stricter) if authenticated, IP rate limit if anonymous. Never apply both to same request.

---

### CF-532 — Media Variant URL Signing vs CDN Config (FLOW-12)

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1084 IMediaVariantService) vs FLOW-12 (CDN/storage config)
**CONFLICT**: Media variant URLs may be signed (with TTL) or unsigned. FLOW-12 CDN config determines signing policy. If FLOW-26 generates unsigned URLs for content that FLOW-12 requires signed, broken links result.
**DETECTION**: CF-532 fires if F1084 does not check FLOW-12 CDN signing policy before constructing variant URLs.
**RESOLUTION**: F1084 MUST resolve URL signing via FLOW-12 config factory. Config: `media.cdn.signUrls` (FREEDOM). Signing TTL configurable.

---

### CF-533 — Permalink Change Breaks Existing Canonical URLs

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 internal — F1119 (IPermalinkConfigService) vs F1113 (ICanonicalUrlService)
**CONFLICT**: If admin changes permalink structure (e.g., from `/{year}/{slug}` to `/{category}/{slug}`), all existing canonical URLs become invalid. F1113 Redis cache still serves old patterns.
**DETECTION**: CF-533 fires if F1119 permalink change does not trigger F1113 cache flush.
**RESOLUTION**: Any F1119 permalink config change MUST enqueue a `CANONICAL_INVALIDATE_ALL` event for the tenant. F1113 processes it by flushing all `blog:canonical:{tenantId}:*` Redis keys.
**IRON RULE**: Permalink change without canonical cache flush = BUILD FAILURE.

---

### CF-534 — Draft Content Indexed Before Publish

**SEVERITY**: ERROR — SECURITY
**FLOWS INVOLVED**: FLOW-26 internal — T397 (SearchIndexCascade) vs T390 (DraftAutosave)
**CONFLICT**: T390 autosave fires frequently. If T397 search indexer subscribes to all content store events (not just publish events), draft content gets indexed and becomes searchable before it's published.
**DETECTION**: CF-534 fires if T397 event trigger does not filter for `blog.content.published` specifically (i.e., subscribes to `blog.content.*`).
**RESOLUTION**: T397 MUST be triggered ONLY by `blog.content.published` event. Never by autosave events. AF-7 validates event subscription filter.
**IRON RULE**: Draft content in search index = BUILD FAILURE (BOLA/privacy).

---

### CF-535 — Webhook Retry Storm on Receiver Failure

**SEVERITY**: WARNING
**FLOWS INVOLVED**: FLOW-26 (F1093 IWebhookDispatcher, T400) vs FLOW-04 (queue/DLQ)
**CONFLICT**: If webhook receiver is down, FLOW-04 retry policy may retry infinitely, creating a storm of webhook calls when receiver recovers.
**DETECTION**: CF-535 fires if F1093 retry policy does not include exponential backoff + max retry cap.
**RESOLUTION**: Webhook retries MUST use exponential backoff (base 2s, max 5 retries). After max retries: DLQ with `WEBHOOK_DELIVERY_FAILED` status. Admin notification via FLOW-04 dead letter handler.

---

### CF-536 — Moderation Queue and Approval Gate Deadlock

**SEVERITY**: ERROR
**FLOWS INVOLVED**: FLOW-26 internal — T402 (CommentModeration) vs T391 (PublishApprovalGate)
**CONFLICT**: If the same human reviewer is assigned to both comment moderation and content approval simultaneously, and the system holds locks on both queues waiting for input, a soft deadlock can occur (reviewer overwhelm → timeout → both DLQ → data loss).
**DETECTION**: CF-536 fires if T402 and T391 can both block on same reviewer identity simultaneously.
**RESOLUTION**: T402 and T391 MUST use separate reviewer pools (FREEDOM: `moderation.reviewers` vs `publish.approvers`). Workload balancing across pool members enforced.

---

### CF-537 through CF-544 — Reserved for Multi-Tenant FLOW-26 Additions

**SEVERITY**: Various
**STATUS**: Reserved for FLOW-26 multi-tenant variant rules (SCIM provisioning, per-tenant plugin isolation, tenant-scoped hook namespacing, cross-tenant search federation edge cases).
**CF-537**: Plugin namespacing isolation — plugin hook names MUST be prefixed with `{pluginId}:` to prevent cross-plugin hook name collisions.
**CF-538**: SCIM user provisioning conflict — if FLOW-26 author profiles (F1116) conflict with FLOW-05 SCIM user records, FLOW-05 is authoritative.
**CF-539**: Per-tenant AI model config — each tenant may configure different AI models for spam detection/SEO. F1101/F1104 MUST resolve from per-tenant config, not global default.
**CF-540**: Comment threading depth limit — max comment nesting depth configurable (FREEDOM: `comments.maxDepth`, default 3). Beyond limit, flat threading.
**CF-541**: Content type schema evolution — if content schema changes, existing revision documents MUST remain readable. ParseDocument (DNA-1) ensures this via Dictionary.
**CF-542**: Editor session takeover — if two users open same content in editor, second open must display warning. F1080 MUST track active session owner.
**CF-543**: Media upload virus scan integration — F1081 MUST call configurable IVirusScanService (optional FREEDOM factory) before committing media asset.
**CF-544**: Archive retention policy — T393 (archive) MUST respect tenant-configured retention period (FREEDOM: `content.archive.retentionDays`). After retention period: permanent delete event emitted.

---

## STRESS TEST SCENARIOS — ST-300 TO ST-323

---

### ST-300 — 1000 Concurrent Content Publishes

**TARGET TASK TYPES**: T391, T389
**SCENARIO**: 1000 tenants each publish one content item simultaneously. Each publish triggers: T391 → T397 (search index) → T398 (cache invalidate) → T405 (sitemap) → hook fan-out (T399).
**LOAD**: 1000 concurrent publish events → estimated 5000+ downstream queue events.
**SUCCESS CRITERIA**:
- All 1000 publish transactions complete within 30s
- Zero cross-tenant data bleeding (CF-522)
- All `blog.content.published` events acknowledged in main queue before moving to consumed
- Search index updates complete within 60s (eventual consistency window)
- No DLQ entries (successful path)
**FAILURE MODES**: Queue backpressure causes timeouts; hook fan-out exceeds maxFanout limit; approval gate deadlock (CF-536).
**AF VALIDATION**: AF-9 judge runs after test. Checks: all revision snapshots created, all audit events persisted.

---

### ST-301 — High-Frequency Autosave (Editor Session)

**TARGET TASK TYPES**: T390
**SCENARIO**: 500 concurrent users each autosaving every 5 seconds for 10 minutes. 60,000 autosave events total.
**LOAD**: 100 events/second sustained for 600 seconds.
**SUCCESS CRITERIA**:
- Redis session TTL correctly reset on each autosave
- No session key collisions across tenants (CF-512)
- Autosave debounce correctly applied (not every event hits DB)
- Memory usage stable (no session leak)
- P99 autosave latency < 50ms
**FAILURE MODES**: Redis memory exhaustion; key namespace collision; missing TTL reset causing session loss.

---

### ST-302 — 500 Concurrent Media Uploads

**TARGET TASK TYPES**: T394, T395
**SCENARIO**: 500 users simultaneously upload 10MB images. Each upload triggers: upload job → virus scan hook → transform variants (thumb, medium, large) → media library index.
**LOAD**: 5GB total data, 1500 transform jobs (3 variants each).
**SUCCESS CRITERIA**:
- All uploads accepted within 5s (async: immediate job ID returned)
- All transform jobs complete within 120s
- No variant URL generated before job complete (no partial state)
- Storage quota checked (CF-523) before byte streaming
- Variant URLs correctly signed per CDN policy (CF-532)
**FAILURE MODES**: Transform queue saturation; quota check bypassed; unsigned URLs served.

---

### ST-303 — Page Cache Hit Rate Under High Read Load

**TARGET TASK TYPES**: T396, T398
**SCENARIO**: 10,000 requests/second to public blog pages for 60 seconds. 80% repeat URLs (cache-eligible).
**LOAD**: 600,000 total requests. Expected: 480,000 cache hits, 120,000 cache misses (DB reads).
**SUCCESS CRITERIA**:
- Cache hit rate > 95% for repeat URLs
- P99 cached response latency < 10ms
- P99 cache-miss response latency < 200ms
- Zero draft content returned (CF-534, CF-525)
- tenantId isolation maintained on all cached pages (CF-522)
**FAILURE MODES**: Cache miss storm after invalidation; draft content in cache; cross-tenant cache pollution.

---

### ST-304 — Hook Fan-Out Handler Isolation

**TARGET TASK TYPES**: T399
**SCENARIO**: One `blog.content.published` event fans out to 20 registered plugin handlers. One handler is a buggy plugin that hangs indefinitely.
**LOAD**: 1 event, 20 handlers, 1 intentionally broken.
**SUCCESS CRITERIA**:
- 19 healthy handlers complete within 5s
- Buggy handler is terminated by IExtensionSandbox after `extensions.sandbox.timeoutMs`
- Buggy handler timeout does NOT affect other handler results
- Buggy handler result stored as `HANDLER_TIMEOUT` in hook results
- CF-515 fan-out limit enforced (no >maxFanout handlers fire)
**FAILURE MODES**: One buggy handler blocks all others; sandbox escape attempt detected (CF-527).

---

### ST-305 — Comment Spam AI Throughput

**TARGET TASK TYPES**: T401, T402
**SCENARIO**: 2000 comment submissions in 60 seconds across 100 tenants. AI spam analysis for each.
**LOAD**: 33 AI calls/second. Mix: 70% ham, 20% spam, 10% borderline (→ human review queue).
**SUCCESS CRITERIA**:
- All comments processed within 30s of submission
- Spam detection AI budget checked before each call (CF-514)
- High-confidence spam (score > 0.9) auto-rejected, no human review
- Borderline (0.4–0.9) queued to T402 moderation queue
- AI budget exhaustion → rule-based fallback activates (not error)
- XSS in comment body blocked (CF-521)
**FAILURE MODES**: AI budget exhausted silently; XSS not sanitized; rate limiting double-counts (CF-531).

---

### ST-306 — Cache Invalidation Cascade After Bulk Publish

**TARGET TASK TYPES**: T397, T398
**SCENARIO**: Admin bulk-publishes 500 draft posts simultaneously. Each triggers cache invalidation cascade.
**LOAD**: 500 `blog.content.published` events → 500 invalidation jobs → potentially millions of cache key evictions.
**SUCCESS CRITERIA**:
- Cache invalidation by tag completes within 30s for all 500 posts
- No partial invalidation (all tags for a post invalidated atomically)
- Redis memory not exhausted by invalidation scan
- Sitemap debounce collapses 500 sitemap jobs into 1 per tenant (CF-519)
**FAILURE MODES**: Partial invalidation leaves stale pages; sitemap storm (CF-519); Redis memory spike.

---

### ST-307 — Cross-Tenant Content Isolation Under Load

**TARGET TASK TYPES**: T389, T391, T396
**SCENARIO**: 50 tenants, each with 200 content items. Under high read/write load, verify zero cross-tenant data access.
**LOAD**: 10,000 mixed operations (read/write/publish) across 50 tenants.
**SUCCESS CRITERIA**:
- Zero results returned with wrong tenantId
- Every ES query contains tenantId in BuildSearchFilter (DNA-2, DNA-5)
- Every Redis key prefixed with tenantId scope
- CF-522 violations: ZERO (config bleed)
- CF-512 violations: ZERO (session bleed)
**FAILURE MODES**: BuildSearchFilter missing tenantId; Redis key missing tenant prefix; ES index shared without filter.

---

### ST-308 — Approval Gate Timeout and DLQ Recovery

**TARGET TASK TYPES**: T391 (approval sub-flow), F1110
**SCENARIO**: 100 publish requests requiring approval. Reviewers are offline. All 100 time out.
**LOAD**: 100 approval requests → all timeout after configured period → DLQ.
**SUCCESS CRITERIA**:
- All 100 timeout messages routed to approval DLQ (not generic DLQ)
- CF-516: FLOW-04 DLQ consumer does NOT auto-retry approval messages
- Admin notification emitted for each timeout
- Content remains in `pending_approval` status (not auto-published)
- On reviewer recovery: admin can re-trigger approval flow for all 100 from DLQ
**FAILURE MODES**: Auto-retry publishes without approval (CF-516); content stuck with no admin alert.

---

### ST-309 — Webhook Retry Storm Recovery

**TARGET TASK TYPES**: T400
**SCENARIO**: Webhook receiver goes offline for 2 minutes. 200 webhooks queued during outage. Receiver comes back online.
**LOAD**: 200 queued webhooks delivered with exponential backoff on recovery.
**SUCCESS CRITERIA**:
- No spike (no all-200 delivered simultaneously)
- Exponential backoff respected (CF-535)
- After 5 retries: DLQ with `WEBHOOK_DELIVERY_FAILED`
- Total webhook retry count within 10x original count
- SSRF validation runs on each retry attempt too (CF-520)
**FAILURE MODES**: Retry storm saturates receiver; SSRF check skipped on retry; endless retry loop.

---

### ST-310 — Taxonomy Propagation at Scale

**TARGET TASK TYPES**: T403
**SCENARIO**: Admin renames a high-traffic taxonomy term used by 10,000 content items. T403 propagates update to all.
**LOAD**: 10,000 document update events queued.
**SUCCESS CRITERIA**:
- All 10,000 documents updated within 5 minutes (eventual consistency)
- Idempotency keys prevent double-application (CF-528)
- Zero orphaned taxonomy references after completion
- No publish or read operations blocked during propagation
- Progress trackable via polling endpoint
**FAILURE MODES**: Orphan references (CF-528); propagation blocks reads; idempotency key collision.

---

### ST-311 — AI Content Enhancement Parallel Models

**TARGET TASK TYPES**: T404
**SCENARIO**: 100 authors simultaneously request AI SEO analysis. AiDispatcher runs Claude + Gemini in parallel.
**LOAD**: 200 parallel AI calls (100 × 2 models). RAG context retrieved for each.
**SUCCESS CRITERIA**:
- All 100 analyses complete within 20s
- AF-10 merge produces coherent result (not raw model dump)
- Circuit breaker activates if one model shows failure rate > 20% (CF-529)
- RAG context retrieval adds < 500ms overhead
- AF-11 feedback stores generation quality for all 100
**FAILURE MODES**: Model blacklisting (CF-529); merge produces incoherent output; RAG timeout blocks generation.

---

### ST-312 — Plugin Load Test

**TARGET TASK TYPES**: T399, F1094 IExtensionSandbox
**SCENARIO**: 50 plugins registered. Each receives `blog.content.published` hook. 1000 publish events fired.
**LOAD**: 50,000 hook executions (1000 events × 50 plugins).
**SUCCESS CRITERIA**:
- maxFanout = 20 enforced per event (max 20,000 actual executions)
- All executions complete or timeout within 5s
- Sandbox isolation: no plugin affects another (CF-527)
- Memory usage stable (no plugin code leak between executions)
**FAILURE MODES**: Fan-out exceeds limit (CF-515); sandbox escape; memory leak.

---

### ST-313 — Permalink Structure Migration

**TARGET TASK TYPES**: F1119, F1113 (config-level)
**SCENARIO**: Admin changes permalink structure for 10,000-post blog from `/{year}/{slug}` to `/{category}/{slug}`.
**LOAD**: 10,000 canonical URL invalidations. 10,000 301 redirects to register.
**SUCCESS CRITERIA**:
- All old canonical URLs flushed from Redis cache (CF-533)
- New canonical URLs generated correctly per new pattern
- Old URL redirect map registered with FLOW-08 router
- Zero stale canonical URLs served after migration
- F1119 change triggers F1113 flush atomically (no window where old and new mix)
**FAILURE MODES**: Partial cache flush (CF-533); old URLs served without redirect; canonical mix.

---

### ST-314 — Media Upload Security Gauntlet

**TARGET TASK TYPES**: T394
**SCENARIO**: 100 upload attempts including: EICAR test virus, .php disguised as .jpg, 100MB file (over quota), SVG with embedded script, zip bomb disguised as image.
**LOAD**: 100 adversarial uploads.
**SUCCESS CRITERIA**:
- EICAR: rejected by virus scan hook (CF-543)
- PHP-as-JPG: rejected by content-type validation (AF-8)
- Over quota: rejected pre-upload by F1081 quota check (CF-523)
- SVG+script: sanitized or rejected (AF-8)
- Zip bomb: size limit enforced before decompression
- Zero adversarial files reach blob storage
**FAILURE MODES**: Any adversarial file accepted = security BUILD FAILURE.

---

### ST-315 through ST-323 — Extended Scenarios (Summary)

**ST-315 — Maintenance Mode Toggle Under Load**: 10,000 concurrent requests when IMaintenanceModeService toggles maintenance ON. All in-flight requests complete; new requests return 503. Toggle back OFF — no dropped requests.

**ST-316 — Editorial Role Permission Cache Invalidation**: Admin demotes user from Editor to Subscriber. All in-flight edit sessions by that user fail immediately (not served from stale cache). IContentPermissionService (F1114) cache TTL < 5s.

**ST-317 — RSS Feed Under High Subscriber Load**: 100,000 RSS feed requests/minute. IFeedGenerator (F1112) uses page cache. Feed regenerated only on `blog.content.published`. Cache TTL: 15 minutes. Hit rate > 99%.

**ST-318 — Search Index Rebuild at Scale**: Full tenant reindex (100,000 posts). IContentIndexer.ReindexTenantAsync() runs without blocking public read traffic. Estimated completion: < 30 minutes. Zero downtime.

**ST-319 — Comment Threading Depth Limit (CF-540)**: Attempt to post comment at depth 4 when maxDepth=3. Rejected with `THREADING_DEPTH_EXCEEDED`. No DB write for rejected comment.

**ST-320 — Scheduled Publish Backlog**: 1000 scheduled posts all set to same publish time. T392 processes backlog. Rate limited to prevent T391 saturation. Completion within 10 minutes. Fairness across tenants.

**ST-321 — Concurrent Moderation and Author Appeal**: Same comment simultaneously reviewed by moderator (T402) and appealed by author. Optimistic lock prevents double-decision. Second decision returns `MODERATION_CONFLICT` status.

**ST-322 — FREEDOM Config Hot Reload**: Admin changes `extensions.hooks.maxFanout` from 20 to 5 at runtime. In-flight hook fan-outs with 20 handlers: complete (not killed mid-flight). New fan-outs: capped at 5. Config reload propagated within 30s.

**ST-323 — Plugin Hook Priority Race**: Two plugins register for same hook with same priority. Engine assigns deterministic execution order (alphabetical pluginId). No race condition. Order stable across restarts.

---

## ARTIFACT NUMBERS SUMMARY

| Artifact | Range | Count |
|----------|-------|-------|
| BFA Conflict Rules | CF-510–CF-544 | 35 rules |
| Stress Tests | ST-300–ST-323 | 24 tests |

---

## STATE SAVE CHECKPOINT

```
FILE: 28-blog-modules_V62_BFA_STRESS_TEST.md
STATUS: COMPLETE ✅
BFA RULES ADDED: CF-510–CF-544 (35 rules)
STRESS TESTS ADDED: ST-300–ST-323 (24 tests)
NEXT FILE: 28-blog-modules_SESSION_STATE.md
```
