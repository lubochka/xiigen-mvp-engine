# FLOW-27 — TASK TYPES CATALOG
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: TASK_TYPES_CATALOG_MERGED.md (T1-T388 unchanged)
## FLOW-27 Task Types: T389–T398
## Templates: 83–84
## Status: AUTHORITATIVE — FLOW-27 ONLY

---

## TASK TYPE: T389 — HumanInteractionGate Node

```
ARCHETYPE:          HUMAN_GATE
ENTRY:              Fires when orchestrator reaches a node with nodeType=HumanInteractionGate
                    in the flow DAG. Can be triggered from any flow template.
PURPOSE:            Suspend the current node's execution path, create a durable UserTask
                    record (via F1075), capture execution context snapshot (via F1077),
                    emit UserTaskCreated notification (via F1096), and suspend until answered.
                    Non-blocking policy: continue with defaults without waiting.
                    Optional policy: skip if time exceeds dueAt.
DISTINCT FROM:      T379 (Conflict Resolution Gate — BFA arbitration, not user input)
                    T285 (Tenant Onboarding Saga — system-level saga, not interactive gate)
                    Previous HumanApprovalGate concept (T389 is the formalized engine contract)

FACTORY DEPENDENCIES:
  F1075: IHumanInteractionGateService     (open gate, get status, skip, expire, cancel)
  F1076: IUserTaskRegistryService          (store/retrieve UserTask document)
  F1077: ITaskContextSnapshotService       (capture immutable context snapshot)
  F1078: ITaskAssignmentResolverService    (resolve eligible users from policy)
  F1087: IDependencySchedulerService       (re-evaluate nodes after gate closes)
  F1100: IUserTaskAnswerProcessorService   (process incoming answer)

FABRIC RESOLUTION:
  F1075 → DATABASE FABRIC (Skill 05 → Elasticsearch user-tasks) +
           QUEUE FABRIC (Skill 04 → Redis Streams hig-events)
  F1076 → DATABASE FABRIC (Skill 05 → Elasticsearch user-tasks)
  F1077 → DATABASE FABRIC (Skill 05 → Elasticsearch task-context-snapshots)
  F1078 → DATABASE FABRIC (Skill 05 → PostgreSQL assignment-policies)
  F1087 → QUEUE FABRIC (Skill 04 → Redis Streams ready-queue)
  F1100 → DATABASE FABRIC (Skill 05 → Elasticsearch user-tasks) +
           QUEUE FABRIC (Skill 04 → Redis Streams hig-events)

AF CONFIGURATION:
  AF-2 Planning:     Decomposes gate into: open → capture → assign → notify → wait → resume
  AF-7 Compliance:   Checks DNA-5 (tenantId on all documents), DNA-1 (Dictionary storage),
                     DNA-3 (DataProcessResult on all methods)
  AF-9 Judge:        Validates: contextSnapshot captured before gate opens,
                     assigneePolicy resolves > 0 eligible users, blockingPolicy declared,
                     resumeTargets[] populated from DAG analysis

BFA VALIDATION:
  CF-510: UserTask cross-tenant visibility — tenantId must isolate all task queries
  CF-511: Duplicate gate prevention — same nodeId+runId cannot have 2 open tasks
  CF-515: Dependent node pre-fire guard — downstream nodes MUST NOT start while gate is blocking
  CF-520: CompletionGate must not close while required gates open

MACHINE/FREEDOM:
  MACHINE (non-configurable):
    - tenantId required on all documents
    - contextSnapshot captured before gate enters waiting_for_user
    - resumeTargets computed from DAG (not manually set)
    - UserTaskAnswered event MUST trigger DependencyScheduler
  FREEDOM (admin-configurable):
    - blockingPolicy: blocking | non_blocking | optional
    - assigneePolicy: user | group | role | anyOf | allOf | quorum
    - dueAt (expiry time)
    - priority
    - questionType and expectedAnswerSchema

IRON RULES:
  IR-T389-1: Gate MUST capture contextSnapshot BEFORE entering waiting_for_user state
  IR-T389-2: Gate MUST emit UserTaskCreated to QUEUE FABRIC atomically (outbox pattern)
  IR-T389-3: non_blocking gate MUST proceed with defaults if dueAt passes — NEVER block run
  IR-T389-4: blocking gate MUST block ALL transitive dependents until answered or expired
  IR-T389-5: ALL documents MUST include tenantId — BUILD FAILURE if missing

QUALITY GATES (AF-9):
  ✓ contextSnapshot doc exists in ES before gate status = waiting_for_user
  ✓ assigneePolicy resolves to at least 1 eligible user within tenant
  ✓ resumeTargets[] correctly identifies downstream nodes from waitFor DAG
  ✓ blockingPolicy declared and valid enum value
  ✓ UserTaskCreated event confirmed in QUEUE FABRIC within 500ms of gate opening
```

---

## TASK TYPE: T390 — GroupUserTask Assignment Gate

```
ARCHETYPE:          ASSIGNMENT
ENTRY:              Fires as sub-step of T389 (HumanInteractionGate) when assigneePolicy.type
                    is group | role | anyOf | allOf | quorum
PURPOSE:            Resolve group/role membership to actual user IDs within tenant.
                    Manage claim lifecycle for single_claim tasks.
                    Track quorum progress for allOf/quorum policies.
                    Prevent duplicate or conflicting answers via claim management.
DISTINCT FROM:      T389 (opens the gate; T390 manages who can answer it)

FACTORY DEPENDENCIES:
  F1078: ITaskAssignmentResolverService  (resolve eligible users)
  F1079: ITaskClaimService               (claim/release/expire management)
  F1080: ITaskQuorumService              (record answers, evaluate quorum)
  F1097: IGroupMembershipResolverService (group/role membership lookup)

FABRIC RESOLUTION:
  F1078 → DATABASE FABRIC (Skill 05 → PostgreSQL assignment-policies + group-membership)
  F1079 → DATABASE FABRIC (Skill 05 → PostgreSQL task-claims) +
           QUEUE FABRIC (Skill 04 → Redis Streams claim-events)
  F1080 → DATABASE FABRIC (Skill 05 → PostgreSQL task-quorums)
  F1097 → DATABASE FABRIC (Skill 05 → PostgreSQL group-membership)

AF CONFIGURATION:
  AF-7 Compliance:   Checks cross-tenant group resolution is forbidden (CF-517)
  AF-9 Judge:        Validates quorum.needed <= group size at assignment time,
                     claim TTL > 0 when claimMode != none,
                     allOf answers deduplicated by userId

BFA VALIDATION:
  CF-512: Quorum answer race condition guard
  CF-513: Claim TTL expiry conflict rule
  CF-517: Group membership must be tenant-scoped
  CF-521: Claim release orphan prevention
  CF-526: Quorum partial answer preservation
  CF-530: allOf answer completeness gate

MACHINE/FREEDOM:
  MACHINE:
    - Group membership queried within tenantId only
    - Duplicate answers from same user rejected (idempotency by userId+taskId)
    - All recorded answers preserved after quorum (audit trail)
    - Claim TTL expiry emits ClaimExpired and auto-releases
  FREEDOM:
    - claimMode: none | single_claim | multi_claim
    - claimTtlSec (default: 1800)
    - allowReassign: bool
    - quorum.needed, quorum.outOf

IRON RULES:
  IR-T390-1: quorum.needed > group size at assignment time = IMMEDIATE FAILURE with explanation
  IR-T390-2: Cross-tenant group reference in assigneePolicy = BUILD FAILURE
  IR-T390-3: single_claim: only 1 active claim at a time (database-enforced)
  IR-T390-4: Answer from non-eligible user = rejected with 403 equivalent DataProcessResult

QUALITY GATES (AF-9):
  ✓ ResolveEligibleUsersAsync returns > 0 results (or clear "no eligible users" failure)
  ✓ For quorum: needed <= actual group size
  ✓ Claim release on TTL confirmed (ST-304 scenario passes)
  ✓ Duplicate answer rejected (ST-301 scenario passes)
```

---

## TASK TYPE: T391 — DependencyAwareScheduler

```
ARCHETYPE:          ORCHESTRATION
ENTRY:              Fires after ANY node state change event (NodeCompleted, NodeFailed,
                    NodeSkipped, UserTaskAnswered, UserTaskExpired)
PURPOSE:            Re-evaluate all BLOCKED/PENDING nodes in the run to find newly READY
                    nodes. Enqueue them for execution. Ensure independent branches keep
                    running even when one branch is WAITING_FOR_USER.
                    This is the engine's "keep working" guarantee.
DISTINCT FROM:      T40 (Three-Way Join Gate — specific join; T391 is the universal scheduler)
                    T33 (Two-way convergence — T391 handles any DAG topology)

FACTORY DEPENDENCIES:
  F1087: IDependencySchedulerService     (evaluate ready nodes, enqueue)
  F1088: INodeReadinessEvaluatorService  (evaluate single node readiness)
  F1089: IBlockedNodeResolverService     (find nodes unblocked by completed node)
  F1090: IJoinPolicyEnforcerService      (evaluate join semantics)
  F1091: IDagWalkerService               (cycle detection, transitive deps)

FABRIC RESOLUTION:
  F1087 → QUEUE FABRIC (Skill 04 → Redis Streams ready-queue)
  F1088 → DATABASE FABRIC (Skill 05 → Elasticsearch node-snapshots + flow-definitions)
  F1089 → QUEUE FABRIC (Skill 04 → Redis Streams resume-events)
  F1090 → DATABASE FABRIC (Skill 05 → Elasticsearch flow-definitions)
  F1091 → DATABASE FABRIC (Skill 05 → Elasticsearch flow-definitions)

AF CONFIGURATION:
  AF-2 Planning:   Decomposes into: load DAG → evaluate each node → sort by readiness →
                   apply join policy → enqueue READY → emit BlockedNodeResolved
  AF-9 Judge:      Validates: no cycles in DAG (F1091), join policy correctly applied,
                   WAITING_FOR_USER nodes correctly kept BLOCKED (not incorrectly made READY)

BFA VALIDATION:
  CF-515: Dependent node pre-fire guard
  CF-519: allSettled non-blocking branch rule
  CF-527: DependencyScheduler cycle detection rule
  CF-529: Cross-flow HumanTask propagation fence

MACHINE/FREEDOM:
  MACHINE:
    - Node READY only when ALL required waitFor satisfied (no exceptions)
    - Join policy from flow-definition (not overridable at runtime)
    - DAG cycle = immediate run failure
  FREEDOM:
    - Join mode per join node: all | allSettled | required+optional
    - progressWeight per node (for progress calculation)

IRON RULES:
  IR-T391-1: DAG cycle detected = run FAILED immediately with clear error
  IR-T391-2: NEVER enqueue a node as READY if any required dependency is non-terminal
  IR-T391-3: WAITING_FOR_USER gate must NOT propagate as READY to dependent nodes
  IR-T391-4: DependencyScheduler MUST run after every node state change event

QUALITY GATES (AF-9):
  ✓ Cycle detection runs at flow load time (not just at execution time)
  ✓ allSettled join correctly proceeds with partial results (FLOW-05 pattern reused)
  ✓ Non-blocking HIG branch continues while other branches run
  ✓ After UserTaskAnswered: transitive dependents re-evaluated and READY ones enqueued
```

---

## TASK TYPE: T392 — RunProgressAggregator

```
ARCHETYPE:          MONITORING
ENTRY:              Fires on any NodeEvent (NodeStarted, SubStepCompleted, NodeProgress,
                    NodeCompleted, NodeFailed, NodeSkipped, etc.)
PURPOSE:            Maintain the materialized RunSnapshot and NodeSnapshot views.
                    Compute progress % using weighted-sum algorithm.
                    Provide real-time progress data for the UI graph API.
DISTINCT FROM:      T394 (NodeStateProjector — handles event sourcing; T392 handles aggregation)

FACTORY DEPENDENCIES:
  F1081: IRunSnapshotService           (store/read RunSnapshot)
  F1082: INodeSnapshotService          (store/read NodeSnapshot)
  F1083: INodeEventEmitterService      (emit NodeProgress events)
  F1084: IFlowProgressAggregatorService (compute progress %)

FABRIC RESOLUTION:
  F1081 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots)
  F1082 → DATABASE FABRIC (Skill 05 → Elasticsearch node-snapshots)
  F1083 → QUEUE FABRIC (Skill 04 → Redis Streams node-events)
  F1084 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots + node-snapshots)

AF CONFIGURATION:
  AF-7 Compliance:   Validates DNA-5 (tenantId on all snapshots)
  AF-9 Judge:        Validates progress % stays in [0.0, 1.0], summary counts sum correctly,
                     snapshot updated within 1s of triggering event

BFA VALIDATION:
  CF-514: Stale snapshot invalidation rule
  CF-516: Run terminal state idempotency rule
  CF-522: NodeSnapshot tenant isolation rule
  CF-524: SubFlow progress rollup integrity rule

MACHINE/FREEDOM:
  MACHINE:
    - Progress algorithm: Σ(weight × statusWeight) / Σ(weight)
    - statusWeight: SUCCEEDED=1.0, RUNNING=0.5, all others=0.0
    - Snapshot updated on every NodeEvent
  FREEDOM:
    - progressWeight per node (default: 1)
    - SubFlow progress from childRun rollup vs provider telemetry (configurable)

IRON RULES:
  IR-T392-1: RunSnapshot.tenantId and NodeSnapshot.tenantId NEVER null
  IR-T392-2: Progress % NEVER exceeds 1.0 regardless of weight configuration
  IR-T392-3: SubFlow progress = child RunSnapshot.progressPct (recursive)

QUALITY GATES (AF-9):
  ✓ Progress % correctly computed for mix of SUCCEEDED/RUNNING/WAITING/FAILED nodes
  ✓ SubFlow node shows child run's rollup progress
  ✓ SKIPPED nodes contribute 1.0 × weight to progress (intentionally not executed)
  ✓ Snapshot tenant isolation: query without tenantId returns empty
```

---

## TASK TYPE: T393 — CompletionGateValidator

```
ARCHETYPE:          VALIDATION
ENTRY:              Fires when ALL nodes in run reach terminal status (no more READY/RUNNING/PENDING)
                    OR when explicitly called by orchestrator after last node completes.
PURPOSE:            Validate ALL completion criteria before marking run as READY:
                    required terminal nodes succeeded, zero open required UserTasks,
                    all AF-9 JudgeService verdicts approved. If not ready, classify why.
DISTINCT FROM:      T393 validates run-level completion. T389 validates node-level gate.

FACTORY DEPENDENCIES:
  F1092: ICompletionGateService         (evaluate + mark complete)
  F1093: IRunReadinessValidatorService  (list all blockers)
  F1094: IRunTerminalStateService       (emit terminal state events)
  F1095: IPendingGateResolverService    (count open required gates)

FABRIC RESOLUTION:
  F1092 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots + user-tasks)
  F1093 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots + user-tasks)
  F1094 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots) +
           QUEUE FABRIC (Skill 04 → Redis Streams)
  F1095 → DATABASE FABRIC (Skill 05 → Elasticsearch user-tasks)

AF CONFIGURATION:
  AF-9 Judge:  Validates completion rule strictly:
               1) ALL terminal nodes: SUCCEEDED
               2) Open required UserTasks = 0
               3) JudgeService approved on all required gates
               REJECTS run-ready if any condition fails

BFA VALIDATION:
  CF-520: CompletionGate must not fire while required gates open
  CF-528: RunReadiness required terminal node rule

MACHINE/FREEDOM:
  MACHINE:
    - All 3 completion conditions required (non-negotiable)
    - MarkRunReadyAsync MUST call EvaluateCompletionAsync first
  FREEDOM:
    - Which nodes are "required terminal nodes" (from flow definition)
    - Which phase gates require JudgeService approval (from flow definition)

IRON RULES:
  IR-T393-1: NEVER mark run READY if open required UserTasks > 0
  IR-T393-2: NEVER mark run READY if any required terminal node is non-SUCCEEDED
  IR-T393-3: NEVER mark run READY if JudgeService has pending/rejected verdict on required gate
  IR-T393-4: MarkRunReadyAsync is idempotent (already-READY run = no-op, not error)

QUALITY GATES (AF-9):
  ✓ Optional blocking gates (blockingPolicy=optional) do NOT prevent READY
  ✓ non_blocking gates with defaults DO NOT count as "open required gates"
  ✓ Run FAILED state: CompletionGate correctly classifies as FailedNeedsRepair
  ✓ PendingUserInput status shown when blocking gates are open
```

---

## TASK TYPE: T394 — NodeStateProjector

```
ARCHETYPE:          EVENT_SOURCING
ENTRY:              Consumes all NodeEvents from QUEUE FABRIC (Redis Streams node-events)
PURPOSE:            Project immutable NodeEvents → mutable NodeSnapshot.
                    Implements event-sourcing read model. Ensures UI always gets consistent
                    snapshot even during concurrent updates. Write path and read path separated.
DISTINCT FROM:      T392 (aggregates progress %; T394 handles event→snapshot projection)

FACTORY DEPENDENCIES:
  F1082: INodeSnapshotService     (upsert NodeSnapshot)
  F1083: INodeEventEmitterService (consume events from node-events stream)
  F1081: IRunSnapshotService      (update RunSnapshot.summary after each projection)

FABRIC RESOLUTION:
  F1082 → DATABASE FABRIC (Skill 05 → Elasticsearch node-snapshots)
  F1083 → QUEUE FABRIC (Skill 04 → Redis Streams node-events)
  F1081 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots)

AF CONFIGURATION:
  AF-7 Compliance:  Validates idempotent projection (same event applied twice = same result)
  AF-9 Judge:       Validates event order handling (out-of-order event does not corrupt state)

BFA VALIDATION:
  CF-516: Run terminal state idempotency rule

MACHINE/FREEDOM:
  MACHINE:
    - Projection is deterministic: same events = same snapshot
    - Events consumed via consumer group (exactly-once semantics)
    - Snapshot version increments with each applied event

IRON RULES:
  IR-T394-1: Projection MUST be idempotent (eventId deduplicated)
  IR-T394-2: Consumer group MUST include tenantId in consumer name for isolation
  IR-T394-3: NEVER discard events — dead letter queue for projection failures

QUALITY GATES (AF-9):
  ✓ Duplicate event does not change snapshot (idempotency check)
  ✓ Out-of-order event handled gracefully (version check)
  ✓ Snapshot tenant isolation enforced at projection level
```

---

## TASK TYPE: T395 — SubFlowDrilldownBridge

```
ARCHETYPE:          NAVIGATION
ENTRY:              Called when UI requests childRun details for a SubFlow node
                    OR when DependencyScheduler needs to aggregate SubFlow progress
PURPOSE:            Bridge between parent run context and child run context.
                    Provides breadcrumb navigation: ParentRun → Node → ChildRun.
                    Aggregates child RunSnapshot progress into parent NodeSnapshot.
                    Exposes same RunGraph API for child runs (recursive).
DISTINCT FROM:      T392 (progress aggregation; T395 handles navigation + bridging)

FACTORY DEPENDENCIES:
  F1081: IRunSnapshotService       (get child RunSnapshot for rollup)
  F1082: INodeSnapshotService      (update parent NodeSnapshot with child progress)
  F1085: IRunGraphQueryService     (get child run graph for drill-down)
  F1086: INodeDebugSurfaceService  (provide trace debug links for child run)

FABRIC RESOLUTION:
  F1081 → DATABASE FABRIC (Skill 05 → Elasticsearch run-snapshots)
  F1082 → DATABASE FABRIC (Skill 05 → Elasticsearch node-snapshots)
  F1085 → DATABASE FABRIC (Skill 05 → Elasticsearch node-snapshots + flow-definitions)
  F1086 → DATABASE FABRIC (Skill 05 → Elasticsearch trace-debug)

MACHINE/FREEDOM:
  MACHINE:
    - breadcrumb is computed from run hierarchy (not user-configured)
    - child progress rollup = childRun.progressPct
  FREEDOM:
    - Max drill-down depth (default: 10 levels)

IRON RULES:
  IR-T395-1: Child run MUST belong to same tenantId as parent (CF-529)
  IR-T395-2: Drill-down API MUST respect tenant scope — child run in different tenant = 404

QUALITY GATES (AF-9):
  ✓ Breadcrumb correctly shows ParentRun → NodeName → ChildRun
  ✓ Child run graph uses same node status enum as parent
  ✓ SubFlow node progress = child progressPct (not hard-coded)
```

---

## TASK TYPE: T396 — TaskClaimManager

```
ARCHETYPE:          COORDINATION
ENTRY:              Fires on UserTask claim request or claim TTL check
PURPOSE:            Manage single_claim / multi_claim lifecycle. Prevents conflicting answers.
                    Handles TTL expiry with auto-release and notification.
                    Supports reassignment with audit trail.
DISTINCT FROM:      T390 (assignment resolves who can answer; T396 manages who is answering now)

FACTORY DEPENDENCIES:
  F1079: ITaskClaimService             (claim/release/expire)
  F1076: IUserTaskRegistryService      (update task claim status)
  F1078: ITaskAssignmentResolverService (verify eligibility before claim)
  F1096: ITaskNotificationOrchestratorService (notify of claim/release)

FABRIC RESOLUTION:
  F1079 → DATABASE FABRIC (Skill 05 → PostgreSQL task-claims) +
           QUEUE FABRIC (Skill 04 → Redis Streams claim-events)
  F1076 → DATABASE FABRIC (Skill 05 → Elasticsearch user-tasks)
  F1078 → DATABASE FABRIC (Skill 05 → PostgreSQL assignment-policies)
  F1096 → QUEUE FABRIC (Skill 04 → Redis Streams notification-events)

BFA VALIDATION:
  CF-513: Claim TTL expiry conflict rule
  CF-521: Claim release orphan prevention
  CF-525: UserTask reassignment audit fence

IRON RULES:
  IR-T396-1: single_claim: optimistic lock — second claim attempt returns conflict result
  IR-T396-2: Claim expiry MUST be scheduled at claim time (TTL-based trigger)
  IR-T396-3: Reassignment MUST create audit event (who reassigned, when, from whom, to whom)

QUALITY GATES (AF-9):
  ✓ Concurrent claim from 2 users: exactly 1 succeeds (ST-303 scenario)
  ✓ TTL expiry releases claim and notifies group (ST-304 scenario)
  ✓ Reassignment audit event stored (CF-525)
```

---

## TASK TYPE: T397 — NotificationFanoutOrchestrator

```
ARCHETYPE:          NOTIFICATION
ENTRY:              Fires on UserTaskCreated event (from QUEUE FABRIC hig-events stream)
PURPOSE:            Fan-out notifications to all eligible recipients for a UserTask.
                    Resolve group/role members within tenant. Deduplicate per channel/recipient.
                    Include rich context payload (trace links, decision description, answer URL).
                    Support reminder notifications as dueAt approaches.
DISTINCT FROM:      T389 (opens gate; T397 handles notification side-effect of opening)

FACTORY DEPENDENCIES:
  F1096: ITaskNotificationOrchestratorService (orchestrate full pipeline)
  F1097: IGroupMembershipResolverService      (resolve recipients)
  F1098: INotificationDedupeService           (prevent duplicate sends)
  F1099: INotificationDeepLinkService         (build context + answer URLs)
  // F68: INotificationProvider (Management fabric — existing, reused)

FABRIC RESOLUTION:
  F1096 → QUEUE FABRIC (Skill 04 → Redis Streams notification-events)
  F1097 → DATABASE FABRIC (Skill 05 → PostgreSQL group-membership)
  F1098 → DATABASE FABRIC (Skill 05 → Redis notif-dedup-cache)
  F1099 → CORE FABRIC (Skill 01 → config)
  // F68 → existing Management fabric notification providers (Slack, Email, In-App, Teams...)

BFA VALIDATION:
  CF-518: Notification anti-spam fence
  CF-517: Group membership tenant scope rule

MACHINE/FREEDOM:
  MACHINE:
    - Recipients resolved within tenantId only (cross-tenant = forbidden)
    - Dedup key = taskId + channel + recipient (per-combination)
    - viewContextUrl and answerUrl always included
  FREEDOM:
    - Notification channels (in-app / email / Slack / Teams — via F68)
    - Reminder schedule (hours before dueAt)
    - Urgency levels mapping

IRON RULES:
  IR-T397-1: Cross-tenant recipient resolution = BUILD FAILURE
  IR-T397-2: viewContextUrl and answerUrl MUST be in every notification payload
  IR-T397-3: Anti-spam: one active notification per (taskId + channel + recipient)

QUALITY GATES (AF-9):
  ✓ Duplicate send prevented for same taskId+channel+recipient (ST-313 scenario)
  ✓ Group dissolved after task assigned — graceful degradation (ST-310 scenario)
  ✓ Notification payload includes all required fields (viewContextUrl, answerUrl, dueAt)
```

---

## TASK TYPE: T398 — MultiTenantTaskVisibilityGate

```
ARCHETYPE:          GOVERNANCE
ENTRY:              Fires on any user-tasks query API call or UserTask list request
PURPOSE:            Enforce tenant isolation on ALL UserTask visibility operations.
                    Ensure users only see tasks for their tenant, their assignments,
                    and their permission level (viewer vs answerer). Enforce DNA-5.
DISTINCT FROM:      T386 (BFA Multi-Tenant Isolation — BFA-specific; T398 is UserTask-specific)

FACTORY DEPENDENCIES:
  F1076: IUserTaskRegistryService      (tenant-scoped task queries)
  F1078: ITaskAssignmentResolverService (visibility check)
  F1082: INodeSnapshotService          (tenant-scoped node queries)
  F1081: IRunSnapshotService           (tenant-scoped run queries)

FABRIC RESOLUTION:
  All → DATABASE FABRIC (Skill 05 → Elasticsearch, PostgreSQL) — all with tenantId filter

AF CONFIGURATION:
  AF-7 Compliance:  Validates DNA-5 (tenantId on every query), rejects unscoped queries
  AF-8 Security:    Validates OWASP API1 — object-level authorization on every taskId lookup
  AF-9 Judge:       Validates: query without tenantId returns empty (not error), never leaks

BFA VALIDATION:
  CF-510: UserTask cross-tenant visibility fence
  CF-522: NodeSnapshot tenant isolation rule

MACHINE/FREEDOM:
  MACHINE:
    - tenantId MANDATORY on every query (DNA-5)
    - IsEligibleToViewAsync must pass before returning task details
    - Cross-tenant object ID access = 403/404 (never 500)

IRON RULES:
  IR-T398-1: Any query without tenantId = DataProcessResult.Failure (not empty result)
  IR-T398-2: User accessing taskId from different tenant = 404 (not 403, to prevent enumeration)
  IR-T398-3: Admin role does NOT override tenant boundary (only super-admin with audit log)

QUALITY GATES (AF-9):
  ✓ Tenant A user cannot see Tenant B tasks (cross-tenant test passes)
  ✓ Non-eligible user gets 404 on task detail (OWASP API1 compliant)
  ✓ ListUserTasksAsync with no tenantId returns DataProcessResult.Failure
```

---

## TEMPLATE 83 — human-interaction-flow-v1

**Purpose:** DAG template showing how any flow embeds HumanInteractionGate nodes
with dependency-aware scheduling and non-blocking branch semantics.

```json
{
  "templateId": "human-interaction-flow-v1",
  "version": "1.0.0",
  "description": "Flow template with human interaction gates, dependency scheduler, non-blocking branches",
  "nodes": [
    {
      "nodeId": "start",
      "nodeType": "StartNode",
      "waitFor": []
    },
    {
      "nodeId": "auto-branch-a",
      "nodeType": "AutomatedTask",
      "waitFor": ["start"],
      "progressWeight": 3
    },
    {
      "nodeId": "auto-branch-b",
      "nodeType": "AutomatedTask",
      "waitFor": ["start"],
      "progressWeight": 2
    },
    {
      "nodeId": "human-gate-1",
      "nodeType": "HumanInteractionGate",
      "taskType": "T389",
      "waitFor": ["start"],
      "blockingPolicy": "blocking",
      "assigneePolicy": { "type": "group", "targets": ["architects"] },
      "progressWeight": 1
    },
    {
      "nodeId": "post-human-task",
      "nodeType": "AutomatedTask",
      "waitFor": ["human-gate-1"],
      "progressWeight": 2
    },
    {
      "nodeId": "join",
      "nodeType": "JoinGate",
      "taskType": "T391",
      "joinPolicy": "required+optional",
      "required": ["auto-branch-a", "post-human-task"],
      "optional": ["auto-branch-b"],
      "waitFor": ["auto-branch-a", "post-human-task", "auto-branch-b"]
    },
    {
      "nodeId": "completion",
      "nodeType": "CompletionGate",
      "taskType": "T393",
      "waitFor": ["join"],
      "requiredTerminalNodes": ["join"],
      "requiredJudgeGates": []
    }
  ]
}
```

**Key behaviors demonstrated:**
- auto-branch-a and auto-branch-b run immediately after start
- human-gate-1 runs concurrently (non-blocking to auto-branches)
- post-human-task is BLOCKED until human-gate-1 is ANSWERED
- join waits for auto-branch-a (required) + post-human-task (required) + auto-branch-b (optional)
- Engine keeps working on auto-branches while human-gate-1 waits

---

## TEMPLATE 84 — progress-run-dashboard-v1

**Purpose:** API contract + snapshot schema for UI progress dashboard.
Fabric-first: zero platform-specific rendering — pure data contract.

```json
{
  "templateId": "progress-run-dashboard-v1",
  "version": "1.0.0",
  "apiContracts": {
    "getRunGraph": {
      "method": "GET",
      "path": "/v1/tenants/{tenantId}/runs/{runId}/graph",
      "factory": "F1085",
      "responseShape": {
        "nodes": [{
          "id": "string",
          "type": "string",
          "nodeName": "string",
          "status": "PENDING|READY|RUNNING|WAITING_FOR_USER|BLOCKED|SUCCEEDED|FAILED|SKIPPED|CANCELLED",
          "progress": "float [0,1]",
          "progressPct": "string (e.g. '67%')",
          "blockedBy": ["nodeId"],
          "taskId": "string|null",
          "childRunIds": ["runId"],
          "subStepCount": "int",
          "subStepDone": "int",
          "assigneeDisplay": "string|null (e.g. 'Architects', 'Claimed by Dana')"
        }],
        "edges": [{ "from": "nodeId", "to": "nodeId" }],
        "summary": {
          "total": "int", "completed": "int", "running": "int",
          "waitingUser": "int", "blocked": "int", "failed": "int", "skipped": "int"
        },
        "progressPct": "float",
        "runStatus": "string"
      }
    },
    "getNodeDetail": {
      "method": "GET",
      "path": "/v1/tenants/{tenantId}/runs/{runId}/nodes/{nodeId}",
      "factory": "F1085",
      "tabs": ["summary", "subSteps", "inputsOutputs", "judgeGates", "childExecution"]
    }
  },
  "nodeChipRenderingRules": {
    "PENDING":            { "color": "gray",   "icon": "clock",     "label": "Pending" },
    "READY":              { "color": "blue",   "icon": "ready",     "label": "Ready" },
    "RUNNING":            { "color": "blue",   "icon": "spinner",   "label": "Running {pct}%" },
    "WAITING_FOR_USER":   { "color": "amber",  "icon": "user",      "label": "Waiting: {assigneeDisplay}" },
    "BLOCKED":            { "color": "orange", "icon": "lock",      "label": "Blocked by {blockedBy[0]}" },
    "SUCCEEDED":          { "color": "green",  "icon": "check",     "label": "Done" },
    "FAILED":             { "color": "red",    "icon": "x",         "label": "Failed" },
    "SKIPPED":            { "color": "gray",   "icon": "skip",      "label": "Skipped" },
    "CANCELLED":          { "color": "gray",   "icon": "cancel",    "label": "Cancelled" }
  }
}
```
