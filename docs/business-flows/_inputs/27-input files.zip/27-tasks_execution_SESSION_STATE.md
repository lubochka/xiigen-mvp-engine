# FLOW-27 — SESSION STATE
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: SESSION_STATE_MERGE.md
## Status: AUTHORITATIVE — FLOW-27 artifacts only

---

## GLOBAL STATE SNAPSHOT (Post FLOW-27)

| Artifact | Pre-FLOW-27 | FLOW-27 Added | Post-FLOW-27 Total |
|----------|-------------|---------------|---------------------|
| Factories | F1-F1074 | F1075-F1100 (26) | F1-F1100 |
| Families | 1-83 | 84 (1) | 84 families |
| Task Types | T1-T388 | T389-T398 (10) | T1-T398 |
| Templates | 1-49 | 50 (1) | 50 templates |
| BFA Rules | CF-1-CF-509 | CF-510-CF-530 (21) | CF-1-CF-530 |
| Stress Tests | ST-1-ST-299 | ST-300-ST-319 (20) | ST-1-ST-319 |
| Skills | SK-1-SK-250 | SK-251-SK-261 (11) | SK-1-SK-261 |
| Design Decisions | DD-1-DD-129 | DD-130-DD-139 (10) | DD-1-DD-139 |
| Design Records | DR-1-DR-98 | DR-99-DR-105 (7) | DR-1-DR-105 |
| DNA Patterns | DNA-1 to DNA-9 | — | 9 patterns |
| Engine Primitives | EP-1 to EP-5 | EP-6 (1) | EP-1 to EP-6 |

---

## NEXT AVAILABLE NUMBERS (FLOW-28 starts here)

```
Factory:         F1101     Family: 85
Task Type:       T399
Template:        51
BFA Rule:        CF-531
Stress Test:     ST-320
Skill:           SK-262
Design Decision: DD-140
Design Record:   DR-106
Engine Primitive: EP-7
```

---

## FLOW-27 SCOPE

### What FLOW-27 Introduces

FLOW-27 adds an **Engine-Level Primitive** — the Human Interaction Gate (HIG) + Visual Runtime State + Dependency-Aware Scheduling — that sits **under all flow templates** (not a flow-specific feature). Any flow running on the engine immediately gains these capabilities without code changes.

**EP-6: HumanInteractionGate** — Universal node type. Suspends flow execution at any point, awaits human answer, resumes dependents. Supports `blocking | non_blocking | optional` policies.

**UserTask Registry** — Durable, tenant-scoped storage for human tasks. Group/role/quorum assignment, claim semantics, TTL, multi-approver collection. Stored via DATABASE FABRIC.

**DependencyAwareScheduler** — Generic DAG scheduler. Keeps executing READY nodes while BLOCKED/WAITING_FOR_USER nodes are suspended. Uses existing `waitFor[]` / `dependsOn[]` from flow JSON — no schema changes needed.

**Visual Runtime State Layer** — Per-node status + progress %. Node Inspector (summary, sub-steps, inputs/outputs, judge gates, SubFlow drill-down). Click WAITING_FOR_USER → answer modal. All via two universal APIs.

**Multi-Tenant Group Tasks** — Tasks assignable to `user | group | role | anyOf | allOf | quorum` within tenant boundary. Claim TTL, quorum completion via Redis atomic ops, notification fan-out through INotificationProvider (F68).

### Domain Entities

| Entity | Index/Collection | Fabric | Key Fields |
|--------|-----------------|--------|-----------|
| UserTask | user-tasks (ES) | DATABASE FABRIC | taskId, tenantId, runId, traceId, nodeId, assignee, status, contextSnapshot |
| TaskClaim | task-claims (PG) | DATABASE FABRIC | claimId, taskId, tenantId, claimerId, expiresAt, status |
| TaskAnswer | task-answers (ES) | DATABASE FABRIC | answerId, taskId, tenantId, responderId, answerPayload, answeredAt |
| RunSnapshot | run-snapshots (ES) | DATABASE FABRIC | runId, tenantId, flowId, status, progress, nodeStatuses[] |
| NodeSnapshot | node-snapshots (ES) | DATABASE FABRIC | nodeId, runId, tenantId, status, progress, blockedBy[], subSteps[] |
| NodeEvent | hig-events (Redis Streams) | QUEUE FABRIC | eventType, nodeId, runId, tenantId, timestamp, payload |
| GroupMembership | group-members (PG) | DATABASE FABRIC | tenantId, groupId, roleKey, userId, effectiveFrom |
| NotificationDedup | notif-dedup-cache (Redis) | DATABASE FABRIC | key=taskId+channel+recipientId, ttl |

### Event Types (FLOW-27)

```
NodeStarted          NodeProgress         NodeCompleted
NodeFailed           NodeSkipped          NodeCancelled
NodeWaitingForUser   NodeBlocked          NodeReady
SubStepStarted       SubStepCompleted
UserTaskCreated      UserTaskClaimed      UserTaskAnswered
UserTaskExpired      UserTaskQuorumReached UserTaskClaimExpired
RunCompleted         RunFailed            RunCancelled
```

---

## FACTORY REGISTRY — FLOW-27

### Family 84: Human Interaction + Runtime State + Dependency Scheduling

| ID | Interface | Fabric | Provider | ES Index / Redis Key |
|----|-----------|--------|----------|----------------------|
| F1075 | IHumanInteractionGateService | DATABASE FABRIC | Elasticsearch | user-tasks |
| F1076 | IUserTaskRegistryService | DATABASE FABRIC | Elasticsearch | user-tasks |
| F1077 | ITaskContextSnapshotService | DATABASE FABRIC | Elasticsearch | task-context-snapshots |
| F1078 | ITaskAssignmentResolverService | DATABASE FABRIC | PostgreSQL | assignment-policies, group-members |
| F1079 | ITaskClaimService | DATABASE FABRIC | Redis (atomic SETNX) | task-claims:{taskId} |
| F1080 | ITaskQuorumService | DATABASE FABRIC | Redis + ES | task-quorum:{taskId}, task-answers |
| F1081 | IRunSnapshotService | DATABASE FABRIC | Elasticsearch | run-snapshots |
| F1082 | INodeSnapshotService | DATABASE FABRIC | Elasticsearch | node-snapshots |
| F1083 | INodeEventEmitterService | QUEUE FABRIC | Redis Streams | node-events stream |
| F1084 | IFlowProgressAggregatorService | DATABASE FABRIC | Elasticsearch | run-snapshots, node-snapshots |
| F1085 | IRunGraphQueryService | DATABASE FABRIC | Elasticsearch | run-snapshots, node-snapshots |
| F1086 | INodeDebugSurfaceService | DATABASE FABRIC | Elasticsearch | trace-debug, node-snapshots |
| F1087 | IDependencySchedulerService | QUEUE FABRIC | Redis Streams | scheduler-ready-queue |
| F1088 | INodeReadinessEvaluatorService | DATABASE FABRIC | Elasticsearch | node-snapshots |
| F1089 | IBlockedNodeResolverService | DATABASE FABRIC | Elasticsearch | node-snapshots |
| F1090 | IJoinPolicyEnforcerService | DATABASE FABRIC | Redis | join-policy:{nodeId} |
| F1091 | IDagWalkerService | CORE FABRIC | In-memory | flow-definitions |
| F1092 | ICompletionGateService | DATABASE FABRIC | Elasticsearch | run-snapshots, user-tasks |
| F1093 | IRunReadinessValidatorService | DATABASE FABRIC | Elasticsearch | run-snapshots |
| F1094 | IRunTerminalStateService | DATABASE FABRIC | Elasticsearch | run-snapshots |
| F1095 | IPendingGateResolverService | DATABASE FABRIC | Elasticsearch | user-tasks |
| F1096 | ITaskNotificationOrchestratorService | AI ENGINE FABRIC | INotificationProvider (F68) | notification-events |
| F1097 | IGroupMembershipResolverService | DATABASE FABRIC | PostgreSQL | group-members |
| F1098 | INotificationDedupeService | DATABASE FABRIC | Redis | notif-dedup-cache |
| F1099 | INotificationDeepLinkService | CORE FABRIC | Config-driven | — |
| F1100 | IUserTaskAnswerProcessorService | DATABASE FABRIC + QUEUE FABRIC | ES + Redis Streams | user-tasks + hig-events |

---

## TASK TYPES ADDED — FLOW-27

| ID | Name | Archetype | Key Factories |
|----|------|-----------|---------------|
| T389 | HumanInteractionGate Node | HUMAN_GATE | F1075, F1076, F1077, F1087, F1100 |
| T390 | GroupUserTask Assignment Gate | HUMAN_GATE | F1078, F1079, F1080, F1097, F1100 |
| T391 | DependencyAwareScheduler | ORCHESTRATION | F1087, F1088, F1089, F1090, F1091 |
| T392 | RunProgressAggregator | AGGREGATION | F1081, F1082, F1083, F1084, F1085 |
| T393 | RunCompletionGate | TERMINAL | F1092, F1093, F1094, F1095 |
| T394 | VisualNodeStateEmitter | PROJECTION | F1081, F1082, F1083, F1094 |
| T395 | NodeDebugSurface | INSPECTION | F1085, F1086, F1082 |
| T396 | NotificationFanOut | NOTIFICATION | F1096, F1097, F1098, F1099, F1078 |
| T397 | GroupTaskNotificationRouter | NOTIFICATION | F1096, F1097, F1098, F1099 |
| T398 | MultiTenantGroupTaskResolver | RESOLUTION | F1078, F1082, F1097 |

---

## BFA RULES — FLOW-27

CF-510 through CF-530 (21 rules) — see 27-tasks_execution_V62_BFA_STRESS_TEST.md

---

## SKILLS — FLOW-27

SK-251 through SK-261 (11 skills) — see 27-tasks_execution_SKILLS_FACTORY_RAG.md

---

## DESIGN RECORDS — FLOW-27

| ID | Decision |
|----|---------|
| DR-99 | HumanInteractionGate promoted to EP-6 (engine primitive, not flow-specific) |
| DR-100 | UserTask in Elasticsearch via DB Fabric: durable, queryable, tenant-scoped by design |
| DR-101 | DependencyScheduler uses existing `waitFor[]` in flow JSON — zero schema migration |
| DR-102 | Event-sourced NodeEvents → materialized NodeSnapshots (write/read separation pattern) |
| DR-103 | TaskClaim uses Redis SETNX atomic operation for race-condition-safe single-claim |
| DR-104 | Quorum: Redis INCR counter per taskId; threshold hit → write final UserTask status to ES |
| DR-105 | Notification fan-out routes through existing INotificationProvider (F68) — no new provider |

---

## DESIGN DECISIONS — FLOW-27

| ID | Decision |
|----|---------|
| DD-130 | UserTask blocking policy (blocking/non_blocking/optional) is per-node config, not flow-wide |
| DD-131 | WAITING_FOR_USER does NOT stop other non-dependent branches (allSettled pattern reused) |
| DD-132 | Node status transitions are event-sourced; snapshots are materialized views — never mutate events |
| DD-133 | Group task claiming: Redis SETNX + TTL guarantees at-most-one active claim per task |
| DD-134 | Quorum answer: Redis INCR + threshold check before writing final UserTask status to ES |
| DD-135 | SubFlow drill-down: UI uses same `/runs/{childRunId}/graph` API — no special SubFlow API |
| DD-136 | Notification dedup key = taskId + channel + recipientId; TTL = task due window |
| DD-137 | All UserTask/RunSnapshot/NodeSnapshot documents MUST include tenantId (DNA-5 mandatory) |
| DD-138 | Progress% = (doneSteps + 0.5*runningSteps) / totalSteps; external long jobs use telemetry events |
| DD-139 | EP-6 is engine-level: any existing or new flow template gains HIG capability without code changes |

---

## NEW ENGINE PRIMITIVE

```
EP-6: HumanInteractionGate (HIG)
  Scope:           Engine-wide — all flow templates inherit
  Status model:    waiting_for_user | answered | expired | skipped | cancelled
  Blocking policy: blocking | non_blocking | optional  (per-node config)
  Assignment:      user | group | role | anyOf | allOf | quorum
  Storage:         DATABASE FABRIC (ES primary) + QUEUE FABRIC (Redis Streams for events)
  Atomic ops:      Redis SETNX for claims, Redis INCR for quorum counting
  Integration:     FlowOrchestrator (Skill 09) recognizes HIG node type
  Resume trigger:  UserTaskAnswered event → IDependencySchedulerService re-evaluates DAG
  Multi-tenant:    tenantId on all documents, all queries, all notifications
```

---

## FLOW-27 DOCUMENT INDEX

| Document | Lines (approx) | Purpose |
|----------|---------------|---------|
| 27-tasks_execution_SESSION_STATE.md | this file | Global state tracker |
| 27-tasks_execution_ENGINE_ARCHITECTURE.md | ~860 | Factory registry, Family 84, ES index schemas |
| 27-tasks_execution_TASK_TYPES_CATALOG.md | ~690 | T389–T398 full engine contracts |
| 27-tasks_execution_V62_BFA_STRESS_TEST.md | ~707 | CF-510–CF-530, ST-300–ST-319 |
| 27-tasks_execution_SKILLS_FACTORY_RAG.md | ~642 | SK-251–SK-261 |
| 27-tasks_execution_UNIFIED_SOURCE_INDEX.md | ~400 | Cross-reference all FLOW-27 artifacts |
| 27-tasks_execution_MASTER_EXECUTION_PLAN.md | ~500 | Phased execution plan P0–P6 |

---

## BACKWARD COMPATIBILITY

- FLOW-01 through FLOW-26: No impact — EP-6 adds beneath existing flows
- T1–T388: Unchanged. New factories F1075+ injectable via DI
- CF-1–CF-509: Unchanged. New rules CF-510+ are additive
- SK-1–SK-250: Unchanged. New skills SK-251+ are additive
- Existing HumanApprovalGate concept: Formalized as T389/T390 — same gate semantics
- FLOW-05 allSettled pattern: Reused and extended by T391 / SK-260
- Management fabric F68 (INotificationProvider): Reused by T396/T397 — no interface changes
- Existing `waitFor[]` / `dependsOn[]` in flow JSON: Interpreted by T391 without migration
