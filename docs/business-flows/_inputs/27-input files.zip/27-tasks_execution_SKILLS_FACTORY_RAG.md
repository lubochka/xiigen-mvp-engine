# FLOW-27 — SKILLS FACTORY RAG
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: SKILLS_FACTORY_RAG_MERGED.md (SK-1-SK-250 unchanged)
## FLOW-27 Skills: SK-251–SK-261
## Status: AUTHORITATIVE — FLOW-27 ONLY

---

## SK-251 — HumanInteractionGate Pattern (Suspend/Resume Lifecycle)

**Purpose:** Reusable pattern for any node that needs to pause execution pending human input,
then resume automatically when answered. Works for any flow, any node type.

**Reuse signal:** Any time a node must wait for human decision before downstream can proceed.

**Positive example:**
```csharp
// CORRECT — HIG via factory, DNA-compliant
public class ArchitectureApprovalGateService : MicroserviceBase  // DNA-4
{
    private readonly IExternalServiceFactory<IHumanInteractionGateService> _higFactory;
    private readonly IExternalServiceFactory<ITaskContextSnapshotService> _snapshotFactory;

    public async Task<DataProcessResult<string>> OpenApprovalGateAsync(
        string tenantId, string runId, string nodeId,
        Dictionary<string,object> incomingContext, CancellationToken ct)  // DNA-1: Dictionary
    {
        var hig = await _higFactory.CreateAsync(new FactoryResolutionContext
        {
            TenantId = tenantId, FlowId = "architecture-flow", NodeId = nodeId
        }, ct);

        // Step 1: Capture context snapshot BEFORE opening gate (IR-T389-1)
        var snapshot = await _snapshotFactory.CreateAsync(..., ct);
        var snapResult = await snapshot.CaptureSnapshotAsync(tenantId, $"snap-{nodeId}",
            new ContextSnapshotRequest { IncomingVariables = incomingContext, TraceId = GetTraceId() }, ct);
        if (!snapResult.Success) return DataProcessResult<string>.Failure(snapResult.Error); // DNA-3

        // Step 2: Open gate with group assignment
        var gateResult = await hig.OpenGateAsync(new OpenGateRequest
        {
            TenantId = tenantId,          // DNA-5: always tenantId
            RunId = runId,
            TraceId = GetTraceId(),
            NodeId = nodeId,
            BlockingPolicy = "blocking",
            AssigneePolicy = new { type = "group", targets = new[] { "architects" } },
            QuestionSchema = new { required = new[] { "approved" }, type = "object" },
            ContextSnapshot = new { snapshotId = snapResult.Value },
            DueAt = DateTimeOffset.UtcNow.AddDays(3),
            Priority = "high"
        }, ct);

        return gateResult;  // DataProcessResult<string> — taskId  DNA-3
    }
}
```

**Negative example:**
```csharp
// WRONG — direct implementation, no factory, typed model
public class BadApprovalGate
{
    public async Task OpenGate(string nodeId)  // No tenantId! No DataProcessResult!
    {
        var task = new UserTask  // WRONG: typed model (DNA-1 violation)
        {
            NodeId = nodeId,
            Status = "waiting"
        };
        _dbContext.UserTasks.Add(task);  // WRONG: direct DB access (Skill 05 violation)
        await _dbContext.SaveChangesAsync();
    }
}
```

**AF-4 RAG search terms:** `human gate`, `user task`, `suspend resume`, `approval wait`

---

## SK-252 — DependencyScheduler + waitFor/dependsOn Evaluator

**Purpose:** Pattern for re-evaluating node readiness after state changes. Ensures engine
keeps executing independent branches even when one is WAITING_FOR_USER.

**Positive example:**
```csharp
// CORRECT — Factory-first dependency evaluation, non-blocking
public class NodeStateChangeHandler : MicroserviceBase  // DNA-4
{
    private readonly IExternalServiceFactory<IDependencySchedulerService> _schedulerFactory;
    private readonly IExternalServiceFactory<IBlockedNodeResolverService> _resolverFactory;

    public async Task<DataProcessResult> HandleNodeCompletedAsync(
        string tenantId, string runId, string completedNodeId, CancellationToken ct)
    {
        var resolver = await _resolverFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);

        // Find nodes unblocked by this completion
        var unblockedResult = await resolver.ResolveUnblockedNodesAsync(
            tenantId, runId, completedNodeId, ct);  // DNA-5: tenantId always

        if (!unblockedResult.Success) return DataProcessResult.Failure(unblockedResult.Error);  // DNA-3

        var scheduler = await _schedulerFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);

        // Evaluate and enqueue newly READY nodes
        var readyResult = await scheduler.EvaluateReadyNodesAsync(tenantId, runId, ct);
        if (!readyResult.Success) return DataProcessResult.Failure(readyResult.Error);

        return await scheduler.EnqueueReadyNodesAsync(tenantId, runId, readyResult.Value, ct);
    }
}
```

**Negative example:**
```csharp
// WRONG — Direct HTTP call between services (must use QUEUE FABRIC)
// WRONG — No tenantId on evaluation
public async Task CheckReady(string runId)
{
    var response = await _httpClient.PostAsync("/nodes/evaluate", ...);  // WRONG: direct HTTP
    // Also missing tenantId scope — DNA-5 violation
}
```

**AF-4 RAG search terms:** `dependency scheduler`, `node readiness`, `waitFor`, `blocked node`, `allSettled`

---

## SK-253 — RunSnapshot + NodeSnapshot Event-Sourced Materialization

**Purpose:** Event-sourcing read model pattern. NodeEvents → immutable stream.
NodeStateProjector compacts events → NodeSnapshot for fast UI reads.

**Key principle:** Write path (emit events) and Read path (read snapshots) are separated.

**Positive example:**
```csharp
// CORRECT — Event emitter via QUEUE FABRIC, projector reads from stream
// Write path: emit events
public class NodeEventPublisher : MicroserviceBase
{
    private readonly IExternalServiceFactory<INodeEventEmitterService> _emitterFactory;

    public async Task<DataProcessResult> EmitNodeStartedAsync(
        string tenantId, string runId, string nodeId, CancellationToken ct)
    {
        var emitter = await _emitterFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);

        return await emitter.EmitAsync(tenantId, new NodeEvent
        {
            EventType = "NodeStarted",
            TenantId = tenantId,  // DNA-5
            RunId = runId,
            NodeId = nodeId,
            TraceId = GetTraceId(),
            Timestamp = DateTimeOffset.UtcNow,
            EventId = ComputeIdempotentId(runId, nodeId, "NodeStarted", DateTimeOffset.UtcNow)
        }, ct);  // DNA-3: DataProcessResult
    }
}

// Read path: query materialized snapshot
public class RunGraphApiService : MicroserviceBase
{
    private readonly IExternalServiceFactory<IRunGraphQueryService> _graphFactory;

    public async Task<DataProcessResult<RunGraphResult>> GetGraphAsync(
        string tenantId, string runId, CancellationToken ct)
    {
        var query = await _graphFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        return await query.GetRunGraphAsync(tenantId, runId, ct);  // DNA-5: tenantId
    }
}
```

**Negative example:**
```csharp
// WRONG — Reading from event stream directly in API (not from snapshot)
// WRONG — No tenant scope on snapshot query
public async Task<object> GetGraph(string runId)
{
    var events = await _redis.StreamReadAsync("node-events:*");  // WRONG: direct Redis
    return ProcessEvents(events);  // Missing tenantId, returns unscoped data
}
```

**AF-4 RAG search terms:** `node snapshot`, `run snapshot`, `event sourcing`, `progress aggregator`, `node status`

---

## SK-254 — GroupTaskAssignment With Claim Semantics

**Purpose:** Pattern for assigning UserTasks to groups/roles with single/multi claim
modes. Prevents conflicting simultaneous answers.

**Positive example:**
```csharp
// CORRECT — Group resolution + claim via factories
public class GroupTaskWorkflowService : MicroserviceBase
{
    private readonly IExternalServiceFactory<ITaskAssignmentResolverService> _assignFactory;
    private readonly IExternalServiceFactory<ITaskClaimService> _claimFactory;

    public async Task<DataProcessResult<ClaimResult>> ClaimTaskAsync(
        string tenantId, string taskId, string userId, CancellationToken ct)
    {
        // Step 1: Verify eligibility (F1078)
        var assign = await _assignFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        var eligibleResult = await assign.IsEligibleToAnswerAsync(tenantId, taskId, userId, ct);
        if (!eligibleResult.Success || !eligibleResult.Value)
            return DataProcessResult<ClaimResult>.Failure("User not eligible to answer this task");

        // Step 2: Attempt claim (F1079)
        var claim = await _claimFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        return await claim.ClaimTaskAsync(tenantId, taskId, userId, ct);
        // Returns ClaimResult: { claimed: bool, claimId, expiresAt }
    }
}
```

**Positive example — quorum:**
```csharp
// CORRECT — Quorum check after each answer
public async Task<DataProcessResult<AnswerResult>> ProcessQuorumAnswerAsync(
    string tenantId, string taskId, string userId,
    Dictionary<string,object> answer, CancellationToken ct)  // DNA-1: Dictionary answer
{
    // Record answer (idempotent by userId+taskId per IR-F1080-1)
    await _quorumService.RecordAnswerAsync(tenantId, taskId, userId, answer, ct);

    // Evaluate if quorum reached
    var quorum = await _quorumService.EvaluateQuorumAsync(tenantId, taskId, ct);
    if (quorum.Value.Reached)
    {
        await _answerProcessor.CloseGateAsync(tenantId, taskId, ct);
    }
    return DataProcessResult<AnswerResult>.Success(new AnswerResult
    {
        Accepted = true,
        GateStatus = quorum.Value.Reached ? "closed" : "still_open"
    });
}
```

**Negative example:**
```csharp
// WRONG — No claim check, direct ES write, cross-tenant group resolution
public async Task SubmitAnswer(string taskId, object answer)
{
    _esClient.Index(answer, taskId);  // WRONG: direct ES, no tenantId, no claim check
    var members = _groupService.GetMembers("all-admins");  // WRONG: no tenantId scope
}
```

**AF-4 RAG search terms:** `group task`, `claim`, `quorum`, `assignment resolver`, `allOf`, `anyOf`

---

## SK-255 — CompletionGate Validation Pattern

**Purpose:** Pattern for validating ALL three run completion conditions before
marking a run as READY/SUCCEEDED.

**Positive example:**
```csharp
// CORRECT — All 3 checks before marking ready
public class RunCompletionService : MicroserviceBase
{
    private readonly IExternalServiceFactory<IRunReadinessValidatorService> _validatorFactory;
    private readonly IExternalServiceFactory<ICompletionGateService> _completionFactory;

    public async Task<DataProcessResult<CompletionStatus>> TryCompleteRunAsync(
        string tenantId, string runId, CancellationToken ct)
    {
        var validator = await _validatorFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);

        // Check 1: all required terminal nodes succeeded
        var terminalOk = await validator.AllTerminalNodesSucceededAsync(tenantId, runId, ct);
        if (!terminalOk.Success || !terminalOk.Value)
            return DataProcessResult<CompletionStatus>.Success(
                new CompletionStatus { Ready = false, Reason = "RequiredNodesPending" });

        // Check 2: no open required UserTasks
        var noOpenTasks = await validator.HasOpenRequiredTasksAsync(tenantId, runId, ct);
        if (noOpenTasks.Value)  // Has open tasks
            return DataProcessResult<CompletionStatus>.Success(
                new CompletionStatus { Ready = false, Reason = "PendingUserInput" });

        // Check 3: all judge gates approved
        var judgesOk = await validator.AllJudgeGatesApprovedAsync(tenantId, runId, ct);
        if (!judgesOk.Value)
            return DataProcessResult<CompletionStatus>.Success(
                new CompletionStatus { Ready = false, Reason = "JudgePending" });

        // All 3 satisfied — mark ready via CompletionGate
        var completion = await _completionFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        await completion.MarkRunReadyAsync(tenantId, runId, ct);  // Idempotent (IR-T393-4)
        return DataProcessResult<CompletionStatus>.Success(new CompletionStatus { Ready = true });
    }
}
```

**AF-4 RAG search terms:** `completion gate`, `run ready`, `run status`, `terminal node`, `judge gate`

---

## SK-256 — Multi-Tenant Notification Fan-Out

**Purpose:** Pattern for notifying group/role members about UserTasks with dedup,
deep links, and tenant-scoped recipient resolution.

**Positive example:**
```csharp
// CORRECT — Fan-out via factories, dedup, tenant-scoped
public class UserTaskNotificationService : MicroserviceBase
{
    private readonly IExternalServiceFactory<IGroupMembershipResolverService> _groupFactory;
    private readonly IExternalServiceFactory<INotificationDedupeService> _dedupeFactory;
    private readonly IExternalServiceFactory<INotificationDeepLinkService> _linkFactory;
    private readonly IExternalServiceFactory<INotificationOrchestratorService> _notifFactory;
    // F68: INotificationProvider resolved via Management fabric

    public async Task<DataProcessResult> NotifyTaskCreatedAsync(
        string tenantId, string taskId, AssigneePolicy policy, CancellationToken ct)
    {
        // Resolve recipients WITHIN tenant only (CF-517)
        var group = await _groupFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        var recipients = policy.Type == "group"
            ? await group.GetMembersAsync(tenantId, policy.Targets[0], ct)
            : await group.GetUsersWithRoleAsync(tenantId, policy.Targets[0], ct);

        if (!recipients.Success) return DataProcessResult.Failure(recipients.Error);

        var dedupe = await _dedupeFactory.CreateAsync(..., ct);
        var links = await _linkFactory.CreateAsync(..., ct);

        foreach (var userId in recipients.Value)
        {
            foreach (var channel in new[] { "in-app", "email" })
            {
                var dedupeKey = $"{taskId}:{channel}:{userId}";
                var isDupe = await dedupe.IsDuplicateAsync(tenantId, dedupeKey, ct);
                if (isDupe.Value) continue;  // Skip duplicate (CF-518)

                var viewUrl = await links.BuildViewContextUrlAsync(tenantId, taskId.RunId, taskId.NodeId, ct);
                var answerUrl = await links.BuildAnswerUrlAsync(tenantId, taskId, ct);

                // Send via INotificationProvider (F68 — existing Management fabric)
                await SendNotificationAsync(userId, channel, new
                {
                    TaskId = taskId, ViewContextUrl = viewUrl.Value,
                    AnswerUrl = answerUrl.Value  // IR-T397-2: always include
                });

                await dedupe.MarkSentAsync(tenantId, dedupeKey, TimeSpan.FromDays(3), ct);
            }
        }
        return DataProcessResult.Success();
    }
}
```

**AF-4 RAG search terms:** `notification fan-out`, `group notification`, `task notification`, `dedup`, `deep link`

---

## SK-257 — NodeStatus Enum + UI Chip Rendering Contract

**Purpose:** Canonical 9-state node status enum and the UI rendering rules for
each status. Fabric-first: pure data contract, zero platform-specific rendering.

**Status State Machine:**
```
PENDING → READY → RUNNING → SUCCEEDED
                 ↘ WAITING_FOR_USER → RUNNING (after answer) → SUCCEEDED
                 ↘ BLOCKED → READY (after dependency resolves)
                 ↘ FAILED
                 ↘ SKIPPED
PENDING → CANCELLED (run cancelled)
```

**Status transition rules:**
```csharp
// MACHINE rules (non-overridable)
PENDING     → READY:              all dependsOn satisfied
READY       → RUNNING:            orchestrator dequeues node
RUNNING     → WAITING_FOR_USER:   HIG gate opened (T389)
RUNNING     → SUCCEEDED:          execution complete
RUNNING     → FAILED:             unrecoverable error
WAITING_FOR_USER → RUNNING:       UserTaskAnswered received (F1100)
WAITING_FOR_USER → EXPIRED:       dueAt passed + blockingPolicy handled
BLOCKED     → READY:              blocking dependency resolved (T391)
ANY         → CANCELLED:          run cancellation propagated (F1094)
```

**UI Chip Data Contract (Template 84):**
```typescript
interface NodeChipData {
  id: string;
  status: NodeStatus;
  nodeName: string;
  progress: number;           // 0.0 to 1.0
  progressPct: string;        // "67%"
  blockedBy: string[];        // nodeId list
  taskId: string | null;      // if WAITING_FOR_USER
  assigneeDisplay: string | null;  // "Architects", "Claimed by Dana", "2/3 approvals"
  subStepDisplay: string | null;   // "Step 3/7"
  childRunCount: number;      // if SubFlow
}
```

**AF-4 RAG search terms:** `node status`, `status enum`, `UI chip`, `node progress`, `waiting for user`

---

## SK-258 — SubFlowDrilldown + Breadcrumb Navigation Pattern

**Purpose:** Pattern for navigating from parent run graph → SubFlow node → child run graph.
Same API surface and status model at every level.

**Positive example:**
```csharp
// CORRECT — SubFlow drill-down via factories, breadcrumb from hierarchy
public class SubFlowDrilldownService : MicroserviceBase
{
    private readonly IExternalServiceFactory<IRunGraphQueryService> _graphFactory;
    private readonly IExternalServiceFactory<IRunSnapshotService> _runSnapshotFactory;

    public async Task<DataProcessResult<SubFlowDrilldownResult>> GetChildRunDetailsAsync(
        string tenantId, string parentRunId, string subFlowNodeId, CancellationToken ct)
    {
        // Get parent node snapshot to find childRunIds
        var graph = await _graphFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        var nodeDetail = await graph.GetNodeDetailAsync(tenantId, parentRunId, subFlowNodeId, ct);

        if (!nodeDetail.Success) return DataProcessResult<SubFlowDrilldownResult>.Failure(nodeDetail.Error);

        var childRunIds = nodeDetail.Value.Snapshot["childRunIds"] as IReadOnlyList<string>;

        // Build breadcrumb
        var breadcrumb = new[] {
            new { RunId = parentRunId, Label = "Parent Run" },
            new { RunId = (string)null, Label = nodeDetail.Value.Snapshot["nodeName"] as string },
        };

        // Get child run graphs (same API, scoped to SAME tenantId — IR-T395-1)
        var childGraphs = new List<RunGraphResult>();
        foreach (var childRunId in childRunIds)
        {
            var childGraph = await graph.GetRunGraphAsync(tenantId, childRunId, ct); // tenantId same
            if (childGraph.Success) childGraphs.Add(childGraph.Value);
        }

        return DataProcessResult<SubFlowDrilldownResult>.Success(new SubFlowDrilldownResult
        {
            Breadcrumb = breadcrumb,
            ChildRunGraphs = childGraphs,
            ParentNodeStatus = nodeDetail.Value.Snapshot["status"] as string
        });
    }
}
```

**AF-4 RAG search terms:** `subflow`, `drill-down`, `breadcrumb`, `child run`, `nested flow`

---

## SK-259 — UserTask Schema (Dictionary-First, DNA-1 Compliant)

**Purpose:** Reference implementation for building and parsing UserTask documents
using Dictionary<string,object> (DNA-1 compliant — never typed models).

**Positive example:**
```csharp
// CORRECT — UserTask as Dictionary, ParseDocument pattern (DNA-1)
public class UserTaskDocumentBuilder  // No typed model anywhere
{
    public Dictionary<string,object> BuildUserTask(OpenGateRequest req, string taskId)
    {
        return new Dictionary<string,object>
        {
            ["taskId"] = taskId,
            ["tenantId"] = req.TenantId,              // DNA-5: always
            ["runId"] = req.RunId,
            ["traceId"] = req.TraceId,
            ["flowId"] = req.FlowId,
            ["nodeId"] = req.NodeId,
            ["nodeType"] = "HumanInteractionGate",
            ["blockingPolicy"] = req.BlockingPolicy,
            ["assigneePolicy"] = req.AssigneePolicy,   // nested Dictionary
            ["questionSchema"] = req.QuestionSchema,
            ["contextSnapshot"] = req.ContextSnapshot,
            ["resumeTargets"] = req.ResumeTargets,
            ["status"] = "waiting_for_user",
            ["createdAt"] = DateTimeOffset.UtcNow.ToString("O"),
            ["dueAt"] = req.DueAt?.ToString("O"),
            ["priority"] = req.Priority,
            ["answeredAt"] = null,
            ["answerPayload"] = null
        };
        // Note: BuildSearchFilter skips nulls automatically (DNA-2)
    }

    public string GetStatus(Dictionary<string,object> doc) =>
        doc.TryGetValue("status", out var s) ? s as string : null;

    // Never create typed class like:
    // class UserTask { public string TaskId {get;set;} ... }  ← WRONG
}
```

**AF-4 RAG search terms:** `user task schema`, `ParseDocument`, `DNA-1`, `dictionary document`, `task document`

---

## SK-260 — allSettled + required+optional Join Policy Patterns

**Purpose:** Join gate patterns that enable non-blocking parallel branches.
Reuses FLOW-05 allSettled pattern, extends with required+optional mode.

**Positive example:**
```csharp
// CORRECT — Join policy via F1090, non-blocking
public class JoinGateEvaluator : MicroserviceBase
{
    private readonly IExternalServiceFactory<IJoinPolicyEnforcerService> _joinFactory;

    public async Task<DataProcessResult<bool>> CanJoinProceedAsync(
        string tenantId, string runId, string joinNodeId, CancellationToken ct)
    {
        var join = await _joinFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);
        var result = await join.EvaluateJoinAsync(tenantId, runId, joinNodeId, ct);

        if (!result.Success) return DataProcessResult<bool>.Failure(result.Error);

        // required+optional: can proceed if all REQUIRED are terminal
        // regardless of OPTIONAL status (CF-519: non-blocking)
        return DataProcessResult<bool>.Success(result.Value.CanProceed);
    }
}

// allSettled: proceeds with partial results (FLOW-05 pattern)
// required+optional: explicit lists
// all: fail-fast on any required failure
```

**AF-4 RAG search terms:** `allSettled`, `join gate`, `join policy`, `required optional`, `non-blocking branch`

---

## SK-261 — Quorum Answer State Machine

**Purpose:** State machine pattern for managing quorum/allOf answer collection.
Ensures atomic transitions, correct quorum evaluation, and audit preservation.

**State machine:**
```
open
  → collecting_answers (first answer recorded)
  → quorum_reached (needed answers collected) → closed
  → allOf_complete (all members answered) → closed
  → expired (dueAt passed, gate force-closed)
  → cancelled (run cancelled)
```

**Positive example:**
```csharp
// CORRECT — Quorum state machine via F1080
public class QuorumStateMachineService : MicroserviceBase
{
    private readonly IExternalServiceFactory<ITaskQuorumService> _quorumFactory;

    public async Task<DataProcessResult<QuorumTransition>> RecordAndEvaluateAsync(
        string tenantId, string taskId, string userId,
        Dictionary<string,object> answer, CancellationToken ct)  // DNA-1: Dictionary
    {
        var quorum = await _quorumFactory.CreateAsync(
            new FactoryResolutionContext { TenantId = tenantId }, ct);

        // Record answer (idempotent by userId+taskId)
        var recordResult = await quorum.RecordAnswerAsync(tenantId, taskId, userId, answer, ct);
        if (!recordResult.Success) return DataProcessResult<QuorumTransition>.Failure(recordResult.Error);

        // Evaluate quorum
        var evalResult = await quorum.EvaluateQuorumAsync(tenantId, taskId, ct);
        if (!evalResult.Success) return DataProcessResult<QuorumTransition>.Failure(evalResult.Error);

        var status = evalResult.Value;
        return DataProcessResult<QuorumTransition>.Success(new QuorumTransition
        {
            QuorumReached = status.Reached,
            AnsweredCount = status.AnsweredCount,
            NeededCount = status.NeededCount,
            AllAnswers = status.Answers,  // Preserved even after quorum (CF-526)
            NextState = status.Reached ? "closed" : "collecting_answers"
        });
    }
}
```

**Negative example:**
```csharp
// WRONG — Deletes answers after quorum (violates CF-526 audit trail)
public async Task CloseQuorum(string taskId)
{
    await _db.DeleteAnswersAsync(taskId);  // WRONG: destroys audit trail
    // Also: no tenantId, direct DB, no DataProcessResult
}
```

**AF-4 RAG search terms:** `quorum`, `allOf`, `answer collection`, `state machine`, `quorum evaluation`

---

## RAG CROSS-REFERENCE: FLOW-27 → EXISTING SKILLS

| FLOW-27 Skill | Reuses / Builds On |
|--------------|-------------------|
| SK-251 | SK-001 (MicroserviceBase), SK-005 (DB Fabric), SK-004 (Queue Fabric) |
| SK-252 | SK-008 (Flow Definition), SK-009 (Flow Orchestrator), SK-004 (Queue Fabric) |
| SK-253 | SK-005 (DB Fabric / ES), SK-004 (Queue Fabric / Redis Streams) |
| SK-254 | SK-005 (DB Fabric / PG), SK-004 (Queue Fabric) |
| SK-255 | SK-009 (Flow Orchestrator), SK-005 (DB Fabric) |
| SK-256 | SK-004 (Queue Fabric), SK-005 (DB Fabric / Redis), Management fabric F68 |
| SK-257 | SK-008 (Flow Definition nodeTypes), Template 84 |
| SK-258 | SK-009 (Flow Orchestrator), SK-005 (ES) |
| SK-259 | SK-001 (ParseDocument DNA-1), SK-002 (BuildQueryFilters DNA-2) |
| SK-260 | FLOW-05 allSettled pattern (existing), SK-009 |
| SK-261 | SK-251, SK-254, SK-005 (PG) |
