# FLOW-27 — ENGINE ARCHITECTURE
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: ENGINE_ARCHITECTURE_MERGED.md (Post FLOW-26)
## FLOW-27 starts at: F1075, Family 153
## Status: AUTHORITATIVE — FLOW-27 ONLY

---

# EXTENSION MANDATE

FLOW-27 adds a **universal engine-level capability**: any flow, any node, any tenant can now
pause at a HumanInteractionGate, expose real-time progress to users, route questions to
groups/roles with quorum semantics, and resume automatically when the gate is answered —
without stopping unrelated branches.

This is NOT a flow-specific feature. It is an **Engine Primitive** that sits beneath all
templates (T1-T388 and beyond). Every new flow automatically inherits it.

---

# SECTION 1 — NEW FAMILIES (153–157)

---

## FAMILY 153 — Human Interaction Gate (HIG) Management

**Purpose:** Universal pause/resume for any flow node that requires human input. Stores
durable UserTask documents, manages assignment policies (user/group/role/quorum), and
emits resume events when gates are answered.

**Fabric Anchor:** DATABASE FABRIC (Skill 05 → Elasticsearch `user-tasks` index) +
                   QUEUE FABRIC (Skill 04 → Redis Streams `hig-events`)

**DNA Compliance:**
- DNA-1: UserTask stored as `Dictionary<string,object>` via ParseDocument
- DNA-3: All methods return `DataProcessResult<T>`
- DNA-4: All services extend MicroserviceBase
- DNA-5: tenantId on EVERY query and document

---

### F1075 — IHumanInteractionGateService

```
INTERFACE:   IHumanInteractionGateService
FAMILY:      153
FABRIC:      DATABASE FABRIC (ES — user-tasks) + QUEUE FABRIC (Redis Streams — hig-events)
FACTORY:     IExternalServiceFactory<IHumanInteractionGateService>
RESOLUTION:  CreateAsync(FactoryResolutionContext{ tenantId, flowId, nodeId }) →
               read config → resolve from registry → validate → health check → fallback

METHODS:
  Task<DataProcessResult<string>>     OpenGateAsync(OpenGateRequest req, CancellationToken ct)
    // Creates UserTask doc in ES, emits UserTaskCreated to QUEUE FABRIC
    // req: { tenantId, runId, traceId, flowId, nodeId, assigneePolicy, questionSchema,
    //         contextSnapshot, blockingPolicy, dueAt, priority }
    // Returns: taskId

  Task<DataProcessResult<GateStatus>>  GetGateStatusAsync(string tenantId, string taskId, CancellationToken ct)
    // Returns current status: waiting_for_user | answered | expired | skipped | cancelled

  Task<DataProcessResult>              SkipGateAsync(string tenantId, string taskId, string reason, CancellationToken ct)
    // Non-blocking policy only: close gate with defaults, emit UserTaskSkipped

  Task<DataProcessResult>              ExpireGateAsync(string tenantId, string taskId, CancellationToken ct)
    // Called by scheduler when dueAt passed; emits UserTaskExpired

  Task<DataProcessResult>              CancelGateAsync(string tenantId, string runId, CancellationToken ct)
    // Cancel all open gates for a run (run cancellation)

DNA RULES:
  - NEVER throw for business logic — always DataProcessResult
  - NEVER import ES driver directly — through IDatabaseService
  - tenantId required on every call
  - ParseDocument on every stored/retrieved document

IRON RULES:
  IR-F1075-1: Gate MUST NOT open if tenantId is null or empty → DataProcessResult.Failure
  IR-F1075-2: OpenGateAsync MUST emit UserTaskCreated event to QUEUE FABRIC atomically
              (transactional outbox pattern via F1083)
  IR-F1075-3: SkipGateAsync MUST check blockingPolicy=non_blocking before allowing skip
```

---

### F1076 — IUserTaskRegistryService

```
INTERFACE:   IUserTaskRegistryService
FAMILY:      153
FABRIC:      DATABASE FABRIC (ES — user-tasks)
FACTORY:     IExternalServiceFactory<IUserTaskRegistryService>

METHODS:
  Task<DataProcessResult<Dictionary<string,object>>>
      GetUserTaskAsync(string tenantId, string taskId, CancellationToken ct)

  Task<DataProcessResult<IReadOnlyList<Dictionary<string,object>>>>
      ListUserTasksAsync(UserTaskQuery query, CancellationToken ct)
      // query: { tenantId, runId?, nodeId?, status?, assigneeId?, groupId?, dueAtBefore? }

  Task<DataProcessResult>
      UpdateTaskStatusAsync(string tenantId, string taskId, string status, CancellationToken ct)

  Task<DataProcessResult>
      AppendAnswerEventAsync(string tenantId, string taskId,
                             Dictionary<string,object> answerPayload, CancellationToken ct)

  Task<DataProcessResult<IReadOnlyList<string>>>
      GetOpenTaskIdsForRunAsync(string tenantId, string runId, CancellationToken ct)

SCHEMA (UserTask document — Dictionary, DNA-1):
  taskId, tenantId, runId, traceId, flowId, flowVersion, nodeId, nodeType
  questionType, expectedAnswerSchema (JSON)
  contextSnapshot: { incomingVariables, upstreamResultsRefs[], decisionNeeded, suggestedOptions[] }
  assigneePolicy: { type: user|group|role|anyOf|allOf|quorum, targets[], quorum?: { needed, outOf? } }
  blockingPolicy: blocking | non_blocking | optional
  resumeTargets[] (nodeIds unblocked when answered)
  claimPolicy: { claimMode: none|single_claim|multi_claim, claimTtlSec, allowReassign }
  status, createdAt, dueAt, priority, answeredAt, answerPayload
  visibility: { viewers: { type, targets[] } }
```

---

### F1077 — ITaskContextSnapshotService

```
INTERFACE:   ITaskContextSnapshotService
FAMILY:      153
FABRIC:      DATABASE FABRIC (ES — task-context-snapshots)

PURPOSE: Stores an immutable snapshot of the exact execution context at the time a
HumanInteractionGate fires. This is the "show the user exactly what variables came in" feature.

METHODS:
  Task<DataProcessResult<string>>
      CaptureSnapshotAsync(string tenantId, string taskId, ContextSnapshotRequest req, CancellationToken ct)
      // req: { incomingVariables, upstreamNodeOutputRefs[], flowContextVars, phaseInputsRef, traceId }
      // Stores immutable snapshot, returns snapshotId

  Task<DataProcessResult<Dictionary<string,object>>>
      GetSnapshotAsync(string tenantId, string taskId, CancellationToken ct)

IRON RULES:
  IR-F1077-1: Snapshot MUST be written BEFORE gate status becomes waiting_for_user
  IR-F1077-2: Snapshot is IMMUTABLE after creation — no updates, only versioned append
```

---

### F1078 — ITaskAssignmentResolverService

```
INTERFACE:   ITaskAssignmentResolverService
FAMILY:      153
FABRIC:      DATABASE FABRIC (PG — assignment-policies + group-membership)

PURPOSE: Resolves the actual list of eligible recipients for a UserTask given an
assigneePolicy. Handles user/group/role/anyOf/allOf/quorum lookup within tenant boundary.

METHODS:
  Task<DataProcessResult<IReadOnlyList<string>>>
      ResolveEligibleUsersAsync(string tenantId, AssigneePolicy policy, CancellationToken ct)
      // Returns userId list from policy targets, group members, role holders — ALL within tenant

  Task<DataProcessResult<bool>>
      IsEligibleToAnswerAsync(string tenantId, string taskId, string userId, CancellationToken ct)

  Task<DataProcessResult<bool>>
      IsEligibleToViewAsync(string tenantId, string taskId, string userId, CancellationToken ct)

IRON RULES:
  IR-F1078-1: Group membership lookup MUST filter by tenantId — cross-tenant groups are FORBIDDEN
  IR-F1078-2: Role resolution MUST use tenant-scoped RBAC only
```

---

### F1079 — ITaskClaimService

```
INTERFACE:   ITaskClaimService
FAMILY:      153
FABRIC:      DATABASE FABRIC (PG — task-claims) + QUEUE FABRIC (Redis Streams — claim-events)

PURPOSE: Manages single_claim / multi_claim semantics. Prevents race conditions where
multiple eligible users submit conflicting answers.

METHODS:
  Task<DataProcessResult<ClaimResult>>
      ClaimTaskAsync(string tenantId, string taskId, string userId, CancellationToken ct)
      // ClaimResult: { claimed: bool, claimId, expiresAt, conflictWith? }

  Task<DataProcessResult>
      ReleaseClaimAsync(string tenantId, string taskId, string claimId, CancellationToken ct)

  Task<DataProcessResult<ClaimStatus>>
      GetClaimStatusAsync(string tenantId, string taskId, CancellationToken ct)

  Task<DataProcessResult>
      ExpireClaimAsync(string tenantId, string taskId, string claimId, CancellationToken ct)
      // Called by TTL scheduler when claim TTL passes

IRON RULES:
  IR-F1079-1: single_claim → only 1 active claim at a time (optimistic lock or DB constraint)
  IR-F1079-2: Claim TTL expiry MUST emit ClaimExpired → claim auto-releases
  IR-F1079-3: multi_claim → claims tracked per user, answer from any claimer accepted
```

---

### F1080 — ITaskQuorumService

```
INTERFACE:   ITaskQuorumService
FAMILY:      153
FABRIC:      DATABASE FABRIC (PG — task-quorums)

PURPOSE: Collects and evaluates answers for allOf and quorum assignee policies.
Determines when a gate can be closed (enough approvals collected).

METHODS:
  Task<DataProcessResult>
      RecordAnswerAsync(string tenantId, string taskId, string userId,
                        Dictionary<string,object> answer, CancellationToken ct)

  Task<DataProcessResult<QuorumStatus>>
      EvaluateQuorumAsync(string tenantId, string taskId, CancellationToken ct)
      // QuorumStatus: { policy, answeredCount, neededCount, reached: bool, answers[] }

  Task<DataProcessResult<bool>>
      IsQuorumReachedAsync(string tenantId, string taskId, CancellationToken ct)

IRON RULES:
  IR-F1080-1: Duplicate answers from same user MUST be rejected (idempotency by userId+taskId)
  IR-F1080-2: If quorum.needed > group size at assignment time → immediate failure with explanation
  IR-F1080-3: All recorded answers PRESERVED even after quorum reached (audit trail)
```

---

## FAMILY 154 — Flow Runtime Visibility

**Purpose:** Real-time materialized view of every run's progress. Emits NodeEvents,
compacts them into RunSnapshot + NodeSnapshot, and exposes the graph API the UI needs.

**Fabric Anchor:** DATABASE FABRIC (Skill 05 → Elasticsearch `run-snapshots`, `node-snapshots`) +
                   QUEUE FABRIC (Skill 04 → Redis Streams `node-events`)

---

### F1081 — IRunSnapshotService

```
INTERFACE:   IRunSnapshotService
FAMILY:      154
FABRIC:      DATABASE FABRIC (ES — run-snapshots)

SCHEMA (RunSnapshot — Dictionary, DNA-1):
  runId, tenantId, flowId, flowVersion, traceId
  status: pending | running | waiting_for_user | blocked | succeeded | failed | cancelled
  summary: { total, completed, running, waitingUser, blocked, failed, skipped }
  progressPct: float (weighted sum)
  startedAt, updatedAt, completedAt
  openTaskIds[] (open HIG tasks)
  terminalNodeIds[] (required completed for READY)
  judgeVerdicts[] (AF-9 approvals)

METHODS:
  Task<DataProcessResult<Dictionary<string,object>>>
      GetRunSnapshotAsync(string tenantId, string runId, CancellationToken ct)

  Task<DataProcessResult>
      UpsertRunSnapshotAsync(string tenantId, string runId,
                             Dictionary<string,object> patch, CancellationToken ct)

  Task<DataProcessResult<string>>
      ComputeRunStatusAsync(string tenantId, string runId, CancellationToken ct)
      // Derives status from all NodeSnapshots + open tasks
```

---

### F1082 — INodeSnapshotService

```
INTERFACE:   INodeSnapshotService
FAMILY:      154
FABRIC:      DATABASE FABRIC (ES — node-snapshots)

NODE STATUS ENUM (9 states):
  PENDING | READY | RUNNING | WAITING_FOR_USER | BLOCKED | SUCCEEDED | FAILED | SKIPPED | CANCELLED

SCHEMA (NodeSnapshot — Dictionary, DNA-1):
  nodeId, runId, tenantId, flowId, nodeType, nodeName
  status (from enum above), progress: float
  blockedBy[] (nodeIds from waitFor that are not terminal)
  taskId? (HIG task if WAITING_FOR_USER)
  childRunIds[] (if SubFlow)
  subSteps[]: { stepId, status, startedAt, endedAt, retryCount }
  inputs: { ref, capturedAt } (reference, not full payload)
  outputs: { ref, capturedAt }
  judgeVerdicts[]
  startedAt, updatedAt, endedAt
  progressWeight: int (default 1)
  errorCode?, errorMessage?

METHODS:
  Task<DataProcessResult<Dictionary<string,object>>>
      GetNodeSnapshotAsync(string tenantId, string runId, string nodeId, CancellationToken ct)

  Task<DataProcessResult<IReadOnlyList<Dictionary<string,object>>>>
      ListNodeSnapshotsForRunAsync(string tenantId, string runId, CancellationToken ct)

  Task<DataProcessResult>
      UpsertNodeSnapshotAsync(string tenantId, string runId, string nodeId,
                               Dictionary<string,object> patch, CancellationToken ct)

  Task<DataProcessResult<IReadOnlyList<string>>>
      GetBlockedByAsync(string tenantId, string runId, string nodeId, CancellationToken ct)
```

---

### F1083 — INodeEventEmitterService

```
INTERFACE:   INodeEventEmitterService
FAMILY:      154
FABRIC:      QUEUE FABRIC (Redis Streams — node-events)

NODE EVENT TYPES (CloudEvents envelope):
  NodeStarted | SubStepCompleted | NodeProgress | NodeWaitingForUser
  NodeCompleted | NodeFailed | NodeSkipped | NodeBlocked | NodeCancelled
  UserTaskCreated | UserTaskAnswered | UserTaskClaimed | UserTaskExpired

METHODS:
  Task<DataProcessResult>
      EmitAsync(string tenantId, NodeEvent evt, CancellationToken ct)
      // All events include: tenantId, runId, nodeId, traceId, timestamp, eventType

  Task<DataProcessResult<IReadOnlyList<NodeEvent>>>
      GetNodeHistoryAsync(string tenantId, string runId, string nodeId, CancellationToken ct)

IRON RULES:
  IR-F1083-1: Every event MUST include tenantId (DNA-5)
  IR-F1083-2: Events MUST use CloudEvents 1.0 envelope with tenantid extension
  IR-F1083-3: Emit is idempotent — eventId = hash(runId+nodeId+eventType+timestamp)
```

---

### F1084 — IFlowProgressAggregatorService

```
INTERFACE:   IFlowProgressAggregatorService
FAMILY:      154
FABRIC:      DATABASE FABRIC (ES — run-snapshots + node-snapshots)

PURPOSE: Computes progress % and summary counts from NodeSnapshots.

PROGRESS ALGORITHM (MACHINE — non-configurable):
  progress = Σ(node.progressWeight × statusWeight) / Σ(node.progressWeight)
  statusWeight: SUCCEEDED/SKIPPED=1.0, RUNNING=0.5, WAITING_FOR_USER=0.0,
                PENDING/READY/BLOCKED=0.0, FAILED=0.0 (but counted in summary)

METHODS:
  Task<DataProcessResult<ProgressResult>>
      ComputeProgressAsync(string tenantId, string runId, CancellationToken ct)
      // ProgressResult: { pct, summary: { completed, running, waitingUser, blocked, failed, skipped } }
```

---

### F1085 — IRunGraphQueryService

```
INTERFACE:   IRunGraphQueryService
FAMILY:      154
FABRIC:      DATABASE FABRIC (ES — node-snapshots + flow-definitions)

PURPOSE: Provides the graph API endpoint data — nodes + edges + summary for UI rendering.

METHODS:
  Task<DataProcessResult<RunGraphResult>>
      GetRunGraphAsync(string tenantId, string runId, CancellationToken ct)
      // RunGraphResult:
      //   nodes[]: { id, type, status, progress, blockedBy[], taskId?, childRunIds?,
      //              nodeName, progressWeight }
      //   edges[]: { from, to }
      //   summary: { done, running, waitingUser, blocked, failed }

  Task<DataProcessResult<NodeDetailResult>>
      GetNodeDetailAsync(string tenantId, string runId, string nodeId, CancellationToken ct)
      // NodeDetailResult:
      //   snapshot (full NodeSnapshot)
      //   subSteps[]
      //   debugLinks: { trace, phase, judge }
      //   childRuns[] (if SubFlow)
```

---

### F1086 — INodeDebugSurfaceService

```
INTERFACE:   INodeDebugSurfaceService
FAMILY:      154
FABRIC:      DATABASE FABRIC (ES — trace-debug)

PURPOSE: Wraps existing debug endpoints (traceId/phaseId/judgeId) with a tenant-scoped
uniform interface for the node inspector UI.

METHODS:
  Task<DataProcessResult<Dictionary<string,object>>>
      GetPhaseInputOutputAsync(string tenantId, string traceId, string phaseId, CancellationToken ct)

  Task<DataProcessResult<Dictionary<string,object>>>
      GetJudgeVerdictAsync(string tenantId, string traceId, string phaseId, CancellationToken ct)

  Task<DataProcessResult<Dictionary<string,object>>>
      GetFullTraceAsync(string tenantId, string traceId, CancellationToken ct)
```

---

## FAMILY 155 — Dependency-Aware Scheduler

**Purpose:** Evaluates node readiness after every state change event. Keeps the engine
working on all READY nodes even when some are WAITING_FOR_USER or BLOCKED.

**Fabric Anchor:** QUEUE FABRIC (Skill 04 → Redis Streams `ready-queue`, `resume-events`) +
                   DATABASE FABRIC (Skill 05 → Elasticsearch `node-snapshots`, `flow-definitions`)

---

### F1087 — IDependencySchedulerService

```
INTERFACE:   IDependencySchedulerService
FAMILY:      155
FABRIC:      QUEUE FABRIC (Redis Streams — ready-queue)

PURPOSE: Processes NodeCompleted / UserTaskAnswered / NodeSkipped events →
evaluates dependency graph → enqueues READY nodes for execution.

METHODS:
  Task<DataProcessResult<IReadOnlyList<string>>>
      EvaluateReadyNodesAsync(string tenantId, string runId, CancellationToken ct)
      // Returns nodeIds that are NOW READY (all waitFor satisfied)

  Task<DataProcessResult>
      EnqueueReadyNodesAsync(string tenantId, string runId,
                              IReadOnlyList<string> nodeIds, CancellationToken ct)
      // Puts nodeIds on QUEUE FABRIC ready-queue with tenantId + runId context

NODE READINESS RULE (MACHINE):
  READY when:
    ALL dependsOn.required[] are SUCCEEDED or (SKIPPED && join policy allows)
    AND ALL dependsOn.human_required[] are ANSWERED
  BLOCKED when:
    ANY dependsOn.required[] is WAITING_FOR_USER or RUNNING or FAILED (no degrade)
  SKIPPABLE when:
    Entry condition evaluates false AND template defines "skip_without_error"
```

---

### F1088 — INodeReadinessEvaluatorService

```
INTERFACE:   INodeReadinessEvaluatorService
FAMILY:      155
FABRIC:      DATABASE FABRIC (ES — node-snapshots + flow-definitions)

METHODS:
  Task<DataProcessResult<ReadinessResult>>
      EvaluateNodeAsync(string tenantId, string runId, string nodeId, CancellationToken ct)
      // ReadinessResult: { ready: bool, status: READY|BLOCKED|SKIPPABLE, blockedBy[], reason }

  Task<DataProcessResult<IReadOnlyList<ReadinessResult>>>
      EvaluateAllNodesAsync(string tenantId, string runId, CancellationToken ct)
```

---

### F1089 — IBlockedNodeResolverService

```
INTERFACE:   IBlockedNodeResolverService
FAMILY:      155
FABRIC:      QUEUE FABRIC (Redis Streams — resume-events)

PURPOSE: When a UserTask is answered or a required node completes, resolves
which BLOCKED nodes become READY and triggers the scheduler.

METHODS:
  Task<DataProcessResult<IReadOnlyList<string>>>
      ResolveUnblockedNodesAsync(string tenantId, string runId,
                                  string completedNodeId, CancellationToken ct)
      // Finds all nodes where completedNodeId was in their blockedBy[]

  Task<DataProcessResult>
      EmitResumeEventsAsync(string tenantId, string runId,
                             IReadOnlyList<string> unblockedNodeIds, CancellationToken ct)
```

---

### F1090 — IJoinPolicyEnforcerService

```
INTERFACE:   IJoinPolicyEnforcerService
FAMILY:      155
FABRIC:      DATABASE FABRIC (ES — flow-definitions)

JOIN MODES (MACHINE):
  all:             fail fast if any required branch fails
  allSettled:      gather partials, proceed with what's available (existing pattern)
  required+optional: explicit lists; optional absence/late does not block join

METHODS:
  Task<DataProcessResult<JoinResult>>
      EvaluateJoinAsync(string tenantId, string runId, string joinNodeId, CancellationToken ct)
      // JoinResult: { canProceed: bool, policy, completedRequired[], pendingRequired[],
      //               completedOptional[], pendingOptional[], missingOptional[] }
```

---

### F1091 — IDagWalkerService

```
INTERFACE:   IDagWalkerService
FAMILY:      155
FABRIC:      DATABASE FABRIC (ES — flow-definitions)

PURPOSE: Validates flow DAG for cycles and computes transitive dependency sets.

METHODS:
  Task<DataProcessResult<bool>>
      HasCycleAsync(string tenantId, string flowId, string flowVersion, CancellationToken ct)

  Task<DataProcessResult<IReadOnlyList<string>>>
      GetTransitiveDependentsAsync(string tenantId, string flowId,
                                   string nodeId, CancellationToken ct)
      // Returns all nodes that transitively depend on nodeId
      // Used to compute "what becomes blocked if this gate waits"
```

---

## FAMILY 156 — Completion Gate

**Purpose:** Determines when a run is READY (fully done). Validates that all required
terminal nodes have succeeded, no open required HumanInteractionGates remain, and
AF-9 JudgeService has approved all required phase gates.

**Fabric Anchor:** DATABASE FABRIC (ES — run-snapshots, user-tasks)

---

### F1092 — ICompletionGateService

```
INTERFACE:   ICompletionGateService
FAMILY:      156
FABRIC:      DATABASE FABRIC (ES — run-snapshots + user-tasks)

COMPLETION RULE (MACHINE):
  READY only when:
    1. All required terminal nodes: SUCCEEDED
    2. Zero open required UserTasks (blockingPolicy=blocking)
    3. AF-9 JudgeService: Approved on all required phase gates

  If NOT ready, status is one of:
    PendingUserInput | Running | BlockedOnDependency | FailedNeedsRepair

METHODS:
  Task<DataProcessResult<CompletionStatus>>
      EvaluateCompletionAsync(string tenantId, string runId, CancellationToken ct)
      // CompletionStatus: { ready: bool, blocking: CompletionBlocker[], summary }

  Task<DataProcessResult>
      MarkRunReadyAsync(string tenantId, string runId, CancellationToken ct)
      // Sets RunSnapshot.status = SUCCEEDED, emits RunCompleted event

IRON RULES:
  IR-F1092-1: MarkRunReadyAsync MUST call EvaluateCompletionAsync first — failure if check fails
  IR-F1092-2: NEVER mark ready if open required UserTasks > 0
```

---

### F1093 — IRunReadinessValidatorService

```
INTERFACE:   IRunReadinessValidatorService
FAMILY:      156
FABRIC:      DATABASE FABRIC (ES — run-snapshots + user-tasks)

METHODS:
  Task<DataProcessResult<IReadOnlyList<CompletionBlocker>>>
      GetBlockersAsync(string tenantId, string runId, CancellationToken ct)
      // Returns all reasons run is not READY: open tasks, failed nodes, pending judges

  Task<DataProcessResult<bool>>
      HasOpenRequiredTasksAsync(string tenantId, string runId, CancellationToken ct)

  Task<DataProcessResult<bool>>
      AllTerminalNodesSucceededAsync(string tenantId, string runId, CancellationToken ct)

  Task<DataProcessResult<bool>>
      AllJudgeGatesApprovedAsync(string tenantId, string runId, CancellationToken ct)
```

---

### F1094 — IRunTerminalStateService

```
INTERFACE:   IRunTerminalStateService
FAMILY:      156
FABRIC:      DATABASE FABRIC (ES — run-snapshots) + QUEUE FABRIC (Redis Streams)

PURPOSE: Handles run-level terminal state transitions (SUCCEEDED / FAILED / CANCELLED).
Emits RunCompleted / RunFailed / RunCancelled events via QUEUE FABRIC.

METHODS:
  Task<DataProcessResult>  CompleteRunAsync(string tenantId, string runId, CancellationToken ct)
  Task<DataProcessResult>  FailRunAsync(string tenantId, string runId, string reason, CancellationToken ct)
  Task<DataProcessResult>  CancelRunAsync(string tenantId, string runId, string reason, CancellationToken ct)
```

---

### F1095 — IPendingGateResolverService

```
INTERFACE:   IPendingGateResolverService
FAMILY:      156
FABRIC:      DATABASE FABRIC (ES — user-tasks)

PURPOSE: Lists and resolves all open required HumanInteractionGates for a run.
Used by CompletionGate and monitoring dashboards.

METHODS:
  Task<DataProcessResult<IReadOnlyList<Dictionary<string,object>>>>
      GetOpenRequiredGatesAsync(string tenantId, string runId, CancellationToken ct)

  Task<DataProcessResult<int>>
      CountOpenRequiredGatesAsync(string tenantId, string runId, CancellationToken ct)
```

---

## FAMILY 157 — Task Notification Orchestrator

**Purpose:** Fan-out notifications when a HumanInteractionGate opens. Routes through
INotificationProvider (F68 from Management fabric). Deduplicates per channel/recipient.
Resolves group membership within tenant boundary.

**Fabric Anchor:** QUEUE FABRIC (Redis Streams — notification-events) +
                   DATABASE FABRIC (PG — group-membership, Redis — notif-dedup-cache)

---

### F1096 — ITaskNotificationOrchestratorService

```
INTERFACE:   ITaskNotificationOrchestratorService
FAMILY:      157
FABRIC:      QUEUE FABRIC (Redis Streams — notification-events)

PURPOSE: Orchestrates notification flow: UserTaskCreated event →
  resolve recipients → dedupe → format payload → dispatch via INotificationProvider (F68)

METHODS:
  Task<DataProcessResult>
      OrchestrateNotificationAsync(string tenantId, string taskId, CancellationToken ct)
      // Full pipeline: resolve → dedupe → dispatch

  Task<DataProcessResult>
      SendReminderAsync(string tenantId, string taskId, CancellationToken ct)
      // Re-notify if dueAt approaching and task still open

NOTIFICATION PAYLOAD (must include):
  taskId, runId, traceId, flowId, nodeId, nodeName
  decisionNeeded (1-3 lines), whyBlocked (dependency explanation)
  viewContextUrl (= /v1/tenants/{tenantId}/runs/{runId}/nodes/{nodeId})
  answerUrl (= POST /v1/tenants/{tenantId}/user-tasks/{taskId}/answer)
  dueAt, urgency
  assigneeDisplay (e.g. "Architects", "Role=SecurityOfficer", "2/3 approvals")

IRON RULES:
  IR-F1096-1: Notification payload MUST include viewContextUrl and answerUrl
  IR-F1096-2: Recipients resolved WITHIN tenant — cross-tenant fan-out FORBIDDEN
```

---

### F1097 — IGroupMembershipResolverService

```
INTERFACE:   IGroupMembershipResolverService
FAMILY:      157
FABRIC:      DATABASE FABRIC (PG — group-membership)

METHODS:
  Task<DataProcessResult<IReadOnlyList<string>>>
      GetMembersAsync(string tenantId, string groupId, CancellationToken ct)

  Task<DataProcessResult<IReadOnlyList<string>>>
      GetUsersWithRoleAsync(string tenantId, string roleKey, CancellationToken ct)

  Task<DataProcessResult<bool>>
      IsMemberAsync(string tenantId, string groupId, string userId, CancellationToken ct)

IRON RULES:
  IR-F1097-1: Every query MUST include tenantId — no cross-tenant group lookup
```

---

### F1098 — INotificationDedupeService

```
INTERFACE:   INotificationDedupeService
FAMILY:      157
FABRIC:      DATABASE FABRIC (Redis — notif-dedup-cache)

PURPOSE: Prevents duplicate notifications. Dedup key = taskId + channel + recipient.
TTL = max(dueAt - now, 24h).

METHODS:
  Task<DataProcessResult<bool>>  IsDuplicateAsync(string tenantId, string dedupeKey, CancellationToken ct)
  Task<DataProcessResult>        MarkSentAsync(string tenantId, string dedupeKey, TimeSpan ttl, CancellationToken ct)
  Task<DataProcessResult>        ClearAsync(string tenantId, string taskId, CancellationToken ct)
```

---

### F1099 — INotificationDeepLinkService

```
INTERFACE:   INotificationDeepLinkService
FAMILY:      157
FABRIC:      CORE FABRIC (Skill 01 — config for base URLs)

METHODS:
  Task<DataProcessResult<string>>
      BuildViewContextUrlAsync(string tenantId, string runId, string nodeId, CancellationToken ct)

  Task<DataProcessResult<string>>
      BuildAnswerUrlAsync(string tenantId, string taskId, CancellationToken ct)

  Task<DataProcessResult<string>>
      BuildTraceUrlAsync(string tenantId, string traceId, CancellationToken ct)
```

---

### F1100 — IUserTaskAnswerProcessorService

```
INTERFACE:   IUserTaskAnswerProcessorService
FAMILY:      157
FABRIC:      DATABASE FABRIC (ES — user-tasks) + QUEUE FABRIC (Redis Streams — hig-events)

PURPOSE: Processes a user's answer to a HumanInteractionGate. Validates eligibility,
applies quorum/allOf logic, closes gate if complete, emits UserTaskAnswered event,
triggers DependencyScheduler to re-evaluate BLOCKED nodes.

METHODS:
  Task<DataProcessResult<AnswerResult>>
      ProcessAnswerAsync(string tenantId, string taskId, string userId,
                         Dictionary<string,object> answer, CancellationToken ct)
      // AnswerResult: { accepted: bool, gateStatus: still_open|closed, unblockedNodes[] }

  Task<DataProcessResult<bool>>
      ValidateAnswerSchemaAsync(string tenantId, string taskId,
                                 Dictionary<string,object> answer, CancellationToken ct)

IRON RULES:
  IR-F1100-1: MUST check IsEligibleToAnswerAsync (F1078) before accepting answer
  IR-F1100-2: MUST check quorum completion (F1080) before closing gate
  IR-F1100-3: MUST emit UserTaskAnswered event via QUEUE FABRIC when gate closes
  IR-F1100-4: MUST trigger IDependencySchedulerService (F1087) after gate closes
```

---

# SECTION 2 — API SURFACE (UI Endpoints)

These are **fabric-first** API contracts. The controller uses DynamicController (DNA-6).
No entity-specific controllers. All through IRunGraphQueryService (F1085) + IUserTaskRegistryService (F1076).

```
GET  /v1/tenants/{tenantId}/runs/{runId}/graph
  → RunGraphResult: nodes[], edges[], summary
  → Source: F1085

GET  /v1/tenants/{tenantId}/runs/{runId}/nodes/{nodeId}
  → NodeDetailResult: snapshot, subSteps[], debugLinks, childRuns[]
  → Source: F1085

GET  /v1/tenants/{tenantId}/user-tasks
  → Query: runId?, nodeId?, status?, assigneeId?
  → Source: F1076

GET  /v1/tenants/{tenantId}/user-tasks/{taskId}
  → Full UserTask document + contextSnapshot
  → Source: F1076 + F1077

POST /v1/tenants/{tenantId}/user-tasks/{taskId}/claim
  → Source: F1079

POST /v1/tenants/{tenantId}/user-tasks/{taskId}/answer
  → Source: F1100

POST /v1/tenants/{tenantId}/user-tasks/{taskId}/skip
  → Source: F1075 (non_blocking gates only)
```

---

# SECTION 3 — ES INDEX SCHEMAS

All indices tenant-scoped. All documents stored as Dictionary (DNA-1). BuildSearchFilter skips empties (DNA-2).

```
user-tasks:
  Index by: tenantId, runId, nodeId, status, assigneeTargets[], dueAt
  Mappings: keyword(tenantId,runId,nodeId,status,taskId), date(createdAt,dueAt,answeredAt)

run-snapshots:
  Index by: tenantId, runId, status
  Mappings: keyword, float(progressPct), date

node-snapshots:
  Index by: tenantId, runId, nodeId, status
  Mappings: keyword, float(progress), nested(subSteps, blockedBy)

task-context-snapshots:
  Index by: tenantId, taskId (immutable documents)
  Mappings: keyword, object(contextSnapshot)

notif-dedup-cache (Redis):
  Key pattern: notif:dedup:{tenantId}:{taskId}:{channel}:{recipientId}
  TTL: max(dueAt - now, 86400s)
```

---

# SECTION 4 — BACKWARD COMPATIBILITY

- F1-F1074: UNCHANGED ✅
- All existing fabric interfaces: UNCHANGED ✅
- All existing families 1-152: UNCHANGED ✅
- FLOW-01 through FLOW-26 flows: UNAFFECTED ✅
- No existing task type modified ✅
- New factories inject into existing MicroserviceBase (Skill 01) via DI ✅
