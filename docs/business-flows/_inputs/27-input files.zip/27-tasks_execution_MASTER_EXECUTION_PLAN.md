# FLOW-27 — MASTER EXECUTION PLAN
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: MASTER_EXECUTION_PLAN_MERGED.md
## Status: AUTHORITATIVE — FLOW-27 only

---

## OVERVIEW

FLOW-27 extends the XIIGen engine with an **Engine-Level Primitive (EP-6)**: the Human Interaction Gate (HIG) + Visual Runtime State + Dependency-Aware Scheduling + Multi-Tenant Group Tasks. This is NOT a flow-specific implementation — it is a capability that sits beneath ALL flow templates.

**What gets built**: 26 factory interfaces (F1075–F1100), 10 task type engine contracts (T389–T398), 21 BFA rules (CF-510–CF-530), 20 stress tests (ST-300–ST-319), 11 skills (SK-251–SK-261), 1 engine primitive (EP-6), 1 template (TPL-50).

**Why phased**: Each phase has clear SAVE STATE, is completable in 15–45 minutes, produces independently verifiable deliverables, and enables recovery in under 60 seconds.

---

## PHASE DEPENDENCY CHAIN

```
P0 (Foundation Schemas) 
  → P1 (HumanInteractionGate + UserTask Registry)
  → P2 (DependencyAwareScheduler)
  → P3 (Visual Runtime State + Progress Aggregation)
  → P4 (Completion Gate + Terminal State)
  → P5 (Multi-Tenant Group Tasks + Notification)
  → P6 (BFA Validation + Stress Tests + DNA Compliance)
```

P0 and P1 can be delivered in parallel with P2.
P3 depends on P1 (needs NodeSnapshot event types established by HIG).
P4 depends on P2+P3.
P5 can be delivered after P1.
P6 validates everything — must come last.

---

## P0 — FOUNDATION: FABRIC SCHEMAS + ES INDICES
**Duration**: 20 min | **Save State**: FLOW27-P0-COMPLETE

### What we build
Elasticsearch index schemas for all FLOW-27 durable documents. These are registered in the DATABASE FABRIC (Skill 05) via config — no code written here.

### Deliverables

**ES Index: `user-tasks`**
```json
{
  "mappings": {
    "properties": {
      "taskId":         { "type": "keyword" },
      "tenantId":       { "type": "keyword" },
      "runId":          { "type": "keyword" },
      "traceId":        { "type": "keyword" },
      "flowId":         { "type": "keyword" },
      "flowVersion":    { "type": "keyword" },
      "nodeId":         { "type": "keyword" },
      "nodeType":       { "type": "keyword" },
      "questionType":   { "type": "keyword" },
      "blockingPolicy": { "type": "keyword" },
      "status":         { "type": "keyword" },
      "assignee":       { "type": "object" },
      "contextSnapshot":{ "type": "object", "enabled": false },
      "resumeTargets":  { "type": "keyword" },
      "createdAt":      { "type": "date" },
      "dueAt":          { "type": "date" },
      "answeredAt":     { "type": "date" },
      "answerPayload":  { "type": "object", "enabled": false }
    }
  }
}
```

**ES Index: `run-snapshots`**
```json
{
  "mappings": {
    "properties": {
      "runId":       { "type": "keyword" },
      "tenantId":    { "type": "keyword" },
      "flowId":      { "type": "keyword" },
      "status":      { "type": "keyword" },
      "progress":    { "type": "float" },
      "nodeCount":   { "type": "integer" },
      "doneCount":   { "type": "integer" },
      "runningCount":{ "type": "integer" },
      "waitingCount":{ "type": "integer" },
      "blockedCount":{ "type": "integer" },
      "startedAt":   { "type": "date" },
      "updatedAt":   { "type": "date" },
      "completedAt": { "type": "date" }
    }
  }
}
```

**ES Index: `node-snapshots`**
```json
{
  "mappings": {
    "properties": {
      "snapshotId":  { "type": "keyword" },
      "nodeId":      { "type": "keyword" },
      "runId":       { "type": "keyword" },
      "tenantId":    { "type": "keyword" },
      "nodeType":    { "type": "keyword" },
      "status":      { "type": "keyword" },
      "progress":    { "type": "float" },
      "blockedBy":   { "type": "keyword" },
      "taskId":      { "type": "keyword" },
      "childRunIds": { "type": "keyword" },
      "subSteps":    { "type": "nested" },
      "startedAt":   { "type": "date" },
      "updatedAt":   { "type": "date" },
      "completedAt": { "type": "date" }
    }
  }
}
```

**Redis Streams**: `hig-events`, `node-events`, `scheduler-ready-queue` — standard consumer group pattern (Skill 04).

**PostgreSQL tables**: `assignment_policies`, `task_claims`, `group_members` — tenant-scoped, RLS-enabled.

### SAVE STATE: FLOW27-P0-COMPLETE
```
Schemas defined: user-tasks, run-snapshots, node-snapshots, task-claims, group-members
Redis streams: hig-events, node-events, scheduler-ready-queue
Resume: Continue from P1
```

---

## P1 — HUMANINTERACTIONGATE + USERTASK REGISTRY
**Duration**: 35 min | **Save State**: FLOW27-P1-COMPLETE
**Factories**: F1075, F1076, F1077, F1100
**Task Types**: T389

### What we build
The EP-6 primitive: `IHumanInteractionGateService` creates a UserTask when a HIG node is reached. `IUserTaskRegistryService` provides CRUD for UserTasks. `ITaskContextSnapshotService` captures exact incomingVariables + trace at gate time. `IUserTaskAnswerProcessorService` validates and records answers, emits `UserTaskAnswered` event.

### Engine Contract T389 (HumanInteractionGate Node)
```
TASK TYPE: T389 — HumanInteractionGate Node
ARCHETYPE: HUMAN_GATE
ENGINE PRIMITIVE: EP-6
ENTRY: FlowOrchestrator reaches a node with nodeType=HumanInteractionGate
PURPOSE: Suspend flow execution, create UserTask, resume dependents on answer
DISTINCT FROM: Old HumanApprovalGate (concept only); T390 (group assignment)

FACTORY DEPENDENCIES: F1075, F1076, F1077, F1087, F1100 — resolved via CreateAsync()
FABRIC RESOLUTION:
  F1075 → DATABASE FABRIC (Elasticsearch) — user-tasks index
  F1076 → DATABASE FABRIC (Elasticsearch) — user-tasks index
  F1077 → DATABASE FABRIC (Elasticsearch) — task-context-snapshots index
  F1087 → QUEUE FABRIC (Redis Streams) — scheduler-ready-queue
  F1100 → DATABASE FABRIC (ES) + QUEUE FABRIC (Redis) — user-tasks + hig-events

AF CONFIGURATION:
  AF-1 (Genesis): generates HIG service code from spec (extends MicroserviceBase)
  AF-4 (RAG): retrieves SK-251 (HIG pattern) + SK-259 (UserTaskRegistry pattern)
  AF-7 (Compliance): validates DNA-1 (no typed models), DNA-5 (tenantId present)
  AF-9 (Judge): validates iron rules below

BFA VALIDATION:
  CF-510: UserTask must include tenantId
  CF-511: Flow cannot resume until UserTask.status=answered (or skipped via policy)
  CF-515: Downstream nodes not enqueued until answer received (blocking policy)
  CF-523: contextSnapshot must capture incomingVariables at gate time

MACHINE (fixed logic):
  - Create UserTask document in ES via F1076
  - Capture contextSnapshot via F1077
  - Emit UserTaskCreated event via QUEUE FABRIC
  - Block downstream scheduler via F1087 (blocking policy only)
  - On answer: validate via F1100, emit UserTaskAnswered, unblock scheduler

FREEDOM (admin configurable):
  - blockingPolicy: blocking | non_blocking | optional
  - dueAt duration (task SLA)
  - questionType and expectedAnswerSchema
  - suggestedOptions[]

IRON RULES:
  1. UserTask document MUST include tenantId (CF-510) → BUILD FAILURE if missing
  2. Blocking HIG MUST NOT allow downstream nodes to run before answer (CF-511)
  3. contextSnapshot MUST capture exact incomingVariables at gate time (CF-523)
  4. Answer processor MUST emit UserTaskAnswered to QUEUE FABRIC before unblocking (CF-515)

QUALITY GATES (AF-9):
  - UserTask stored before any downstream unblocking occurs
  - Idempotency: duplicate UserTaskCreated for same nodeId+runId is rejected
  - Non_blocking HIG proceeds with defaults + records "assumption" flag
  - Optional HIG records skip if no answer after dueAt
```

### SAVE STATE: FLOW27-P1-COMPLETE
```
T389 engine contract: complete
Factories: F1075, F1076, F1077, F1100 registered
Skills: SK-251, SK-259 defined
Resume: Continue from P2 or P5 (parallel)
```

---

## P2 — DEPENDENCY-AWARE SCHEDULER
**Duration**: 30 min | **Save State**: FLOW27-P2-COMPLETE
**Factories**: F1087, F1088, F1089, F1090, F1091
**Task Types**: T391

### What we build
Generic DAG scheduler that keeps executing READY nodes while others are BLOCKED or WAITING_FOR_USER. Reads `waitFor[]` from flow JSON (no schema migration). Implements JoinPolicy (allOf/anyOf/quorum). Cycle detection via IDagWalkerService.

### Engine Contract T391 (DependencyAwareScheduler)
```
TASK TYPE: T391 — DependencyAwareScheduler
ARCHETYPE: ORCHESTRATION
ENTRY: FlowOrchestrator starts a run; also triggered by UserTaskAnswered event
PURPOSE: Evaluate DAG, enqueue READY nodes, block on dependencies, resume after human answers
DISTINCT FROM: T13 (static orchestration); T391 is dynamic, event-driven, human-gate-aware

FACTORY DEPENDENCIES: F1087, F1088, F1089, F1090, F1091 — resolved via CreateAsync()
FABRIC RESOLUTION:
  F1087 → QUEUE FABRIC (Redis Streams) — scheduler-ready-queue (producer)
  F1088 → DATABASE FABRIC (Elasticsearch) — node-snapshots (read)
  F1089 → DATABASE FABRIC (Elasticsearch) — node-snapshots (read/write)
  F1090 → DATABASE FABRIC (Redis) — join-policy:{nodeId} atomic check
  F1091 → CORE FABRIC (in-memory) — flow-definition DAG traversal

AF CONFIGURATION:
  AF-1 (Genesis): generates scheduler service code
  AF-4 (RAG): retrieves SK-252 (DependencyScheduler pattern) + SK-260 (JoinPolicy)
  AF-7 (Compliance): DNA-4 (MicroserviceBase), DNA-5 (tenantId on all queries)
  AF-9 (Judge): validates CF-515, CF-519, CF-525, CF-527, CF-529

BFA VALIDATION:
  CF-515: No node enqueued with unresolved waitFor dependencies
  CF-519: allOf join waits for ALL required upstream nodes
  CF-525: No duplicate enqueue of already-READY node
  CF-527: IDagWalkerService must detect + reject circular dependencies at BUILD time
  CF-529: DAGWalker must traverse all reachable nodes from root

MACHINE (fixed):
  - On run start: traverse DAG via F1091, enqueue all root nodes via F1087
  - On NodeCompleted event: re-evaluate blocked nodes via F1088
  - On UserTaskAnswered event: re-evaluate HIG-dependent nodes
  - JoinPolicy check via F1090 (allOf/anyOf/quorum) before marking parent READY
  - Cycle detection at BUILD time via F1091

FREEDOM (admin configurable):
  - JoinPolicy per edge (allOf | anyOf | quorum)
  - degradedOk flag (allows SKIPPED upstream to satisfy dependency)
  - maxConcurrentNodes per run (throttle)

IRON RULES:
  1. Never enqueue node with unresolved dependencies (CF-515)
  2. allOf join must wait for ALL required nodes (CF-519)
  3. Circular dependency = BUILD FAILURE, not runtime error (CF-527)
  4. No duplicate enqueue (CF-525)

QUALITY GATES (AF-9):
  - Scheduler handles UserTaskAnswered event within 500ms SLA
  - allSettled pattern: one BLOCKED branch does not freeze sibling branches
  - Race condition safety: F1090 uses Redis atomic check for join policy
```

### SAVE STATE: FLOW27-P2-COMPLETE
```
T391 engine contract: complete
Factories: F1087, F1088, F1089, F1090, F1091 registered
Skills: SK-252, SK-260 defined
Resume: Continue from P3
```

---

## P3 — VISUAL RUNTIME STATE + PROGRESS AGGREGATION
**Duration**: 35 min | **Save State**: FLOW27-P3-COMPLETE
**Factories**: F1081, F1082, F1083, F1084, F1085, F1086
**Task Types**: T392, T394, T395

### What we build
Event-sourced NodeEvents → materialized RunSnapshot + NodeSnapshot. Universal graph API. Node Inspector API. Progress calculation formula. SubFlow drill-down (via childRunId scoping of same API — no new API needed).

### Engine Contracts T392, T394, T395

**T392 — RunProgressAggregator**
```
ARCHETYPE: AGGREGATION
ENTRY: Fired on every NodeStarted / NodeCompleted / NodeFailed / NodeProgress event
PURPOSE: Maintain materialized RunSnapshot + NodeSnapshot for fast UI reads
FACTORY DEPENDENCIES: F1081, F1082, F1083, F1084, F1085 via CreateAsync()
FABRIC RESOLUTION:
  F1081, F1082, F1084, F1085 → DATABASE FABRIC (ES) — run/node-snapshots
  F1083 → QUEUE FABRIC (Redis Streams) — node-events consumer
IRON RULES:
  CF-514: NodeSnapshot (runId+nodeId) unique within tenant
  CF-522: NodeSnapshot MUST include tenantId (DNA-5)
  CF-524: RunSnapshot progress = weighted avg of NodeSnapshot progress values
PROGRESS FORMULA: progress = (doneCount + 0.5*runningCount) / totalNodeCount
```

**T394 — VisualNodeStateEmitter**
```
ARCHETYPE: PROJECTION
ENTRY: Fired on any node status transition event
PURPOSE: Emit NodeStatusChanged events for real-time UI subscription (WebSocket/SSE)
FACTORY DEPENDENCIES: F1081, F1082, F1083, F1094 via CreateAsync()
IRON RULES: CF-514 (snapshot uniqueness), CF-516 (no events after terminal state)
```

**T395 — NodeDebugSurface**
```
ARCHETYPE: INSPECTION
ENTRY: API call GET /runs/{runId}/nodes/{nodeId}
PURPOSE: Serve node inspector data: status, subSteps, inputs/outputs, judge verdicts, childRunIds
FACTORY DEPENDENCIES: F1082, F1085, F1086 via CreateAsync()
SubFlow drill-down: if nodeType=SubFlow, return childRunIds[] — UI calls same graph API with childRunId
IRON RULES: CF-514, CF-524
```

### SAVE STATE: FLOW27-P3-COMPLETE
```
T392, T394, T395 engine contracts: complete
Factories: F1081–F1086 registered
Skills: SK-253, SK-257, SK-258 defined
APIs: /runs/{runId}/graph, /runs/{runId}/nodes/{nodeId} contracts defined
Resume: Continue from P4
```

---

## P4 — COMPLETION GATE + TERMINAL STATE
**Duration**: 20 min | **Save State**: FLOW27-P4-COMPLETE
**Factories**: F1092, F1093, F1094, F1095
**Task Types**: T393

### What we build
ICompletionGateService checks that ALL required nodes are terminal AND no open HIG gates remain before marking a run COMPLETED. IRunTerminalStateService writes the final state and prevents further event processing.

### Engine Contract T393 (RunCompletionGate)
```
TASK TYPE: T393 — RunCompletionGate
ARCHETYPE: TERMINAL
ENTRY: Fired when all root-level terminal nodes complete
PURPOSE: Validate no open human gates, no failed required nodes → mark run COMPLETED or FAILED
FACTORY DEPENDENCIES: F1092, F1093, F1094, F1095 via CreateAsync()
FABRIC RESOLUTION: All → DATABASE FABRIC (Elasticsearch) — run-snapshots, user-tasks
IRON RULES:
  CF-516: Once COMPLETED/FAILED, no further status events accepted
  CF-520: COMPLETED status forbidden while any blocking HIG gate is open
  CF-528: Run cannot start if flow JSON has no terminal node
QUALITY GATES (AF-9):
  - CompletionGate queries user-tasks index for open blocking tasks (tenantId scoped)
  - RunReadinessValidator runs at flow START to detect missing terminal node early
```

### SAVE STATE: FLOW27-P4-COMPLETE
```
T393 engine contract: complete
Factories: F1092, F1093, F1094, F1095 registered
Skill: SK-255 defined
Resume: Continue from P5
```

---

## P5 — MULTI-TENANT GROUP TASKS + NOTIFICATION FAN-OUT
**Duration**: 35 min | **Save State**: FLOW27-P5-COMPLETE
**Factories**: F1078, F1079, F1080, F1096, F1097, F1098, F1099
**Task Types**: T390, T396, T397, T398

### What we build
Group-assignable tasks with claim/quorum semantics. Notification fan-out through existing INotificationProvider (F68). GroupMembership resolution (tenant-scoped). DeepLink generation for "open task in context".

### Engine Contracts T390, T396, T397, T398

**T390 — GroupUserTask Assignment Gate**
```
TASK TYPE: T390 — GroupUserTask Assignment Gate
ARCHETYPE: HUMAN_GATE
ENTRY: HIG node with assignee.type = group | role | anyOf | allOf | quorum
PURPOSE: Assign UserTask to a group/role within tenant; manage claim, multi-approver, quorum
FACTORY DEPENDENCIES: F1078, F1079, F1080, F1097, F1100 via CreateAsync()
FABRIC RESOLUTION:
  F1078, F1097 → DATABASE FABRIC (PostgreSQL) — assignment-policies, group-members
  F1079 → DATABASE FABRIC (Redis SETNX) — task-claims:{taskId}
  F1080 → DATABASE FABRIC (Redis INCR + ES) — task-quorum:{taskId}, task-answers
  F1100 → DATABASE FABRIC (ES) + QUEUE FABRIC — user-tasks + hig-events
IRON RULES:
  CF-512: quorum count ≤ assignee count
  CF-513: Only claimer (or admin) may answer a claimed task
  CF-517: Group membership must be resolved within tenant scope (DNA-5)
  CF-521: Claim TTL expiry auto-releases + emits ClaimExpired
  CF-526: Same responderId counts only once toward quorum (idempotent)
  CF-530: Group must exist in tenant before task creation
```

**T396 — NotificationFanOut**
```
TASK TYPE: T396 — NotificationFanOut
ARCHETYPE: NOTIFICATION
ENTRY: UserTaskCreated event
PURPOSE: Resolve recipients from group/role within tenant, dedupe, send via INotificationProvider
FACTORY DEPENDENCIES: F1075, F1076, F1078, F1079, F1087, F1096, F1097, F1098, F1099 via CreateAsync()
FABRIC RESOLUTION:
  F1096 → AI ENGINE FABRIC (INotificationProvider F68) — notification-events
  F1097 → DATABASE FABRIC (PG) — group-members
  F1098 → DATABASE FABRIC (Redis) — notif-dedup-cache
  F1099 → CORE FABRIC (config) — deep link templates
IRON RULES:
  CF-518: Same recipient must not receive duplicate notification for same task (dedup key: taskId+channel+recipientId)
  CF-523: Notification payload must include traceId + incomingVariables reference
```

**T397 — GroupTaskNotificationRouter**
```
TASK TYPE: T397 — GroupTaskNotificationRouter
ARCHETYPE: NOTIFICATION
ENTRY: Called by T396; handles group expansion
PURPOSE: Expand group to individual members within tenant, apply visibility rules, route per channel
IRON RULES: CF-517 (tenant-scoped), CF-518 (dedup)
```

**T398 — MultiTenantGroupTaskResolver**
```
TASK TYPE: T398 — MultiTenantGroupTaskResolver
ARCHETYPE: RESOLUTION
ENTRY: Task assignment creation for group/role assignee type
PURPOSE: Validate group exists in tenant, resolve membership, return eligible answerers
IRON RULES: CF-530 (group must exist), CF-517 (tenant scope), CF-522 (tenantId on NodeSnapshot)
```

### SAVE STATE: FLOW27-P5-COMPLETE
```
T390, T396, T397, T398 engine contracts: complete
Factories: F1078, F1079, F1080, F1096, F1097, F1098, F1099 registered
Skills: SK-254, SK-256, SK-261 defined
Resume: Continue from P6
```

---

## P6 — BFA VALIDATION + STRESS TESTS + DNA COMPLIANCE
**Duration**: 30 min | **Save State**: FLOW27-P6-COMPLETE
**BFA Rules**: CF-510–CF-530
**Stress Tests**: ST-300–ST-319

### What we build
Full BFA cross-flow validation matrix: all 21 new rules verified against FLOW-01 through FLOW-26. 20 stress tests covering edge cases identified in requirements (race conditions, TTL expiry, quorum conflicts, duplicate answers, circular dependencies).

### Key Stress Tests Summary

| ST | Scenario | Validates | Expected Outcome |
|----|---------|-----------|-----------------|
| ST-300 | User answers HIG 7 days after creation | CF-511, CF-523 | Answer accepted if within dueAt; rejected if expired |
| ST-301 | Duplicate UserTaskCreated for same nodeId+runId | CF-511 | Second creation rejected (idempotency) |
| ST-302 | Non-blocking HIG: downstream starts before answer | CF-515, DD-131 | Downstream runs with defaults; assumption flagged |
| ST-303 | Two users simultaneously answer quorum=1 task | CF-526 | Only first answer counted; second rejected (idempotent) |
| ST-304 | Quorum=3 task receives 4 answers | CF-512 | First 3 counted; 4th ignored; UserTaskQuorumReached emitted |
| ST-305 | User answers task claimed by another user | CF-513 | Rejected with 403; audit logged |
| ST-306 | Node B depends on Node A; A fails | CF-515, CF-519 | B transitions to BLOCKED; non-dependent C continues |
| ST-307 | Flow has no terminal node | CF-528 | RunReadinessValidator rejects at start time |
| ST-308 | Event received after RunTerminalState=COMPLETED | CF-516 | Event discarded; warning logged |
| ST-309 | Circular dependency in flow JSON (A→B→C→A) | CF-527 | IDagWalkerService → BUILD FAILURE |
| ST-310 | SubFlow node drill-down | DD-135 | Same /graph API with childRunId returns child graph |
| ST-311 | allOf join: one upstream fails | CF-519 | Join not satisfied; downstream BLOCKED; escalation path |
| ST-312 | Notification for 50-member group | CF-518 | All 50 notified; dedup prevents double-send on retry |
| ST-313 | Notification retry after provider failure | CF-518 | Dedup key prevents duplicate; retry succeeds once |
| ST-314 | Group task assigned to non-existent group | CF-530 | Task creation fails with validation error; run not started |
| ST-315 | Node Inspector query for completed subflow | — | childRunIds returned; child graph queryable by runId |
| ST-316 | Progress aggregation with 100 nodes | CF-524 | RunSnapshot progress accurate; batch update within 1s |
| ST-317 | NodeDebugSurface query for failed node | — | Returns inputs, outputs, judge verdicts, error trace |
| ST-318 | Blocking HIG + 5 parallel independent branches | CF-511, CF-515 | HIG branch blocked; 5 other branches continue |
| ST-319 | NodeSnapshot missing tenantId | CF-522, DNA-5 | BUILD FAILURE — rejected at compliance check AF-7 |

### DNA Compliance Matrix (FLOW-27 Services)

| DNA Pattern | How FLOW-27 Complies |
|-------------|---------------------|
| DNA-1: ParseDocument | All UserTask, RunSnapshot, NodeSnapshot use Dictionary<string,object>. No typed DTOs |
| DNA-2: BuildQueryFilters | All ES queries via IDatabaseService.BuildSearchFilter — empty fields auto-skipped |
| DNA-3: DataProcessResult<T> | All factory methods return DataProcessResult<T> — no exceptions for business logic |
| DNA-4: MicroserviceBase | All FLOW-27 services extend MicroserviceBase (19 components inherited) |
| DNA-5: Scope Isolation | tenantId on EVERY query, EVERY document, EVERY Redis key — CF-510, CF-517, CF-522 |
| DNA-6: DynamicController | No entity-specific controllers — universal /runs/{runId}/graph + /user-tasks/{taskId} only |

### BFA Cross-Flow Conflict Register (FLOW-27 new entities vs existing flows)

| New Entity | Potential Conflict With | BFA Check | Resolution |
|-----------|------------------------|-----------|-----------|
| user-tasks ES index | Existing ES indices (FLOW-01 to FLOW-26) | Index name uniqueness | Confirmed unique — no conflict |
| node-events Redis Stream | Existing Redis streams | Stream name uniqueness | Confirmed unique |
| UserTaskCreated event | Existing event types | Event type registry | Confirmed unique |
| INotificationProvider (F68) | Reused by FLOW-27 (T396) | Interface unchanged | No conflict — additive caller |
| tenantId on all docs | Existing multi-tenant pattern | DNA-5 compliance | Aligned — no conflict |
| HumanInteractionGate nodeType | FlowOrchestrator (Skill 09) | Node type registry | New type handler — additive |

### SAVE STATE: FLOW27-P6-COMPLETE
```
All 21 BFA rules: CF-510–CF-530 registered and cross-validated
All 20 stress tests: ST-300–ST-319 defined
DNA compliance matrix: PASSED (all 6 patterns)
Cross-flow conflicts: NONE detected
Promotion ladder: GENERATED → ready for INJECTED phase
FLOW-27: COMPLETE
```

---

## SUMMARY: WHAT FLOW-27 ENABLES

After FLOW-27, every flow in the engine (FLOW-01 through FLOW-27 and all future flows) automatically gains:

1. **"Leave and come back"** — any node can be a HumanInteractionGate. Run survives user absence. UserTask stores exact context needed to resume.

2. **Non-blocking execution** — DependencyScheduler keeps all non-dependent branches running while human gates are open. One waiting node never freezes the whole flow.

3. **Visual progress** — every run has `/graph` API returning per-node status + progress%. Click any node → Node Inspector. Click SubFlow → drill into child run. Click WAITING_FOR_USER → answer modal with exact context.

4. **Group tasks** — tasks assignable to groups, roles, or quorum within tenant. Claim prevents conflicting answers. Quorum collects N approvals. All tenant-scoped.

5. **Notifications** — fan-out to group members via existing INotificationProvider (F68). Deep links back to task context. Dedup prevents duplicate notifications on retry.

6. **Complete audit trail** — immutable NodeEvents + materialized snapshots. All queryable by traceId. All tenant-scoped. All compliant with 9 DNA patterns.

---

## RECOVERY COMMANDS

```
"Continue FLOW-27 from P0"  → Foundation schemas + ES indices
"Continue FLOW-27 from P1"  → HumanInteractionGate + UserTask Registry
"Continue FLOW-27 from P2"  → DependencyAwareScheduler
"Continue FLOW-27 from P3"  → Visual Runtime State + Progress
"Continue FLOW-27 from P4"  → Completion Gate + Terminal State
"Continue FLOW-27 from P5"  → Multi-Tenant Group Tasks + Notifications
"Continue FLOW-27 from P6"  → BFA Validation + Stress Tests
```
