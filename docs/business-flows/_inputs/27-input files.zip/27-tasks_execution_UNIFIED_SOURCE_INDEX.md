# FLOW-27 — UNIFIED SOURCE INDEX
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: UNIFIED_SOURCE_INDEX_MERGED.md
## Status: AUTHORITATIVE — FLOW-27 artifacts only

---

## ARTIFACT CROSS-REFERENCE MAP

### Factories → Task Types → BFA Rules → Skills

| Factory | Interface | Used By Task Types | BFA Rules | Skills |
|---------|-----------|-------------------|-----------|--------|
| F1075 | IHumanInteractionGateService | T389, T396 | CF-511, CF-515, CF-520, CF-523 | SK-251, SK-259 |
| F1076 | IUserTaskRegistryService | T389, T390, T396, T398 | CF-510, CF-511, CF-522 | SK-259 |
| F1077 | ITaskContextSnapshotService | T389 | CF-511 | SK-251 |
| F1078 | ITaskAssignmentResolverService | T390, T396, T397, T398 | CF-517, CF-530 | SK-254 |
| F1079 | ITaskClaimService | T390, T396 | CF-513, CF-521 | SK-254 |
| F1080 | ITaskQuorumService | T390 | CF-512, CF-526, CF-530 | SK-261 |
| F1081 | IRunSnapshotService | T392, T393, T394, T395 | CF-516, CF-524 | SK-253, SK-258 |
| F1082 | INodeSnapshotService | T392, T394, T395, T398 | CF-514, CF-522, CF-524 | SK-253, SK-257 |
| F1083 | INodeEventEmitterService | T392, T394, T397 | CF-516 | SK-253 |
| F1084 | IFlowProgressAggregatorService | T392, T395 | CF-524 | SK-253 |
| F1085 | IRunGraphQueryService | T392, T395 | CF-514 | SK-258 |
| F1086 | INodeDebugSurfaceService | T395 | — | SK-258 |
| F1087 | IDependencySchedulerService | T391, T396, T397 | CF-515, CF-527 | SK-252 |
| F1088 | INodeReadinessEvaluatorService | T391 | CF-515, CF-519 | SK-252 |
| F1089 | IBlockedNodeResolverService | T391 | CF-515 | SK-252 |
| F1090 | IJoinPolicyEnforcerService | T391 | CF-519 | SK-260 |
| F1091 | IDagWalkerService | T391 | CF-527, CF-529 | SK-252 |
| F1092 | ICompletionGateService | T393 | CF-520, CF-528 | SK-255 |
| F1093 | IRunReadinessValidatorService | T393 | CF-520, CF-528 | SK-255 |
| F1094 | IRunTerminalStateService | T393, T394 | CF-516 | SK-255 |
| F1095 | IPendingGateResolverService | T393 | CF-520 | SK-255 |
| F1096 | ITaskNotificationOrchestratorService | T397, T396 | CF-518 | SK-256 |
| F1097 | IGroupMembershipResolverService | T390, T397 | CF-517, CF-518 | SK-256 |
| F1098 | INotificationDedupeService | T397 | CF-518 | SK-256 |
| F1099 | INotificationDeepLinkService | T397 | — | SK-256 |
| F1100 | IUserTaskAnswerProcessorService | T389, T390 | CF-512, CF-513, CF-523 | SK-251, SK-254 |

---

### Task Types → Factories → BFA Rules → Stress Tests

| Task Type | Name | Factories | Key BFA Rules | Key Stress Tests |
|-----------|------|-----------|---------------|-----------------|
| T389 | HumanInteractionGate Node | F1075, F1076, F1077, F1078, F1087, F1100 | CF-511, CF-515, CF-520 | ST-300, ST-301, ST-302, ST-318 |
| T390 | GroupUserTask Assignment Gate | F1078, F1079, F1080, F1097, F1100 | CF-512, CF-513, CF-517, CF-530 | ST-303, ST-304, ST-305, ST-314 |
| T391 | DependencyAwareScheduler | F1087, F1088, F1089, F1090, F1091 | CF-515, CF-519, CF-527 | ST-306, ST-311, ST-318 |
| T392 | RunProgressAggregator | F1081, F1082, F1083, F1084, F1085 | CF-514, CF-516, CF-524 | ST-316, ST-319 |
| T393 | RunCompletionGate | F1092, F1093, F1094, F1095 | CF-516, CF-520, CF-528 | ST-307, ST-308 |
| T394 | VisualNodeStateEmitter | F1081, F1082, F1083, F1094 | CF-514, CF-516 | ST-309, ST-310 |
| T395 | NodeDebugSurface | F1082, F1085, F1086 | CF-514, CF-524 | ST-315, ST-317 |
| T396 | NotificationFanOut | F1075, F1076, F1078, F1079, F1087, F1096, F1097, F1098, F1099 | CF-518, CF-523 | ST-312, ST-313 |
| T397 | GroupTaskNotificationRouter | F1083, F1096, F1097, F1098, F1099 | CF-517, CF-518 | ST-312, ST-313 |
| T398 | MultiTenantGroupTaskResolver | F1078, F1082, F1097 | CF-522, CF-530 | ST-314, ST-319 |

---

### BFA Rules → Task Types → Stress Tests

| BFA Rule | Description (short) | Applies To | Stress Tests |
|----------|---------------------|------------|--------------|
| CF-510 | UserTask must have valid tenantId | T389, T390 | ST-300 |
| CF-511 | HIG node cannot resume without UserTask answer record | T389 | ST-300, ST-301 |
| CF-512 | Quorum count must not exceed assignee count | T390 | ST-303, ST-304 |
| CF-513 | Claimed task cannot be answered by non-claimer | T390 | ST-305 |
| CF-514 | NodeSnapshot.runId + nodeId must be unique within tenant | T392, T394, T395 | ST-316 |
| CF-515 | Scheduler must not enqueue node with unresolved dependencies | T389, T391 | ST-306, ST-318 |
| CF-516 | RunTerminalState must be final — no further events after COMPLETED/FAILED | T393, T394 | ST-308 |
| CF-517 | Group membership resolution must be tenant-scoped (DNA-5) | T390, T397, T398 | ST-314 |
| CF-518 | Notification dedup must prevent same recipient receiving same task notification twice | T396, T397 | ST-312, ST-313 |
| CF-519 | JoinPolicy allOf must wait for ALL required upstream nodes | T391 | ST-306, ST-311 |
| CF-520 | CompletionGate must verify no open HIG gates before marking run COMPLETED | T393 | ST-307, ST-308 |
| CF-521 | Claim TTL expiry must auto-release and emit ClaimExpired event | T390 | ST-305 |
| CF-522 | NodeSnapshot must include tenantId on every document (DNA-5) | T390, T392 | ST-319 |
| CF-523 | UserTask contextSnapshot must include exact incomingVariables at gate time | T389, T396 | ST-300, ST-318 |
| CF-524 | RunSnapshot progress must equal weighted average of NodeSnapshot progress values | T392, T395 | ST-316, ST-319 |
| CF-525 | DependencyScheduler must not duplicate-enqueue a node already in READY state | T391 | ST-306 |
| CF-526 | Quorum answer must be idempotent (same responderId cannot count twice) | T390 | ST-303 |
| CF-527 | DAGWalker cycle detection must fail BUILD if circular dependency found | T391 | ST-309 |
| CF-528 | RunReadinessValidator must reject start if flow JSON has no terminal node | T393 | ST-307 |
| CF-529 | IDagWalkerService must traverse all reachable nodes from root | T391 | ST-309 |
| CF-530 | Group assignment must validate group exists in tenant before task creation | T390, T398 | ST-314 |

---

### Skills → Factories → Task Types

| Skill | Name | Covers Factories | Used By Task Types |
|-------|------|-----------------|-------------------|
| SK-251 | HumanInteractionGate Implementation | F1075, F1077, F1100 | T389 |
| SK-252 | DependencyAwareScheduler Implementation | F1087, F1088, F1089, F1091 | T391 |
| SK-253 | RunProgressAggregator + NodeSnapshot | F1081, F1082, F1083, F1084 | T392, T394 |
| SK-254 | TaskClaimService + AssignmentResolver | F1078, F1079, F1100 | T390 |
| SK-255 | CompletionGate + RunTerminalState | F1092, F1093, F1094, F1095 | T393 |
| SK-256 | GroupTaskNotificationRouter | F1096, F1097, F1098, F1099 | T396, T397 |
| SK-257 | NodeDebugSurface Pattern | F1082, F1086 | T395 |
| SK-258 | RunGraphQuery API | F1085, F1086 | T392, T395 |
| SK-259 | UserTaskRegistry CRUD | F1075, F1076 | T389, T390 |
| SK-260 | JoinPolicyEnforcer (allOf/anyOf/quorum) | F1090 | T391 |
| SK-261 | TaskQuorumService (Redis counter pattern) | F1080 | T390 |

---

### Design Records → Task Types

| DR | Decision | Impacts |
|----|---------|---------|
| DR-99 | HumanInteractionGate is EP-6 (engine primitive) | T389, T390, all flows |
| DR-100 | UserTask in Elasticsearch (durable, queryable) | T389, T390, T396 |
| DR-101 | DependencyScheduler uses `waitFor[]` — no schema change | T391 |
| DR-102 | Event-sourced NodeEvents → materialized NodeSnapshots | T392, T394 |
| DR-103 | Claim uses Redis SETNX atomic op | T390, SK-254 |
| DR-104 | Quorum uses Redis INCR + threshold | T390, SK-261 |
| DR-105 | Notification routes through existing INotificationProvider F68 | T396, T397 |

---

### Design Decisions → Architectural Impact

| DD | Decision | Components Impacted |
|----|---------|---------------------|
| DD-130 | Blocking policy is per-node config | T389, T391, flow JSON schema |
| DD-131 | WAITING_FOR_USER doesn't stop other branches | T391, T392 |
| DD-132 | Events immutable, snapshots are materialized views | T392, T394, SK-253 |
| DD-133 | Redis SETNX for single-claim guarantee | T390, SK-254 |
| DD-134 | Redis INCR for quorum completion | T390, SK-261 |
| DD-135 | SubFlow drill-down uses same graph API (childRunId scope) | T395, UI |
| DD-136 | Notification dedup = taskId+channel+recipientId | T396, T397, SK-256 |
| DD-137 | tenantId mandatory on all new documents | T389–T398, DNA-5 |
| DD-138 | Progress% formula: (done + 0.5*running) / total | T392, T394, SK-253 |
| DD-139 | EP-6 is engine-level — all flows inherit | All flows, EP-6 |

---

## FABRIC RESOLUTION MAP

| Factories | Fabric | Provider | ES Index / Redis Key |
|-----------|--------|----------|----------------------|
| F1075, F1076, F1077 | DATABASE FABRIC (ES) | Elasticsearch | user-tasks, task-context-snapshots |
| F1075 (events) | QUEUE FABRIC | Redis Streams | hig-events |
| F1078 | DATABASE FABRIC (PG) | PostgreSQL | assignment-policies, group-members |
| F1079 | DATABASE FABRIC (Redis) | Redis SETNX | task-claims:{taskId} |
| F1080 | DATABASE FABRIC (Redis+ES) | Redis INCR + ES | task-quorum:{taskId}, task-answers |
| F1081, F1082, F1084, F1085, F1086 | DATABASE FABRIC (ES) | Elasticsearch | run-snapshots, node-snapshots |
| F1083 | QUEUE FABRIC | Redis Streams | node-events |
| F1087, F1089 | QUEUE FABRIC | Redis Streams | scheduler-ready-queue, resume-events |
| F1088, F1090, F1091 | DATABASE FABRIC (ES/Redis) | Elasticsearch + Redis | node-snapshots, join-policy |
| F1092, F1093, F1094, F1095 | DATABASE FABRIC (ES) | Elasticsearch | run-snapshots, user-tasks |
| F1096 | AI ENGINE FABRIC | INotificationProvider (F68) | notification-events |
| F1097 | DATABASE FABRIC (PG) | PostgreSQL | group-members |
| F1098 | DATABASE FABRIC (Redis) | Redis | notif-dedup-cache |
| F1099 | CORE FABRIC | Config-driven (Skill 01) | — |
| F1100 | DATABASE FABRIC (ES) + QUEUE FABRIC | ES + Redis Streams | user-tasks + hig-events |

---

## UI CONTRACT — UNIVERSAL APIs

```http
# Visual runtime state (fabric-first, platform-agnostic)
GET  /api/runs/{runId}/graph
  tenant-scoped via auth context (DNA-5)
  → nodes[] (id, type, status, progress, blockedBy[], taskId?, childRunIds?)
  → edges[] (from, to, label?)
  → summary { done, running, waitingUser, blocked, failed, total }

GET  /api/runs/{runId}/nodes/{nodeId}
  → snapshot { status, progress%, startedAt, endedAt }
  → subSteps[] { id, title, status, startedAt, endedAt, retryCount }
  → timings { queuedAt, startedAt, endedAt, durationMs }
  → debugLinks { traceId, phaseLink, judgeLink }
  → childRunIds[] (if nodeType = SubFlow)

# Human task lifecycle
GET  /api/user-tasks?runId={runId}          (tenant-scoped)
GET  /api/user-tasks/{taskId}
  → task { questionType, expectedAnswerSchema, contextSnapshot }
  → contextSnapshot { incomingVariables, decisionNeeded, suggestedOptions[] }
  → assignee { type, targets[], quorum? }
  → currentClaim { claimerId, expiresAt } | null
POST /api/user-tasks/{taskId}/claim          (atomic via Redis SETNX)
POST /api/user-tasks/{taskId}/answer         (triggers resume event)
```

---

## FLOW-27 vs Existing Flows: Backward Compatibility

| Existing Artifact | Impact from FLOW-27 |
|------------------|---------------------|
| FLOW-01 to FLOW-26 | No impact — EP-6 adds beneath all flows |
| T1–T388 | Unchanged. New factories F1075+ injectable via DI |
| CF-1–CF-509 | Unchanged. CF-510+ are additive |
| SK-1–SK-250 | Unchanged. SK-251+ are additive |
| Existing HumanApprovalGate concept | Formalized as T389/T390 — same semantics |
| FLOW-05 allSettled pattern | Reused and extended in T391 / SK-260 |
| F68 INotificationProvider | Reused by T396/T397 — no interface changes |
| `waitFor[]` / `dependsOn[]` in flow JSON | Interpreted by T391 — no schema migration |
| FlowOrchestrator (Skill 09) | New HIG node type recognized — additive handler |

---

## FLOW-27 TEMPLATE SUMMARY

### Template 50: Human-Gated Flow with Visual Runtime State

```json
{
  "templateId": "TPL-50",
  "name": "HumanGatedFlowTemplate",
  "version": "1.0",
  "description": "Universal template: any flow step can be a HIG node. Engine manages dependency scheduling, progress tracking, and notification fan-out automatically.",
  "nodeTypes": ["HumanInteractionGate", "GroupUserTaskGate", "SubFlow", "AutoStep"],
  "requiredCapabilities": ["EP-6:HumanInteractionGate", "T391:DependencyAwareScheduler", "T392:RunProgressAggregator"],
  "fabricDependencies": {
    "database": "IDatabaseService (Skill 05)",
    "queue": "IQueueService (Skill 04)",
    "notification": "INotificationProvider (F68)",
    "core": "MicroserviceBase (Skill 01)"
  },
  "afStations": {
    "generator": "AF-1",
    "ragContext": "AF-4",
    "compliance": "AF-7",
    "judge": "AF-9"
  },
  "dnaPatternsEnforced": ["DNA-1", "DNA-2", "DNA-3", "DNA-4", "DNA-5", "DNA-6"]
}
```
