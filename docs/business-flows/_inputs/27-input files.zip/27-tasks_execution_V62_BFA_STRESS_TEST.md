# FLOW-27 — V62 BFA STRESS TEST
## Human Interaction Gate + Dependency Scheduler + Visual Runtime State + Multi-Tenant Group Tasks
## Extension of: V62_BFA_STRESS_TEST_MERGED.md (CF-1-CF-509 and ST-1-ST-299 unchanged)
## FLOW-27 BFA Rules: CF-510–CF-530 | Stress Tests: ST-300–ST-320
## Status: AUTHORITATIVE — FLOW-27 ONLY

---

# BFA CONFLICT RULES (CF-510 – CF-530)

---

## CF-510 — UserTask Cross-Tenant Visibility Fence

```
RULE:         UserTask documents MUST be queryable only by their owning tenantId.
              Any API call that retrieves, lists, or modifies a UserTask MUST
              include tenantId in the query filter (DNA-5).
TRIGGER:      T398 (MultiTenantTaskVisibilityGate), T389 (HIG Node), T390 (GroupTask Assignment)
SEVERITY:     CRITICAL
FACTORY OPS:  F1076.ListUserTasksAsync — BuildSearchFilter must include tenantId
              F1076.GetUserTaskAsync — tenantId check before returning document
VIOLATION:    UserTask returned without tenantId filter in query
RESOLUTION:   All task queries go through F1076/T398 with mandatory tenantId
IRON RULE:    User accessing taskId from different tenant receives 404 (not 403, no enumeration)
```

---

## CF-511 — HumanGate Duplicate Task Prevention

```
RULE:         For a given (tenantId, runId, nodeId), at most ONE UserTask may be in
              status waiting_for_user at a time.
TRIGGER:      T389 (HumanInteractionGate Node) — OpenGateAsync
SEVERITY:     HIGH
FACTORY OPS:  F1075.OpenGateAsync must check existing open task for same nodeId+runId
VIOLATION:    Two UserTasks for same (tenantId, runId, nodeId) both in waiting_for_user
RESOLUTION:   Idempotency check in F1075: if open task exists, return existing taskId
IRON RULE:    OpenGateAsync is idempotent — duplicate call returns existing taskId, not error
```

---

## CF-512 — Quorum Answer Race Condition Guard

```
RULE:         When multiple users submit answers simultaneously to a quorum gate,
              exactly the needed count should be accepted; excess answers are preserved
              in audit trail but do not change gate outcome.
TRIGGER:      T390 (GroupUserTask Assignment), F1080.RecordAnswerAsync
SEVERITY:     HIGH
FACTORY OPS:  F1080 must use optimistic locking or atomic counter for quorum tracking
              F1080.EvaluateQuorumAsync called after each answer
VIOLATION:    Gate closed with fewer than needed answers, OR gate closed multiple times
RESOLUTION:   Atomic increment with compare-and-swap on answeredCount
IRON RULE:    All recorded answers preserved even after quorum (audit trail — IR-F1080-3)
```

---

## CF-513 — Claim TTL Expiry Conflict Rule

```
RULE:         When a claim TTL expires, the claim MUST auto-release before another
              user can claim. The expiring user's in-progress answer MUST be rejected
              if submitted after TTL.
TRIGGER:      T396 (TaskClaimManager), F1079.ExpireClaimAsync
SEVERITY:     HIGH
FACTORY OPS:  F1079: claim TTL scheduler fires ExpireClaimAsync
              F1100: check claim validity before accepting answer
VIOLATION:    Answer accepted from user whose claim TTL already expired
RESOLUTION:   F1100.ProcessAnswerAsync checks claim status before accepting
IRON RULE:    ClaimExpired event emitted; claim auto-releases; group notified (IR-F1079-2)
```

---

## CF-514 — Stale Snapshot Invalidation Rule

```
RULE:         A NodeSnapshot must not be served from cache if the underlying node
              state changed more recently than the snapshot's updatedAt timestamp.
TRIGGER:      T392 (RunProgressAggregator), T394 (NodeStateProjector)
SEVERITY:     MEDIUM
FACTORY OPS:  F1082.UpsertNodeSnapshotAsync must update updatedAt on every state change
              F1085.GetNodeDetailAsync must use ES updatedAt for cache validation
VIOLATION:    UI shows RUNNING status for a node that completed 30 seconds ago
RESOLUTION:   ES query uses sort by updatedAt DESC; no client-side cache > 5s
```

---

## CF-515 — Dependent Node Pre-Fire Guard

```
RULE:         A node with nodeType=HumanInteractionGate and blockingPolicy=blocking
              MUST block ALL transitive dependents in the DAG from reaching READY state
              until the gate is answered or expired with non_blocking fallback.
TRIGGER:      T391 (DependencyAwareScheduler), F1088.EvaluateNodeAsync
SEVERITY:     CRITICAL
FACTORY OPS:  F1088: READY check requires ALL human_required waitFor in answered status
              F1091.GetTransitiveDependentsAsync used to identify blocked subgraph
VIOLATION:    A node downstream of a blocking HIG reaches READY/RUNNING before gate answered
RESOLUTION:   DependencyScheduler checks blockingPolicy for every HIG in waitFor chain
IRON RULE:    IR-T391-3 — WAITING_FOR_USER gate must NOT propagate as READY to dependents
```

---

## CF-516 — Run Terminal State Idempotency Rule

```
RULE:         Calling CompleteRunAsync / FailRunAsync / CancelRunAsync on a run that
              is already in a terminal state (SUCCEEDED/FAILED/CANCELLED) MUST be a
              no-op, not an error and not a state change.
TRIGGER:      T393 (CompletionGateValidator), F1094
SEVERITY:     MEDIUM
FACTORY OPS:  F1094: check current status before applying terminal state
VIOLATION:    SUCCEEDED run becomes FAILED due to delayed terminal event
RESOLUTION:   Idempotency guard: if already terminal, log and return success
IRON RULE:    IR-T393-4 — MarkRunReadyAsync already-READY = no-op
```

---

## CF-517 — Group Membership Tenant Scope Rule

```
RULE:         ALL group membership and role resolution queries MUST include tenantId.
              Cross-tenant groups are architecturally forbidden.
TRIGGER:      T390, T397, F1097.GetMembersAsync
SEVERITY:     CRITICAL
FACTORY OPS:  F1097: every query includes WHERE tenantId = $tenantId
              F1078: every eligibility check scoped to tenantId
VIOLATION:    Group membership query returns users from another tenant
RESOLUTION:   DB FABRIC (PG) query always includes tenantId filter; test with DNA-5 scanner
IRON RULE:    Cross-tenant group reference in assigneePolicy = BUILD FAILURE (IR-T390-2)
```

---

## CF-518 — Notification Anti-Spam Fence

```
RULE:         At most one active notification per (taskId, channel, recipient).
              Re-notifications only allowed if: dueAt is approaching, task was re-opened,
              or user explicitly requests resend.
TRIGGER:      T397 (NotificationFanoutOrchestrator), F1098 (INotificationDedupeService)
SEVERITY:     MEDIUM
FACTORY OPS:  F1098.IsDuplicateAsync before every send
              F1098.MarkSentAsync after successful send with TTL = max(dueAt-now, 24h)
VIOLATION:    User receives 50 notifications for the same task
RESOLUTION:   Dedup cache (Redis) keyed by taskId+channel+recipient
IRON RULE:    IR-T397-3 — one active notification per combination
```

---

## CF-519 — allSettled Non-Blocking Branch Rule

```
RULE:         In allSettled join mode, a branch that is WAITING_FOR_USER or SKIPPED
              MUST NOT prevent other branches from completing and progressing through the join.
TRIGGER:      T391 (DependencyAwareScheduler), F1090 (IJoinPolicyEnforcerService)
SEVERITY:     HIGH
FACTORY OPS:  F1090.EvaluateJoinAsync: allSettled proceeds when all required branches terminal
              Optional branches in non-terminal state = treated as absent (not blocking)
VIOLATION:    allSettled join blocked because one optional branch is WAITING_FOR_USER
RESOLUTION:   Join policy distinguishes required vs optional branches explicitly
IRON RULE:    Pattern reused from FLOW-05 allSettled — backward-compatible
```

---

## CF-520 — CompletionGate Open HumanTask Fence

```
RULE:         A run MUST NOT be marked READY/SUCCEEDED while any UserTask with
              blockingPolicy=blocking exists in status waiting_for_user for that run.
TRIGGER:      T393 (CompletionGateValidator), F1092.MarkRunReadyAsync
SEVERITY:     CRITICAL
FACTORY OPS:  F1092: EvaluateCompletionAsync must call F1095.CountOpenRequiredGatesAsync
              If count > 0: return CompletionStatus{ ready: false, blocking: [...] }
VIOLATION:    Run marked READY while user is still being asked for input
RESOLUTION:   F1092: explicit check before any SUCCEEDED state transition
IRON RULE:    IR-T393-1 — NEVER mark READY if open required UserTasks > 0
```

---

## CF-521 — Claim Release Orphan Prevention

```
RULE:         If a claim is released (TTL expiry or manual release), the underlying
              UserTask MUST remain in waiting_for_user state — NOT advance to answered
              or closed. The release only affects the claim, not the task gate.
TRIGGER:      T396 (TaskClaimManager), F1079.ReleaseClaimAsync / ExpireClaimAsync
SEVERITY:     HIGH
FACTORY OPS:  F1079: release only updates task-claims; F1076 task status unchanged
VIOLATION:    UserTask closed when claim releases (no answer recorded)
RESOLUTION:   Claim release = update claim doc; gate status unchanged until actual answer
```

---

## CF-522 — NodeSnapshot Tenant Isolation Rule

```
RULE:         ALL NodeSnapshot documents in node-snapshots ES index MUST include tenantId.
              ALL queries against node-snapshots MUST filter by tenantId.
TRIGGER:      T392, T394, F1082
SEVERITY:     CRITICAL
FACTORY OPS:  F1082: UpsertNodeSnapshotAsync requires tenantId in document
              F1082: GetNodeSnapshotAsync requires tenantId in query
VIOLATION:    NodeSnapshot returned without tenantId scope check
RESOLUTION:   DNA-5 compliance check enforced by AF-7 Compliance station
```

---

## CF-523 — HumanGate Expired-Answer Rejection Rule

```
RULE:         If a UserTask has status=expired, any answer submission MUST be rejected.
              Expired gates should not be re-openable without explicit flow restart.
TRIGGER:      T389, F1100.ProcessAnswerAsync
SEVERITY:     HIGH
FACTORY OPS:  F1100: check task status before accepting answer; expired = DataProcessResult.Failure
VIOLATION:    Answer recorded for expired task, causing phantom resume of cancelled branch
RESOLUTION:   Status check as first step in ProcessAnswerAsync
```

---

## CF-524 — SubFlow Progress Rollup Integrity Rule

```
RULE:         A SubFlow parent node's progress MUST be computed from the child
              RunSnapshot.progressPct — not from child node count directly.
              If child run is not yet started, progress = 0.0 (not null/error).
TRIGGER:      T395 (SubFlowDrilldownBridge), T392, F1084
SEVERITY:     MEDIUM
FACTORY OPS:  F1082: SubFlow node progress = child IRunSnapshotService.GetRunSnapshotAsync
              F1084: ComputeProgressAsync handles missing child run gracefully (default 0.0)
VIOLATION:    SubFlow node shows null or 100% when child run not started
RESOLUTION:   Explicit null-safe default in F1084 progress computation
```

---

## CF-525 — UserTask Reassignment Audit Fence

```
RULE:         Every reassignment of a UserTask MUST create an immutable audit event
              recording: reassignedBy (userId), fromAssignee, toAssignee, timestamp, reason.
TRIGGER:      T396 (TaskClaimManager), F1076.AppendAnswerEventAsync (for audit)
SEVERITY:     MEDIUM
FACTORY OPS:  F1076: append audit event on reassignment (type=Reassigned)
              F1078: verify reassigning user has reassign permission (allowReassign=true)
VIOLATION:    Reassignment with no audit trail
RESOLUTION:   Audit event appended atomically with claim update
```

---

## CF-526 — Quorum Partial Answer Preservation Rule

```
RULE:         For quorum/allOf tasks, partial answers collected before quorum is reached
              MUST be preserved in the UserTask document even if quorum is later cancelled
              or the run is cancelled. Answers are immutable once recorded.
TRIGGER:      T390, F1080
SEVERITY:     MEDIUM
FACTORY OPS:  F1080.RecordAnswerAsync: append to answers[] array (never replace)
VIOLATION:    Answers lost when run cancelled or quorum policy changed
RESOLUTION:   answers[] is append-only; immutable after RecordAnswerAsync
```

---

## CF-527 — DependencyScheduler Cycle Detection Rule

```
RULE:         A flow DAG with a cycle (nodeA → nodeB → nodeA) MUST be detected
              at flow-load time and prevent run start. Running with a cycle = infinite
              BLOCKED state with no progress possible.
TRIGGER:      T391 (DependencyAwareScheduler), F1091.HasCycleAsync
SEVERITY:     CRITICAL
FACTORY OPS:  F1091.HasCycleAsync called during flow validation (before first run)
              If cycle detected: DataProcessResult.Failure with cycle path explanation
VIOLATION:    Run starts with cyclic flow definition — all nodes BLOCKED forever
RESOLUTION:   Pre-run validation gate using F1091
IRON RULE:    IR-T391-1: DAG cycle = run FAILED immediately with clear error
```

---

## CF-528 — RunReadiness Required Terminal Node Rule

```
RULE:         CompletionGate requires ALL required terminal nodes to be in SUCCEEDED
              status. A terminal node in FAILED, CANCELLED, or SKIPPED (if required)
              prevents READY declaration.
TRIGGER:      T393, F1093.AllTerminalNodesSucceededAsync
SEVERITY:     CRITICAL
FACTORY OPS:  F1093: check each required terminal node status from NodeSnapshot
VIOLATION:    Run declared READY while required terminal node is in FAILED state
RESOLUTION:   Explicit required terminal node list in flow definition + F1093 check
```

---

## CF-529 — Cross-Flow HumanTask Propagation Fence

```
RULE:         HumanInteractionGate tasks belong to exactly one runId. A SubFlow's
              HIG tasks MUST NOT propagate to parent run as open requirements.
              Parent run completion checks only PARENT run's open required tasks.
TRIGGER:      T393, T395, F1092/F1093
SEVERITY:     HIGH
FACTORY OPS:  F1093.GetOpenRequiredTasksAsync: filter by runId (not recursive to childRunIds)
              SubFlow node's completion = childRun SUCCEEDED (not 0 child open tasks)
VIOLATION:    Parent run blocked by child run's HIG tasks
RESOLUTION:   CompletionGate checks runId-scoped tasks only; SubFlow node = complete when child run SUCCEEDED
```

---

## CF-530 — AllOf Answer Completeness Gate

```
RULE:         For allOf assignee policy, gate MUST NOT close until every member of
              the target list has submitted an answer. If a member is deleted or
              removed from group, the allOf requirement must be re-evaluated and
              admin must explicitly resolve.
TRIGGER:      T390, F1080.EvaluateQuorumAsync
SEVERITY:     HIGH
FACTORY OPS:  F1080: for allOf, needed = len(targets); check all answered
              F1078: if target user deactivated, return warning + require admin resolution
VIOLATION:    allOf gate closes with 4/5 answers because 1 user deleted
RESOLUTION:   Admin resolution flow: remove deactivated user from targets, re-evaluate
```

---

# STRESS TESTS (ST-300 – ST-320)

---

## ST-300 — User Does Not Respond For 7 Days

```
SCENARIO:     blocking HumanInteractionGate opened; dueAt = 7 days; user never responds
SETUP:        flowId=human-interaction-flow-v1, nodeId=human-gate-1, assignee=user-123
              dueAt = now + 7 days, blockingPolicy=blocking
ACTIONS:      1. Gate opens (T389) — UserTaskCreated emitted
              2. auto-branch-a and auto-branch-b continue running (unblocked branches)
              3. Time advances 7 days — no answer submitted
              4. TTL scheduler fires ExpireGateAsync (F1075)
EXPECTED:
              - auto-branch-a: SUCCEEDED (unaffected by gate)
              - human-gate-1: status=expired
              - post-human-task: status=BLOCKED → FAILED (required dep expired without non_blocking fallback)
              - RunSnapshot.status: BlockedOnDependency or FailedNeedsRepair
              - No duplicate notifications after expiry
              - Run NOT marked READY (CF-520, CF-528)
FAILURE MODES: Gate stays waiting_for_user forever (TTL scheduler not wired)
               non_blocking fallback applied when blockingPolicy=blocking (CF-515)
```

---

## ST-301 — Duplicate Answer From Two Devices

```
SCENARIO:     single_claim task; user Dana submits answer from phone AND laptop simultaneously
SETUP:        taskId=T1, claimMode=single_claim, Dana has active claim
              Two simultaneous POST /user-tasks/T1/answer at t=0 from different devices
ACTIONS:      1. Dana claims task on laptop at t=-30s
              2. Simultaneously at t=0: laptop sends answer, phone sends answer
EXPECTED:
              - Exactly 1 answer accepted (idempotency by userId+taskId)
              - Second submission receives DataProcessResult.Failure (already answered)
              - UserTask.status = answered (not double-answered)
              - Gate closes exactly once
              - DependencyScheduler fires once (not twice)
FAILURE MODES: Gate closes twice → DependencyScheduler fires twice → nodes enqueued twice
```

---

## ST-302 — Answer Arrives After Branch Timeout

```
SCENARIO:     non_blocking HIG; engine proceeds with defaults after timeout;
              user submits answer 2 hours later
SETUP:        blockingPolicy=non_blocking, dueAt=1h from now
              t=0: gate opened; t=1h: engine proceeds with defaults (gate skipped)
              t=2h: user submits answer
EXPECTED:     - At t=1h: gate skipped (F1075.SkipGateAsync), downstream unblocked with defaults
              - At t=2h: ProcessAnswerAsync returns: { accepted: false, reason: "gate_expired" }
              - RunSnapshot unaffected by late answer
              - UserTask.status stays expired (CF-523)
              - No re-processing of downstream with actual answer (would cause duplicate execution)
FAILURE MODES: Late answer triggers re-run of already-completed downstream nodes
```

---

## ST-303 — Quorum Reached Simultaneously By 3 Users

```
SCENARIO:     quorum.needed=2, 3 users submit answers simultaneously
SETUP:        taskId=T2, assigneePolicy={ type:quorum, needed:2, outOf:5 }
              t=0: Users A, B, C all submit answers simultaneously
EXPECTED:     - Exactly 2 answers accepted (atomic counter)
              - 3rd answer: recorded in audit trail but gate already closed
              - Gate closes exactly once → DependencyScheduler fires once
              - QuorumStatus.reached=true after 2 answers
              - All 3 answers preserved in task document (CF-526)
FAILURE MODES: Race condition causes gate to close 3 times
               Only 1 answer accepted due to overly aggressive lock
```

---

## ST-304 — Claim TTL Expires Mid-Answer

```
SCENARIO:     User starts filling answer form; claim TTL expires before submission
SETUP:        taskId=T3, claimTtlSec=300 (5min), user Dana claimed at t=0
              At t=4:30 Dana starts writing long answer; at t=5:00 claim TTL fires
              At t=5:30 Dana submits answer
EXPECTED:     - At t=5:00: claim auto-expires, ClaimExpired event emitted (CF-513)
              - Dana's claim released; other group members can now claim
              - At t=5:30: Dana's submission fails (CF-513: check claim before accepting)
              - Group notified that task is unclaimed again (T397)
              - No orphan claim record (CF-521)
FAILURE MODES: Dana's answer accepted after claim TTL (stale claim check)
               Task stuck with released claim but not notified to group
```

---

## ST-305 — AllOf Requires 5 Approvers, One Is Inactive

```
SCENARIO:     allOf task with 5 targets; target-user-3 is deactivated mid-task
SETUP:        taskId=T4, assigneePolicy={ type:allOf, targets:[U1,U2,U3,U4,U5] }
              U1, U2, U4, U5 answer. U3 deactivated before answering.
EXPECTED:     - Gate remains open after 4/5 answers (CF-530)
              - Admin alert: "User U3 deactivated, allOf requires resolution"
              - Admin removes U3 from targets (F1078 re-evaluation)
              - Re-evaluation: 4/4 answered → gate closes
              - Audit trail includes U3 removal event
FAILURE MODES: Gate never closes (stuck at 4/5 forever)
               Gate closes with 4/5 without admin action (bypassing allOf rule)
```

---

## ST-306 — Non-Blocking Branch Gate Answered After Child Completed

```
SCENARIO:     optional HIG gate on Branch B; Branch A + B complete; gate answered late
SETUP:        human-gate-2 on optional branch, blockingPolicy=optional
              Branch A completes at t=0; Branch B (non-gate nodes) completes at t=1
              Join gate (allSettled) fires at t=1; run completes at t=2
              User answers human-gate-2 at t=3 (after run completed)
EXPECTED:     - Run SUCCEEDED at t=2 (optional gate does not prevent completion — CF-520 only for required)
              - Late answer at t=3: gate status already=expired or skipped; answer rejected (CF-523)
              - Run status unchanged (still SUCCEEDED)
FAILURE MODES: Late answer re-opens completed run
               Run blocked at completion because of optional gate (violates CF-519)
```

---

## ST-307 — SubFlow Parent Cancelled While Child Running

```
SCENARIO:     Parent run cancelled; child SubFlow run is actively RUNNING
SETUP:        parentRunId=R1, SubFlow node launches childRunId=R2
              R2 nodes are 50% complete when R1 is cancelled
EXPECTED:     - F1094.CancelRunAsync(tenantId, "R1") emits RunCancelled
              - Orchestrator propagates cancellation to childRunId R2
              - R2: CancelRunAsync called, all running nodes get NodeCancelled event
              - NodeSnapshot for SubFlow node in R1: status=CANCELLED
              - No further events emitted for R2 after cancellation
FAILURE MODES: Child run continues running after parent cancelled (resource waste)
               Child run status doesn't reflect in parent SubFlow node snapshot
```

---

## ST-308 — Node Snapshot Stale When Answer Arrives

```
SCENARIO:     High-throughput scenario; 50 events/sec; snapshot may lag event stream
SETUP:        runId=R3, 200 nodes; NodeStateProjector (T394) processing events
              human-gate-X answered at t=0; snapshot updatedAt still shows t=-5s
              DependencyScheduler reads snapshot at t=0.1s
EXPECTED:     - DependencyScheduler reads snapshot from ES with consistency (not from cache)
              - If snapshot stale: re-read from source (ES) before READY evaluation
              - No READY evaluation based on stale WAITING_FOR_USER status
              - Eventual consistency within 1s (CF-514)
FAILURE MODES: READY evaluation uses stale snapshot → node incorrectly stays BLOCKED
               Or node incorrectly becomes READY before answer recorded
```

---

## ST-309 — 10,000 Pending UserTasks In One Tenant

```
SCENARIO:     Large enterprise tenant with high-volume flow; 10,000 simultaneous open gates
SETUP:        tenantId=enterprise-1; 10,000 UserTask documents in ES; bulk operations
EXPECTED:     - ListUserTasksAsync with status=waiting_for_user: paginates correctly
              - ES query uses tenantId+status composite index (no full scan)
              - CountOpenRequiredGatesAsync returns within 200ms
              - No cross-tenant bleed (CF-510)
              - Notification dedup cache (Redis) handles 10,000 keys per tenant without eviction
FAILURE MODES: ES query times out on large tenant (missing composite index)
               Notification storm: 10,000 tasks × N channels = millions of sends
```

---

## ST-310 — Group Dissolved After Task Assigned

```
SCENARIO:     Task assigned to group "security-reviewers"; group deleted mid-task
SETUP:        taskId=T5, assigneePolicy={ type:group, targets:["security-reviewers"] }
              Group exists at t=0; group deleted at t=30s; no answers yet
EXPECTED:     - F1097.GetMembersAsync returns empty list after deletion
              - F1098 notification dedup: pending notifications for deleted group members = cleanup
              - UserTask status: waiting_for_user (NOT auto-closed; requires admin intervention)
              - Admin alert: "Assigned group dissolved; task has no eligible answerers"
              - Run: PendingUserInput status, not stuck silently
FAILURE MODES: Task silently never answered (group gone, no alert)
               Task auto-closed without answer because group is empty (violates gate semantics)
```

---

## ST-311 — DAG Cycle Introduced Via Bad Flow Definition

```
SCENARIO:     Flow definition with cycle: nodeA waitFor=[nodeC], nodeC waitFor=[nodeA]
SETUP:        POST /flows (tenantId, invalid-dag with cycle)
EXPECTED:     - F1091.HasCycleAsync detects cycle at load time
              - Flow version not published; DataProcessResult.Failure with cycle path
              - "Cycle detected: nodeA → nodeC → nodeA" in error detail
              - No run can be started with this flow version
FAILURE MODES: Cycle not detected; run starts; all nodes BLOCKED forever (CF-527)
```

---

## ST-312 — Run Completed But 1 Optional Gate Still Open

```
SCENARIO:     flow with optional HIG gate; all required paths done; optional gate still open
SETUP:        human-gate-optional: blockingPolicy=optional, dueAt=future
              All required terminal nodes: SUCCEEDED; 0 required open tasks
              human-gate-optional: still waiting_for_user
EXPECTED:     - CompletionGate evaluates: required nodes SUCCEEDED ✓, required open tasks=0 ✓
              - Optional gate does NOT prevent READY declaration (CF-520 only required)
              - Run marked SUCCEEDED
              - human-gate-optional: auto-expired on run completion (F1075.CancelGateAsync)
              - UI: run shows SUCCEEDED; optional gate shows CANCELLED
FAILURE MODES: Optional gate prevents run from reaching SUCCEEDED (confusion between required/optional)
```

---

## ST-313 — Notification Sent To Deleted User Account

```
SCENARIO:     UserTask notification in flight; target user account deleted before delivery
SETUP:        taskId=T6, recipient=user-456; notification queued at t=0
              user-456 deleted at t=1s; notification delivery attempted at t=2s
EXPECTED:     - INotificationProvider (F68) returns "user not found" or delivery failure
              - F1096: records delivery failure; does NOT retry to same recipient
              - Dedup cache: MarkSentAsync still called (prevents future retries for deleted user)
              - Other group recipients: unaffected, receive notifications normally
              - No exception propagation; DataProcessResult handles gracefully (DNA-3)
FAILURE MODES: Notification retry loop for deleted user (infinite retries)
               Exception breaks notification fan-out for all recipients
```

---

## ST-314 — Quorum needed=3 But Only 2 Group Members Exist

```
SCENARIO:     Task created with quorum.needed=3 but group has only 2 members
SETUP:        assigneePolicy={ type:quorum, needed:3, outOf:5 }
              At task creation time: group has 2 active members
EXPECTED:     - F1080: quorum.needed > group.size at assignment time = IMMEDIATE FAILURE
              - Error: "Quorum needed (3) exceeds eligible users (2)"
              - Gate NOT opened; UserTask NOT created
              - Flow run transitions to FailedNeedsRepair
              - Admin notified with explanation (IR-F1080-2)
FAILURE MODES: Gate opens knowing quorum can never be reached; run stuck forever
```

---

## ST-315 — CompletionGate Fires While Required Node Still RUNNING

```
SCENARIO:     Orchestrator erroneously fires CompletionGate before all nodes complete
SETUP:        required terminal node "final-validation": status=RUNNING
              CompletionGate triggered prematurely
EXPECTED:     - F1093.AllTerminalNodesSucceededAsync: returns false
              - CompletionGate: EvaluateCompletionAsync returns { ready: false }
              - MarkRunReadyAsync NOT called (CF-528)
              - Run status stays RUNNING (not SUCCEEDED)
              - Orchestrator logs warning: premature completion gate trigger
FAILURE MODES: Run marked SUCCEEDED while final validation still running
               Subsequent node failure on still-running node goes unrecorded
```

---

## ST-316 — NodeSnapshot Concurrent Update Race

```
SCENARIO:     NodeProgress event AND UserTaskAnswered event arrive simultaneously
              for the same nodeId/runId; concurrent upsert to node-snapshots
SETUP:        nodeId=process-X, runId=R4; simultaneous events at t=0
              Event-1: NodeProgress { progress: 0.7 }
              Event-2: UserTaskAnswered { taskId: X, unblocks: [process-X] }
EXPECTED:     - ES optimistic concurrency control prevents lost update
              - Final NodeSnapshot reflects latest consistent state
              - If conflict: retry with exponential backoff (DNA-3, no throw)
              - NodeStateProjector (T394) handles out-of-order via version check
FAILURE MODES: One event overwrites the other; snapshot shows contradictory state
```

---

## ST-317 — Cross-Tenant Group Referenced In Task Assignment

```
SCENARIO:     Malicious or misconfigured assigneePolicy references group from another tenant
SETUP:        taskId=T7, tenantId=tenant-A
              assigneePolicy={ type:group, targets:["tenant-B:admin-group"] }
EXPECTED:     - F1078.ResolveEligibleUsersAsync: tenantId filter applied to ALL group lookups
              - Cross-tenant group "tenant-B:admin-group" returns 0 members (not cross-tenant leak)
              - Task NOT created (0 eligible users = IMMEDIATE FAILURE per IR-F1080-2 equivalent)
              - Error logged: "cross-tenant group reference rejected"
              - BUILD FAILURE if cross-tenant reference detected at flow validation (IR-T390-2)
FAILURE MODES: Cross-tenant group resolves; tenant-B users receive task from tenant-A
```

---

## ST-318 — HIG Node Skipped Due To Conditional Branch — Downstream Unblocked?

```
SCENARIO:     HIG node is on a conditional branch that is SKIPPED; downstream nodes
              have waitFor=[hig-node]; should downstream be unblocked?
SETUP:        human-gate-conditional: entry condition = false → SKIPPED
              post-hig-node: waitFor=[human-gate-conditional], not itself conditional
EXPECTED:     - human-gate-conditional: status=SKIPPED
              - DependencyScheduler re-evaluates post-hig-node
              - F1090.EvaluateJoinAsync: SKIPPED node with join policy "skip_without_error" = satisfied
              - post-hig-node: becomes READY
              - No UserTask created for SKIPPED gate (F1075 never called)
FAILURE MODES: post-hig-node stays BLOCKED because SKIPPED ≠ SUCCEEDED in readiness check
               Downstream incorrectly treated as if gate was answered
```

---

## ST-319 — Progress API Called During Node State Transition

```
SCENARIO:     GET /runs/{runId}/graph called while NodeStateProjector is mid-update
SETUP:        runId=R5; NodeStateProjector writing NodeSnapshot for node-Y (status RUNNING→SUCCEEDED)
              UI calls graph API at t=0 (mid-write)
EXPECTED:     - ES read: consistent read (seqNo/primaryTerm from ES ensures consistent snapshot)
              - If node-Y shows RUNNING: UI refreshes within 5s to show SUCCEEDED
              - Progress API returns valid (non-corrupted) snapshot even if slightly stale
              - No partial writes visible (atomic ES document upsert)
FAILURE MODES: Node shows both RUNNING and SUCCEEDED simultaneously (impossible but test verifies)
               Progress % > 100% due to partial write
```

---

## ST-320 — Run READY Declared Before JudgeService Verdict

```
SCENARIO:     CompletionGate fires; AF-9 JudgeService verdict not yet returned
              for required phase gate
SETUP:        requiredJudgeGates=[phase-gate-final], verdict=PENDING at CompletionGate evaluation
EXPECTED:     - F1093.AllJudgeGatesApprovedAsync: returns false (verdict PENDING)
              - CompletionGate: { ready: false, blocking: [{ type: judgeGatePending, gateId: phase-gate-final }] }
              - Run status: BlockedOnDependency (waiting for AF-9)
              - Once AF-9 returns Approved: JudgeGateApproved event → CompletionGate re-evaluates
              - Run marked READY after all 3 conditions satisfied
FAILURE MODES: Run marked READY before AF-9 approves — skips quality gate entirely (IR-T393-3)
```
