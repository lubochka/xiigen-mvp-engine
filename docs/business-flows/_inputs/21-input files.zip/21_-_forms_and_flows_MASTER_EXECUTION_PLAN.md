# MASTER EXECUTION PLAN — FLOW-15: Forms & Flow Automation Builder
## Extends MASTER_EXECUTION_PLAN_MERGED.md
## Backward Compatible: All prior flow execution plans UNCHANGED
## Save Point: FLOW15:P7:MASTER_EXEC ✅

---

## FLOW-15 OVERVIEW

```
DOMAIN:       Forms authoring + submission pipeline + automation recipes + connectors
SPEC SOURCE:  21_-_forms_and_flows.md (architecture overview)
              21_-_forms_and_flows_deep_search.md (submission pipeline patterns)
              21_-_forms_and_flows_deep_search_engine.md (engine design)
              21_-_forms_and_flows_deep_search_engine_multi_tenant.md (MT model)

STARTING IDs:
  Factories:    F466  (Families 60–68)
  Task Types:   T179
  Templates:    36
  BFA Rules:    CF-214
  Stress Tests: ST-104
  Skills:       SK-99
  Design Decs:  DD-86
  Design Recs:  DR-66

FINAL IDs (FLOW-15):
  Factories:    F514  (49 new, Families 60–68, 9 new families)
  Task Types:   T198  (20 new, 4 new archetypes)
  Templates:    38    (3 new: 36, 37, 38)
  BFA Rules:    CF-235 (22 new)
  Stress Tests: ST-115 (12 new)
  Skills:       SK-110 (12 new)
  Design Decs:  DD-97  (12 new)
  Design Recs:  DR-75  (10 new)
```

---

## PLAN VALIDATION MATRIX (Phase 0)

| Spec Requirement | Engine Coverage | Status |
|-----------------|----------------|--------|
| Form schema authoring (drag/drop fields, conditional logic) | F466, F468, T179 | ✅ |
| Multi-step wizard support | SK-107, F476 wizard state | ✅ |
| Submission pipeline (intake→validate→antispam→persist) | F478–F482, T180–T183 | ✅ |
| Entry storage + lifecycle management | F485, F491, T184 | ✅ |
| Notification engine (email/SMS/push with merge tags) | F492–F495, T186 | ✅ |
| Integration feeds (CRM, mailing list, webhook) | F497–F503, T187–T188 | ✅ |
| Payment states + triggers | F503, T189, CF-223 | ✅ |
| File uploads with security scanning | F487–F491, T196, SK-106 | ✅ |
| Save & continue (partial entries) | F484, F485, T185 | ✅ |
| Automation recipe builder | F504–F509, T190–T192 | ✅ |
| Recipe execution + retry + replay | F507–F509, T193, SK-102 | ✅ |
| Connector SDK (OAuth, CRM, Slack, etc.) | F510–F513, T194–T195 | ✅ |
| Multi-tenant isolation | F514, T198, SK-110 | ✅ |
| Fabric-first UI (zero platform-specific values) | F471, SK-107 | ✅ |
| AI-assisted form authoring | F474, T179 AF-1, DD-97 | ✅ |
| Backward compatibility F1-F465, T1-T178 | All pre-existing IDs unchanged | ✅ |

---

## POSITIVE EXAMPLE (expected correct output)

```csharp
// ✅ CORRECT — FLOW-15 service: F482 IEntryPersistenceService
// - Extends MicroserviceBase (DNA-4)
// - Uses Dictionary only (DNA-1)
// - Returns DataProcessResult<T> (DNA-3)
// - tenantId on every write (DNA-5)
// - Goes through DATABASE FABRIC, never direct ES client (Fabric law)
// - Emits event AFTER persist (INV-15-1 / DR-66)

public class EntryPersistenceService : MicroserviceBase, IEntryPersistenceService
{
    public async Task<DataProcessResult<string>> PersistEntryAsync(
        Dictionary<string, object> payload,
        string tenantId,
        string formId)
    {
        // DNA-1: Dictionary only, no typed Entry class
        var document = _objectProcessor.ProcessDocument(payload);
        document["tenantId"] = tenantId;              // DNA-5
        document["formId"]   = formId;
        document["entryId"]  = Ulid.NewUlid().ToString();
        document["persistedAt"] = DateTimeOffset.UtcNow.ToString("O");
        document["status"]   = "active";

        // DNA-2: BuildSearchFilter skips empty fields automatically
        var filter = _objectProcessor.BuildSearchFilter(new Dictionary<string, object>
        {
            ["tenantId"] = tenantId,
            ["formId"]   = formId
        });

        // Fabric: DATABASE FABRIC, never new ElasticsearchClient()
        var result = await _database.StoreDocument("entries", document);

        if (!result.IsSuccess)
            // DNA-3: return DataProcessResult, never throw
            return DataProcessResult<string>.Failure(result.Error);

        // INV-15-1: Emit AFTER persist — never before
        await _queue.EnqueueAsync("entry.persisted", new Dictionary<string, object>
        {
            ["entryId"]  = document["entryId"],
            ["tenantId"] = tenantId,
            ["formId"]   = formId
        });

        return DataProcessResult<string>.Success(document["entryId"].ToString());
    }
}
```

---

## NEGATIVE EXAMPLE (violations = BUILD FAILURE)

```csharp
// ❌ VIOLATION 1: Typed model (DNA-1 violation)
public class EntryPersistenceService
{
    public async Task<Entry> PersistEntry(EntrySubmission submission) // FAIL: typed models
    { ... }
}

// ❌ VIOLATION 2: Direct ES SDK (Fabric violation)
var client = new ElasticsearchClient(settings);          // FAIL: direct provider import
await client.IndexAsync(entry, "entries");

// ❌ VIOLATION 3: Emit before persist (CF-220 / DR-66 / INV-15-1 violation)
await _eventPublisher.Publish(submissionEvent);          // FAIL: event before persistence
await _entryRepo.Save(entry);                           // FAIL: persist after emit

// ❌ VIOLATION 4: Missing tenantId (DNA-5 violation)
var result = await _database.StoreDocument("entries", payload); // FAIL: no tenantId

// ❌ VIOLATION 5: throw instead of DataProcessResult (DNA-3 violation)
throw new ValidationException("Form not found");         // FAIL: never throw for business logic

// ❌ VIOLATION 6: Direct AI call without fabric (DD-97 violation)
var openai = new OpenAIClient(apiKey);                   // FAIL: direct provider import
var schema = await openai.GetChatCompletions(...);
```

---

## EXECUTION PHASES

---

### Phase 0: Plan & Validation ✅
**Duration:** 15–30 minutes
**Goal:** Confirm FLOW-15 scope covers all spec requirements from 21_-_forms_and_flows*.md
**Output:** Plan validation matrix (above)

SAVE POINT: FLOW15:P0:PLAN ✅

---

### Phase 1: Engine Architecture (Factories F466–F514 + Design Records DR-66–DR-75)
**Duration:** 30–45 minutes
**Goal:** Define all 49 factory interfaces across 9 families + 10 design records
**Output file:** 21_-_forms_and_flows_ENGINE_ARCHITECTURE.md ✅

SCOPE:
- Family 60: Form Schema & Authoring (F466-F473)
- Family 61: Form Runtime Engine (F474-F477)
- Family 62: Submission Pipeline (F478-F484)
- Family 63: Entry Lifecycle & Storage (F485-F491)
- Family 64: Notification Engine (F492-F496)
- Family 65: Integration Feeds (F497-F503)
- Family 66: Automation Recipe Engine (F504-F509)
- Family 67: Connector SDK (F510-F513)
- Family 68: Forms Multi-Tenant Isolation (F514)
- Design Records: DR-66 through DR-75

KEY DECISIONS MADE:
- DR-66: Persist-Before-Emit (INV-15-1)
- DR-67: Anti-Spam as Fabric Gate
- DR-68: Conditional Logic as ES Document
- DR-69: Merge Tags as Runtime Resolver (AI-assisted)
- DR-70: Feed Execution Idempotent via Redis Key
- DR-71: Recipe DAG stored in ES (Skill 09 pattern reuse)
- DR-72: Connector OAuth Tokens in PG Encrypted Only
- DR-73: File Virus Scan Before Signed URL Generation
- DR-74: Partial Entry Preserved in Redis with TTL → PG
- DR-75: Forms Tenant Isolation Inherits FLOW-08 + FLOW-14 MT Models

RECOVERY COMMAND:
  "Resume FLOW-15 P1: Load SESSION_STATE. Generate F466–F514.
   Start at Family 60 (Form Schema)."

SAVE POINT: FLOW15:P1:FACTORIES ✅

---

### Phase 2: Task Types Catalog (T179–T198 + Templates 36–38)
**Duration:** 45–60 minutes
**Goal:** 20 full engine contracts in exact T40 format + 3 flow templates
**Output file:** 21_-_forms_and_flows_TASK_TYPES_CATALOG.md ✅

TASK TYPES DEFINED:
```
T179  Form Schema Authoring Gate        AUTHORING   (new archetype)
T180  Submission Intake Gate            INGESTION
T181  Field Normalization Step          TRANSFORM
T182  Submission Validation Gate        VALIDATION
T183  Anti-Spam Security Gate           VALIDATION
T184  Entry Persistence Gate            PERSISTENCE (new archetype)
T185  Partial Entry Save Gate           PERSISTENCE
T186  Notification Dispatch Gate        NOTIFICATION (new archetype)
T187  Integration Feed Execution Gate   FEED_EXECUTION (new archetype)
T188  Webhook Feed Dispatch Gate        FEED_EXECUTION
T189  Payment Feed Processing Gate      ORCHESTRATION
T190  Recipe Definition Gate            AUTHORING
T191  Recipe Trigger Evaluation Gate    ORCHESTRATION
T192  Recipe Step Execution Gate        ORCHESTRATION
T193  Recipe Retry Gate                 DURABLE_SAGA
T194  Connector Auth Gate               PROVISIONING
T195  Data Mapping Transform Gate       TRANSFORM
T196  File Upload Security Gate         VALIDATION
T197  Entry Export Gate                 ACTIVATION
T198  Form Tenant Provision Gate        PROVISIONING
```

TEMPLATES:
```
Template 36: form-submission-pipeline-v1  (T179→T180→T181→T182→T183→T184→T186→T187)
Template 37: recipe-execution-v1          (T190→T191→T192→T193)
Template 38: connector-auth-integration-v1 (T194→T195→T188)
```

FIRST-TIME ARCHETYPES:
- AUTHORING: T179, T190 — form/recipe schema creation with AI assist + versioning
- PERSISTENCE: T184, T185 — entry save with dedup, idempotency, Redis→PG two-phase
- NOTIFICATION: T186 — multi-channel dispatch with merge tag resolution + routing
- FEED_EXECUTION: T187, T188 — integration feed: condition check → map → push → idempotency

RECOVERY COMMAND:
  "Resume FLOW-15 P2: T179-T198 task types. Start at T179.
   Follow T40 engine contract format exactly."

SAVE POINT: FLOW15:P2:TASK_TYPES ✅

---

### Phase 3: BFA Conflict Rules (CF-214–CF-235) + Stress Tests (ST-104–ST-115)
**Duration:** 30–40 minutes
**Goal:** 22 BFA rules + 12 stress tests covering forms-specific conflicts
**Output file:** 21_-_forms_and_flows_V62_BFA_STRESS_TEST.md ✅

BFA RULE GROUPS:
```
CF-214-CF-217: Forms Internal (4 rules)
  CF-214: schema must be published before submission accepted
  CF-215: validation rules loaded before anti-spam gate
  CF-216: anti-spam gate before persistence (INV-15-2)
  CF-217: wizard state isolated per session + tenantId

CF-218-CF-221: Submission Pipeline (4 rules)
  CF-218: intake dedup key prevents double-processing
  CF-219: validate before persist (no skipping stages)
  CF-220: emit AFTER persist only (INV-15-1)
  CF-221: no partial entry progresses to feed execution

CF-222-CF-225: Feeds & Notifications (4 rules)
  CF-222: feed executes after notification dispatch
  CF-223: payment feed is last in fan-out chain
  CF-224: webhook retry must carry idempotency key
  CF-225: CRM feed must check for duplicate contact before create

CF-226-CF-228: Recipe Engine (3 rules)
  CF-226: trigger evaluation before step execution
  CF-227: retry only via DLQ (never inline re-execute)
  CF-228: each recipe step atomic (no partial completion)

CF-229-CF-231: Connector Safety (3 rules)
  CF-229: OAuth tokens stored in PG encrypted only (DD-93)
  CF-230: data mapping executed before any outbound push
  CF-231: run history immutable (no updates, only appends)

CF-232-CF-234: MT Forms Isolation (3 rules)
  CF-232: all schema queries include tenantId filter
  CF-233: entry reads require PG RLS policy active
  CF-234: connector credentials never cross tenant boundary

CF-235: Cross-Flow (1 rule)
  CF-235: forms entries never write to DWH raw zone directly
          (must go through FLOW-14 ingestion pipeline)
```

STRESS TESTS:
```
ST-104: Form schema publish under concurrent edit (race condition)
ST-105: 10k simultaneous submissions (intake dedup + queue backpressure)
ST-106: Anti-spam false positive under load
ST-107: Partial entry TTL expiry during active session
ST-108: Notification routing fan-out (1 submission → 50 recipients)
ST-109: CRM feed duplicate detection (same entry replayed 3x)
ST-110: Webhook retry storm (DLQ overflow scenario)
ST-111: Recipe chain 20+ steps (executor timeout / saga rollback)
ST-112: OAuth token refresh race (2 threads, 1 expiry window)
ST-113: File upload virus scan queue saturation
ST-114: Cross-tenant form schema leak attempt
ST-115: Recipe idempotency key collision under UUID-v4 birthday paradox
```

RECOVERY COMMAND:
  "Resume FLOW-15 P3: BFA rules CF-214+. Generate conflict rules then stress tests."

SAVE POINT: FLOW15:P3:BFA ✅

---

### Phase 4: Skills Factory RAG (SK-99–SK-110)
**Duration:** 25–35 minutes
**Goal:** 12 reusable skill patterns for AF-4 RAG retrieval
**Output file:** 21_-_forms_and_flows_SKILLS_FACTORY_RAG.md ✅

SKILLS DEFINED:
```
SK-99:  Form Schema DAG validation pattern
SK-100: Submission pipeline stage-gate pattern (intake→validate→persist)
SK-101: Merge-tag resolver with AI fallback
SK-102: Feed executor idempotency (Redis key + PG log)
SK-103: Recipe DAG execution (adapts Skill 09 Flow Orchestrator)
SK-104: Connector OAuth PKCE flow via Core Fabric
SK-105: Anti-spam composite gate (honeypot + reCAPTCHA + AI scoring)
SK-106: File upload secure pipeline (upload→scan→sign→store)
SK-107: Fabric-first UI spec (render spec in ES, zero platform values)
SK-108: Partial entry save-and-continue (Redis TTL → PG promotion)
SK-109: Conditional logic evaluator (ES rule doc → runtime evaluation)
SK-110: Multi-tenant forms isolation (schema + entry + connector scope)
```

AF-4 RAG TRIGGER PATTERNS:
- "form schema", "field validation" → SK-99
- "submission", "pipeline", "stage gate" → SK-100
- "merge tags", "notifications", "templates" → SK-101
- "feed", "idempotent", "integration" → SK-102
- "recipe", "automation", "DAG" → SK-103
- "OAuth", "connector", "auth" → SK-104
- "spam", "security gate", "captcha" → SK-105
- "file upload", "virus scan" → SK-106
- "UI spec", "fabric-first", "render" → SK-107
- "partial entry", "save continue", "wizard" → SK-108
- "conditional", "show/hide", "logic rules" → SK-109
- "multi-tenant", "forms isolation" → SK-110

RECOVERY COMMAND:
  "Resume FLOW-15 P4: Skills SK-99–SK-110. Generate each in SK standard format."

SAVE POINT: FLOW15:P4:SKILLS ✅

---

### Phase 5: Unified Source Index (DD-86–DD-97 + Concept Maps)
**Duration:** 25–35 minutes
**Goal:** 12 design decisions + 5 concept maps
**Output file:** 21_-_forms_and_flows_UNIFIED_SOURCE_INDEX.md ✅

DESIGN DECISIONS:
  DD-86: Why FormSchema in ES (not PG)
  DD-87: Why submission pipeline uses stage-gate queue pattern
  DD-88: Why anti-spam is a fabric service (not middleware)
  DD-89: Why partial entries use Redis→PG two-phase store
  DD-90: Why notification templates use merge tags + AI resolver
  DD-91: Why feed execution is idempotent-first
  DD-92: Why recipe DAG is an ES document
  DD-93: Why connector OAuth tokens are PG-only
  DD-94: Why file scan is a QUEUE FABRIC step (not inline)
  DD-95: Why conditional logic is an ES rule document
  DD-96: Why forms MT isolation inherits FLOW-08 model
  DD-97: Why AI-assisted form authoring goes through AI ENGINE FABRIC

CONCEPT MAPS:
  Map 1: Forms Platform Architecture (full stack view)
  Map 2: Automation Recipe Engine (trigger→execute→history)
  Map 3: Connector SDK & OAuth Flow
  Map 4: Submission Pipeline Stage Gates (detailed)
  Map 5: Multi-Tenant Forms Isolation

RECOVERY COMMAND:
  "Resume FLOW-15 P5: Design decisions DD-86+. Then concept maps."

SAVE POINT: FLOW15:P5:UNIFIED_INDEX ✅

---

### Phase 6: Session State (Global Tracker Update)
**Duration:** 15 minutes
**Goal:** Update global tracker with FLOW-15 delta, backward compat check, starting IDs for FLOW-16
**Output file:** 21_-_forms_and_flows_SESSION_STATE.md ✅

DELTA RECORDED:
  Factories: 465 → 514 (+49)
  Task Types: 178 → 198 (+20)
  Templates: 35 → 38 (+3)
  BFA Rules: 213 → 235 (+22)
  Stress Tests: 103 → 115 (+12)
  Skills: 98 → 110 (+12)
  DDs: 85 → 97 (+12)
  DRs: 65 → 75 (+10)

BACKWARD COMPAT: F1-F465 UNCHANGED ✅ | T1-T178 UNCHANGED ✅ | DNA-1-9 STABLE ✅

NEXT FLOW STARTS: F515 | T199 | CF-236 | ST-116 | SK-111 | DD-98 | DR-76 | Template 39 | Family 69

RECOVERY COMMAND:
  "Resume FLOW-15 P6: Generate SESSION_STATE.
   Record delta, backward compat, FLOW-16 starting IDs."

SAVE POINT: FLOW15:P6:SESSION_STATE ✅

---

### Phase 7: Master Execution Plan (This File)
**Duration:** 15 minutes
**Goal:** Compile all phases into single execution plan with recovery commands
**Output file:** 21_-_forms_and_flows_MASTER_EXECUTION_PLAN.md ✅

SAVE POINT: FLOW15:P7:MASTER_EXEC ✅

---

## COMPLETE FILE REGISTRY — FLOW-15

| # | File | Content | Save Point |
|---|------|---------|-----------|
| 1 | 21_-_forms_and_flows_ENGINE_ARCHITECTURE.md | F466-F514, Families 60-68, DR-66-DR-75 | P1 ✅ |
| 2 | 21_-_forms_and_flows_TASK_TYPES_CATALOG.md | T179-T198, Templates 36-38, AF maps | P2 ✅ |
| 3 | 21_-_forms_and_flows_V62_BFA_STRESS_TEST.md | CF-214-CF-235, ST-104-ST-115 | P3 ✅ |
| 4 | 21_-_forms_and_flows_SKILLS_FACTORY_RAG.md | SK-99-SK-110, AF-4 RAG patterns | P4 ✅ |
| 5 | 21_-_forms_and_flows_UNIFIED_SOURCE_INDEX.md | DD-86-DD-97, 5 concept maps | P5 ✅ |
| 6 | 21_-_forms_and_flows_MASTER_EXECUTION_PLAN.md | All phases + recovery (this file) | P7 ✅ |
| 7 | 21_-_forms_and_flows_SESSION_STATE.md | Global state tracker, FLOW-16 start | P6 ✅ |

---

## MASTER RECOVERY COMMANDS

```
Load FLOW-15 state:
  "Load 21_-_forms_and_flows_SESSION_STATE.md — engine at F514/T198/CF-235"

Start FLOW-16:
  "Start FLOW-16 from F515, T199, CF-236 — load 21_-_forms_and_flows_SESSION_STATE"

Review submission pipeline:
  "Load 21_-_forms_and_flows_ENGINE_ARCHITECTURE.md Family 62 + SK-100 + CF-218-CF-221"

Review recipe engine:
  "Load 21_-_forms_and_flows_ENGINE_ARCHITECTURE.md Family 66 + SK-103 + CF-226-CF-228"

Review connector SDK:
  "Load 21_-_forms_and_flows_ENGINE_ARCHITECTURE.md Family 67 + SK-104 + CF-229-CF-231"

Review MT forms isolation:
  "Load F514 + SK-110 + CF-232-CF-234 + DR-75 for multi-tenant forms model"

Reload skills for AF-4:
  "Load SK-99–SK-110 from 21_-_forms_and_flows_SKILLS_FACTORY_RAG.md"

Check all BFA rules:
  "Load CF-214–CF-235 from 21_-_forms_and_flows_V62_BFA_STRESS_TEST.md"

Run full validation:
  "Run FLOW-15 validation matrix from 21_-_forms_and_flows_MASTER_EXECUTION_PLAN.md Phase 0"

Merge FLOW-15 into canonical 7:
  "Merge all 21_-_forms_and_flows_* files into FLOW-14 canonical merged files"
```

---

## KEY INVARIANTS (Quick Reference)

| ID | Rule | Enforcement |
|----|------|-------------|
| INV-15-1 | Persist BEFORE emit — always | DR-66, CF-220 |
| INV-15-2 | Anti-spam BEFORE persist — never after | DR-67, CF-216 |
| INV-15-3 | Conditional logic = ES doc, never code | DR-68, DNA-1 |
| INV-15-4 | Feed execution idempotent via Redis key | DR-70, CF-222 |
| INV-15-5 | OAuth tokens = PG encrypted only | DR-72, CF-229 |
| INV-15-6 | File virus scan before signed URL | DR-73 |
| INV-15-7 | Partial entry Redis TTL ≤ 48h, then promote/expire | DR-74 |
| INV-15-8 | Recipe DAG = ES document (Skill 09 pattern) | DR-71, SK-103 |
| INV-15-9 | All form queries include tenantId (DNA-5) | DNA-5, CF-232 |
| INV-15-10 | Connector credentials never cross tenant | CF-234, F511 |

---

## SAVE POINT: FLOW15:COMPLETE ✅
## All 7 files generated. Ready for FLOW-16.
## Resume: "Continue from FLOW-16" → Load 21_-_forms_and_flows_SESSION_STATE.md + basic_prompt.txt
