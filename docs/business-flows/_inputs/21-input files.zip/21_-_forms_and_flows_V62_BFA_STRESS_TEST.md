# BFA STRESS TEST — FLOW-15: Forms & Flow Automation Builder
## Extends V62_BFA_STRESS_TEST_MERGED.md
## Backward Compatible: CF-1-CF-213, ST-1-ST-103 UNCHANGED
## Save Point: FLOW15:P5:BFA ✅

---

## OVERVIEW

```
NEW BFA RULES:   CF-214-CF-235 (22 rules)
NEW STRESS TESTS: ST-104-ST-115 (12 tests)
DOMAIN:          Forms authoring + submission pipeline + automation + connectors
```

---

## BUSINESS FLOW ARBITER (BFA) — CONFLICT RULES CF-214 to CF-235

### GROUP A — Forms Internal Ordering (CF-214–CF-217)

#### CF-214 — Schema Version Before Publish Event
```
RULE ID:    CF-214
CATEGORY:   Forms Internal
TRIGGER:    IFormPublishService.PublishForm() called
CONFLICT:   FORM_PUBLISHED event emitted before version snapshot created
RESOLUTION: F469.CreateVersion() must complete before F470.PublishForm() event emission
RATIONALE:  Version history must be consistent before downstream systems receive
            the published event. Otherwise renders may use outdated schema.
ENFORCED BY: AF-7, IR-179-3
TASK TYPES: T179
```

#### CF-215 — Render Spec Invalidated on Every Publish
```
RULE ID:    CF-215
CATEGORY:   Forms Internal
TRIGGER:    FORM_PUBLISHED event consumed
CONFLICT:   Stale render spec served after schema publish
RESOLUTION: F471.GenerateRenderSpec() called synchronously after FORM_PUBLISHED received
RATIONALE:  Clients must never serve outdated render specs — field config changes
            must be reflected immediately.
ENFORCED BY: AF-7, QG-179-2
TASK TYPES: T179
```

#### CF-216 — Anti-Spam Before Persist
```
RULE ID:    CF-216
CATEGORY:   Forms Internal — submission pipeline ordering
TRIGGER:    Submission pipeline step sequencing
CONFLICT:   F482.PersistEntry() called before F481.CheckSpam() clears
RESOLUTION: T183 (Anti-Spam Gate) must precede T184 (Entry Persistence Gate)
            in all generated flow templates
RATIONALE:  DR-67 — spam entries must never reach ES/PG storage.
            Inline spam check in persist service = DNA violation (pipeline collapse).
ENFORCED BY: AF-7, DR-67, IR-183-1, Template-36 step ordering
TASK TYPES: T183, T184
```

#### CF-217 — Wizard Session Isolated Per Tenant
```
RULE ID:    CF-217
CATEGORY:   Forms Internal — MT isolation
TRIGGER:    IMultiStepWizardService.AdvanceStep() or GetCurrentStep()
CONFLICT:   Wizard session state readable by different tenant
RESOLUTION: F476 Redis key must be namespaced: {tenantId}:wizard:{sessionId}
RATIONALE:  Multi-step form state may contain sensitive field values.
            Cross-tenant session read = data breach.
ENFORCED BY: DNA-5, IR-179-8, F514 (IFormTenantIsolationService)
TASK TYPES: T179, T185
```

---

### GROUP B — Submission Pipeline Ordering (CF-218–CF-221)

#### CF-218 — Intake Deduplication Before Queue Enqueue
```
RULE ID:    CF-218
CATEGORY:   Submission Pipeline
TRIGGER:    ISubmissionIntakeService.IntakeSubmission() called
CONFLICT:   Duplicate submission enqueued without dedup check
RESOLUTION: F478.CheckDuplicate() must be called and return false before EnqueueAsync()
RATIONALE:  QUEUE FABRIC at-least-once delivery + client retries can produce
            duplicate intake events. Dedup at intake is the primary guard.
ENFORCED BY: IR-180-2, SK-100 (stage-gate pattern)
TASK TYPES: T180
```

#### CF-219 — Validation Before Persistence
```
RULE ID:    CF-219
CATEGORY:   Submission Pipeline
TRIGGER:    Entry persistence attempt
CONFLICT:   F482.PersistEntry() called before F480.ValidateSubmission() completes
RESOLUTION: T182 (Validation Gate) precedes T184 (Persistence Gate) — enforced by Template-36
RATIONALE:  Invalid entries must never reach the ES store. Downstream consumers
            (notifications, feeds) assume valid data — corrupt data = cascade failures.
ENFORCED BY: Template-36 step ordering, IR-182-1
TASK TYPES: T182, T184
```

#### CF-220 — Emit After Persist
```
RULE ID:    CF-220
CATEGORY:   Submission Pipeline — persist-before-emit
TRIGGER:    ENTRY_PERSISTED event emission
CONFLICT:   Event emitted before entry written to ES/PG
RESOLUTION: F482.PersistEntry() and F491.LogAction() must complete before QUEUE FABRIC
            event emission in T184
RATIONALE:  DR-66 — downstream consumers (T186, T187) read entry by entryId from ES.
            Event before persist = consumer reads non-existent entry = cascade failure.
ENFORCED BY: DR-66, IR-184-1, INV-15-1
TASK TYPES: T184
```

#### CF-221 — No Partial Entry in Feed Chain
```
RULE ID:    CF-221
CATEGORY:   Submission Pipeline
TRIGGER:    Feed execution trigger
CONFLICT:   T187 (Feed Execution) triggered by partial entry save (T185)
RESOLUTION: Feed chain (T187, T188, T189) only triggered by ENTRY_PERSISTED event,
            never by PARTIAL_ENTRY_SAVED event
RATIONALE:  Partial entries are incomplete — CRM sync with partial data creates
            incomplete contacts. Feeds must only process completed entries.
ENFORCED BY: Template-36, Template-37, F505 trigger index filtering
TASK TYPES: T185, T187
```

---

### GROUP C — Feeds & Notifications (CF-222–CF-225)

#### CF-222 — Feed Execution Idempotency Key Required
```
RULE ID:    CF-222
CATEGORY:   Feeds & Notifications
TRIGGER:    IFeedExecutorService.ExecuteFeed() called
CONFLICT:   Feed executed without idempotency key registration
RESOLUTION: F509.RegisterExecution() must complete before F499.ExecuteFeed() proceeds
RATIONALE:  DR-70 — QUEUE FABRIC at-least-once delivery + event replays will
            re-trigger feeds. Duplicate CRM contact creation = data integrity failure.
ENFORCED BY: DR-70, IR-187-2, INV-15-4, SK-102
TASK TYPES: T187, T188
```

#### CF-223 — Payment Feed Runs Last
```
RULE ID:    CF-223
CATEGORY:   Feeds & Notifications
TRIGGER:    Payment feed in multi-feed submission
CONFLICT:   Payment feed (F503) executes before CRM/mailing list feeds
RESOLUTION: T189 (Payment Feed) sequenced after T187 (Integration Feed)
            in all generated flow templates
RATIONALE:  Payment is irreversible — it must be the last action after all
            other integrations succeed. Partial payment with failed CRM = orphaned payment.
ENFORCED BY: Template-36, IR-189-1
TASK TYPES: T187, T189
```

#### CF-224 — Webhook Retry Idempotent
```
RULE ID:    CF-224
CATEGORY:   Feeds & Notifications
TRIGGER:    IWebhookFeedService retry attempt
CONFLICT:   Same webhook sent twice to external endpoint
RESOLUTION: F509 idempotency key checked before each retry attempt in T188
RATIONALE:  External systems (CRM, Slack, Jira) may not be idempotent —
            duplicate webhook delivery creates duplicate records/notifications.
ENFORCED BY: IR-188-2, QG-188-2
TASK TYPES: T188, T193
```

#### CF-225 — CRM Feed No Duplicate Contact
```
RULE ID:    CF-225
CATEGORY:   Feeds & Notifications
TRIGGER:    ICrmFeedService.SyncContact() called
CONFLICT:   Duplicate CRM contact created for same submitter
RESOLUTION: F501 must check existing contact by email before creating new one.
            Idempotency key = hash(feedId + entryId) prevents duplicate API calls.
ENFORCED BY: IR-187-2, QG-187-1, SK-102
TASK TYPES: T187
```

---

### GROUP D — Recipe Engine (CF-226–CF-228)

#### CF-226 — Trigger Before Execute
```
RULE ID:    CF-226
CATEGORY:   Recipe Engine
TRIGGER:    Recipe execution start
CONFLICT:   Recipe execution started without trigger evaluation + idempotency check
RESOLUTION: T191 (Trigger Evaluation) with F509 idempotency check must precede
            T192 (Step Execution) — enforced by Template-37
RATIONALE:  DR-71 — recipe DAG execution follows Flow Engine pattern (Skill 09).
            Execution without trigger evaluation = runaway automation.
ENFORCED BY: Template-37 step ordering, IR-191-1, INV-15-4
TASK TYPES: T191, T192
```

#### CF-227 — Retry Via DLQ Only
```
RULE ID:    CF-227
CATEGORY:   Recipe Engine
TRIGGER:    Recipe step failure
CONFLICT:   Inline retry loop in IRecipeExecutionService or IRecipeStepResolverService
RESOLUTION: All retry logic exclusively via F508 + DLQ queue path (T193)
RATIONALE:  Inline retry loops block QUEUE FABRIC consumer thread, reduce throughput,
            and bypass backoff policies. DLQ-based retry is the only safe pattern.
ENFORCED BY: IR-193-1, QG-193-1
TASK TYPES: T192, T193
```

#### CF-228 — Recipe Step Atomic
```
RULE ID:    CF-228
CATEGORY:   Recipe Engine
TRIGGER:    IRecipeExecutionService.AdvanceExecution() called
CONFLICT:   Next step triggered before current step result recorded in run state
RESOLUTION: F507 must write step result to PG run state before emitting next-step event
RATIONALE:  CF-228 mirrors CF-220 (persist-before-emit) for recipe steps.
            Next step consuming stale state = incorrect conditional branching.
ENFORCED BY: IR-192-1, QG-192-2
TASK TYPES: T192
```

---

### GROUP E — Connector Safety (CF-229–CF-231)

#### CF-229 — OAuth Token in PG Encrypted Only
```
RULE ID:    CF-229
CATEGORY:   Connector Safety
TRIGGER:    Any OAuth token write operation
CONFLICT:   OAuth access/refresh token written to ES, Redis, or application log
RESOLUTION: F511.ExchangeCode() and F511.RefreshToken() store tokens only in
            PG with column-level encryption. No other storage path allowed.
RATIONALE:  DR-72 — ES has no column-level encryption. Redis is ephemeral.
            Token in ES = searchable secret. Token in Redis = non-durable + no encryption.
ENFORCED BY: DR-72, IR-194-1, INV-15-5
TASK TYPES: T194
```

#### CF-230 — Mapping Before External Push
```
RULE ID:    CF-230
CATEGORY:   Connector Safety
TRIGGER:    Any feed attempting to push to external system
CONFLICT:   Raw entry Dictionary sent to external API without field mapping
RESOLUTION: T195 (Data Mapping Transform) must precede T187/T188 for all connector feeds
RATIONALE:  External systems have strict schema requirements. Raw form Dictionary
            contains internal field IDs, not external field names. Raw push = API error.
ENFORCED BY: IR-195-4, Template-38 step ordering
TASK TYPES: T195, T187, T188
```

#### CF-231 — Run History Immutable
```
RULE ID:    CF-231
CATEGORY:   Connector Safety
TRIGGER:    Any write to IRunHistoryService
CONFLICT:   Run history record updated or deleted after initial write
RESOLUTION: F513 ES run log is append-only — no update/delete methods exposed
RATIONALE:  Run history is audit trail for connector integrations.
            Mutable run history = compliance violation (cannot investigate failures).
ENFORCED BY: IR-T196-implied, DNA-3 (immutable pattern)
TASK TYPES: T187, T188, T197
```

---

### GROUP F — Multi-Tenant Forms Isolation (CF-232–CF-234)

#### CF-232 — Schema Per-Tenant Namespaced
```
RULE ID:    CF-232
CATEGORY:   MT Forms Isolation
TRIGGER:    Any IFormSchemaService operation
CONFLICT:   Form schema document readable by a different tenant
RESOLUTION: F466 ES index namespaced: {tenantId}-forms-schemas.
            F514 validates namespace on every schema operation.
RATIONALE:  Form schemas may contain business-sensitive field configurations
            (pricing formulas, approval workflows). Cross-tenant read = data leak.
ENFORCED BY: DNA-5, F514, IR-179-5, INV-15-9
TASK TYPES: T179, T198
```

#### CF-233 — Entry RLS at PG Level
```
RULE ID:    CF-233
CATEGORY:   MT Forms Isolation
TRIGGER:    Entry read from PG (audit, export, partial promotion)
CONFLICT:   PG query returns entries from multiple tenants
RESOLUTION: F514.EnforceEntryRLS() applies PG Row Level Security policy.
            All PG entry queries include tenantId in WHERE clause (DNA-5).
RATIONALE:  PG RLS as defense-in-depth — even if application bug omits tenantId,
            PG policy blocks cross-tenant read at database level.
ENFORCED BY: F514, DNA-5, IR-198-3
TASK TYPES: T198, T184, T185
```

#### CF-234 — Connector Credentials Isolated Per Tenant
```
RULE ID:    CF-234
CATEGORY:   MT Forms Isolation
TRIGGER:    Any IOAuthConnectorService operation
CONFLICT:   Connector token/credentials accessible by a different tenant
RESOLUTION: F511 PG token table includes tenantId column with RLS policy.
            F514 validates connector credential isolation on tenant provision.
RATIONALE:  INV-15-10 — connector credential cross-tenant access = integration
            hijack (sending data to wrong CRM, wrong Slack, wrong Stripe account).
ENFORCED BY: DR-72, CF-229, INV-15-10, IR-194-5
TASK TYPES: T194, T198
```

---

### GROUP G — Cross-Flow (CF-235)

#### CF-235 — Forms Entries Never Conflict with DWH Raw Zone
```
RULE ID:    CF-235
CATEGORY:   Cross-Flow (FLOW-15 vs FLOW-14)
TRIGGER:    Any cross-system write involving form entries + DWH raw zone
CONFLICT:   Form entry ES index written to same index as FLOW-14 raw landing zone
RESOLUTION: Form entry ES index: {tenantId}-forms-entries (FLOW-15 namespace)
            DWH raw zone ES index: {tenantId}-dwh-raw (FLOW-14 namespace)
            Both use DATABASE FABRIC but different index namespaces — never shared.
RATIONALE:  FLOW-14 raw zone is immutable (DR-58). If form entries land in raw zone,
            they become subject to DWH zone promotion rules — incorrect pipeline routing.
ENFORCED BY: DR-58 (FLOW-14), F438 (IRawLandingService namespace), F482 namespace
TASK TYPES: T184 (FLOW-15), T169 (FLOW-14)
```

---

## STRESS TESTS (ST-104–ST-115)

### ST-104 — Form Schema Publish Under Concurrent Edit
```
STRESS TEST ID:  ST-104
TASK TYPES:      T179
FACTORIES:       F466, F469, F470
SCENARIO:
  Two admins simultaneously edit and publish the same form schema.
  Race condition: both create version snapshots, both emit FORM_PUBLISHED events.
LOAD PROFILE:
  2 concurrent publish operations on formId="form-A", tenantId="tenant-1"
EXPECTED BEHAVIOR:
  - Only one version snapshot created (F469 optimistic lock on version sequence)
  - Second publish returns DataProcessResult.Failure with CONCURRENT_EDIT code
  - No partial version state in PG
  - Single FORM_PUBLISHED event in QUEUE FABRIC
FAILURE SIGNAL:
  - Two conflicting render specs (F471) for same version number
  - Two FORM_PUBLISHED events with different schema payloads
  - PG version table has duplicate (formId, versionNumber) row
RECOVERY:
  Load latest version via F469.GetVersion(), re-apply changes, republish
```

### ST-105 — 10k Simultaneous Submissions
```
STRESS TEST ID:  ST-105
TASK TYPES:      T180, T181, T182, T183, T184
FACTORIES:       F478, F479, F480, F481, F482
SCENARIO:
  10,000 form submissions arrive simultaneously (form goes viral / load test).
  All submissions for the same formId, 500 different tenants (20/tenant).
LOAD PROFILE:
  10,000 POST requests in 1-second window
  20% are duplicate submissions (same idempotencyKey)
EXPECTED BEHAVIOR:
  - F478 dedup catches 2,000 duplicates (DataProcessResult.Failure, not enqueued)
  - 8,000 unique submissions enqueued to QUEUE FABRIC
  - Pipeline stages (T181-T184) process via consumer groups with backpressure
  - ES entry writes succeed for all 8,000 within 30 seconds
  - Redis rate limiter triggers for IPs exceeding threshold (F481)
  - Zero cross-tenant entry leaks
FAILURE SIGNAL:
  - Queue overflow (DLQ receives non-failure messages)
  - Duplicate entries in ES (dedup failure)
  - Redis dedup key collision producing false negatives
  - Pipeline stage latency > 30s for 8,000 entries
RECOVERY:
  DLQ replay via F499.ReplayRun()
  Dedup key TTL audit via Redis SCAN {tenantId}:dedup:*
```

### ST-106 — Anti-Spam False Positive Under Load
```
STRESS TEST ID:  ST-106
TASK TYPES:      T183
FACTORIES:       F481
SCENARIO:
  1,000 legitimate submissions from a corporate IP submitting a registration form.
  Anti-spam AI model flags IP as suspicious due to high submission velocity.
LOAD PROFILE:
  1,000 submissions from same IP, 10-second window, all unique users
EXPECTED BEHAVIOR:
  - Rate limiter (Redis) does NOT trigger (per-user threshold, not per-IP only)
  - AI spam scoring returns < 0.3 (legitimate, not flagged)
  - All 1,000 submissions pass spam gate and reach T184
  - False positive rate < 0.1% (QG-183-1)
FAILURE SIGNAL:
  - AI spam score > 0.8 for legitimate submissions (false positive)
  - Redis rate limit triggers per-IP instead of per-user+form
  - Spam gate blocks > 1% of legitimate submissions
MITIGATION:
  AI spam threshold configurable per form (FREEDOM config)
  IP-based rate limit only as secondary signal, not primary block
```

### ST-107 — Partial Entry TTL Expiry During Active Session
```
STRESS TEST ID:  ST-107
TASK TYPES:      T185
FACTORIES:       F484, F476
SCENARIO:
  User saves partial entry (T185), stops filling form. 48 hours pass.
  Redis TTL expires. User returns with resume token.
LOAD PROFILE:
  Single user, resume token presented 48h01m after save
EXPECTED BEHAVIOR:
  - F484.LoadPartial() returns DataProcessResult.Failure with TTL_EXPIRED code
  - Redis key confirmed deleted (no dangling state)
  - PG has no orphaned partial entry record
  - User redirected to form start (not crash/500)
FAILURE SIGNAL:
  - Redis key not deleted after TTL (TTL not set correctly)
  - PG partial entry record exists without corresponding Redis key
  - Resume token accepted after TTL (security bypass)
RECOVERY:
  Redis TTL audit: redis-cli TTL {tenantId}:partial:{resumeToken}
  PG orphan scan: SELECT * FROM partial_entries WHERE promoted = false AND created_at < NOW() - INTERVAL '48h'
```

### ST-108 — Notification Fan-Out 50 Recipients
```
STRESS TEST ID:  ST-108
TASK TYPES:      T186
FACTORIES:       F492, F493, F494, F495
SCENARIO:
  Sales lead form submission triggers notification to all 50 sales team members.
  Each recipient gets a personalized merge-tag resolved email.
LOAD PROFILE:
  1 submission → 50 notification events → 50 email deliveries
EXPECTED BEHAVIOR:
  - F494 routing rules evaluate and return 50 recipient entries
  - F493 resolves merge tags for each recipient (personalized sender name, etc.)
  - F495 enqueues 50 delivery events to QUEUE FABRIC (not 50 synchronous sends)
  - All 50 emails delivered within 60 seconds
  - Zero duplicate deliveries per recipient
FAILURE SIGNAL:
  - F494 returns < 50 recipients (routing rule evaluation error)
  - F495 sends synchronously (blocks for 50 SMTP calls in one thread)
  - Recipient receives > 1 email for same submission
THROUGHPUT TARGET:
  50 notification dispatches in < 5 seconds queue enqueue time
```

### ST-109 — CRM Feed Duplicate Detection
```
STRESS TEST ID:  ST-109
TASK TYPES:      T187
FACTORIES:       F499, F501, F509
SCENARIO:
  ENTRY_PERSISTED event replayed 3 times (QUEUE FABRIC at-least-once delivery).
  Each replay triggers CRM feed execution.
LOAD PROFILE:
  entryId="entry-X", feedId="crm-feed-1", 3 identical events, 5-second window
EXPECTED BEHAVIOR:
  - First execution: F509 registers idempotency key, F501 creates CRM contact
  - Second execution: F509 detects duplicate, returns DataProcessResult.Failure (DUPLICATE_SKIP)
  - Third execution: F509 detects duplicate, same result
  - CRM has exactly 1 contact created for entry-X
  - PG run log records 1 success + 2 idempotent skips
FAILURE SIGNAL:
  - CRM has 3 duplicate contacts for same entry
  - F509 idempotency key collision (birthday paradox scenario with ST-115)
  - PG run log records 3 successes (dedup not working)
RECOVERY:
  Redis key audit: redis-cli GET {tenantId}:idempotency:{feedId}:{entryId}
  CRM dedup cleanup: ICrmFeedService.DeduplicateContacts()
```

### ST-110 — Webhook Retry Storm / DLQ Overflow
```
STRESS TEST ID:  ST-110
TASK TYPES:      T188, T193
FACTORIES:       F500, F508, F499
SCENARIO:
  External webhook endpoint goes down for 2 hours. 5,000 webhook events fail.
  All 5,000 are queued to DLQ. Endpoint recovers. Retry storm begins.
LOAD PROFILE:
  5,000 webhook events in DLQ, endpoint recovers, all retried simultaneously
EXPECTED BEHAVIOR:
  - F508 exponential backoff prevents all 5,000 retrying at exactly same moment
  - Retry rate capped at 100/minute per tenant (FREEDOM config)
  - Endpoint receives retries at manageable rate (no overwhelming)
  - All 5,000 succeed within 1 hour of endpoint recovery
  - Idempotency keys prevent duplicate webhook sends during retry
FAILURE SIGNAL:
  - DLQ overflow (messages lost, not just delayed)
  - Endpoint receives 5,000 requests simultaneously (retry storm)
  - Duplicate webhook sends (idempotency key expired before retry)
MITIGATION:
  DLQ capacity: min(10x normal queue depth, 1M messages)
  Retry rate limiting: F508 FREEDOM config retryRatePerMinute
```

### ST-111 — Recipe Chain 20+ Steps / Timeout / Saga Rollback
```
STRESS TEST ID:  ST-111
TASK TYPES:      T192, T193
FACTORIES:       F506, F507, F508
SCENARIO:
  Automation recipe with 25 steps: CRM sync → mailing list → Slack → Jira → email
  chain. Step 18 fails (Jira API rate limit). Retry exhausted after 5 attempts.
LOAD PROFILE:
  recipeId="onboarding-recipe", 25 steps, step 18 fails with 429 Too Many Requests
EXPECTED BEHAVIOR:
  - Steps 1-17 complete successfully, results in PG run state
  - Step 18 failures queued to DLQ (T193)
  - Exponential backoff: 1s, 2s, 4s, 8s, 16s — 5 attempts, then EXHAUSTED
  - Recipe marked FAILED in run state after exhaustion
  - Admin alert notification sent (F492 + F495)
  - Steps 1-17 results preserved in run state (not rolled back — saga, not 2PC)
FAILURE SIGNAL:
  - Step 19-25 execute before step 18 completes (ordering violation)
  - PG run state corrupted by concurrent step writes
  - Recipe timeout without entering FAILED state
  - Steps 1-17 purged from run state on step 18 failure
```

### ST-112 — OAuth Token Refresh Race (2 Threads, 1 Expiry Window)
```
STRESS TEST ID:  ST-112
TASK TYPES:      T194
FACTORIES:       F511
SCENARIO:
  Connector OAuth token expires. Two feed executions attempt to refresh simultaneously.
  Both read expired token, both attempt refresh — double refresh race.
LOAD PROFILE:
  2 concurrent feed executions, token TTL = T+1 second, both detect expiry simultaneously
EXPECTED BEHAVIOR:
  - PG pessimistic lock on token refresh operation (one wins, one waits)
  - Winning thread refreshes token, writes new token to PG encrypted
  - Waiting thread reads refreshed token (not refreshes again)
  - External OAuth server receives exactly 1 refresh request
  - Both feed executions proceed with valid token
FAILURE SIGNAL:
  - External OAuth server receives 2 refresh requests (token invalidation)
  - Second refresh invalidates first token (race produces invalid state)
  - One thread proceeds with expired token after race
IMPLEMENTATION:
  PG advisory lock: SELECT pg_advisory_xact_lock(hashtext(connectorId || tenantId))
```

### ST-113 — File Upload Virus Scan Queue Saturation
```
STRESS TEST ID:  ST-113
TASK TYPES:      T196
FACTORIES:       F487, F488, F489
SCENARIO:
  1,000 file uploads arrive simultaneously (batch import form submission).
  Virus scan queue saturates, scan jobs back up.
LOAD PROFILE:
  1,000 file upload complete events in 10-second window
EXPECTED BEHAVIOR:
  - 1,000 scan jobs enqueued to QUEUE FABRIC scan queue
  - Backpressure: scan consumer groups process at max throughput
  - New signed URLs only generated as scans complete (not batched release)
  - Files remain quarantined until scan completes (no optimistic URL generation)
  - No scan jobs lost — DLQ catches scan failures
FAILURE SIGNAL:
  - Signed URLs generated before scan complete (INV-15-6 violation)
  - Scan queue overflow (jobs lost, files stuck in quarantine permanently)
  - Scan timeout after 60s returns DataProcessResult.Failure (file stays quarantined)
THROUGHPUT TARGET:
  Scan queue handles 100 concurrent scans per consumer group
```

### ST-114 — Cross-Tenant Form Schema Leak Attempt
```
STRESS TEST ID:  ST-114
TASK TYPES:      T179, T198
FACTORIES:       F466, F514
SCENARIO:
  Attacker-controlled tenant-A account attempts to enumerate and read form schemas
  from tenant-B by guessing formIds. Direct ES query with formId but wrong tenantId.
LOAD PROFILE:
  1,000 GET /forms/{formId} requests with valid JWT for tenant-A but target tenant-B formIds
EXPECTED BEHAVIOR:
  - F466.GetSchema() checks tenantId against schema document tenantId field
  - All 1,000 attempts return DataProcessResult.Failure with NOT_FOUND (not 403 — no schema enumeration)
  - F514 tenant scope validation logs all cross-tenant attempts (F491 audit)
  - ES query includes tenantId filter (DNA-5) — never returns cross-tenant results
  - No tenant-B schema data in any response
FAILURE SIGNAL:
  - Any 200 response containing tenant-B schema data
  - 403 response revealing that formId exists (enumeration risk)
  - ES query without tenantId filter returning all-tenant results
CRITICAL:       This test must pass with zero leaks — any failure = P0 security incident
```

### ST-115 — Recipe Idempotency Key Collision Under UUID-v4 Birthday Paradox
```
STRESS TEST ID:  ST-115
TASK TYPES:      T191, T192
FACTORIES:       F509
SCENARIO:
  1 billion recipe executions with triggerHash generated from UUIDv4.
  Birthday paradox probability analysis for Redis idempotency key collision.
LOAD PROFILE:
  10M executions simulated, 500k unique recipeIds, 20k executions per recipe
EXPECTED BEHAVIOR:
  - Zero key collisions observed in 10M execution simulation
  - Collision probability < 1 in 2^64 for triggerHash space
  - triggerHash = SHA-256(recipeId + eventId + tenantId) — not raw UUIDv4
  - Redis key format: {tenantId}:idem:{recipeId}:{triggerHash[:16]}
FAILURE SIGNAL:
  - Any colliding triggerHash causes two different executions to share idempotency key
  - Recipe execution skipped (DUPLICATE_SKIP) for different trigger events
  - Collision detected in < 10M samples (birthday paradox threshold exceeded)
MITIGATION:
  Use SHA-256 of composite key (not UUIDv4) for triggerHash — collision space 2^256
  Monitor collision rate via F513 run history anomaly detection
```

---

## BACKWARD COMPATIBILITY VERIFICATION

```
CF-1-CF-213:  UNCHANGED ✅
ST-1-ST-103:  UNCHANGED ✅
CF-214 starts at correct next ID (213 + 1 = 214)
ST-104 starts at correct next ID (103 + 1 = 104)
No modifications to existing BFA rules or stress test scenarios
```

---

## SAVE POINT: FLOW15:P5:BFA ✅
## Recovery: "Load 21_-_forms_and_flows_V62_BFA_STRESS_TEST — CF-214-235, ST-104-115 complete"
