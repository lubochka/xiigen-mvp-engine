# TASK TYPES CATALOG — FLOW-15: Forms & Flow Automation Builder
## Extends TASK_TYPES_CATALOG_MERGED.md
## Backward Compatible: T1-T178 and Templates 1-35 UNCHANGED
## Save Point: FLOW15:P3:TASK_TYPES ✅

---

## OVERVIEW

```
NEW TASK TYPES: T179-T198 (20 total)
NEW TEMPLATES:  36-38     (3 total)
NEW ARCHETYPES: AUTHORING, PERSISTENCE, NOTIFICATION, FEED_EXECUTION
DOMAIN:         Forms authoring + submission pipeline + automation recipes
```

---

## TASK TYPE: T179 — Form Schema Authoring Gate
```
TASK TYPE:          T179
ARCHETYPE:          AUTHORING  ← FIRST USE (new archetype)
ENTRY:              Fires when admin initiates form create/edit in form builder UI
PURPOSE:            Validates, versions, and publishes form schema (fields, pages,
                    conditional logic) through AI-assisted authoring pipeline.
                    Produces platform-agnostic render spec for client consumption.
DISTINCT FROM:      T167 (Connector Registration — provisioning, not authoring)
                    T190 (Recipe Definition — automation DAG, not form schema)

FACTORY DEPENDENCIES:
  F466 IFormSchemaService          — stores/retrieves schema from ES
  F467 IFieldDefinitionService     — validates field types against catalog
  F468 IConditionalLogicService    — stores and AI-suggests conditional rules
  F469 IFormVersioningService      — creates immutable version snapshot on publish
  F470 IFormPublishService         — transitions schema draft→published + emits event
  F471 IFormRenderSpecService      — generates platform-agnostic render spec
  F474 IAiFormAssistService        — AI-assisted field/schema generation

FABRIC RESOLUTION:
  F466 → DATABASE FABRIC (Elasticsearch)
  F467 → DATABASE FABRIC (Elasticsearch)
  F468 → DATABASE FABRIC (ES) + AI ENGINE FABRIC
  F469 → DATABASE FABRIC (PostgreSQL)
  F470 → QUEUE FABRIC + DATABASE FABRIC (ES)
  F471 → DATABASE FABRIC (Elasticsearch)
  F474 → AI ENGINE FABRIC (AiDispatcher)

AF CONFIGURATION:
  AF-1 Genesis:       Generates IFormSchemaService implementation on top of ES fabric
  AF-2 Planning:      Decomposes schema authoring into validate→version→publish→render steps
  AF-3 Prompt Library: Retrieves form-authoring domain prompts
  AF-4 RAG:           Searches SK-99 (schema DAG validation), SK-107 (fabric-first UI),
                      SK-109 (conditional logic evaluator) for reusable patterns
  AF-5 Multi-model:   Runs competing models for AI schema suggestions (F474)
  AF-6 Code review:   Reviews generated IFormSchemaService against DNA patterns
  AF-7 Compliance:    Checks DNA-1 (no typed FormSchema), DNA-5 (tenantId on all ES writes)
  AF-8 Security:      Validates F473 permission checks, tenant scope isolation
  AF-9 Judge:         Validates iron rules, quality gates below
  AF-10 Merge:        Combines multi-model schema suggestions
  AF-11 Feedback:     Stores schema quality scores for AI improvement

BFA VALIDATION:
  CF-214: Schema publish requires version snapshot (F469) before event (F470)
  CF-215: Render spec regenerated on every schema publish (F470→F471)
  CF-232: Schema namespaced per tenant — no cross-tenant schema read

MACHINE (fixed):
  - Schema stored as ES document (DNA-1)
  - Version created on every publish (DR via F469)
  - Render spec platform-agnostic (SK-107)
  - AI suggestions via IAiProvider.GenerateAsync() (never direct SDK)
  - tenantId on every ES write (DNA-5)

FREEDOM (configurable):
  - AI provider for schema suggestions (claude|openai|gemini|deepseek)
  - Maximum fields per form (FREEDOM config)
  - Versioning retention policy (keep N versions)
  - Conditional logic complexity limits

IRON RULES (violations = BUILD FAILURE):
  IR-179-1: Schema stored as Dictionary<string,object> — no typed FormSchema class
  IR-179-2: IAiProvider.GenerateAsync() only — never import openai/anthropic/gemini SDK
  IR-179-3: Version snapshot created BEFORE publish event emitted
  IR-179-4: Render spec contains zero platform-specific values (SK-107 compliant)
  IR-179-5: tenantId present on every ES index write in generated service
  IR-179-6: Conditional rules stored as ES document — never compiled into service code
  IR-179-7: F473 permission check executed before schema mutation
  IR-179-8: IFormSchemaService resolved via CreateAsync() — never directly instantiated

QUALITY GATES (AF-9 validates):
  QG-179-1: AI-suggested schemas return DataProcessResult<Dictionary>
  QG-179-2: Published render spec parseable by client without platform imports
  QG-179-3: Version rollback restores previous render spec correctly
  QG-179-4: Conditional rules evaluate without exception on empty field values
  QG-179-5: Schema publish idempotent (republish same version = no duplicate)
  QG-179-6: Cross-tenant schema read returns DataProcessResult.Failure
```

---

## TASK TYPE: T180 — Submission Intake Gate
```
TASK TYPE:          T180
ARCHETYPE:          INGESTION
ENTRY:              HTTP POST from form client (web/mobile/API)
PURPOSE:            Captures raw form submission, deduplicates, and enqueues
                    for pipeline processing. Returns immediately — processing async.
DISTINCT FROM:      T169 (Webhook Ingestion — external push, HMAC verify)
                    T184 (Entry Persistence — downstream stage, not intake)

FACTORY DEPENDENCIES:
  F478 ISubmissionIntakeService   — dedup + enqueue
  F479 IFieldNormalizerService    — raw payload normalization
  F475 IFormSessionService        — validates active session

FABRIC RESOLUTION:
  F478 → QUEUE FABRIC (Redis Streams) + DATABASE FABRIC (Redis dedup)
  F479 → CORE FABRIC (ObjectProcessor)
  F475 → DATABASE FABRIC (Redis sessions)

AF CONFIGURATION:
  AF-1: Generates ISubmissionIntakeService — QUEUE FABRIC enqueue + Redis dedup
  AF-4: RAG retrieves SK-100 (submission stage-gate pattern)
  AF-7: DNA-1 (Dictionary), DNA-5 (tenantId on dedup key), DNA-3 (no throw)
  AF-9: Validates iron rules, quality gates

BFA VALIDATION:
  CF-216: Anti-spam (F481) must run before entry persist (F482) — this stage pre-spam
  CF-217: Wizard session state isolated per tenant (F475)

IRON RULES:
  IR-180-1: Raw payload enqueued to QUEUE FABRIC before any synchronous processing
  IR-180-2: Dedup key = hash(formId + visitorId + payload) checked in Redis before enqueue
  IR-180-3: Return 202 Accepted immediately — never block on pipeline completion
  IR-180-4: tenantId on every Redis dedup key namespace
  IR-180-5: No typed SubmissionRequest class — raw payload as Dictionary
  IR-180-6: Session validation via F475 before intake
  IR-180-7: Duplicate submission returns DataProcessResult.Failure with DUPLICATE_SUBMISSION code
  IR-180-8: ISubmissionIntakeService resolved via CreateAsync()

QUALITY GATES:
  QG-180-1: 10k concurrent submissions handled without queue overflow (ST-105)
  QG-180-2: Dedup detection rate > 99.9% for identical replayed submissions
  QG-180-3: Response latency < 100ms (queue enqueue, not full pipeline)
  QG-180-4: Cross-tenant submission leak returns DataProcessResult.Failure
  QG-180-5: Intake handles malformed payload with DataProcessResult.Failure (no 500)
  QG-180-6: Redis dedup TTL matches submission idempotency window (config-driven)
```

---

## TASK TYPE: T181 — Field Normalization Step
```
TASK TYPE:          T181
ARCHETYPE:          TRANSFORM
ENTRY:              Fires from QUEUE FABRIC after submission intake
PURPOSE:            Normalizes raw field values per schema type definitions,
                    strips disallowed fields, resolves file references.
DISTINCT FROM:      T171 (Raw-to-Staging Transform — DWH zones, not form fields)
                    T195 (Data Mapping Transform — connector payload mapping)

FACTORY DEPENDENCIES:
  F479 IFieldNormalizerService    — core normalization
  F466 IFormSchemaService         — schema lookup for type coercion

FABRIC RESOLUTION:
  F479 → CORE FABRIC (ObjectProcessor)
  F466 → DATABASE FABRIC (Elasticsearch)

IRON RULES:
  IR-181-1: Output is Dictionary<string,object> — no typed NormalizedSubmission
  IR-181-2: Unknown fields stripped (not passed through) — security boundary
  IR-181-3: File references resolved to fileId tokens — never raw file bytes in payload
  IR-181-4: Schema lookup via F466 CreateAsync() — never direct ES client
  IR-181-5: tenantId on schema lookup
  IR-181-6: Normalization failure returns DataProcessResult.Failure with field errors
  IR-181-7: Empty fields skipped via BuildSearchFilter (DNA-2)
  IR-181-8: Normalization is idempotent — running twice produces same output

QUALITY GATES:
  QG-181-1: All 40 field types (text, date, file, payment, repeater...) normalize correctly
  QG-181-2: Cross-field normalization preserves relationships (e.g. start < end date)
  QG-181-3: File ref normalization tokens are tenant-scoped
  QG-181-4: Malicious field injection (XSS payloads) neutralized at normalization
  QG-181-5: Idempotency: double normalization produces identical Dictionary output
  QG-181-6: Performance: 10k field normalizations/sec on standard hardware
```

---

## TASK TYPE: T182 — Submission Validation Gate
```
TASK TYPE:          T182
ARCHETYPE:          VALIDATION
ENTRY:              Fires from QUEUE FABRIC after field normalization (T181)
PURPOSE:            Validates normalized submission against form rules: required
                    fields, regex patterns, cross-field rules, business constraints.
DISTINCT FROM:      T183 (Anti-Spam — security gate, not business validation)
                    T172 (Schema Drift Detection — DWH schema, not form fields)

FACTORY DEPENDENCIES:
  F480 ISubmissionValidatorService  — rule evaluation
  F466 IFormSchemaService           — rule source lookup
  F468 IConditionalLogicService     — conditional required-field evaluation

FABRIC RESOLUTION:
  F480 → DATABASE FABRIC (ES) + RAG FABRIC (hybrid strategy)
  F466 → DATABASE FABRIC (Elasticsearch)
  F468 → DATABASE FABRIC (ES) + AI ENGINE FABRIC

IRON RULES:
  IR-182-1: Validation runs AFTER normalization (T181) — never on raw payload
  IR-182-2: Validation rules loaded from ES — never hardcoded in service
  IR-182-3: Conditional required-field evaluation via F468 (not inline if/else)
  IR-182-4: All validation errors collected — never fail-fast on first error
  IR-182-5: Result is DataProcessResult<Dictionary> with errors[] array
  IR-182-6: tenantId on all ES rule lookups
  IR-182-7: RAG fabric retrieves validation patterns via IRagService.SearchAsync()
  IR-182-8: ISubmissionValidatorService resolved via CreateAsync()

QUALITY GATES:
  QG-182-1: All required field types validated (text, email, phone, date, file)
  QG-182-2: Regex validation patterns configurable per field (FREEDOM config)
  QG-182-3: Cross-field rules (e.g. end date after start date) evaluated correctly
  QG-182-4: Validation result errors array includes field IDs for UI highlighting
  QG-182-5: Conditional required fields re-evaluated on each step change
  QG-182-6: Validation performant: < 20ms for 100-field form
```

---

## TASK TYPE: T183 — Anti-Spam Security Gate
```
TASK TYPE:          T183
ARCHETYPE:          VALIDATION
ENTRY:              Fires from QUEUE FABRIC after validation (T182), before persist
PURPOSE:            Composite spam/security check: honeypot, reCAPTCHA, rate limit,
                    AI scoring. Blocks submission if spam score exceeds threshold.
DISTINCT FROM:      T182 (Business Validation — field rules, not security)
                    T196 (File Upload Security — virus scan, not submission gate)

FACTORY DEPENDENCIES:
  F481 IAntiSpamService   — composite spam gate

FABRIC RESOLUTION:
  F481 → AI ENGINE FABRIC (spam scoring) + DATABASE FABRIC (Redis rate limit)

IRON RULES:
  IR-183-1: Anti-spam runs BEFORE entry persistence (T184) — never after (DR-67, CF-216)
  IR-183-2: Composite gate: honeypot + reCAPTCHA + AI scoring — all three evaluated
  IR-183-3: Rate limit check via Redis before AI scoring (avoid wasted AI calls)
  IR-183-4: Spam result includes {score, blocked, reason} as Dictionary fields
  IR-183-5: Spam block returns DataProcessResult.Failure — submission not persisted
  IR-183-6: tenantId on Redis rate limit key namespace
  IR-183-7: AI scoring via IAiProvider.GenerateAsync() — never direct LLM import
  IR-183-8: Spam thresholds configurable per form (FREEDOM config)

QUALITY GATES:
  QG-183-1: False positive rate < 0.1% on known-legitimate submissions (ST-106)
  QG-183-2: Rate limit triggers correctly at configured threshold
  QG-183-3: AI spam score returned as normalized 0.0-1.0 float in result Dictionary
  QG-183-4: reCAPTCHA verification returns DataProcessResult.Failure on invalid token
  QG-183-5: Honeypot detection does not add latency > 5ms
  QG-183-6: Spam gate bypass attempt (missing gate stage) = BUILD FAILURE via AF-7
```

---

## TASK TYPE: T184 — Entry Persistence Gate
```
TASK TYPE:          T184
ARCHETYPE:          PERSISTENCE  ← FIRST USE (new archetype)
ENTRY:              Fires from QUEUE FABRIC after anti-spam gate (T183) clears
PURPOSE:            Persists validated, spam-cleared entry to ES (primary) and
                    PG (audit). Emits ENTRY_PERSISTED event AFTER storage.
DISTINCT FROM:      T185 (Partial Entry Save — Redis interim, not final persist)
                    T169 (Webhook Ingestion — external push capture, not form persist)

FACTORY DEPENDENCIES:
  F482 IEntryPersistenceService  — ES primary + PG audit write
  F491 IEntryAuditService        — immutable audit log
  F485 IEntryStatusService       — initial status set (unread)

FABRIC RESOLUTION:
  F482 → DATABASE FABRIC (ES primary) + DATABASE FABRIC (PG audit)
  F491 → DATABASE FABRIC (PG WORM) + DATABASE FABRIC (ES)
  F485 → DATABASE FABRIC (Elasticsearch)

IRON RULES:
  IR-184-1: Entry persisted to ES BEFORE ENTRY_PERSISTED event emitted (DR-66, INV-15-1)
  IR-184-2: entryId = Ulid.NewUlid() — generated at persist, not at intake
  IR-184-3: Entry stored as Dictionary<string,object> — no typed Entry class
  IR-184-4: tenantId written to every ES document and PG audit record
  IR-184-5: PG audit record written in same transaction scope as ES write
  IR-184-6: Initial status = "unread" set via F485 on persist
  IR-184-7: ENTRY_PERSISTED event payload contains entryId + formId + tenantId only
  IR-184-8: IEntryPersistenceService resolved via CreateAsync()

QUALITY GATES:
  QG-184-1: ES document and PG audit both written before event emitted
  QG-184-2: entryId uniqueness guaranteed across 1M concurrent submissions
  QG-184-3: Entry retrieval by entryId returns exact persisted Dictionary
  QG-184-4: Cross-tenant entry read returns DataProcessResult.Failure
  QG-184-5: Persist failure rolls back (no orphaned PG audit without ES entry)
  QG-184-6: Audit trail queryable by entryId + tenantId within 100ms
```

---

## TASK TYPE: T185 — Partial Entry Save Gate
```
TASK TYPE:          T185
ARCHETYPE:          PERSISTENCE
ENTRY:              Fires when user clicks "Save & Continue" on multi-step form
PURPOSE:            Saves in-progress form data to Redis with TTL.
                    Issues resume token. Promotes to full entry on completion.
DISTINCT FROM:      T184 (Final persist — completed submissions, PG primary)
                    T176 (Redis session state — form session, not partial entry)

FACTORY DEPENDENCIES:
  F484 IPartialEntryService   — Redis TTL + PG promotion
  F476 IMultiStepWizardService — current step state

FABRIC RESOLUTION:
  F484 → DATABASE FABRIC (Redis TTL) + DATABASE FABRIC (PostgreSQL)
  F476 → DATABASE FABRIC (Redis)

IRON RULES:
  IR-185-1: Partial entry stored ONLY in Redis (not ES, not PG) until completion
  IR-185-2: Redis TTL ≤ 48 hours — never configurable above 48h (DR-74)
  IR-185-3: Resume token = cryptographically random 32-byte hex (not entryId)
  IR-185-4: Promotion to PG on complete — Redis key deleted after promotion
  IR-185-5: On TTL expiry, partial deleted without promotion (no orphaned PG record)
  IR-185-6: tenantId on Redis key namespace and PG promotion record
  IR-185-7: Partial data stored as Dictionary — no typed PartialEntry class
  IR-185-8: IPartialEntryService resolved via CreateAsync()

QUALITY GATES:
  QG-185-1: Resume token valid for configured TTL window (ST-107)
  QG-185-2: Partial promoted to full entry preserves all field values exactly
  QG-185-3: TTL expiry deletes Redis key without PG orphan (ST-107)
  QG-185-4: Cross-tenant resume token returns DataProcessResult.Failure
  QG-185-5: 1M concurrent partial entries handled within Redis memory budget
  QG-185-6: Resume flow reconstructs wizard step from partial data correctly
```

---

## TASK TYPE: T186 — Notification Dispatch Gate
```
TASK TYPE:          T186
ARCHETYPE:          NOTIFICATION  ← FIRST USE (new archetype)
ENTRY:              Fires from QUEUE FABRIC after ENTRY_PERSISTED event
PURPOSE:            Resolves notification templates with merge tags, routes to
                    correct recipients per routing rules, delivers multi-channel.
DISTINCT FROM:      T187 (Integration Feed — CRM/webhook push, not notification)
                    T188 (Webhook Feed — single channel push, not multi-channel notify)

FACTORY DEPENDENCIES:
  F492 INotificationTemplateService  — template retrieval
  F493 IMergeTagResolverService      — tag resolution + AI assist
  F494 INotificationRouterService    — routing rule evaluation
  F495 INotificationDeliveryService  — multi-channel delivery
  F496 INotificationAttachmentService — file/PDF attachments

FABRIC RESOLUTION:
  F492 → DATABASE FABRIC (Elasticsearch)
  F493 → DATABASE FABRIC (ES) + AI ENGINE FABRIC
  F494 → QUEUE FABRIC + DATABASE FABRIC (ES routing rules)
  F495 → QUEUE FABRIC (multi-channel Redis Streams)
  F496 → DATABASE FABRIC (ES) + F488 (scan gate)

IRON RULES:
  IR-186-1: Notification dispatched AFTER ENTRY_PERSISTED event — never before (DR-66)
  IR-186-2: Merge tags resolved via F493 — never string.Replace() on typed model fields
  IR-186-3: Routing rules loaded from ES — never hardcoded recipient lists
  IR-186-4: Multi-channel delivery via QUEUE FABRIC — never synchronous HTTP in service
  IR-186-5: File attachment requires F488 MarkClean before attach (DR-73)
  IR-186-6: tenantId on all template and routing rule lookups
  IR-186-7: AI tag resolution via IAiProvider.GenerateAsync() — never direct LLM
  IR-186-8: INotificationDeliveryService resolved via CreateAsync()

QUALITY GATES:
  QG-186-1: Fan-out to 50 recipients from single entry (ST-108)
  QG-186-2: Merge tag resolution for all standard tags < 50ms
  QG-186-3: Unknown merge tags return DataProcessResult.Failure with missing-tag list
  QG-186-4: Channel routing applies conditional rules correctly (Finance team test)
  QG-186-5: PDF attachment generated + scanned before delivery
  QG-186-6: Delivery failure queued to DLQ with retry schedule
```

---

## TASK TYPE: T187 — Integration Feed Execution Gate
```
TASK TYPE:          T187
ARCHETYPE:          FEED_EXECUTION  ← FIRST USE (new archetype)
ENTRY:              Fires from QUEUE FABRIC after notification dispatch (T186)
PURPOSE:            Evaluates feed conditions, maps data, executes integration
                    (CRM, mailing list, ticketing) with idempotency guarantee.
DISTINCT FROM:      T188 (Webhook Feed — single webhook push, not full feed)
                    T186 (Notification — internal email/SMS, not external integration)

FACTORY DEPENDENCIES:
  F497 IFeedDefinitionService    — feed config lookup
  F498 IFeedConditionService     — condition evaluation
  F499 IFeedExecutorService      — idempotent execution + run log
  F501 ICrmFeedService           — CRM integration
  F502 IMailingListFeedService   — mailing list sync
  F512 IDataMappingService       — payload transformation

FABRIC RESOLUTION:
  F497 → DATABASE FABRIC (Elasticsearch)
  F498 → DATABASE FABRIC (ES) + AI ENGINE FABRIC
  F499 → QUEUE FABRIC + DATABASE FABRIC (PG run log)
  F501 → AI ENGINE FABRIC + DATABASE FABRIC (ES connector config)
  F502 → QUEUE FABRIC + DATABASE FABRIC (ES list config)
  F512 → DATABASE FABRIC (ES mapping) + AI ENGINE FABRIC

IRON RULES:
  IR-187-1: Feed condition evaluated BEFORE execution — never execute unconditionally
  IR-187-2: Redis idempotency key registered BEFORE feed execution (DR-70, INV-15-4)
  IR-187-3: Data mapping validated via F512 BEFORE push to external system (CF-230)
  IR-187-4: Feed execution result recorded in PG run log regardless of outcome
  IR-187-5: CRM payload as Dictionary — no typed CrmContact class (DNA-1)
  IR-187-6: tenantId on all condition rule and run log queries
  IR-187-7: Feed failure queued to DLQ — never lost (CF-222)
  IR-187-8: IFeedExecutorService resolved via CreateAsync()

QUALITY GATES:
  QG-187-1: CRM duplicate detection via idempotency key (ST-109)
  QG-187-2: Condition evaluation supports AND/OR/NOT operators
  QG-187-3: Field mapping transforms all data types (string, date, number, bool)
  QG-187-4: Run log queryable by feedId + entryId + tenantId
  QG-187-5: Feed replay (F499.ReplayRun) re-executes correctly with same outcome
  QG-187-6: Cross-tenant feed config read returns DataProcessResult.Failure
```

---

## TASK TYPE: T188 — Webhook Feed Dispatch Gate
```
TASK TYPE:          T188
ARCHETYPE:          FEED_EXECUTION
ENTRY:              Fires from QUEUE FABRIC for webhook-type feeds
PURPOSE:            Sends HTTP POST to configured webhook endpoint with
                    mapped entry data. Retry with backoff on failure.
DISTINCT FROM:      T169 (Webhook Ingestion — inbound HMAC verify, not outbound push)
                    T187 (Full Feed — multi-integration, not single webhook)

FACTORY DEPENDENCIES:
  F500 IWebhookFeedService    — outbound webhook
  F499 IFeedExecutorService   — idempotency + run log
  F512 IDataMappingService    — payload mapping

FABRIC RESOLUTION:
  F500 → QUEUE FABRIC + CORE FABRIC (HTTP)
  F499 → QUEUE FABRIC + DATABASE FABRIC (PG)
  F512 → DATABASE FABRIC (ES) + AI ENGINE FABRIC

IRON RULES:
  IR-188-1: Webhook sent via QUEUE FABRIC — never synchronous HTTP in service
  IR-188-2: Idempotency key prevents duplicate webhook sends (CF-222)
  IR-188-3: Retry with exponential backoff — max 5 attempts via DLQ
  IR-188-4: Webhook payload mapped via F512 — no raw entry Dictionary sent directly
  IR-188-5: Endpoint URL stored in ES feed config — never hardcoded
  IR-188-6: tenantId included in webhook headers (X-Tenant-Id)
  IR-188-7: HTTP failure returns DataProcessResult.Failure with status + body
  IR-188-8: IWebhookFeedService resolved via CreateAsync()

QUALITY GATES:
  QG-188-1: Retry storm handled — DLQ overflow prevention (ST-110)
  QG-188-2: Idempotency: webhook not sent twice for same entryId + feedId
  QG-188-3: Endpoint verification validates URL format + reachability
  QG-188-4: Webhook payload includes X-Signature-256 HMAC header
  QG-188-5: Timeout handling: 30s timeout returns failure, not hang
  QG-188-6: Run history (F513) records all webhook attempts including failures
```

---

## TASK TYPE: T189 — Payment Feed Processing Gate
```
TASK TYPE:          T189
ARCHETYPE:          ORCHESTRATION
ENTRY:              Fires from QUEUE FABRIC after PaymentStateChanged event
PURPOSE:            Processes payment state transitions (pending→captured→failed→refunded),
                    updates entry, triggers downstream feeds on payment success.
DISTINCT FROM:      T187 (Generic Feed — non-payment integrations)
                    T184 (Entry Persist — initial save, not payment state update)

FACTORY DEPENDENCIES:
  F503 IPaymentFeedService    — payment state + PG log
  F482 IEntryPersistenceService — entry update with payment state
  F499 IFeedExecutorService   — downstream feed trigger

FABRIC RESOLUTION:
  F503 → QUEUE FABRIC + DATABASE FABRIC (PG payment log)
  F482 → DATABASE FABRIC (ES + PG audit)
  F499 → QUEUE FABRIC + DATABASE FABRIC (PG)

IRON RULES:
  IR-189-1: Payment feed runs LAST in feed chain after other integrations (CF-223)
  IR-189-2: Payment state transitions follow allowed state machine (pending→captured only)
  IR-189-3: Entry updated with payment state BEFORE downstream feeds triggered
  IR-189-4: PG payment log written with gatewayRef, amount, currency as Dictionary
  IR-189-5: tenantId on all payment log and entry update records
  IR-189-6: Refund state triggers refund-specific notification (F492 template)
  IR-189-7: Payment state stored as Dictionary {status, gatewayRef, amount, currency}
  IR-189-8: IPaymentFeedService resolved via CreateAsync()

QUALITY GATES:
  QG-189-1: State machine rejects invalid transitions (captured→pending)
  QG-189-2: Double-capture prevention via idempotency key (gatewayRef)
  QG-189-3: Refund triggers correct downstream notification template
  QG-189-4: Payment log query by gatewayRef + tenantId returns correct record
  QG-189-5: Failed payment returns DataProcessResult.Failure with gateway error
  QG-189-6: Payment feed isolated per tenant (no cross-tenant payment data)
```

---

## TASK TYPE: T190 — Recipe Definition Gate
```
TASK TYPE:          T190
ARCHETYPE:          AUTHORING
ENTRY:              Fires when admin creates/edits automation recipe in builder UI
PURPOSE:            Validates, stores, and activates automation recipe DAG
                    (trigger + steps + conditions) in Elasticsearch.
DISTINCT FROM:      T179 (Form Schema Authoring — form definition, not automation recipe)
                    T191 (Recipe Trigger Evaluation — runtime execution, not authoring)

FACTORY DEPENDENCIES:
  F504 IRecipeDefinitionService  — ES recipe DAG store
  F505 IRecipeTriggerService     — trigger registration
  F506 IRecipeStepResolverService — step catalog validation

FABRIC RESOLUTION:
  F504 → DATABASE FABRIC (Elasticsearch)
  F505 → QUEUE FABRIC + DATABASE FABRIC (ES)
  F506 → DATABASE FABRIC (ES) + FLOW ENGINE FABRIC

IRON RULES:
  IR-190-1: Recipe DAG stored as ES document — same pattern as Skill 09 (DR-71)
  IR-190-2: Recipe as Dictionary {trigger, steps[], conditions{}} — no typed RecipeClass
  IR-190-3: All step types validated against step catalog (F506) before activation
  IR-190-4: Trigger registered in QUEUE FABRIC trigger index on activation
  IR-190-5: tenantId on all recipe and trigger records
  IR-190-6: Recipe activation idempotent — re-activate same recipe = no duplicate
  IR-190-7: Step resolver via FLOW ENGINE FABRIC — extends Skill 09 pattern
  IR-190-8: IRecipeDefinitionService resolved via CreateAsync()

QUALITY GATES:
  QG-190-1: DAG cycle detection — circular step dependencies = BUILD FAILURE
  QG-190-2: All referenced factory interfaces exist in catalog before activation
  QG-190-3: Recipe with 20+ steps activates without timeout (ST-111)
  QG-190-4: Trigger registration idempotent across QUEUE FABRIC restarts
  QG-190-5: Cross-tenant recipe read returns DataProcessResult.Failure
  QG-190-6: Recipe rollback deactivates trigger cleanly
```

---

## TASK TYPE: T191 — Recipe Trigger Evaluation Gate
```
TASK TYPE:          T191
ARCHETYPE:          ORCHESTRATION
ENTRY:              Fires when QUEUE FABRIC delivers a trigger event
PURPOSE:            Evaluates whether incoming event matches registered recipe triggers.
                    Starts execution for matching recipes with idempotency check.
DISTINCT FROM:      T192 (Recipe Step Execution — individual step, not trigger eval)
                    T505 (Trigger Registration — authoring time, not runtime eval)

FACTORY DEPENDENCIES:
  F505 IRecipeTriggerService       — trigger evaluation
  F509 IRecipeIdempotencyService   — dedup before execution

FABRIC RESOLUTION:
  F505 → QUEUE FABRIC + DATABASE FABRIC (ES)
  F509 → DATABASE FABRIC (Redis dedup)

IRON RULES:
  IR-191-1: Idempotency check BEFORE trigger fires execution (CF-226, INV-15-4)
  IR-191-2: Trigger evaluation reads from ES — never hardcoded in listener
  IR-191-3: Multiple recipes can match single event — all started independently
  IR-191-4: Trigger hash = hash(eventType + sourceId + timestamp-window)
  IR-191-5: tenantId on all trigger index queries
  IR-191-6: Matched recipe IDs returned as List<string> in DataProcessResult
  IR-191-7: No-match result = DataProcessResult.Success with empty list
  IR-191-8: IRecipeTriggerService resolved via CreateAsync()

QUALITY GATES:
  QG-191-1: Trigger evaluation < 10ms for 1000-recipe catalog
  QG-191-2: Idempotency key prevents duplicate execution on event replay
  QG-191-3: All matching recipes started in parallel (not sequential)
  QG-191-4: Trigger condition supports formId, eventType, field-value filters
  QG-191-5: No-match scenario logged but not error
  QG-191-6: Cross-tenant trigger match returns DataProcessResult.Failure
```

---

## TASK TYPE: T192 — Recipe Step Execution Gate
```
TASK TYPE:          T192
ARCHETYPE:          ORCHESTRATION
ENTRY:              Fires from QUEUE FABRIC per recipe step event
PURPOSE:            Executes individual recipe step: resolve factory, call action,
                    record result, advance to next step.
DISTINCT FROM:      T191 (Trigger Evaluation — recipe start, not step execution)
                    T193 (Retry Gate — failure recovery, not normal execution)

FACTORY DEPENDENCIES:
  F506 IRecipeStepResolverService  — step factory resolution
  F507 IRecipeExecutionService     — state management + next-step advance

FABRIC RESOLUTION:
  F506 → DATABASE FABRIC (ES) + FLOW ENGINE FABRIC
  F507 → QUEUE FABRIC + DATABASE FABRIC (PG)

IRON RULES:
  IR-192-1: Step result recorded in PG run state before next step triggered
  IR-192-2: Step factory resolved via CreateAsync() — never hardcoded class
  IR-192-3: Step failure triggers T193 (Retry) — not inline retry loop
  IR-192-4: Step execution atomic — partial step state not visible to other consumers
  IR-192-5: tenantId on all run state reads/writes
  IR-192-6: Step result as Dictionary — no typed StepResult class
  IR-192-7: Max concurrent steps per recipe = FREEDOM config (default 10)
  IR-192-8: IRecipeExecutionService resolved via CreateAsync()

QUALITY GATES:
  QG-192-1: Recipe chain of 20+ steps completes without timeout (ST-111)
  QG-192-2: Step ordering preserved — step N+1 never fires before step N completes
  QG-192-3: Step result data available to subsequent steps via run state
  QG-192-4: Concurrent recipe executions (same recipe, different entries) isolated
  QG-192-5: Run state queryable mid-execution for observability
  QG-192-6: Step with conditional branch evaluates branch at execution time
```

---

## TASK TYPE: T193 — Recipe Retry Gate
```
TASK TYPE:          T193
ARCHETYPE:          DURABLE_SAGA
ENTRY:              Fires from DLQ when recipe step fails
PURPOSE:            Implements exponential backoff retry for failed recipe steps.
                    Marks recipe as failed after exhausting retry attempts.
DISTINCT FROM:      T508 (Recipe Retry Service — the service itself)
                    T170 (Backfill Saga — DWH backfill, not recipe retry)

FACTORY DEPENDENCIES:
  F508 IRecipeRetryService        — DLQ + backoff scheduling
  F507 IRecipeExecutionService    — run state update on exhaustion

FABRIC RESOLUTION:
  F508 → QUEUE FABRIC (DLQ) + DATABASE FABRIC (PG backoff log)
  F507 → QUEUE FABRIC + DATABASE FABRIC (PG)

IRON RULES:
  IR-193-1: Retry via DLQ ONLY — never inline retry loop (CF-227)
  IR-193-2: Exponential backoff: 1s, 2s, 4s, 8s, 16s (configurable via FREEDOM)
  IR-193-3: Max retry attempts configurable per recipe step (FREEDOM config)
  IR-193-4: After max attempts: recipe marked FAILED in run state, alert emitted
  IR-193-5: Retry job records attempt number + error in PG backoff log
  IR-193-6: tenantId on all retry and run state records
  IR-193-7: Retry is idempotent — duplicate retry job for same step = no-op
  IR-193-8: IRecipeRetryService resolved via CreateAsync()

QUALITY GATES:
  QG-193-1: Retry backoff intervals respect configured schedule
  QG-193-2: Exhaustion triggers alert notification (F492) to admin
  QG-193-3: Retry storm prevention — max concurrent retries per tenant capped
  QG-193-4: DLQ overflow handled gracefully (ST-110 pattern)
  QG-193-5: Retry job idempotency prevents duplicate step execution
  QG-193-6: Failed recipe run queryable with full retry history
```

---

## TASK TYPE: T194 — Connector Auth Gate
```
TASK TYPE:          T194
ARCHETYPE:          PROVISIONING
ENTRY:              Fires when admin connects an external service integration
PURPOSE:            Completes OAuth PKCE flow, stores encrypted tokens in PG,
                    validates connector capabilities.
DISTINCT FROM:      T167 (DWH Connector Registration — warehouse connectors)
                    T198 (Form Tenant Provision — tenant setup, not connector auth)

FACTORY DEPENDENCIES:
  F511 IOAuthConnectorService      — PKCE flow + PG encrypted token store
  F510 IConnectorDefinitionService — connector capability validation

FABRIC RESOLUTION:
  F511 → DATABASE FABRIC (PG encrypted) + CORE FABRIC (HTTP)
  F510 → DATABASE FABRIC (Elasticsearch)

IRON RULES:
  IR-194-1: OAuth tokens stored in PG encrypted ONLY (DR-72, INV-15-5, CF-229)
  IR-194-2: Tokens never written to ES, Redis, or logs
  IR-194-3: PKCE code verifier generated per auth session — never reused
  IR-194-4: Token refresh scheduled before expiry (not on-demand)
  IR-194-5: Connector credentials never cross tenant boundary (CF-234, INV-15-10)
  IR-194-6: tenantId on all PG token records + RLS enforced
  IR-194-7: Connector capabilities validated against F510 catalog before token store
  IR-194-8: IOAuthConnectorService resolved via CreateAsync()

QUALITY GATES:
  QG-194-1: OAuth token refresh race condition handled (ST-112)
  QG-194-2: Token encryption verified at PG column level (not application-level only)
  QG-194-3: PKCE verifier collision probability < 1 in 2^128
  QG-194-4: Cross-tenant connector credential read returns DataProcessResult.Failure
  QG-194-5: Token expiry handled gracefully — service retries with refreshed token
  QG-194-6: Revoked connector tokens cleaned up within 1 TTL window
```

---

## TASK TYPE: T195 — Data Mapping Transform Gate
```
TASK TYPE:          T195
ARCHETYPE:          TRANSFORM
ENTRY:              Fires before any feed pushes to external system
PURPOSE:            Transforms form entry Dictionary to target system payload format
                    via ES mapping rules. AI-assisted mapping suggestion.
DISTINCT FROM:      T181 (Field Normalization — internal form normalization)
                    T171 (DWH Raw-to-Staging — warehouse transform zones)

FACTORY DEPENDENCIES:
  F512 IDataMappingService   — mapping rules + AI suggestions + transform

FABRIC RESOLUTION:
  F512 → DATABASE FABRIC (ES mapping rules) + AI ENGINE FABRIC

IRON RULES:
  IR-195-1: Mapping rules loaded from ES — never hardcoded (DR-68 pattern for mappings)
  IR-195-2: Transform output is Dictionary — no typed CRM/Webhook payload class
  IR-195-3: AI mapping suggestions via IAiProvider.GenerateAsync()
  IR-195-4: Mapping validated BEFORE push to external system (CF-230)
  IR-195-5: tenantId on all mapping rule lookups
  IR-195-6: Missing required target field returns DataProcessResult.Failure
  IR-195-7: Mapping is idempotent — same input always produces same output
  IR-195-8: IDataMappingService resolved via CreateAsync()

QUALITY GATES:
  QG-195-1: All standard data types mapped correctly (string, date, number, bool, array)
  QG-195-2: AI suggestion produces valid mapping for 90%+ of standard form→CRM combos
  QG-195-3: Missing required target field detected before external API call
  QG-195-4: Mapping idempotency verified across 1000 transform runs
  QG-195-5: Mapping performance < 5ms per entry transformation
  QG-195-6: Mapping version tracked — rollback to previous version supported
```

---

## TASK TYPE: T196 — File Upload Security Gate
```
TASK TYPE:          T196
ARCHETYPE:          VALIDATION
ENTRY:              Fires from QUEUE FABRIC after file upload complete
PURPOSE:            Virus scans uploaded file, quarantines on threat detection,
                    marks clean for signed URL generation.
DISTINCT FROM:      T183 (Anti-Spam — submission-level, not file-level)
                    T489 (Signed URL — post-scan, not scan itself)

FACTORY DEPENDENCIES:
  F487 IFileUploadService   — file metadata
  F488 IVirusScanService    — async scan queue
  F489 ISignedUrlService    — post-clean URL generation

FABRIC RESOLUTION:
  F487 → DATABASE FABRIC (ES meta) + CORE FABRIC (storage)
  F488 → AI ENGINE FABRIC + QUEUE FABRIC
  F489 → CORE FABRIC (Auth) + DATABASE FABRIC (Redis TTL)

IRON RULES:
  IR-196-1: Signed URL generation ONLY after MarkClean (DR-73, INV-15-6, CF-235)
  IR-196-2: Scan via QUEUE FABRIC — never inline in upload handler
  IR-196-3: Quarantine applied immediately on threat detection
  IR-196-4: File metadata stored as Dictionary {fileId, status, mimeType, sizeBytes}
  IR-196-5: tenantId on all file metadata and scan job records
  IR-196-6: Scan timeout = BUILD FAILURE if IVirusScanService not called before URL
  IR-196-7: Scan result includes {status, threats[], scanJobId} as Dictionary
  IR-196-8: IVirusScanService resolved via CreateAsync()

QUALITY GATES:
  QG-196-1: Scan queue saturation handled gracefully (ST-113)
  QG-196-2: Quarantined file inaccessible — signed URL returns DataProcessResult.Failure
  QG-196-3: Clean file URL TTL configurable per form (FREEDOM config)
  QG-196-4: Scan handles all common MIME types (pdf, docx, xlsx, jpg, png, zip)
  QG-196-5: Malicious zip extraction (zip bomb) detected and quarantined
  QG-196-6: Scan result queryable by fileId + tenantId
```

---

## TASK TYPE: T197 — Entry Export Gate
```
TASK TYPE:          T197
ARCHETYPE:          ACTIVATION
ENTRY:              Fires when admin requests entry export
PURPOSE:            Exports form entries to CSV/JSON/XLSX asynchronously.
                    Applies tenant-scoped filter. Generates secure download link.
DISTINCT FROM:      T177 (Reverse ETL Activation — outbound to SaaS, not export)
                    T486 (Export Service — the service itself)

FACTORY DEPENDENCIES:
  F486 IEntryExportService   — async export job + download
  F489 ISignedUrlService     — secure download link

FABRIC RESOLUTION:
  F486 → DATABASE FABRIC (PG) + QUEUE FABRIC
  F489 → CORE FABRIC (Auth) + DATABASE FABRIC (Redis TTL)

IRON RULES:
  IR-197-1: Export runs async via QUEUE FABRIC — never synchronous large query
  IR-197-2: Export filter always includes tenantId (DNA-5) — no cross-tenant data
  IR-197-3: Export file delivered via signed URL (F489) — not direct download
  IR-197-4: Export format (csv/json/xlsx) resolved via FREEDOM config
  IR-197-5: Export job status queryable by exportJobId + tenantId
  IR-197-6: Export result as Dictionary {exportJobId, status, downloadUrl, expiresAt}
  IR-197-7: Export file deleted after signed URL TTL expires
  IR-197-8: IEntryExportService resolved via CreateAsync()

QUALITY GATES:
  QG-197-1: 1M entry export completes within 5 minutes
  QG-197-2: Export file format validated against schema (no malformed CSV)
  QG-197-3: Cross-tenant filter bypass returns DataProcessResult.Failure
  QG-197-4: Download URL expires correctly at configured TTL
  QG-197-5: Concurrent exports (same form, different admins) isolated correctly
  QG-197-6: Export resumes correctly after QUEUE FABRIC restart
```

---

## TASK TYPE: T198 — Form Tenant Provision Gate
```
TASK TYPE:          T198
ARCHETYPE:          PROVISIONING
ENTRY:              Fires when new tenant is onboarded to form platform
PURPOSE:            Provisions tenant form space: ES namespacing, PG RLS policies,
                    Redis key prefixes, connector credential isolation.
DISTINCT FROM:      T167 (Connector Registration — DWH connector, not form tenant)
                    T178 (Warehouse Tenant Provision — DWH, not forms)

FACTORY DEPENDENCIES:
  F514 IFormTenantIsolationService  — full tenant provision
  F466 IFormSchemaService           — tenant ES index setup
  F482 IEntryPersistenceService     — tenant entry index setup
  F511 IOAuthConnectorService       — connector credential isolation

FABRIC RESOLUTION:
  F514 → CORE FABRIC + MT ISOLATION FABRIC (Skill 11) + DATABASE FABRIC (PG RLS)
  F466 → DATABASE FABRIC (Elasticsearch)
  F482 → DATABASE FABRIC (ES + PG)
  F511 → DATABASE FABRIC (PG encrypted)

IRON RULES:
  IR-198-1: Inherits FLOW-08 MT model + FLOW-14 warehouse MT model (DR-75)
  IR-198-2: ES form schema index namespaced per tenant (CF-232)
  IR-198-3: PG RLS policies applied for entry reads/writes (CF-233)
  IR-198-4: Connector credentials isolated per tenant at PG level (CF-234)
  IR-198-5: Redis key prefix registered for tenant (no key collision risk)
  IR-198-6: Provision failure rolls back — no partial tenant state
  IR-198-7: tenantId on all provisioning records (obviously DNA-5)
  IR-198-8: IFormTenantIsolationService resolved via CreateAsync()

QUALITY GATES:
  QG-198-1: Provision completes in < 500ms (all 5 isolation planes)
  QG-198-2: Cross-tenant schema read returns DataProcessResult.Failure post-provision
  QG-198-3: PG RLS policy blocks cross-tenant entry read at DB level
  QG-198-4: Connector credential isolation verified (ST-114)
  QG-198-5: Provision idempotent — re-provisioning same tenant = no-op
  QG-198-6: Deprovision cleans all 5 isolation planes completely
```

---

## FLOW TEMPLATES (36–38)

### Template 36 — form-submission-pipeline-v1
```json
{
  "template_id": "tpl-36",
  "name": "form-submission-pipeline-v1",
  "description": "Full submission pipeline from intake through persistence, notification, and feeds",
  "version": "1.0",
  "flow_definition": {
    "steps": [
      {
        "id": "step-1",
        "task_type": "T180",
        "factory": "F478",
        "fabric": "QUEUE_FABRIC+DATABASE_FABRIC(Redis)",
        "next": "step-2",
        "on_failure": "dlq"
      },
      {
        "id": "step-2",
        "task_type": "T181",
        "factory": "F479",
        "fabric": "CORE_FABRIC(ObjectProcessor)",
        "next": "step-3",
        "on_failure": "dlq"
      },
      {
        "id": "step-3",
        "task_type": "T182",
        "factory": "F480",
        "fabric": "DATABASE_FABRIC(ES)+RAG_FABRIC",
        "next": "step-4",
        "on_failure": "reject-with-errors"
      },
      {
        "id": "step-4",
        "task_type": "T183",
        "factory": "F481",
        "fabric": "AI_ENGINE_FABRIC+DATABASE_FABRIC(Redis)",
        "next": "step-5",
        "on_failure": "reject-spam"
      },
      {
        "id": "step-5",
        "task_type": "T184",
        "factory": "F482",
        "fabric": "DATABASE_FABRIC(ES+PG)",
        "next": "step-6",
        "on_failure": "dlq"
      },
      {
        "id": "step-6",
        "task_type": "T186",
        "factory": "F494+F495",
        "fabric": "QUEUE_FABRIC+DATABASE_FABRIC(ES)",
        "next": "step-7",
        "on_failure": "dlq"
      },
      {
        "id": "step-7",
        "task_type": "T187",
        "factory": "F499",
        "fabric": "QUEUE_FABRIC+DATABASE_FABRIC(PG)",
        "next": null,
        "on_failure": "dlq-with-retry"
      }
    ]
  }
}
```

### Template 37 — recipe-execution-v1
```json
{
  "template_id": "tpl-37",
  "name": "recipe-execution-v1",
  "description": "Automation recipe lifecycle: definition → trigger evaluation → step execution → retry",
  "version": "1.0",
  "flow_definition": {
    "steps": [
      {
        "id": "step-1",
        "task_type": "T190",
        "factory": "F504+F505",
        "fabric": "DATABASE_FABRIC(ES)+FLOW_ENGINE_FABRIC",
        "next": "step-2"
      },
      {
        "id": "step-2",
        "task_type": "T191",
        "factory": "F505+F509",
        "fabric": "QUEUE_FABRIC+DATABASE_FABRIC(ES+Redis)",
        "next": "step-3"
      },
      {
        "id": "step-3",
        "task_type": "T192",
        "factory": "F506+F507",
        "fabric": "QUEUE_FABRIC+DATABASE_FABRIC(ES+PG)",
        "next": null,
        "on_failure": "step-4"
      },
      {
        "id": "step-4",
        "task_type": "T193",
        "factory": "F508",
        "fabric": "QUEUE_FABRIC(DLQ)+DATABASE_FABRIC(PG)",
        "next": null
      }
    ]
  }
}
```

### Template 38 — connector-auth-integration-v1
```json
{
  "template_id": "tpl-38",
  "name": "connector-auth-integration-v1",
  "description": "Connector OAuth setup → data mapping → webhook/feed dispatch",
  "version": "1.0",
  "flow_definition": {
    "steps": [
      {
        "id": "step-1",
        "task_type": "T194",
        "factory": "F511+F510",
        "fabric": "DATABASE_FABRIC(PG-encrypted)+CORE_FABRIC(HTTP)",
        "next": "step-2"
      },
      {
        "id": "step-2",
        "task_type": "T195",
        "factory": "F512",
        "fabric": "DATABASE_FABRIC(ES)+AI_ENGINE_FABRIC",
        "next": "step-3"
      },
      {
        "id": "step-3",
        "task_type": "T188",
        "factory": "F500+F499",
        "fabric": "QUEUE_FABRIC+CORE_FABRIC(HTTP)",
        "next": null,
        "on_failure": "dlq-with-retry"
      }
    ]
  }
}
```

---

## BACKWARD COMPATIBILITY VERIFICATION

```
T1-T178:    UNCHANGED ✅  (no modifications to pre-existing task types)
Templates 1-35: UNCHANGED ✅
New archetypes do NOT modify existing archetype definitions
AUTHORING:     New — does not conflict with PROVISIONING or INGESTION
PERSISTENCE:   New — does not conflict with existing archetypes
NOTIFICATION:  New — does not conflict with ACTIVATION or FEED_EXECUTION
FEED_EXECUTION: New — does not conflict with ORCHESTRATION
```

---

## SAVE POINT: FLOW15:P3:TASK_TYPES ✅
## Recovery: "Load 21_-_forms_and_flows_TASK_TYPES_CATALOG — T179-T198 complete"
