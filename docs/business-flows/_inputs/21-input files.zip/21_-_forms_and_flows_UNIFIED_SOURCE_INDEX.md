# UNIFIED SOURCE INDEX — FLOW-15: Forms & Flow Automation Builder
## Extends UNIFIED_SOURCE_INDEX_MERGED.md
## Backward Compatible: DD-1-DD-85, all prior concept maps UNCHANGED
## Save Point: FLOW15:P6:UNIFIED_INDEX ✅

---

## OVERVIEW

```
NEW DESIGN DECISIONS:  DD-86-DD-97 (12 decisions)
CONCEPT MAPS:          Forms platform, submission pipeline, recipe engine, connector SDK
DOMAIN:                Forms authoring + submission + automation + connectors + MT
STARTING IDs:          DD-86, SK-99 (see SKILLS_FACTORY_RAG for full SK list)
```

---

## DESIGN DECISIONS (DD-86–DD-97)

### DD-86 — Why Form Schemas Stored in Elasticsearch (Not PostgreSQL)
```
DECISION ID:    DD-86
QUESTION:       Should FormSchema definitions be stored in ES or PG?
DECISION:       Elasticsearch (DATABASE FABRIC, ES provider)
RATIONALE:
  1. Dynamic field catalog: forms have variable numbers of fields with schema-per-form.
     PG requires ALTER TABLE for schema changes — ES handles arbitrary JSON natively.
  2. Full-text search: form builder needs to search schemas by field label, type, tags.
  3. DNA-1 alignment: FormSchema is a Dictionary — ES stores it without schema migration.
  4. Nested conditional rules: ES handles nested JSON objects efficiently.
  5. Render spec generation: AF-4 RAG searches form schemas — ES is the RAG fabric backend.

TRADE-OFF:
  ES is not ACID transactional. PG is used for version history (F469) where
  sequence guarantees matter. ES for current schema + PG for audit = hybrid approach.

ALTERNATIVE CONSIDERED:
  PG with JSONB — rejected because schema search complexity and AI indexing requirements
  favor ES. Version history specifically uses PG (DR-66 pattern).

DNA COMPLIANCE:
  DNA-1: Stored as Dictionary — ES natively handles this
  DNA-5: tenantId as ES routing key for tenant isolation
```

### DD-87 — Why Submission Pipeline Uses Stage-Gate Queue Pattern
```
DECISION ID:    DD-87
QUESTION:       Should submission processing be synchronous (inline) or stage-gate queue?
DECISION:       Stage-gate queue pattern via QUEUE FABRIC (Redis Streams)
RATIONALE:
  1. Decoupling: Each stage (intake, normalize, validate, spam, persist) can fail
     and retry independently without blocking the HTTP response.
  2. Throughput: 10k concurrent submissions (ST-105) cannot be handled synchronously.
     Queue backpressure manages load without dropping submissions.
  3. Idempotency: Stage gates with dedup keys (F478) handle at-least-once delivery.
  4. Observability: Each stage emits events — full pipeline visibility in QUEUE FABRIC.
  5. Recovery: DLQ per stage — submission stuck at validation can be replayed
     after admin fixes the form schema, without losing other submissions.

TRADE-OFF:
  Latency: End-to-end pipeline is 100-500ms vs 10ms synchronous.
  Acceptable: user sees 202 Accepted immediately (IR-180-3).

ALTERNATIVE CONSIDERED:
  Synchronous pipeline — rejected because ST-105 throughput and resilience
  requirements cannot be met with blocking request/response.
```

### DD-88 — Why Anti-Spam Is a Fabric Service (Not Middleware)
```
DECISION ID:    DD-88
QUESTION:       Should anti-spam be middleware in the HTTP request pipeline or a fabric service?
DECISION:       Dedicated QUEUE FABRIC service stage (IAntiSpamService via F481)
RATIONALE:
  1. DR-67: Anti-spam is a composite gate (honeypot + reCAPTCHA + AI scoring).
     Each layer has different latency characteristics — inline middleware blocks the thread.
  2. AI scoring (IAiProvider.GenerateAsync) has variable latency (100ms-2s).
  3. Rate limiting state (Redis) needs to be shared across all instances.
  4. Testability: Fabric service is independently testable + replaceable (DNA-4 pattern).
  5. FREEDOM config: Spam threshold, AI model, reCAPTCHA key — all admin-configurable
     in ES FREEDOM layer, not in middleware config files.

ALTERNATIVE CONSIDERED:
  ASP.NET middleware filter — rejected because AI scoring latency + shared state
  requirements cannot be met in synchronous middleware pattern.
```

### DD-89 — Why Partial Entries Use Redis→PG Two-Phase Store
```
DECISION ID:    DD-89
QUESTION:       Should partial entries (save & continue) go directly to PG or Redis first?
DECISION:       Redis with TTL for active partial entries → PG on completion (DR-74)
RATIONALE:
  1. Performance: Save-and-continue happens on every wizard step advance.
     ES/PG writes on every step = unnecessary I/O for most forms that complete in session.
     Redis writes are sub-millisecond.
  2. Memory efficiency: Incomplete forms that are never completed should not
     permanently occupy PG. Redis TTL (48h) automatically evicts abandoned partials.
  3. Isolation: Active session state (Redis) vs completed entry data (PG/ES) are
     different operational concerns with different access patterns.
  4. PG as source of truth: Promoted entries in PG are immutable — edit collisions prevented.

TRADE-OFF:
  Redis TTL expiry loses partially filled forms. Mitigated by 48h window + notification
  to user. Default TTL configurable via FREEDOM config.
```

### DD-90 — Why Notification Templates Use Merge Tags + AI Resolver (Not Handlebars)
```
DECISION ID:    DD-90
QUESTION:       Should notification templates use Handlebars/Mustache or a custom merge-tag resolver?
DECISION:       Custom merge-tag resolver (IMergeTagResolverService F493) with AI fallback (DR-69)
RATIONALE:
  1. DNA-1 alignment: Handlebars compiles templates into typed model accessors.
     {{entry.submitterName}} requires typed object — violates DNA-1.
     Merge tag resolver works with Dictionary<string,object> natively.
  2. Extensibility: New form fields = new merge tags at runtime, no recompile needed.
  3. AI fallback: Novel tags handled by IAiProvider.GenerateAsync() — Handlebars cannot.
  4. FREEDOM config: Template bodies stored in ES — admin can add new templates
     without deployment.

ALTERNATIVE CONSIDERED:
  Handlebars.NET — rejected: DNA-1 typed model requirement + AI extension requirement.
  Liquid templates — same rejection reason.
```

### DD-91 — Why Feed Execution Is Idempotent-First (vs At-Most-Once)
```
DECISION ID:    DD-91
QUESTION:       Should feed execution be at-most-once (skip duplicates) or at-least-once with idempotency?
DECISION:       At-least-once delivery + idempotency key guard (DR-70, SK-102)
RATIONALE:
  1. QUEUE FABRIC (Redis Streams) guarantees at-least-once delivery by design.
  2. At-most-once loses messages on consumer crash — data loss unacceptable for CRM feeds.
  3. CRM, webhook, and mailing list integrations are naturally idempotent with a dedup key.
  4. Redis idempotency key is cheap (single GET) vs cost of lost CRM contacts
     or duplicate invoices.

TRADE-OFF:
  Redis key TTL window: if event replayed after key TTL expiry, feed executes again.
  Default: 30-day TTL configurable via FREEDOM config.
```

### DD-92 — Why Recipe DAG Is an ES Document (Reuses Flow Engine Pattern)
```
DECISION ID:    DD-92
QUESTION:       Should automation recipes be stored as PG records, code, or ES documents?
DECISION:       ES document — same pattern as FLOW ENGINE FABRIC (Skill 09, DR-71)
RATIONALE:
  1. Admin-configurable: Recipes are FREEDOM layer constructs. No deployment to add/modify.
  2. Pattern consistency: Flow orchestrator (Skill 09) already reads DAG from ES.
     Recipes follow identical pattern — code reuse, consistent mental model.
  3. Search: Admin needs to find recipes by trigger event, step type, connector.
  4. Versioning: F469 versioning service reused for recipe version history.

ALTERNATIVE CONSIDERED:
  PG with JSONB DAG — rejected in favor of ES pattern consistency with Skill 09.
  Code-generated recipes — rejected (violates FREEDOM principle, requires deployment).
```

### DD-93 — Why Connector OAuth Tokens Are PG-Only (Encryption at Rest Requirement)
```
DECISION ID:    DD-93
QUESTION:       Where should OAuth access/refresh tokens be stored?
DECISION:       PostgreSQL with column-level encryption exclusively (DR-72, CF-229)
RATIONALE:
  1. ES stores plaintext by default — tokens in ES = searchable secrets = security failure.
  2. Redis is ephemeral — token loss on eviction = broken integration.
  3. PG supports column-level AES-256 encryption (pgcrypto) + TLS at rest.
  4. Combined with RLS (CF-234), provides strongest isolation in stack.
  5. PG audit log tracks token lifecycle (created, refreshed, revoked).

ALTERNATIVE CONSIDERED:
  HashiCorp Vault — valid for enterprise, adds external dependency.
  Available as FREEDOM config override — default remains PG encrypted.
```

### DD-94 — Why File Scan Is a QUEUE FABRIC Step (Not Inline)
```
DECISION ID:    DD-94
QUESTION:       Should virus scanning run inline during upload or as async queue step?
DECISION:       Async QUEUE FABRIC step (SK-106, T196)
RATIONALE:
  1. Scan latency: External scan services (ClamAV, VirusTotal) have variable latency
     (100ms-10s). Inline scan blocks upload response for full scan duration.
  2. Throughput: ST-113 — 1,000 simultaneous uploads. Queue-based = controlled concurrency.
  3. Quarantine-first: Files quarantined on upload regardless of scan result.
     No race condition — scan cannot complete before quarantine is set.
  4. Retry: QUEUE FABRIC retries automatically on scan service unavailability.

ALTERNATIVE CONSIDERED:
  Inline synchronous scan — rejected due to latency + throughput (ST-113).
  Hash-based known-malware check (fast, inline) as pre-filter — valid FREEDOM config option.
```

### DD-95 — Why Conditional Logic Is an ES Rule Document (Admin-Configurable FREEDOM)
```
DECISION ID:    DD-95
QUESTION:       Should form conditional logic (show/hide/require) be in code or configuration?
DECISION:       ES rule documents evaluated at runtime (DR-68, SK-109)
RATIONALE:
  1. FREEDOM principle: Conditional logic must be admin-configurable without deployment.
  2. AI assist: F468 can suggest conditional rules during authoring — AI-generated rules
     stored in ES, not compiled into service code.
  3. DNA-1: Conditions as Dictionary — typed ConditionalRule class violates DNA-1.
  4. Testability: ES rule documents testable without running full service.
  5. Versioning: Rule versions tracked in ES — rollback available (F469 pattern).

ALTERNATIVE CONSIDERED:
  Expression language (JEXL) compiled into service — rejected. Dynamic expression eval
  has security implications. Rule Dictionary with supported operators is safer.
```

### DD-96 — Why Forms MT Isolation Inherits FLOW-08 Model (Not Reinvented)
```
DECISION ID:    DD-96
QUESTION:       Should FLOW-15 define its own MT isolation model or inherit from FLOW-08?
DECISION:       Inherit FLOW-08 MT model + FLOW-14 warehouse MT extensions (DR-75)
RATIONALE:
  1. Consistency: Tenants expect identical isolation guarantees across all features.
  2. Proven: FLOW-08 MT model stress-tested — proven patterns should be reused.
  3. Complexity: Building new MT isolation introduces new failure modes.
     F514 as thin adaptation layer on Skill 11 = minimal safe approach.
  4. FLOW-14 warehouse MT (F461) provides PG RLS patterns directly applicable
     to forms entry tables — reuse DR-65 patterns.

TRADE-OFF:
  Inheritance means forms MT is constrained by FLOW-08 design decisions.
  If FLOW-08 MT model changes, forms isolation must be reviewed.
  Mitigated by explicit DR-75 reference in F514 documentation.
```

### DD-97 — Why AI-Assisted Form Authoring Goes Through AI ENGINE FABRIC
```
DECISION ID:    DD-97
QUESTION:       Should F474 (IAiFormAssistService) call OpenAI/Claude directly or via fabric?
DECISION:       AI ENGINE FABRIC (IAiProvider + AiDispatcher via Skills 06/07)
RATIONALE:
  1. Provider agnosticism: operator may use Claude, GPT-4, or Gemini — direct import = lock-in.
  2. Cost control: AiDispatcher routes to cheapest model meeting quality threshold.
  3. Multi-model consensus: F474.GenerateSchema() benefits from AF-5 multi-model comparison.
  4. Rate limiting: IAiProvider manages rate limits, retries, fallbacks.
  5. AF station integration: AF-1 (Genesis) and AF-11 (Feedback) track usage for cost/quality.

VIOLATION:
  var client = new OpenAIClient(apiKey);                         // ← FAIL: direct import
  var result = await client.GetChatCompletions(model, messages); // ← FAIL

CORRECT:
  var result = await _aiProvider.GenerateAsync(prompt);          // via IAiProvider (fabric)
```

---

## CONCEPT MAPS

### Concept Map 1 — Forms Platform Architecture (FLOW-15 Full View)
```
FORMS PLATFORM OVERVIEW

  ┌─────────────────────────────────────────────────────────────────┐
  │  FORM BUILDER UI (fabric-first render spec — SK-107)            │
  │  Platform-agnostic: web / mobile / admin = same ES render spec  │
  │  F471: IFormRenderSpecService → ES                              │
  └──────────────────────┬──────────────────────────────────────────┘
                         │ FORM_SCHEMA_PUBLISHED (QUEUE FABRIC)
  ┌──────────────────────▼──────────────────────────────────────────┐
  │  FORM SCHEMA LAYER (Family 60)                                  │
  │  F466 IFormSchemaService    → ES (current schema)               │
  │  F467 IFieldDefinitionService → ES (field catalog)              │
  │  F468 IConditionalLogicService → ES rules + AI ENGINE FABRIC    │
  │  F469 IFormVersioningService → PG (version history)             │
  │  F470 IFormPublishService   → QUEUE FABRIC + ES                 │
  │  F474 IAiFormAssistService  → AI ENGINE FABRIC (Skill 06/07)    │
  └──────────────────────┬──────────────────────────────────────────┘
                         │ FORM_SUBMITTED (QUEUE FABRIC)
  ┌──────────────────────▼──────────────────────────────────────────┐
  │  SUBMISSION PIPELINE (Families 62-63, Template 36)              │
  │  Stage 1: F478 ISubmissionIntakeService → QUEUE + Redis dedup   │
  │  Stage 2: F479 IFieldNormalizerService  → CORE (ObjectProcessor)│
  │  Stage 3: F480 ISubmissionValidatorService → ES rules + RAG     │
  │  Stage 4: F481 IAntiSpamService         → AI + Redis RL         │
  │  Stage 5: F482 IEntryPersistenceService → ES primary + PG audit │
  │  Stage 6: F483 IConfirmationService     → QUEUE + ES templates  │
  │  Alt:     F484 IPartialEntryService     → Redis TTL → PG        │
  └──────┬────────────────────────────────────┬───────────────────-─┘
         │ ENTRY_PERSISTED                    │ ENTRY_PERSISTED
  ┌──────▼──────────┐              ┌──────────▼──────────────────────┐
  │ NOTIFICATIONS   │              │  INTEGRATION FEEDS              │
  │ (Family 64)     │              │  (Family 65)                    │
  │ F492 Templates  │              │  F497 Feed Definition           │
  │ F493 MergeTag   │              │  F498 Feed Conditions           │
  │ F494 Router     │              │  F499 Feed Executor (idempotent)│
  │ F495 Delivery   │              │  F500 Webhook Feed              │
  │   → email/SMS   │              │  F501 CRM Feed                  │
  │   → push        │              │  F502 Mailing List Feed         │
  └─────────────────┘              │  F503 Payment Feed              │
                                   └─────────────────────────────────┘
```

### Concept Map 2 — Automation Recipe Engine
```
RECIPE ENGINE FLOW (FLOW-15, Families 66-67, Template 37)

  EVENT SOURCE (any fabric event)
         │
  ┌──────▼────────────────────────────┐
  │  F505 IRecipeTriggerService       │
  │  QUEUE FABRIC + ES trigger index  │
  │  → evaluates: which recipe fires? │
  └──────┬────────────────────────────┘
         │ RECIPE_TRIGGERED
  ┌──────▼────────────────────────────┐
  │  F504 IRecipeDefinitionService    │
  │  DATABASE FABRIC (ES — DAG doc)   │
  │  → loads recipe DAG (DD-92)       │
  │  → same pattern as Skill 09       │
  └──────┬────────────────────────────┘
         │ steps[]
  ┌──────▼────────────────────────────┐
  │  F506 IRecipeStepResolverService  │
  │  ES + FLOW ENGINE FABRIC          │
  │  → resolves each step to factory  │
  └──────┬────────────────────────────┘
         │ STEP_EXECUTE
  ┌──────▼────────────────────────────┐
  │  F507 IRecipeExecutionService     │
  │  QUEUE FABRIC + PG run state      │
  │  → executes step                  │
  │  → if fail → DLQ → F508 retry     │
  │  → idempotency: F509 Redis key    │
  └──────┬────────────────────────────┘
         │ RECIPE_COMPLETED / RECIPE_FAILED
  ┌──────▼────────────────────────────┐
  │  F513 IRunHistoryService          │
  │  DATABASE FABRIC (ES — immutable) │
  └───────────────────────────────────┘
```

### Concept Map 3 — Connector SDK & OAuth Flow
```
CONNECTOR INTEGRATION (Family 67, Template 38)

  ADMIN                  F510                   F511
  connects    ──────►  IConnectorDefinition  ──►  IOAuthConnectorService
  OAuth app            (ES catalog)               (PG encrypted tokens — DD-93)
                                                   ↓
                                             PKCE flow via CORE FABRIC
                                             (SK-104 pattern)
                                                   ↓
                                             TOKEN_STORED (PG, RLS-protected)

  RECIPE STEP    ──────► F512 IDataMappingService  (ES mapping + AI ENGINE FABRIC)
  (e.g., CRM push)            ↓
                       mapped Dictionary<string,object>
                              ↓
                       F501/F500/F502 Feed Service → QUEUE FABRIC → external API
                              ↓
                       F509 IRecipeIdempotencyService → Redis dedup key check
                              ↓
                       F513 IRunHistoryService → ES run log (immutable — CF-229)
```

### Concept Map 4 — Submission Pipeline Stage Gates
```
SUBMISSION PIPELINE DETAIL (Template 36, DR-66)

  HTTP POST /submit
       │ 202 Accepted (immediate)
       ↓
  [Stage 1] F478 Intake ────── Redis dedup key: hash(formId+fingerprint)
       │ INTAKE_COMPLETE
       ↓
  [Stage 2] F479 Normalize ─── CORE FABRIC ObjectProcessor
       │                        → Dictionary<string,object> (DNA-1)
       │ NORMALIZED
       ↓
  [Stage 3] F480 Validate ──── ES rule docs (SK-109)
       │                        + RAG FABRIC (similar form patterns)
       │ VALIDATED              → if FAIL → DLQ → admin review
       ↓
  [Stage 4] F481 Anti-Spam ─── honeypot check (fast, no I/O)
       │                        + reCAPTCHA verify (CORE FABRIC HTTP)
       │                        + AI scoring (AI ENGINE FABRIC)
       │ SPAM_CLEARED           → if SPAM → quarantine entry
       ↓
  [Stage 5] F482 Persist ───── ES primary index (searchable)
       │                        + PG audit log (immutable)
       │                        INV-15-1: PERSIST BEFORE EMIT
       │ ENTRY_PERSISTED ──────────────────────────────────────┐
       ↓                                                        ↓
  [Stage 6] F483 Confirm ──── email/redirect              F494 Router
                               to submitter               → feeds + notifications
```

### Concept Map 5 — Multi-Tenant Forms Isolation
```
MT ISOLATION FOR FORMS (Family 68, SK-110, DR-75)

  INHERITS:
  ├── FLOW-08 MT Model (tenant provisioning + scope isolation)
  ├── FLOW-14 PG RLS pattern (F461, F463 → reused for form entry tables)
  └── Skill 11: MT ISOLATION FABRIC

  F514 IFormTenantIsolationService

  Per-Tenant Isolated Artifacts:
  ├── Form Schemas          → ES: tenantId routing key (DNA-5)
  ├── Form Entries          → ES: tenantId field + PG RLS (CF-232)
  ├── Connector Credentials → PG: RLS row filter + column encryption (CF-234)
  ├── Notification Templates → ES: tenantId scope
  ├── Recipe DAGs            → ES: tenantId scope
  └── Partial Entries        → Redis: tenantId-prefixed keys

  Cross-Tenant Violations (= BUILD FAILURE):
  CF-232: Schema queries without tenantId filter
  CF-233: Entry reads without RLS policy active
  CF-234: Connector credentials accessed from wrong tenantId context
```

---

## SKILL INDEX (FLOW-15 additions — full patterns in SKILLS_FACTORY_RAG)

| Skill | Name | Pattern | AF-4 Trigger |
|-------|------|---------|--------------|
| SK-99 | Form Schema DAG Validation | ES schema integrity check | "form schema", "field validation" |
| SK-100 | Submission Pipeline Stage-Gate | Intake→validate→persist via queue | "submission", "pipeline", "stage gate" |
| SK-101 | Merge-Tag Resolver with AI Fallback | Dictionary-based template eval + AI | "merge tags", "notifications", "templates" |
| SK-102 | Feed Executor Idempotency | Redis key + PG run log | "feed", "idempotent", "integration" |
| SK-103 | Recipe DAG Execution | Adapts Skill 09 for recipe context | "recipe", "automation", "DAG" |
| SK-104 | Connector OAuth PKCE Flow | PKCE via Core Fabric | "OAuth", "connector", "auth" |
| SK-105 | Anti-Spam Composite Gate | Honeypot + reCAPTCHA + AI scoring | "spam", "security gate", "captcha" |
| SK-106 | File Upload Secure Pipeline | Upload→scan→sign→store | "file upload", "virus scan" |
| SK-107 | Fabric-First UI Spec | Render spec in ES, zero platform values | "UI spec", "fabric-first", "render" |
| SK-108 | Partial Entry Save-and-Continue | Redis TTL → PG promotion | "partial entry", "save continue", "wizard" |
| SK-109 | Conditional Logic Evaluator | ES rule doc → runtime eval | "conditional", "show/hide", "logic rules" |
| SK-110 | Multi-Tenant Forms Isolation | Schema + entry + connector scope | "multi-tenant", "forms isolation" |

---

## CONCEPT CROSS-REFERENCE TABLE

| Concept | Defined In | Used By | Related DRs |
|---------|-----------|---------|-------------|
| FormSchema | F466, DD-86 | F467-F471, T179, SK-99 | DR-68 |
| SubmissionPipeline | F478-F482, DD-87 | T180-T184, SK-100 | DR-66, DR-67 |
| AntiSpam Gate | F481, DD-88 | T183, SK-105 | DR-67 |
| PartialEntry | F484, DD-89 | T185, SK-108 | DR-74 |
| MergeTagResolver | F493, DD-90 | T186, SK-101 | DR-69 |
| FeedIdempotency | F499/F509, DD-91 | T187-T188, SK-102 | DR-70 |
| RecipeDAG | F504-F509, DD-92 | T190-T193, SK-103 | DR-71 |
| OAuthTokenStore | F511, DD-93 | T194, SK-104 | DR-72 |
| FileScanQueue | F488, DD-94 | T196, SK-106 | DR-73 |
| ConditionalLogicDoc | F468, DD-95 | T179, SK-109 | DR-68 |
| FormsMTIsolation | F514, DD-96 | T198, SK-110 | DR-75 |
| AIFormAssist | F474, DD-97 | T179 (AF-1), SK-99 | DR-68 |

---

## SAVE POINT: FLOW15:P6:UNIFIED_INDEX ✅
## Next: FLOW-16 DD-98+ | Reference this file for all FLOW-15 design decisions
