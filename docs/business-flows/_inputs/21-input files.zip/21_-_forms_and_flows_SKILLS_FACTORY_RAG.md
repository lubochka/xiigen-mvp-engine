# SKILLS FACTORY RAG — FLOW-15: Forms & Flow Automation Builder
## Extends SKILLS_FACTORY_RAG_MERGED.md
## Backward Compatible: SK-1-SK-98 UNCHANGED
## Save Point: FLOW15:P6:SKILLS ✅

---

## OVERVIEW

```
NEW SKILLS:  SK-99-SK-110 (12 patterns)
DOMAIN:      Forms authoring + submission pipeline + automation recipes + connectors
AF-4 RAG:    All patterns indexed for retrieval by RAG FABRIC (IRagService.SearchAsync())
```

---

## SK-99 — Form Schema DAG Validation Pattern

```
SKILL ID:       SK-99
NAME:           Form Schema DAG Validation
CATEGORY:       Validation / Schema
ARCHETYPE:      AUTHORING (T179)
FACTORIES:      F466, F467, F468, F469
FABRIC:         DATABASE FABRIC (ES) + AI ENGINE FABRIC

PATTERN DESCRIPTION:
  Validates form schema as a directed acyclic graph (DAG) of fields, pages,
  and conditional dependencies. Ensures no circular conditional dependencies
  (Field A visible if B, Field B visible if A = cycle).

REUSABLE PATTERN:
  // DNA-1: Schema as Dictionary
  var schema = await _formSchema.GetSchema(formId, tenantId);
  if (!schema.IsSuccess) return DataProcessResult<bool>.Failure(schema.Error);

  var fields = schema.Value["fields"] as List<Dictionary<string,object>>;
  var visited = new HashSet<string>();
  var inStack = new HashSet<string>();

  foreach (var field in fields)
  {
      var fieldId = field["fieldId"].ToString();
      if (HasCycle(fieldId, schema.Value, visited, inStack))
          return DataProcessResult<bool>.Failure("CIRCULAR_DEPENDENCY:" + fieldId);
  }
  return DataProcessResult<bool>.Success(true);

CYCLE DETECTION:
  DFS on field dependency graph (conditionalDependencies[] per field definition)
  O(V + E) where V = fields, E = conditional rules

AF-4 RETRIEVAL TRIGGER:
  Query: "form schema validation cycle detection DAG"
  Used by: AF-7 (Compliance check — conditional logic never compiled, DR-68)

DNA COMPLIANCE:
  DNA-1: Schema traversed as Dictionary — no FieldNode class
  DNA-3: Cycle detection returns DataProcessResult.Failure with cyclic field ID
  DNA-5: tenantId on schema retrieval
```

---

## SK-100 — Submission Pipeline Stage-Gate Pattern

```
SKILL ID:       SK-100
NAME:           Submission Pipeline Stage-Gate
CATEGORY:       Pipeline / Ordering
ARCHETYPE:      INGESTION → TRANSFORM → VALIDATION → PERSISTENCE (T180-T184)
FACTORIES:      F478, F479, F480, F481, F482
FABRIC:         QUEUE FABRIC (stage transitions) + multiple DATABASE FABRICs

PATTERN DESCRIPTION:
  Enforces strict stage ordering: intake → normalize → validate → anti-spam → persist.
  Each stage emits a completion event consumed by the next stage.
  Failure at any stage routes to DLQ — pipeline does not proceed.

STAGE-GATE SEQUENCE:
  SUBMISSION_RECEIVED
    → [T180: Intake Dedup]
  SUBMISSION_DEDUPED
    → [T181: Normalize]
  SUBMISSION_NORMALIZED
    → [T182: Validate]
  SUBMISSION_VALIDATED
    → [T183: Anti-Spam]
  SUBMISSION_CLEARED
    → [T184: Persist]
  ENTRY_PERSISTED
    → [T186: Notify | T187: Feed]

REUSABLE PATTERN:
  // DNA-3: Each stage returns DataProcessResult — never throws
  // DNA-5: tenantId flows through every stage event payload
  var intakeResult = await _intake.IntakeSubmission(raw, formId, tenantId);
  if (!intakeResult.IsSuccess) return intakeResult;  // DLQ routing

  // Emit stage event — next stage consumer handles normalization
  await _queue.EnqueueAsync("submission.deduped", new Dictionary<string,object>
  {
      ["submissionId"] = intakeResult.Value,
      ["tenantId"] = tenantId,
      ["formId"] = formId
  });

AF-4 RETRIEVAL TRIGGER:
  Query: "submission pipeline stage gate ordering queue"
  Used by: AF-2 (Planning — decompose pipeline into ordered stages)
           AF-7 (Compliance — CF-216, CF-219, CF-220 ordering rules)

DNA COMPLIANCE:
  DNA-3: Every stage returns DataProcessResult — pipeline never blocks on exception
  DNA-5: tenantId in every queue event payload
  DNA-4: Pipeline stages extend MicroserviceBase
```

---

## SK-101 — Merge Tag Resolver with AI Fallback

```
SKILL ID:       SK-101
NAME:           Merge Tag Resolver with AI Fallback
CATEGORY:       Notification / Template
ARCHETYPE:      NOTIFICATION (T186)
FACTORIES:      F492, F493
FABRIC:         DATABASE FABRIC (ES) + AI ENGINE FABRIC

PATTERN DESCRIPTION:
  Resolves notification template merge tags at runtime. Known tags resolved from
  entry data Dictionary. Unknown/dynamic tags fall back to AI for resolution.
  Never uses string.Replace() on typed model properties.

REUSABLE PATTERN:
  // DNA-1: No typed NotificationTemplate — template is Dictionary
  var template = await _templateService.GetTemplate(formId, eventType, channel, tenantId);
  var templateBody = template.Value["body"].ToString();

  // Extract tags: {submitterEmail}, {formTitle}, {customField}
  var tags = ExtractMergeTags(templateBody);

  var resolved = new Dictionary<string, string>();
  foreach (var tag in tags)
  {
      // Try entry data first (DNA-1: entry is Dictionary)
      if (entryData.TryGetValue(tag, out var value))
      {
          resolved[tag] = value?.ToString() ?? "";
      }
      else
      {
          // AI fallback via IAiProvider.GenerateAsync() — never direct LLM
          var aiResult = await _aiProvider.GenerateAsync(
              $"Resolve tag '{tag}' from context: {JsonSerializer.Serialize(entryData)}");
          resolved[tag] = aiResult.IsSuccess ? aiResult.Value : "[unresolved]";
      }
  }

  // Replace tags in template body
  var body = resolved.Aggregate(templateBody, (s, kv) => s.Replace($"{{{kv.Key}}}", kv.Value));
  return DataProcessResult<string>.Success(body);

AF-4 RETRIEVAL TRIGGER:
  Query: "merge tag template resolution AI notification"
  Used by: AF-1 (Genesis — generate INotificationTemplateService)
           AF-3 (Prompt Library — notification domain prompts)

DNA COMPLIANCE:
  DNA-1: Template and entry both as Dictionary — no typed Email/Notification class
  DNA-3: AI resolution failure returns DataProcessResult.Failure with missing-tag list
  DNA-5: tenantId on template lookup
```

---

## SK-102 — Feed Executor Idempotency (Redis Key + PG Log)

```
SKILL ID:       SK-102
NAME:           Feed Executor Idempotency
CATEGORY:       Integration / Feeds
ARCHETYPE:      FEED_EXECUTION (T187, T188)
FACTORIES:      F499, F509
FABRIC:         DATABASE FABRIC (Redis dedup + PG log) + QUEUE FABRIC

PATTERN DESCRIPTION:
  Guarantees at-most-once feed execution despite at-least-once QUEUE FABRIC delivery.
  Redis idempotency key checked before execution. PG run log records all outcomes.

REUSABLE PATTERN:
  // Step 1: Check idempotency key
  var idemKey = $"{tenantId}:idem:{feedId}:{entryId}";
  var isDuplicate = await _idempotency.CheckIdempotency(feedId, entryHash, tenantId);
  if (isDuplicate.IsSuccess && isDuplicate.Value)
      return DataProcessResult<string>.Failure("IDEMPOTENT_SKIP");

  // Step 2: Register key BEFORE execution (not after)
  await _idempotency.RegisterExecution(feedId, entryHash, runId, tenantId);

  // Step 3: Execute feed (CRM, webhook, etc.)
  var execResult = await _feedAdapter.Execute(feedPayload, tenantId);

  // Step 4: Record to PG run log regardless of outcome (DNA-3)
  await _runLog.LogRun(feedId, entryId, new Dictionary<string,object>
  {
      ["runId"] = runId,
      ["status"] = execResult.IsSuccess ? "success" : "failure",
      ["error"] = execResult.IsSuccess ? null : execResult.Error,
      ["tenantId"] = tenantId
  }, tenantId);

  return execResult;

KEY FORMAT:     SHA-256(feedId + entryId + tenantId) — not UUIDv4 (ST-115)

AF-4 RETRIEVAL TRIGGER:
  Query: "feed executor idempotency Redis key dedup at-least-once"
  Used by: AF-1 (Genesis — generate IFeedExecutorService)
           AF-9 (Judge — QG-187-1 CRM duplicate detection)

DNA COMPLIANCE:
  DNA-3: All outcomes (success, failure, idempotent skip) as DataProcessResult
  DNA-5: tenantId on Redis key and PG log
```

---

## SK-103 — Recipe DAG Execution (Adapts Skill 09 Flow Orchestrator)

```
SKILL ID:       SK-103
NAME:           Recipe DAG Execution
CATEGORY:       Automation / Orchestration
ARCHETYPE:      ORCHESTRATION (T191, T192)
FACTORIES:      F504, F505, F506, F507
FABRIC:         DATABASE FABRIC (ES DAG) + FLOW ENGINE FABRIC + QUEUE FABRIC

PATTERN DESCRIPTION:
  Adapts the FLOW ENGINE FABRIC (Skill 09 IFlowOrchestrator) pattern to automation
  recipes. Recipe DAG stored in ES. Each step emits a queue event.
  Execution state maintained in PG. Mirrors Template 36 step-event model.

RECIPE DAG STRUCTURE (ES document):
  {
    "recipeId": "uuid",
    "tenantId": "tenant-1",
    "trigger": {"eventType": "ENTRY_PERSISTED", "formId": "form-A"},
    "steps": [
      {"stepId": "s1", "type": "CRM_SYNC", "factory": "F501", "next": "s2"},
      {"stepId": "s2", "type": "SLACK_NOTIFY", "factory": "custom", "next": null}
    ],
    "conditions": {"s2": {"runIf": "s1.status == 'success'"}}
  }

EXECUTION PATTERN:
  // DNA-1: Recipe loaded as Dictionary
  var recipe = await _recipeDef.GetRecipe(recipeId, tenantId);
  var steps = recipe.Value["steps"] as List<Dictionary<string,object>>;
  var currentStepId = runState.Value["currentStepId"].ToString();
  var step = steps.First(s => s["stepId"].ToString() == currentStepId);

  // Resolve factory via CreateAsync() — DNA-4 pattern
  var factory = await _stepResolver.ResolveStep(step, context, tenantId);

  // Execute step, record result, advance
  var result = await factory.Execute(context);
  await _execService.AdvanceExecution(runId, tenantId);  // persist-before-event

AF-4 RETRIEVAL TRIGGER:
  Query: "recipe DAG execution Elasticsearch step orchestrator"
  Used by: AF-1 (Genesis — generate IRecipeExecutionService)
           AF-4 (RAG — Skill 09 pattern reference for DR-71)

DNA COMPLIANCE:
  DNA-1: Recipe and step state as Dictionary — no typed RecipeStep class
  DNA-3: Step failure returns DataProcessResult.Failure — triggers T193 (Retry)
  DNA-5: tenantId on all ES and PG operations
```

---

## SK-104 — Connector OAuth PKCE Flow via Core Fabric

```
SKILL ID:       SK-104
NAME:           Connector OAuth PKCE Flow
CATEGORY:       Connector / Authentication
ARCHETYPE:      PROVISIONING (T194)
FACTORIES:      F511, F510
FABRIC:         DATABASE FABRIC (PG encrypted) + CORE FABRIC (HTTP)

PATTERN DESCRIPTION:
  Implements OAuth 2.0 PKCE flow for connector authentication.
  Tokens stored in PG with column-level encryption. Never in ES or Redis.
  PG advisory lock prevents token refresh race.

PKCE FLOW:
  1. GenerateCodeVerifier() → cryptographic random 32-byte → base64url
  2. codeChallenge = SHA-256(codeVerifier) → base64url
  3. Redirect to OAuth provider with code_challenge + code_challenge_method=S256
  4. Provider redirects back with auth code
  5. ExchangeCode(code, codeVerifier) → access_token + refresh_token
  6. Store encrypted tokens in PG: AES-256 column encryption

TOKEN REFRESH PATTERN (ST-112 race prevention):
  // PG advisory lock prevents double-refresh race
  await _pg.ExecuteAsync("SELECT pg_advisory_xact_lock(hashtext(@lockKey))",
      new { lockKey = $"{connectorId}:{tenantId}" });

  // Re-check token freshness after acquiring lock
  var current = await _tokenStore.GetToken(connectorId, tenantId);
  if (current.ExpiresAt > DateTimeOffset.UtcNow.AddMinutes(5))
      return DataProcessResult<string>.Success(current.AccessToken);  // Another thread refreshed

  // Refresh with external OAuth server
  var refreshResult = await _httpClient.PostAsync(tokenEndpoint, refreshPayload);
  // ... store new tokens in PG

AF-4 RETRIEVAL TRIGGER:
  Query: "OAuth PKCE connector token refresh race lock"
  Used by: AF-8 (Security — token storage validation, CF-229)
           AF-1 (Genesis — generate IOAuthConnectorService)

DNA COMPLIANCE:
  DNA-3: OAuth exchange failure returns DataProcessResult.Failure
  DNA-5: tenantId on all PG token records + RLS enforced
  DNA-4: IOAuthConnectorService extends MicroserviceBase
```

---

## SK-105 — Anti-Spam Composite Gate (Honeypot + reCAPTCHA + AI Scoring)

```
SKILL ID:       SK-105
NAME:           Anti-Spam Composite Gate
CATEGORY:       Security / Validation
ARCHETYPE:      VALIDATION (T183)
FACTORIES:      F481
FABRIC:         AI ENGINE FABRIC + DATABASE FABRIC (Redis rate limit)

PATTERN DESCRIPTION:
  Three-layer composite spam check. Rate limit first (cheapest), then honeypot,
  then reCAPTCHA, then AI scoring (most expensive last).
  Each layer returns early on block — avoids unnecessary compute.

COMPOSITE GATE PATTERN:
  // Layer 1: Rate limit (Redis — cheapest, no AI cost)
  var rateLimited = await _antiSpam.IsRateLimited(visitorId, formId, tenantId);
  if (rateLimited.Value) return DataProcessResult<Dictionary>.Failure("RATE_LIMITED");

  // Layer 2: Honeypot (client-side hidden field check)
  var honeypot = normalized.TryGetValue("_hp_field", out var hpVal) && !string.IsNullOrEmpty(hpVal?.ToString());
  if (honeypot) return DataProcessResult<Dictionary>.Failure("HONEYPOT_TRIGGERED");

  // Layer 3: reCAPTCHA token verification (external API via CORE FABRIC HTTP)
  if (normalized.TryGetValue("recaptchaToken", out var token))
  {
      var captchaResult = await _captchaVerifier.Verify(token.ToString(), tenantId);
      if (!captchaResult.IsSuccess) return DataProcessResult<Dictionary>.Failure("CAPTCHA_FAILED");
  }

  // Layer 4: AI spam scoring (IAiProvider.GenerateAsync — most expensive, run last)
  var aiScore = await _aiProvider.GenerateAsync(spamClassificationPrompt + JsonSerializer.Serialize(normalized));
  var score = ParseSpamScore(aiScore.Value);  // 0.0-1.0

  return score > spamThreshold
      ? DataProcessResult<Dictionary>.Failure("SPAM_DETECTED:" + score)
      : DataProcessResult<Dictionary>.Success(new Dictionary<string,object> { ["score"] = score, ["blocked"] = false });

AF-4 RETRIEVAL TRIGGER:
  Query: "anti-spam honeypot reCAPTCHA AI scoring composite"
  Used by: AF-3 (Prompt Library — spam classification prompts)
           AF-8 (Security — spam gate before persist, DR-67)

DNA COMPLIANCE:
  DNA-1: Spam result as Dictionary {score, blocked, reason}
  DNA-3: Every layer returns DataProcessResult — no exceptions thrown
  DNA-5: tenantId on Redis rate limit key
```

---

## SK-106 — File Upload Secure Pipeline (Upload → Scan → Sign → Store)

```
SKILL ID:       SK-106
NAME:           File Upload Secure Pipeline
CATEGORY:       Security / File Handling
ARCHETYPE:      VALIDATION (T196)
FACTORIES:      F487, F488, F489, F490
FABRIC:         DATABASE FABRIC (ES meta) + AI ENGINE FABRIC + QUEUE FABRIC + CORE FABRIC

PATTERN DESCRIPTION:
  Complete file upload security pipeline: receive → quarantine → scan → sign → store.
  Signed URLs only generated after scan clears. Retention policy applied at store.

PIPELINE STAGES:
  STAGE 1: Upload Initiation (F487)
    file status = "quarantined" (never "available" before scan)

  STAGE 2: Virus Scan Enqueue (F488)
    scan job enqueued to QUEUE FABRIC (never inline)
    scan job ID returned immediately

  STAGE 3: Scan Complete (F488 consumer)
    scan result: {status: "clean|infected", threats: []}
    if infected: F488.Quarantine() — status = "infected", file access blocked
    if clean: F488.MarkClean() — status = "clean"

  STAGE 4: Signed URL Generation (F489)
    ONLY called after MarkClean() — enforced at service boundary (DR-73)
    URL TTL = FREEDOM config (default 24h)

  STAGE 5: Retention Policy (F490)
    Schedule deletion at retentionDays from upload date

REUSABLE PATTERN:
  // Step 1: Initiate + set quarantine status
  var upload = await _fileUpload.CompleteUpload(uploadId, metadata, tenantId);
  // status is "quarantined" — no URL yet

  // Step 2: Enqueue scan (QUEUE FABRIC — not inline)
  var scanJob = await _virusScan.EnqueueScan(upload.Value, tenantId);

  // Step 3 happens in scan consumer (separate service/step)
  // Step 4: After MarkClean (only reachable via scan-complete consumer)
  var url = await _signedUrl.GenerateSignedUrl(fileId, ttlSeconds, tenantId);

AF-4 RETRIEVAL TRIGGER:
  Query: "file upload virus scan signed URL quarantine pipeline"
  Used by: AF-8 (Security — CF-235, INV-15-6)
           AF-9 (Judge — IR-196-1, QG-196-1)

DNA COMPLIANCE:
  DNA-3: All pipeline stages return DataProcessResult — quarantine never throws
  DNA-5: tenantId on all file metadata records
```

---

## SK-107 — Fabric-First UI Spec (Render Spec in ES, Zero Platform Values)

```
SKILL ID:       SK-107
NAME:           Fabric-First UI Render Spec
CATEGORY:       UI / Fabric-First
ARCHETYPE:      AUTHORING (T179)
FACTORIES:      F471, F477
FABRIC:         DATABASE FABRIC (Elasticsearch — render spec store)

PATTERN DESCRIPTION:
  Form render specs stored in ES as platform-agnostic dictionaries.
  Zero platform-specific values: no React props, no SwiftUI modifiers,
  no HTML attributes. Client interprets abstract field types.

CORRECT RENDER SPEC (Fabric-First):
  {
    "formId": "form-A",
    "tenantId": "tenant-1",
    "pages": [
      {
        "pageId": "p1",
        "fields": [
          {
            "fieldId": "f1",
            "type": "TEXT_INPUT",          // abstract type, not <input type="text">
            "label": {"en": "Full Name"},
            "required": true,
            "maxLength": 100,
            "validation": "NON_EMPTY"      // abstract rule, not regex string
          },
          {
            "fieldId": "f2",
            "type": "EMAIL_INPUT",          // abstract, not <input type="email">
            "label": {"en": "Email"},
            "required": true
          }
        ]
      }
    ],
    "layout": "SINGLE_COLUMN",             // abstract layout token
    "theme": "DEFAULT"                     // abstract theme token
  }

VIOLATION (Platform-Specific — BUILD FAILURE):
  "component": "TextInput",          // React Native component name ← FAIL
  "style": {"marginTop": 16},        // React Native style prop ← FAIL
  "htmlAttributes": {"autocomplete": "email"}  // HTML attribute ← FAIL
  "swiftUIModifier": ".keyboardType(.emailAddress)"  // SwiftUI ← FAIL

AF-4 RETRIEVAL TRIGGER:
  Query: "fabric-first UI render spec platform-agnostic abstract"
  Used by: AF-7 (Compliance — zero platform values enforced)
           AF-1 (Genesis — generate IFormRenderSpecService)
           AF-9 (Judge — IR-179-4, QG-179-2)

DNA COMPLIANCE:
  DNA-1: Render spec as Dictionary — no typed RenderSpec<Platform> class
  DNA-5: tenantId on render spec ES document
  DNA-6: DynamicController serves render spec — no form-specific controller
```

---

## SK-108 — Partial Entry Save-and-Continue (Redis TTL → PG Promotion)

```
SKILL ID:       SK-108
NAME:           Partial Entry Save-and-Continue
CATEGORY:       Persistence / UX
ARCHETYPE:      PERSISTENCE (T185)
FACTORIES:      F484, F476
FABRIC:         DATABASE FABRIC (Redis TTL) + DATABASE FABRIC (PostgreSQL)

PATTERN DESCRIPTION:
  Two-phase partial entry storage: Redis for active session, PG on completion.
  Redis TTL ≤ 48h. Resume token is cryptographically random (not entryId).
  Promotion to PG on form complete. Deletion on TTL expiry (no orphans).

REUSABLE PATTERN:
  // SAVE: Redis with TTL
  var resumeToken = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
  var redisKey = $"{tenantId}:partial:{resumeToken}";
  var partialData = new Dictionary<string,object>
  {
      ["formId"] = formId,
      ["tenantId"] = tenantId,
      ["sessionId"] = sessionId,
      ["currentStep"] = currentStep,
      ["fieldValues"] = fieldValues  // Dictionary<string,object>
  };
  await _redis.SetAsync(redisKey, JsonSerializer.Serialize(partialData), TimeSpan.FromHours(48));

  // LOAD: Redis lookup with TTL check
  var raw = await _redis.GetAsync(redisKey);
  if (raw == null) return DataProcessResult<Dictionary>.Failure("PARTIAL_EXPIRED");

  // PROMOTE: On form complete — write to PG, delete Redis
  await _pg.InsertAsync("partial_entries_completed", partialData);
  await _redis.DeleteAsync(redisKey);  // Clean up Redis after promotion

  // PG schema: partial_entries_completed (tenantId, formId, entryId, fieldValues jsonb, completedAt)

TTL RULE:       48h Redis TTL is HARD maximum — never configurable above (DR-74, IR-185-2)
RESUME TOKEN:   32-byte cryptographic random — not guessable, not sequential

AF-4 RETRIEVAL TRIGGER:
  Query: "partial entry save continue Redis TTL PG promotion"
  Used by: AF-1 (Genesis — generate IPartialEntryService)
           AF-7 (Compliance — DR-74, IR-185-1)

DNA COMPLIANCE:
  DNA-1: Partial data as Dictionary — no typed PartialEntry class
  DNA-3: TTL expiry returns DataProcessResult.Failure (not null)
  DNA-5: tenantId on Redis key namespace + PG record
```

---

## SK-109 — Conditional Logic Evaluator (ES Rule Doc → Runtime Evaluation)

```
SKILL ID:       SK-109
NAME:           Conditional Logic Evaluator
CATEGORY:       Form Runtime / Rules Engine
ARCHETYPE:      AUTHORING (T179) + INGESTION (T180)
FACTORIES:      F468, F476
FABRIC:         DATABASE FABRIC (ES — rule docs) + AI ENGINE FABRIC

PATTERN DESCRIPTION:
  Evaluates show/hide/required conditional rules from ES documents at runtime.
  Rules never compiled into service code. AI can suggest rules in authoring mode.
  Evaluator processes rule Dictionary — no typed ConditionalRule class.

RULE DOCUMENT STRUCTURE (ES):
  {
    "formId": "form-A",
    "tenantId": "tenant-1",
    "rules": [
      {
        "ruleId": "r1",
        "targetFieldId": "f3",
        "action": "SHOW",
        "condition": {
          "fieldId": "f2",
          "operator": "EQUALS",
          "value": "Yes"
        }
      },
      {
        "ruleId": "r2",
        "targetFieldId": "f4",
        "action": "REQUIRE",
        "condition": {
          "operator": "AND",
          "conditions": [
            {"fieldId": "f1", "operator": "NOT_EMPTY"},
            {"fieldId": "f2", "operator": "EQUALS", "value": "Other"}
          ]
        }
      }
    ]
  }

EVALUATOR PATTERN:
  // DNA-1: rules loaded as Dictionary, fieldValues as Dictionary
  var rules = await _conditionalLogic.EvaluateRules(formId, fieldValues, tenantId);
  var results = new Dictionary<string,object>();  // {fieldId: {visible, required}}

  foreach (var rule in rules.Value["rules"] as List<Dictionary<string,object>>)
  {
      var matches = EvaluateCondition(rule["condition"] as Dictionary<string,object>, fieldValues);
      var fieldId = rule["targetFieldId"].ToString();
      var action = rule["action"].ToString();
      // Apply action to results Dictionary
  }

VIOLATION:
  if (formData["department"] == "Finance") { field.Visible = true; }  // ← FAIL: hardcoded condition

AF-4 RETRIEVAL TRIGGER:
  Query: "conditional logic form rules evaluator ES document runtime"
  Used by: AF-7 (Compliance — DR-68 rules never compiled)
           AF-4 (RAG — SK-99 schema DAG + SK-109 evaluator combined)

DNA COMPLIANCE:
  DNA-1: All rules and evaluation results as Dictionary
  DNA-3: Evaluator returns DataProcessResult.Failure on malformed rule
  DNA-5: tenantId on ES rule lookup
```

---

## SK-110 — Multi-Tenant Forms Isolation

```
SKILL ID:       SK-110
NAME:           Multi-Tenant Forms Isolation
CATEGORY:       Multi-Tenancy / Security
ARCHETYPE:      PROVISIONING (T198)
FACTORIES:      F514, F466, F482, F511
FABRIC:         CORE FABRIC + MT ISOLATION FABRIC (Skill 11) + DATABASE FABRIC (PG RLS)

PATTERN DESCRIPTION:
  Five-plane isolation for forms platform:
  1. ES schema namespace: {tenantId}-forms-schemas
  2. ES entry namespace:  {tenantId}-forms-entries
  3. PG RLS on entry audit + partial promoted entries
  4. Redis key prefix:    {tenantId}:*
  5. PG connector credentials: RLS + column-level encryption

INHERITS FLOW-08 MT MODEL + FLOW-14 WAREHOUSE MT MODEL (DR-75).
Does not reinvent isolation — extends proven patterns.

ISOLATION VERIFICATION:
  // Test 1: Cross-tenant schema read returns Failure
  var schema = await _formSchema.GetSchema(tenantBFormId, tenantAId);
  Assert.False(schema.IsSuccess);  // NOT_FOUND — no enumeration leak

  // Test 2: PG RLS blocks cross-tenant entry query
  // Simulated: SET app.current_tenant = 'tenant-A'
  // SELECT * FROM entries WHERE entry_id = '{tenantBEntryId}'  → 0 rows

  // Test 3: Redis key isolation
  var partialKeys = await _redis.ScanAsync($"tenant-A:*");
  Assert.DoesNotContain(partialKeys, k => k.StartsWith("tenant-B:"));

  // Test 4: Connector credential cross-tenant
  var token = await _oauthConnector.GetAccessToken(tenantBConnectorId, tenantAId);
  Assert.False(token.IsSuccess);

PROVISION CHECKLIST (T198):
  ✅ ES index aliases created: {tenantId}-forms-schemas, {tenantId}-forms-entries
  ✅ PG RLS policy: CREATE POLICY tenant_isolation ON entries USING (tenant_id = current_setting('app.current_tenant'))
  ✅ Redis prefix documented in FREEDOM config
  ✅ Connector credential table RLS policy applied
  ✅ MT ISOLATION FABRIC (Skill 11) validation called

AF-4 RETRIEVAL TRIGGER:
  Query: "multi-tenant forms isolation ES namespace PG RLS Redis prefix"
  Used by: AF-8 (Security — ST-114 cross-tenant leak test)
           AF-9 (Judge — CF-232-234, IR-198-1 through 198-8)

DNA COMPLIANCE:
  DNA-5: tenantId isolation is the entire purpose of this skill
  DNA-3: All isolation checks return DataProcessResult.Failure (not exception)
  DNA-4: F514 extends MicroserviceBase with MT isolation components
```

---

## AF-4 RAG INDEX — FLOW-15 RETRIEVAL MAP

```
QUERY PATTERN                                           → SKILLS RETRIEVED
─────────────────────────────────────────────────────────────────────────
"form schema validation cycle detection"                → SK-99, SK-109
"submission pipeline stage gate ordering"               → SK-100
"merge tag template notification AI"                    → SK-101
"feed executor idempotency Redis dedup"                 → SK-102
"recipe DAG execution Elasticsearch"                    → SK-103, SK-99
"OAuth PKCE connector token refresh"                    → SK-104
"anti-spam honeypot reCAPTCHA AI scoring"               → SK-105
"file upload virus scan signed URL"                     → SK-106
"fabric-first UI render spec platform-agnostic"         → SK-107
"partial entry save continue Redis TTL"                 → SK-108
"conditional logic rules evaluator ES"                  → SK-109
"multi-tenant forms isolation ES PG RLS"                → SK-110
"persist before emit entry event"                       → SK-100 + DR-66 (ENGINE_ARCH)
"concurrent recipe execution step state"                → SK-103
"anti-spam before persist pipeline"                     → SK-105, SK-100
"OAuth token race condition lock"                       → SK-104 (ST-112)
```

---

## BACKWARD COMPATIBILITY VERIFICATION

```
SK-1-SK-98:  UNCHANGED ✅
SK-99 starts at correct next ID (98 + 1 = 99)
SK-110 is the last new skill (99 + 12 - 1 = 110)
No modifications to existing skill patterns
```

---

## SAVE POINT: FLOW15:P6:SKILLS ✅
## Recovery: "Load 21_-_forms_and_flows_SKILLS_FACTORY_RAG — SK-99-SK-110 complete"
