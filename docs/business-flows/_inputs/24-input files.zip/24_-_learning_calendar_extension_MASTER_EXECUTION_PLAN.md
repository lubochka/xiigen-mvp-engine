# MASTER EXECUTION PLAN — FLOW-24: Learning Calendar Extension (Personal AI Tutor)
## Status: COMPLETE ✅ | 7 Execution Zones | State: BLUEPRINT_COMPLETE

---

## OVERVIEW

FLOW-24 extends the XIIGen engine to support an AI-powered Personal Tutor platform integrated with Google Calendar / Outlook. The engine generates flows across three domain packs (School, Business Owner, Developer) with adaptive learning, gamification, and calendar-native scheduling.

**Engine extension scope:**
- 7 factory families (119–125), 46 factories (F852–F897)
- 8 engine contracts (T307–T314), 4 flow templates (64–67)
- 15 BFA conflict rules (CF-380–CF-394), 10 stress tests (ST-215–ST-224)
- 10 skills (SK-189–SK-198)
- 10 design decisions (DD-180–DD-189), 8 design records (DR-134–DR-141)

---

## EXECUTION ZONES

### ZONE A — Student Identity & Consent Foundation
**Factories:** F852–F857 (Family 119)  
**Task Types:** T307 (partial — identity/consent steps)  
**Phase duration:** ~30 min  

**Deliverables:**
1. IStudentProfileService (F852) — PostgreSQL, tenant-scoped
2. IConsentProfileService (F853) — minor gate, GDPR/COPPA, append-style consent log
3. IStudentAuthService (F854) — MicroserviceBase auth context passthrough
4. IMultiTenantTutorGate (F855) — quota + noisy-neighbor + scope enforcement
5. ILocaleConfigService (F856) — ES FREEDOM config for locale/curriculum settings
6. ICurriculumPackService (F857) — domain pack registry (school/biz/dev)

**Save point:** `FLOW24:ZONE_A:F852-F857`  
**Recovery:** "Load ENGINE_ARCHITECTURE_MERGED — FLOW-24 Zone A — Family 119"

---

### ZONE B — Knowledge Diagnosis Engine
**Factories:** F858–F863 (Family 120)  
**Task Types:** T307 (diagnosis steps), T311  
**Phase duration:** ~30 min  

**Deliverables:**
1. IKnowledgeMapService (F858) — ES, optimistic concurrency, tenant-scoped
2. IQuestionnaireService (F859) — PG, domain-pack-driven questionnaire definitions
3. IBaselineQuizService (F860) — PG append-only attempts
4. IDiagnosticScoreService (F861) — AI Engine Fabric, multi-model conservative consensus
5. IKnowledgeGapAnalyzer (F862) — RAG Vector strategy, gap pattern retrieval
6. IPrerequisiteValidator (F863) — DB Fabric → Neo4j, graph readiness check

**Key integration:** T307 orchestrates: consent gate (Zone A) → questionnaire → baseline quiz → F861 diagnostic score → F858 knowledge map build → F863 prerequisite validation  

**Save point:** `FLOW24:ZONE_B:F858-F863`  
**Recovery:** "Load ENGINE_ARCHITECTURE_MERGED — FLOW-24 Zone B — Family 120"

---

### ZONE C — Curriculum Graph & RAG
**Factories:** F864–F869 (Family 121)  
**Task Types:** T308, T311 (curriculum selection steps)  
**Phase duration:** ~30 min  

**Deliverables:**
1. ICurriculumGraphService (F864) — Neo4j via DB Fabric, path traversal
2. ITopicOntologyService (F865) — RAG Hybrid (graph + vector), topic search
3. IPrerequisiteEdgeService (F866) — Neo4j, edge management
4. IMasteryPathService (F867) — AI Engine Fabric, long-horizon path planning
5. ILearningAtomService (F868) — RAG Vector, atom storage + retrieval
6. ITopicProgressService (F869) — PG, per-topic session history

**Key integration:** SK-192 (Curriculum Graph-RAG) documents the hybrid traversal pattern. F863 + F864 + F865 combine for topic selection in T308 Step S02–S03.

**Save point:** `FLOW24:ZONE_C:F864-F869`  
**Recovery:** "Load ENGINE_ARCHITECTURE_MERGED — FLOW-24 Zone C — Family 121"

---

### ZONE D — Lesson Composer + Safety Gate
**Factories:** F870–F877 (Family 122)  
**Task Types:** T308 (lesson generation pipeline), T312, T314  
**Phase duration:** ~35 min  

**Deliverables:**
1. ILessonComposerService (F870) — AI Engine Fabric, AiDispatcher multi-model
2. IRAGAtomFetcherService (F871) — RAG Vector, pre-composition atom retrieval
3. ILessonSafetyGate (F872) — AI Engine Fabric moderation, SafetyGateToken protocol
4. ILessonPublishService (F873) — MongoDB, requires SafetyGateToken
5. ILessonLocalizationService (F874) — AI Engine Fabric, locale variants
6. IDifficultyAdapterService (F875) — AI Engine Fabric, simplify/enrich branches
7. ILessonCatalogService (F876) — ES index, searchable catalog
8. ILessonContentStore (F877) — MongoDB, multi-variant content

**Critical path:** F871 (RAG) → F870 (compose) → F875 (adapt) → F872 (safety gate) → F873 (publish). ORDER IS IRON RULE.  

**Template 65 validated in this zone.**

**Save point:** `FLOW24:ZONE_D:F870-F877`  
**Recovery:** "Load TASK_TYPES_CATALOG_MERGED — T308 + Template 65"

---

### ZONE E — Quiz Engine & Gamification Ledger
**Factories:** F878–F889 (Families 123–124)  
**Task Types:** T309 (hybrid quiz → gamification), T311  
**Phase duration:** ~35 min  

**Deliverables:**
1. IQuizGeneratorService (F878) — AI Engine Fabric, topic-aware quiz generation
2. IQuizRunnerService (F879) — PG, session management
3. IQuizAttemptStore (F880) — PG append-only, immutable attempts
4. IQuizGraderService (F881) — AI Engine Fabric (server-side, MACHINE)
5. IQuizAdaptationService (F882) — AI Engine Fabric, difficulty recommendations
6. IQuizTemplateService (F883) — RAG FanOut, template retrieval
7. IGamificationLedgerService (F884) — PG append-only ledger
8. IBadgeDefinitionService (F885) — ES FREEDOM config
9. IBadgeUnlockService (F886) — Queue Fabric Redis Streams, async badge eval
10. IStreakManagerService (F887) — Redis hot + PG persist, timezone-correct
11. IPointsCalculatorService (F888) — CORE Fabric MACHINE compute
12. ILeaderboardService (F889) — Redis sorted sets

**Critical patterns:** SK-194 (ledger), SK-195 (streak), Template 66 (hybrid contract)  
**BFA rules activated:** CF-384, CF-385, CF-386, CF-389 all verified in this zone.

**Save point:** `FLOW24:ZONE_E:F878-F889`  
**Recovery:** "Load TASK_TYPES_CATALOG_MERGED — T309 + Template 66"

---

### ZONE F — Adaptive Planner & Calendar Sync
**Factories:** F890–F897 (Family 125)  
**Task Types:** T310, T311, T313, T314  
**Phase duration:** ~30 min  

**Deliverables:**
1. ILessonPlanService (F890) — PG, 30-day plan storage
2. IAdaptivePlannerService (F891) — AI Engine Fabric, plan adaptation
3. ICalendarSyncService (F892) — Queue Fabric Redis Streams, durable sync
4. IGoogleCalendarConnector (F893) — CORE Fabric external connector
5. IOutlookCalendarConnector (F894) — CORE Fabric external connector
6. IQuietHoursService (F895) — PG FREEDOM config
7. IReminderOrchestratorService (F896) — Queue Fabric Redis Streams, escalation
8. IStreakProtectionService (F897) — PG, uses-per-month enforcement

**Templates 67 (missed lesson recovery) and T313 (conflict resolution) validated in this zone.**

**Save point:** `FLOW24:ZONE_F:F890-F897`  
**Recovery:** "Load ENGINE_ARCHITECTURE_MERGED — FLOW-24 Zone F — Family 125"

---

### ZONE G — Integration, BFA Validation & DNA Lock
**Task Types:** T307–T314 full validation  
**BFA Rules:** CF-380–CF-394 all active  
**Stress Tests:** ST-215–ST-224 all run  
**Phase duration:** ~30 min  

**Deliverables:**
1. Full flow integration tests — all 4 templates (64–67) exercised end-to-end
2. BFA conflict detection — all 15 rules triggered and handled
3. DNA compliance scan — AF-7 validates all 46 factories against DNA-1 through DNA-9
4. Security scan — AF-8 validates: consent gate, server-side grading, no SDK imports, timezone trust
5. Multi-tenant isolation test — ST-215 (cross-tenant), ST-218 (minor consent), ST-223 (SDK check)
6. Backward compatibility verification — F1–F851, T1–T306, CF-1–CF-379 unchanged
7. SESSION_STATE updated — canonical state document updated to FLOW-24

**Save point:** `FLOW24:ZONE_G:COMPLETE`

---

## EXECUTION SEQUENCING

```
ZONE A → ZONE B → ZONE C → ZONE D → ZONE E → ZONE F → ZONE G
  ↓          ↓          ↓         ↓          ↓          ↓         ↓
 F852–F857  F858–F863  F864–F869 F870–F877  F878–F889  F890–F897  VALIDATE
 ~30min     ~30min     ~30min    ~35min     ~35min     ~30min     ~30min
```

**Parallelization opportunities:** Zone C (curriculum graph) can run parallel to Zone B after F858 (knowledge map) is ready. Zone E (quiz) can run parallel to Zone D (lesson) — they share no factory dependencies.

---

## DOMAIN PACK SUPPORT MATRIX

| Flow / Zone | School Pack | Business Owner Pack | Developer Pack |
|-------------|-------------|---------------------|----------------|
| Onboarding (T307) | ✅ | ✅ | ✅ |
| Daily Lesson (T308) | ✅ | ✅ | ✅ |
| Quiz + Gamification (T309) | ✅ | ✅ | ✅ |
| Missed Lesson Recovery (T310) | ✅ | ✅ | ✅ |
| Knowledge Map Update (T311) | ✅ | ✅ | ✅ |
| Weekly Research Digest (T312) | ❌ | ❌ | ✅ (FREEDOM enabled) |
| Calendar Conflict Resolution (T313) | ✅ | ✅ | ✅ |
| Monthly Capstone (T314) | ❌ | ✅ | ✅ |

---

## FREEDOM vs MACHINE — QUICK REFERENCE

| Parameter | MACHINE (fixed) | FREEDOM (ES config) |
|-----------|----------------|---------------------|
| Minor status | ✅ Server READ-ONLY | — |
| Consent gate | ✅ Blocking — no bypass | — |
| Quiz grading | ✅ Server-side F881 | — |
| Points formula structure | ✅ F888 computes | Values configurable |
| Ledger append-only | ✅ DDL + app enforced | — |
| Streak timezone | ✅ From F852 profile | — |
| Safety gate blocking | ✅ F872 required | Threshold configurable |
| Lesson length | — | ✅ 5/7/10 min |
| Badge thresholds | — | ✅ ES config via F885 |
| Reminder policy | — | ✅ soft/hard/none |
| Quiet hours | — | ✅ Per-student in F895 |
| Quiz frequency | — | ✅ Configurable |
| AI model selection | — | ✅ Per tenant in F856 |
| Calendar provider | — | ✅ From F852 profile |
| Sources whitelist (dev) | — | ✅ ES config F856 |
| Domain pack | — | ✅ F857 config |

---

## RECOVERY COMMANDS

```
Load full FLOW-24:            "Load all 7 FLOW-24 files — Learning Calendar Extension"
Resume from Zone A:           "Load FLOW-24 ENGINE_ARCHITECTURE — F852-F857 defined"
Resume from Zone D:           "Load FLOW-24 TASK_TYPES_CATALOG — T308 + Template 65"
Resume from Zone E:           "Load FLOW-24 TASK_TYPES_CATALOG — T309 + Template 66"
Resume from BFA:              "Load FLOW-24 V62_BFA_STRESS_TEST — CF-380-CF-394"
Resume from skills:           "Load FLOW-24 SKILLS_FACTORY_RAG — SK-189-SK-198"
Check specific pattern:       "Load FLOW-24 SKILLS_FACTORY_RAG — search for SK-[N]"
Start FLOW-25:                "Start FLOW-25 from F898, T315, CF-395, SK-199"
```

---

## SAVE POINT: FLOW24:MASTER_EXECUTION_PLAN ✅
