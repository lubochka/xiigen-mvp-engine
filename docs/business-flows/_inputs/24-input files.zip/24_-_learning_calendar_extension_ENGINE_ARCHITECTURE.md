# ENGINE ARCHITECTURE — FLOW-24: Learning Calendar Extension (Personal AI Tutor)
## Status: COMPLETE ✅ | Factories F852–F897 | Families 119–125

---

## SYSTEM CONTEXT

FLOW-24 extends the XIIGen engine with a domain-agnostic **Personal AI Tutor** platform that:
- Diagnoses knowledge gaps via questionnaires and adaptive tests → **Knowledge Map**
- Generates micro-lessons daily (5–10 min) personalized by difficulty and locale
- Runs server-side graded quizzes with an append-only gamification ledger
- Syncs lessons as calendar tasks/events (Google Calendar, Outlook, CalDAV)
- Adapts tomorrow's plan based on today's quiz performance
- Supports three domain packs: **School** (grade-level), **Business Owner** (KPI-driven), **Developer** (skill tree)
- Full multi-tenant support with minor/consent protection

All services extend `MicroserviceBase` (DNA-4). All inter-service calls route through Queue Fabric (DNA — no direct HTTP). All data access through Database Fabric (no raw SQL/ORM imports). All AI calls through AI Engine Fabric (no provider SDK imports).

---

## FACTORY REGISTRY — FLOW-24

### FAMILY 119 — Student Identity & Consent
**Range:** F852–F857 | **Fabric anchor:** DATABASE FABRIC (PG) + CORE FABRIC

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F852 | IStudentProfileService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F853 | IConsentProfileService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F854 | IStudentAuthService | CORE FABRIC (Skill 01) | Auth context via MicroserviceBase |
| F855 | IMultiTenantTutorGate | CORE FABRIC (Skill 01) | Scope isolation — tenantId + consentId |
| F856 | ILocaleConfigService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F857 | ICurriculumPackService | DATABASE FABRIC (Skill 05) | Elasticsearch |

**Factory contracts:**
```
F852: IStudentProfileService
  CreateAsync(FactoryResolutionContext{tenantId, studentId}) → Task<IStudentProfileService>
  Methods:
    GetProfileAsync(studentId, tenantId) → DataProcessResult<Dictionary<string,object>>
    UpsertProfileAsync(Dictionary<string,object> profile) → DataProcessResult<string>
    ListProfilesAsync(Dictionary<string,object> filter) → DataProcessResult<List<...>>
  DNA: ParseDocument (no typed model), BuildSearchFilter (empty-field skip), DataProcessResult<T>
  IRON RULE: tenantId MUST be present in every query — BUILD FAILURE if absent

F853: IConsentProfileService
  CreateAsync(FactoryResolutionContext{tenantId, studentId}) → Task<IConsentProfileService>
  Methods:
    GetConsentAsync(studentId) → DataProcessResult<Dictionary<string,object>>
    SetConsentAsync(Dictionary<string,object> consent) → DataProcessResult<bool>
    IsMinorAsync(studentId) → DataProcessResult<bool>
    RequiresParentalConsentAsync(studentId) → DataProcessResult<bool>
  MACHINE RULE: Minor status is READ-ONLY server-side. Client cannot set age.
  IRON RULE: Any content generation flow MUST check IsMinorAsync before AI calls.

F854: IStudentAuthService
  FABRIC: CORE FABRIC — resolved via MicroserviceBase auth context
  Methods:
    ValidateTokenAsync(token) → DataProcessResult<Dictionary<string,object>>
    GetAuthContextAsync() → DataProcessResult<Dictionary<string,object>>
  NOTE: No direct IdP SDK import. Auth context injected by MicroserviceBase.

F855: IMultiTenantTutorGate
  FABRIC: CORE FABRIC — scope isolation enforcement point
  Methods:
    EnforceScopeAsync(tenantId, studentId) → DataProcessResult<bool>
    ValidateQuotaAsync(tenantId) → DataProcessResult<Dictionary<string,object>>
    CheckNoiseNeighborAsync(tenantId) → DataProcessResult<bool>
  IRON RULE: Edge-only tenant resolution (DD-172 pattern). No header trust.

F856: ILocaleConfigService
  FABRIC: DATABASE FABRIC → Elasticsearch
  Methods:
    GetLocaleConfigAsync(locale, grade) → DataProcessResult<Dictionary<string,object>>
    GetCurriculumVariantAsync(locale, grade) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: curriculum_pack, lesson_language, difficulty_scale — all ES config documents

F857: ICurriculumPackService
  FABRIC: DATABASE FABRIC → Elasticsearch
  Methods:
    GetPackAsync(packId) → DataProcessResult<Dictionary<string,object>>
    ListSubjectsAsync(packId, locale) → DataProcessResult<List<Dictionary<string,object>>>
    GetSubjectWeightsAsync(tenantId, packId) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: subject_weights configurable per tenant/locale in ES index
```

---

### FAMILY 120 — Knowledge Diagnosis Engine
**Range:** F858–F863 | **Fabric anchor:** DATABASE FABRIC (PG + ES) + RAG FABRIC + AI ENGINE FABRIC

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F858 | IKnowledgeMapService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F859 | IQuestionnaireService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F860 | IBaselineQuizService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F861 | IDiagnosticScoreService | AI ENGINE FABRIC (Skill 07) | AiDispatcher (multi-model) |
| F862 | IKnowledgeGapAnalyzer | RAG FABRIC (Skill 00b) | Vector strategy |
| F863 | IPrerequisiteValidator | DATABASE FABRIC (Skill 05) | Neo4j / Graph provider |

**Factory contracts:**
```
F858: IKnowledgeMapService
  FABRIC: DATABASE FABRIC → Elasticsearch
  Methods:
    GetMapAsync(studentId) → DataProcessResult<Dictionary<string,object>>
    UpsertTopicScoreAsync(studentId, topicId, score, confidence) → DataProcessResult<bool>
    GetGapsAsync(studentId, minGapThreshold) → DataProcessResult<List<Dictionary<string,object>>>
    GetStrongTopicsAsync(studentId) → DataProcessResult<List<Dictionary<string,object>>>
  Data shape (Dictionary): { topicId, score(0–1), confidence, lastSeen, prerequisitesMissing[], level }
  MACHINE: Score computed server-side only. Client score submissions rejected.

F859: IQuestionnaireService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    GetOnboardingQuestionnaireAsync(packId, locale) → DataProcessResult<Dictionary<string,object>>
    SubmitResponsesAsync(studentId, Dictionary<string,object> responses) → DataProcessResult<string>
    GetDomainPackQuestionsAsync(packId) → DataProcessResult<List<Dictionary<string,object>>>
  NOTE: Domain packs: "school", "business_owner", "developer" — config-driven, not hardcoded.

F860: IBaselineQuizService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    GetBaselineQuizAsync(topicId, grade) → DataProcessResult<Dictionary<string,object>>
    StoreAttemptAsync(Dictionary<string,object> attempt) → DataProcessResult<string>
  MACHINE: Immutable attempts (append-only). No update/delete on attempts.

F861: IDiagnosticScoreService
  FABRIC: AI ENGINE FABRIC (Skill 07) → AiDispatcher
  Methods:
    ScoreResponsesAsync(Dictionary<string,object> responses, packId) → DataProcessResult<Dictionary<string,object>>
    BuildKnowledgeMapAsync(studentId, scores) → DataProcessResult<Dictionary<string,object>>
  NOTE: Multi-model parallel scoring with conservative consensus (DD-175 pattern)
  FREEDOM: scoring_model, score_threshold — FREEDOM config in ES

F862: IKnowledgeGapAnalyzer
  FABRIC: RAG FABRIC (Skill 00b) → Vector strategy
  Methods:
    FindSimilarGapsAsync(knowledgeMap) → DataProcessResult<List<Dictionary<string,object>>>
    GetLearningRecommendationsAsync(gaps, packId) → DataProcessResult<List<Dictionary<string,object>>>
  NOTE: Retrieves past successful gap-fill paths from vector store

F863: IPrerequisiteValidator
  FABRIC: DATABASE FABRIC (Skill 05) → Graph provider (Neo4j)
  Methods:
    GetPrerequisitesAsync(topicId) → DataProcessResult<List<string>>
    CheckReadinessAsync(studentId, topicId) → DataProcessResult<Dictionary<string,object>>
    GetNextReadyTopicsAsync(studentId) → DataProcessResult<List<Dictionary<string,object>>>
  NOTE: Graph traversal for prerequisite chain. Swappable to any graph provider via config.
```

---

### FAMILY 121 — Curriculum Graph & RAG
**Range:** F864–F869 | **Fabric anchor:** DATABASE FABRIC (Neo4j) + RAG FABRIC

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F864 | ICurriculumGraphService | DATABASE FABRIC (Skill 05) | Neo4j / Graph provider |
| F865 | ITopicOntologyService | RAG FABRIC (Skill 00b) | Hybrid strategy |
| F866 | IPrerequisiteEdgeService | DATABASE FABRIC (Skill 05) | Neo4j / Graph provider |
| F867 | IMasteryPathService | AI ENGINE FABRIC (Skill 07) | AiDispatcher (path planning) |
| F868 | ILearningAtomService | RAG FABRIC (Skill 00b) | Vector strategy |
| F869 | ITopicProgressService | DATABASE FABRIC (Skill 05) | PostgreSQL |

**Factory contracts:**
```
F864: ICurriculumGraphService
  FABRIC: DATABASE FABRIC → Graph provider (Neo4j)
  Methods:
    GetTopicNodeAsync(topicId) → DataProcessResult<Dictionary<string,object>>
    TraversePrerequisitesAsync(topicId, depth) → DataProcessResult<List<Dictionary<string,object>>>
    GetLearningPathAsync(fromTopic, toTopic) → DataProcessResult<List<Dictionary<string,object>>>
  FREEDOM: graph_depth_limit, traversal_strategy — FREEDOM config

F865: ITopicOntologyService
  FABRIC: RAG FABRIC (Skill 00b) → Hybrid strategy (vector + graph)
  Methods:
    SearchTopicAsync(query, packId, locale) → DataProcessResult<List<Dictionary<string,object>>>
    GetRelatedConceptsAsync(topicId) → DataProcessResult<List<Dictionary<string,object>>>
  NOTE: Graph-RAG pattern — combines F864 graph traversal with vector similarity

F866: IPrerequisiteEdgeService
  FABRIC: DATABASE FABRIC → Neo4j
  Methods:
    AddEdgeAsync(fromTopic, toTopic, weight) → DataProcessResult<bool>
    GetBlockingPrerequisitesAsync(topicId, studentId) → DataProcessResult<List<string>>

F867: IMasteryPathService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    PlanPathAsync(studentId, goalTopic, timeHorizon) → DataProcessResult<Dictionary<string,object>>
    AdaptPathAsync(studentId, recentPerformance) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: path_planning_model, horizon_days — FREEDOM config

F868: ILearningAtomService
  FABRIC: RAG FABRIC (Skill 00b) → Vector strategy
  Methods:
    FetchAtomsAsync(topicId, difficulty, locale) → DataProcessResult<List<Dictionary<string,object>>>
    StoreAtomAsync(Dictionary<string,object> atom) → DataProcessResult<string>
  Atom shape (Dictionary): { atomId, type(definition/example/story/template), topicId, difficulty, locale, content, sourceRef }
  NOTE: Citations required for research atoms (MACHINE rule — DD per SK-196)

F869: ITopicProgressService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    UpdateProgressAsync(studentId, topicId, sessionResult) → DataProcessResult<bool>
    GetProgressSummaryAsync(studentId) → DataProcessResult<Dictionary<string,object>>
```

---

### FAMILY 122 — Lesson Composer
**Range:** F870–F877 | **Fabric anchor:** AI ENGINE FABRIC + RAG FABRIC + DATABASE FABRIC (Mongo + ES)

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F870 | ILessonComposerService | AI ENGINE FABRIC (Skill 07) | AiDispatcher (multi-model) |
| F871 | IRAGAtomFetcherService | RAG FABRIC (Skill 00b) | Vector strategy |
| F872 | ILessonSafetyGate | AI ENGINE FABRIC (Skill 07) | AiDispatcher (moderation model) |
| F873 | ILessonPublishService | DATABASE FABRIC (Skill 05) | MongoDB |
| F874 | ILessonLocalizationService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F875 | IDifficultyAdapterService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F876 | ILessonCatalogService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F877 | ILessonContentStore | DATABASE FABRIC (Skill 05) | MongoDB |

**Factory contracts:**
```
F870: ILessonComposerService
  FABRIC: AI ENGINE FABRIC (Skill 07) → AiDispatcher
  Methods:
    ComposeAsync(Dictionary<string,object> spec) → DataProcessResult<Dictionary<string,object>>
      spec keys: topicId, difficulty, locale, grade, studentStrengths[], atoms[], packId
    RegenerateWithFeedbackAsync(lessonId, feedback) → DataProcessResult<Dictionary<string,object>>
  NOTE: AiDispatcher runs parallel models; conservative merge for lesson quality (DD-175)
  FREEDOM: lesson_length_minutes, composition_model, include_story, include_example_count — ES config

F871: IRAGAtomFetcherService
  FABRIC: RAG FABRIC (Skill 00b) → Vector strategy
  Methods:
    FetchForLessonAsync(topicId, difficulty, count) → DataProcessResult<List<Dictionary<string,object>>>
    FetchStoriesAsync(topicId, locale) → DataProcessResult<List<Dictionary<string,object>>>

F872: ILessonSafetyGate
  FABRIC: AI ENGINE FABRIC → AiDispatcher (moderation)
  Methods:
    EvaluateAsync(Dictionary<string,object> lesson, isMinor) → DataProcessResult<Dictionary<string,object>>
      returns: { passed: bool, flags: [], score: float, recommendation: string }
  MACHINE — IRON RULE: Lesson MUST NOT be published if passed=false. BUILD FAILURE if bypass attempted.
  IRON RULE: isMinor=true triggers stricter content policy; no override.

F873: ILessonPublishService
  FABRIC: DATABASE FABRIC → MongoDB
  Methods:
    PublishAsync(Dictionary<string,object> lesson) → DataProcessResult<string>  // returns lessonId
    GetPublishedAsync(lessonId) → DataProcessResult<Dictionary<string,object>>
    ArchiveAsync(lessonId) → DataProcessResult<bool>

F874: ILessonLocalizationService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    LocalizeAsync(lessonId, targetLocale) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: supported_locales — FREEDOM config

F875: IDifficultyAdapterService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    SimplifyAsync(lessonId, targetDifficulty) → DataProcessResult<Dictionary<string,object>>
    EnrichAsync(lessonId, targetDifficulty) → DataProcessResult<Dictionary<string,object>>
  NOTE: Called AFTER safety gate. Never bypasses F872.

F876: ILessonCatalogService
  FABRIC: DATABASE FABRIC → Elasticsearch
  Methods:
    IndexLessonAsync(Dictionary<string,object> lesson) → DataProcessResult<bool>
    SearchAsync(Dictionary<string,object> filter) → DataProcessResult<List<Dictionary<string,object>>>
  DNA-2: BuildSearchFilter — empty fields auto-skipped

F877: ILessonContentStore
  FABRIC: DATABASE FABRIC → MongoDB
  Methods:
    StoreVariantAsync(lessonId, locale, Dictionary<string,object> content) → DataProcessResult<string>
    GetVariantAsync(lessonId, locale) → DataProcessResult<Dictionary<string,object>>
```

---

### FAMILY 123 — Quiz Engine
**Range:** F878–F883 | **Fabric anchor:** AI ENGINE FABRIC + DATABASE FABRIC (PG) + RAG FABRIC

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F878 | IQuizGeneratorService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F879 | IQuizRunnerService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F880 | IQuizAttemptStore | DATABASE FABRIC (Skill 05) | PostgreSQL (append-only) |
| F881 | IQuizGraderService | AI ENGINE FABRIC (Skill 07) | AiDispatcher (MACHINE) |
| F882 | IQuizAdaptationService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F883 | IQuizTemplateService | RAG FABRIC (Skill 00b) | FanOut strategy |

**Factory contracts:**
```
F878: IQuizGeneratorService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    GenerateAsync(topicId, difficulty, questionCount) → DataProcessResult<Dictionary<string,object>>
    GenerateFromLessonAsync(lessonId, questionCount) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: question_count, difficulty_distribution, question_types — FREEDOM config

F879: IQuizRunnerService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    StartSessionAsync(studentId, quizId) → DataProcessResult<Dictionary<string,object>>
    SubmitAnswerAsync(sessionId, questionId, answer) → DataProcessResult<Dictionary<string,object>>
    CompleteSessionAsync(sessionId) → DataProcessResult<Dictionary<string,object>>
  NOTE: Returns SYNC points preview (hybrid contract — same as FLOW-05)

F880: IQuizAttemptStore
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    AppendAttemptAsync(Dictionary<string,object> attempt) → DataProcessResult<string>
    GetAttemptsAsync(studentId, topicId) → DataProcessResult<List<Dictionary<string,object>>>
  MACHINE — IRON RULE: Append-only. No UPDATE or DELETE on attempts table. Ever.

F881: IQuizGraderService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    GradeAsync(sessionId, Dictionary<string,object> answers) → DataProcessResult<Dictionary<string,object>>
      returns: { score, correctCount, explanations[], pointsEarned }
  MACHINE — IRON RULE: Server-side grading ONLY. Client-submitted scores = BUILD FAILURE.
  NOTE: Points calculated here, passed to F884. Client never computes points.

F882: IQuizAdaptationService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    AnalyzePerformanceAsync(studentId, recentAttempts) → DataProcessResult<Dictionary<string,object>>
    SuggestNextDifficultyAsync(studentId, topicId) → DataProcessResult<string>  // "simpler"|"same"|"harder"

F883: IQuizTemplateService
  FABRIC: RAG FABRIC (Skill 00b) → FanOut strategy
  Methods:
    GetTemplatesAsync(topicId, packId) → DataProcessResult<List<Dictionary<string,object>>>
    StoreTemplateAsync(Dictionary<string,object> template) → DataProcessResult<string>
```

---

### FAMILY 124 — Gamification Ledger
**Range:** F884–F889 | **Fabric anchor:** DATABASE FABRIC (PG + Redis) + QUEUE FABRIC

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F884 | IGamificationLedgerService | DATABASE FABRIC (Skill 05) | PostgreSQL (append-only) |
| F885 | IBadgeDefinitionService | DATABASE FABRIC (Skill 05) | Elasticsearch |
| F886 | IBadgeUnlockService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F887 | IStreakManagerService | DATABASE FABRIC (Skill 05) | Redis (hot) + PostgreSQL (persist) |
| F888 | IPointsCalculatorService | CORE FABRIC (Skill 01) | MACHINE — MicroserviceBase compute |
| F889 | ILeaderboardService | DATABASE FABRIC (Skill 05) | Redis (sorted sets) |

**Factory contracts:**
```
F884: IGamificationLedgerService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    AppendEventAsync(Dictionary<string,object> event) → DataProcessResult<string>
      event keys: studentId, tenantId, type, points, source, timestamp, quizAttemptId
    GetTotalsAsync(studentId) → DataProcessResult<Dictionary<string,object>>
    GetHistoryAsync(studentId, fromDate) → DataProcessResult<List<Dictionary<string,object>>>
  MACHINE — IRON RULE: Append-only ledger. No UPDATE/DELETE. BigInt running totals.
  MACHINE — IRON RULE: Points source MUST be server-side (F881 grader) — never client input.

F885: IBadgeDefinitionService
  FABRIC: DATABASE FABRIC → Elasticsearch
  Methods:
    GetBadgeAsync(badgeId) → DataProcessResult<Dictionary<string,object>>
    ListAvailableAsync(packId) → DataProcessResult<List<Dictionary<string,object>>>
    CheckEligibilityAsync(studentId, badgeId) → DataProcessResult<bool>
  FREEDOM: badge_thresholds, badge_names, badge_icons — all ES FREEDOM config (no literals in code)

F886: IBadgeUnlockService
  FABRIC: QUEUE FABRIC (Skill 04) → Redis Streams
  Methods:
    EnqueueUnlockCheckAsync(studentId, eventType) → DataProcessResult<bool>
    ProcessUnlockAsync(Dictionary<string,object> event) → DataProcessResult<Dictionary<string,object>>
  NOTE: Async badge evaluation. Consumer group pattern. DLQ on failure.

F887: IStreakManagerService
  FABRIC: DATABASE FABRIC → Redis (hot state) + PostgreSQL (durable persist)
  Methods:
    GetStreakAsync(studentId, tenantId) → DataProcessResult<Dictionary<string,object>>
    UpdateStreakAsync(studentId, completionTimestamp, timezone) → DataProcessResult<Dictionary<string,object>>
    BreakStreakAsync(studentId, reason) → DataProcessResult<bool>
  MACHINE — IRON RULE: Streak computed in student's LOCAL timezone (trust-critical).
  MACHINE — IRON RULE: Timezone derived from student profile, NOT from client request header.
  FREEDOM: streak_protection_enabled, grace_period_hours — FREEDOM config

F888: IPointsCalculatorService
  FABRIC: CORE FABRIC (Skill 01) — pure compute, MicroserviceBase
  Methods:
    CalculateAsync(quizResult, streakMultiplier, bonusFlags) → DataProcessResult<Dictionary<string,object>>
  MACHINE: Formula is MACHINE (no client input to calculation). Values are FREEDOM (ES config).
  FREEDOM: base_points_per_correct, streak_multiplier_cap, bonus_thresholds — ES FREEDOM config

F889: ILeaderboardService
  FABRIC: DATABASE FABRIC → Redis sorted sets
  Methods:
    UpdateRankAsync(studentId, tenantId, totalPoints) → DataProcessResult<bool>
    GetLeaderboardAsync(tenantId, scope, topN) → DataProcessResult<List<Dictionary<string,object>>>
  FREEDOM: leaderboard_scope (class/school/tenant/global), refresh_interval — FREEDOM config
```

---

### FAMILY 125 — Adaptive Planner & Calendar Sync
**Range:** F890–F897 | **Fabric anchor:** DATABASE FABRIC (PG) + QUEUE FABRIC + CORE FABRIC

| Factory | Interface | Fabric Resolution | Provider |
|---------|-----------|-------------------|----------|
| F890 | ILessonPlanService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F891 | IAdaptivePlannerService | AI ENGINE FABRIC (Skill 07) | AiDispatcher |
| F892 | ICalendarSyncService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F893 | IGoogleCalendarConnector | CORE FABRIC (Skill 01) | External connector — Google Calendar API |
| F894 | IOutlookCalendarConnector | CORE FABRIC (Skill 01) | External connector — Microsoft Graph API |
| F895 | IQuietHoursService | DATABASE FABRIC (Skill 05) | PostgreSQL |
| F896 | IReminderOrchestratorService | QUEUE FABRIC (Skill 04) | Redis Streams |
| F897 | IStreakProtectionService | DATABASE FABRIC (Skill 05) | PostgreSQL |

**Factory contracts:**
```
F890: ILessonPlanService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    GetTodaysPlanAsync(studentId) → DataProcessResult<Dictionary<string,object>>
    UpsertPlanAsync(Dictionary<string,object> plan) → DataProcessResult<string>
    GetWeeklyPlanAsync(studentId, weekStart) → DataProcessResult<List<Dictionary<string,object>>>

F891: IAdaptivePlannerService
  FABRIC: AI ENGINE FABRIC → AiDispatcher
  Methods:
    RegenerateTomorrowAsync(studentId, todayPerformance) → DataProcessResult<Dictionary<string,object>>
    Generate30DayPlanAsync(studentId, knowledgeMap) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: horizon_days, sessions_per_day, min_session_minutes — FREEDOM config

F892: ICalendarSyncService
  FABRIC: QUEUE FABRIC (Skill 04) → Redis Streams
  Methods:
    EnqueueSyncAsync(studentId, lessonPlan, provider) → DataProcessResult<bool>
    ProcessSyncAsync(Dictionary<string,object> event) → DataProcessResult<Dictionary<string,object>>
  NOTE: Durable queue — Retry + DLQ for calendar sync reliability (calendar sync must survive transient API failures)
  NOTE: provider field routes to F893 (Google) or F894 (Outlook) via factory resolution

F893: IGoogleCalendarConnector
  FABRIC: CORE FABRIC (Skill 01) — external connector, not a database fabric
  Methods:
    UpsertEventAsync(Dictionary<string,object> calendarEvent) → DataProcessResult<Dictionary<string,object>>
    DeleteEventAsync(eventId, calendarId) → DataProcessResult<bool>
    FindFreeSlotAsync(studentId, durationMinutes, preferredWindow) → DataProcessResult<Dictionary<string,object>>
  NOTE: Service code NEVER imports google-auth or googleapis SDK directly.
        Connector wraps all Google-specific logic. Swappable to ICalendarConnector interface.
  IRON RULE: No platform-specific values in service code — UI and service must be fabric-first.

F894: IOutlookCalendarConnector
  FABRIC: CORE FABRIC (Skill 01) — external connector
  Methods:
    UpsertEventAsync(Dictionary<string,object> calendarEvent) → DataProcessResult<Dictionary<string,object>>
    DeleteEventAsync(eventId) → DataProcessResult<bool>
    FindFreeSlotAsync(studentId, durationMinutes, preferredWindow) → DataProcessResult<Dictionary<string,object>>
  NOTE: Wraps Microsoft Graph API. No @microsoft/microsoft-graph-client import in service code.

F895: IQuietHoursService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    GetQuietHoursAsync(studentId) → DataProcessResult<Dictionary<string,object>>
    IsQuietTimeNowAsync(studentId, timezone) → DataProcessResult<bool>
    GetNextAllowedSlotAsync(studentId, afterTimestamp) → DataProcessResult<long>
  FREEDOM: quiet_hours_start, quiet_hours_end, blackout_dates — FREEDOM config

F896: IReminderOrchestratorService
  FABRIC: QUEUE FABRIC (Skill 04) → Redis Streams
  Methods:
    EnqueueReminderAsync(Dictionary<string,object> reminder) → DataProcessResult<bool>
    ProcessEscalationAsync(Dictionary<string,object> event) → DataProcessResult<Dictionary<string,object>>
  FREEDOM: reminder_escalation_policy (soft/hard), nudge_interval_minutes — FREEDOM config
  NOTE: Escalation ladder: calendar task → push notification → "2-minute recap" fallback

F897: IStreakProtectionService
  FABRIC: DATABASE FABRIC → PostgreSQL
  Methods:
    ApplyProtectionAsync(studentId, missedDate, reason) → DataProcessResult<bool>
    IsProtectedAsync(studentId, date) → DataProcessResult<bool>
  FREEDOM: streak_protection_enabled, protection_uses_per_month — FREEDOM config
  NOTE: Optional grace policy. MACHINE validates usage count; FREEDOM sets threshold.
```

---

## DESIGN RECORDS — FLOW-24

### DR-134: Calendar Connector Abstraction
**Decision:** Calendar sync routes through ICalendarSyncService (Queue Fabric) → IGoogleCalendarConnector / IOutlookCalendarConnector. No direct SDK in service code.
**Rationale:** Swappable calendar providers. DLQ protection on calendar API failures.

### DR-135: Hybrid Sync/Async Quiz Completion
**Decision:** Quiz submission returns points preview SYNC (≤1s UX). Ledger write, badge check, streak update, plan adaptation run ASYNC via Queue Fabric.
**Rationale:** Same hybrid contract as FLOW-05 gamification. User sees instant feedback. Durable events prevent loss.

### DR-136: Append-Only Gamification Ledger
**Decision:** IGamificationLedgerService uses PostgreSQL append-only table. No UPDATE/DELETE ever.
**Rationale:** Anti-cheat, auditability, SOC2-ready event trail. BigInt running totals maintained server-side.

### DR-137: Timezone-Correct Streaks
**Decision:** IStreakManagerService uses timezone from StudentProfile (F852), not client request header.
**Rationale:** Trust-critical. Client-supplied timezone could manipulate streak boundaries.

### DR-138: Safety Gate Blocking Rule
**Decision:** ILessonSafetyGate (F872) MUST pass before any lesson is published. isMinor flag triggers strict policy. No bypass path.
**Rationale:** Minor protection, age-appropriate content guarantee.

### DR-139: Server-Side Grading Only
**Decision:** IQuizGraderService (F881) is the sole points source. Client-submitted scores = build failure.
**Rationale:** Anti-cheat. Gamification integrity.

### DR-140: Domain Pack Architecture
**Decision:** Curriculum packs (School/Business/Developer) are configuration in ES (F857), not code branches.
**Rationale:** Freedom Machine — new domain packs without code changes.

### DR-141: Graph-RAG for Prerequisites
**Decision:** ICurriculumGraphService (F864) uses graph DB (Neo4j default, swappable). ITopicOntologyService (F865) combines graph traversal + vector RAG.
**Rationale:** Linear vector search insufficient for prerequisite dependency chains.

---

## BACKWARD COMPATIBILITY

All F1–F851 factories remain UNCHANGED.
All Families 1–118 remain UNCHANGED.
FLOW-24 adds:
- Families 119–125 (7 new families)
- Factories F852–F897 (46 new factories)
- Design Records DR-134–DR-141 (8 new DRs)

---

## SAVE POINT: FLOW24:ENGINE_ARCHITECTURE ✅
**Next numbers after FLOW-24:**
- Factory: F898, Family: 126
