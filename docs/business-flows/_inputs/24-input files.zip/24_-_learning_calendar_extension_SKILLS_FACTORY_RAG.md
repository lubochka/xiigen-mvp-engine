# SKILLS FACTORY RAG — FLOW-24: Learning Calendar Extension (Personal AI Tutor)
## Status: COMPLETE ✅ | Skills SK-189–SK-198

---

## PURPOSE

These skills are the AF-4 (RAG Task Context) retrieval library for FLOW-24. When the engine generates a new service related to the learning calendar domain, AF-4 searches this skill library to retrieve reusable patterns, avoiding re-invention of already-solved problems.

Each skill includes:
- Pattern description and use cases
- Positive example (correct engine-generated code pattern)
- Negative example (what the generated code must NOT do)
- Which task types and factories reference this skill
- DNA compliance annotation

---

## SK-189: Knowledge Map Builder
**Domain:** Knowledge Diagnosis  
**AF-4 Retrieval Tags:** `knowledge-map`, `diagnosis`, `topic-score`, `competency`, `gap-analysis`  
**Referenced By:** T307, T311 | F858, F861  

**Pattern:** Build a dynamic, schema-less topic score map using Dictionary<string,object>. Scores are server-computed. Map supports partial updates per topic (upsert by topicId).

```csharp
// ✅ POSITIVE — correct engine-generated pattern
public async Task<DataProcessResult<Dictionary<string,object>>> UpsertTopicScoreAsync(
    string studentId, string tenantId, string topicId, float score, float confidence)
{
    // DNA-1: no typed KnowledgeMapEntry model — Dictionary only
    var filter = BuildSearchFilter(new Dictionary<string, object>
    {
        ["student_id"] = studentId,
        ["tenant_id"] = tenantId  // DNA-5: scope isolation
    });
    
    var existing = await _db.SearchDocumentsAsync<Dictionary<string,object>>(filter);
    var map = existing.Data?.FirstOrDefault() ?? new Dictionary<string, object>();
    
    var topics = map.ContainsKey("topics") 
        ? (Dictionary<string,object>)map["topics"] 
        : new Dictionary<string, object>();
    
    topics[topicId] = new Dictionary<string, object>
    {
        ["score"] = score,          // server-computed — DNA-3
        ["confidence"] = confidence,
        ["last_seen"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        ["version"] = Guid.NewGuid().ToString()  // optimistic concurrency
    };
    
    map["topics"] = topics;
    map["student_id"] = studentId;
    map["tenant_id"] = tenantId;
    
    return await _db.StoreDocumentAsync(map);
}

// ❌ NEGATIVE — DNA violations
public async Task UpdateScoreAsync(KnowledgeMapEntry entry)  // VIOLATION: typed model
{
    await _db.UpdateAsync(entry);  // VIOLATION: direct ORM, not fabric interface
    // VIOLATION: no tenantId scope
    // VIOLATION: typed model instead of Dictionary
}
```

**When AF-4 returns this skill:** Any T307 or T311 generation requesting knowledge map persistence pattern.

---

## SK-190: Consent Gate — Minor Protection
**Domain:** Student Identity & Consent  
**AF-4 Retrieval Tags:** `consent`, `minor`, `parental-gate`, `COPPA`, `blocking-gate`  
**Referenced By:** T307, T308, T309 | F853, F872  

**Pattern:** Consent gate fires as the FIRST step in any flow touching a student. Minor=true triggers stricter policies. Consent status is READ-ONLY server-side.

```csharp
// ✅ POSITIVE — consent gate pattern
public async Task<DataProcessResult<bool>> CheckAndEnforceConsentAsync(
    string studentId, string tenantId, string operationType)
{
    // Always first — scope gate
    var scopeResult = await _tenantGate.EnforceScopeAsync(tenantId, studentId);
    if (!scopeResult.IsSuccess) return DataProcessResult<bool>.Fail("SCOPE_VIOLATION");
    
    // Minor check — server-computed, never from client
    var consentData = await _consentService.GetConsentAsync(studentId);
    if (!consentData.IsSuccess) return DataProcessResult<bool>.Fail("CONSENT_READ_FAILED");
    
    var isMinor = (bool)consentData.Data["is_minor"];  // server truth
    var consentGranted = (bool)consentData.Data["consent_granted"];
    
    if (isMinor && !consentGranted)
        return DataProcessResult<bool>.Fail("PARENTAL_CONSENT_REQUIRED");
    
    // Propagate to downstream context (for ASYNC consumers)
    _context.SetConsentContext(new Dictionary<string, object>
    {
        ["is_minor"] = isMinor,
        ["consent_version"] = consentData.Data["consent_version"],
        ["tenant_id"] = tenantId,
        ["student_id"] = studentId
    });
    
    return DataProcessResult<bool>.Success(true);
}

// ❌ NEGATIVE — bypass pattern
public async Task GenerateLessonAsync(string studentId, bool isMinor)  
// VIOLATION: isMinor from client parameter, not server
{
    // VIOLATION: no consent check before AI call
    var lesson = await _openAiClient.CreateChatCompletionAsync(...); // VIOLATION: direct SDK
}
```

---

## SK-191: Lesson Composer — RAG + LLM Pattern
**Domain:** Lesson Generation  
**AF-4 Retrieval Tags:** `lesson-composer`, `rag-llm`, `ai-generation`, `difficulty-adapter`, `micro-lesson`  
**Referenced By:** T308, T312, T314 | F870, F871, F875  

**Pattern:** Fetch RAG atoms first (no LLM without retrieval context). Compose via AiDispatcher (multi-model). Safety gate after compose, before publish.

```csharp
// ✅ POSITIVE — RAG-before-LLM pattern
public async Task<DataProcessResult<Dictionary<string,object>>> ComposeLessonAsync(
    string topicId, string studentId, string tenantId, float difficulty)
{
    // DNA-5: scope isolation on atom retrieval
    var ragSpec = BuildSearchFilter(new Dictionary<string, object>
    {
        ["topic_id"] = topicId,
        ["difficulty_min"] = difficulty - 0.15f,
        ["difficulty_max"] = difficulty + 0.15f,
        ["tenant_id"] = tenantId
    });
    
    // Step 1: RAG atoms BEFORE LLM (iron rule IR-308-5)
    var atoms = await _ragService.SearchAsync(ragSpec);
    if (!atoms.IsSuccess) return DataProcessResult<Dictionary<string,object>>.Fail("RAG_FAILED");
    
    // Step 2: Build composition spec (Dictionary — DNA-1)
    var spec = new Dictionary<string, object>
    {
        ["topic_id"] = topicId,
        ["atoms"] = atoms.Data,
        ["difficulty"] = difficulty,
        ["locale"] = _context.Locale,
        ["is_minor"] = _context.IsMinor  // propagated from consent gate (SK-190)
    };
    
    // Step 3: AI Engine Fabric — never openai.chat() directly
    var composed = await _aiDispatcher.GenerateAsync(spec);  // IAiProvider
    
    // Step 4: Safety gate — ALWAYS before return (CF-387)
    var safetyResult = await _safetyGate.EvaluateAsync(composed.Data, _context.IsMinor);
    if (!(bool)safetyResult.Data["passed"])
        return DataProcessResult<Dictionary<string,object>>.Fail("SAFETY_GATE_FAILED");
    
    composed.Data["safety_gate_token"] = safetyResult.Data["token"];  // required by F873
    return composed;
}

// ❌ NEGATIVE
var lesson = await _openAiClient.GenerateAsync(prompt);  // VIOLATION: direct SDK (IR-308-3)
// VIOLATION: no RAG atoms fetched
// VIOLATION: safety gate not called
```

---

## SK-192: Curriculum Graph-RAG
**Domain:** Curriculum & Prerequisites  
**AF-4 Retrieval Tags:** `curriculum-graph`, `prerequisites`, `graph-rag`, `neo4j`, `skill-tree`, `mastery-path`  
**Referenced By:** T307, T308, T311 | F863, F864, F865, F867  

**Pattern:** Hybrid Graph-RAG — graph traversal (Neo4j via DB Fabric) combined with vector similarity (RAG Fabric). All graph queries through IDatabaseService with Graph provider config.

```csharp
// ✅ POSITIVE — Graph-RAG hybrid
public async Task<DataProcessResult<List<Dictionary<string,object>>>> GetNextReadyTopicsAsync(
    string studentId, string tenantId)
{
    // Step 1: Get knowledge map gaps
    var gapFilter = BuildSearchFilter(new Dictionary<string, object>
    {
        ["student_id"] = studentId,
        ["tenant_id"] = tenantId,  // DNA-5
        ["score_max"] = 0.6f       // topics below mastery threshold
    });
    var gaps = await _knowledgeMapService.GetGapsAsync(studentId, 0.6f);
    
    // Step 2: Graph traversal for prerequisites (DB Fabric → Neo4j provider)
    var readyTopics = new List<Dictionary<string, object>>();
    foreach (var gap in gaps.Data)
    {
        var prereqCheck = await _prereqValidator.CheckReadinessAsync(
            studentId, (string)gap["topic_id"]);
        
        if ((bool)prereqCheck.Data["is_ready"])
            readyTopics.Add(gap);
    }
    
    // Step 3: Vector similarity for related topics (RAG Fabric)
    if (readyTopics.Count < 3)
    {
        var similar = await _topicOntology.SearchTopicAsync(
            BuildSearchFilter(new Dictionary<string, object>
            {
                ["pack_id"] = _context.PackId,
                ["locale"] = _context.Locale
            }), _context.PackId, _context.Locale);
        readyTopics.AddRange(similar.Data.Take(3 - readyTopics.Count));
    }
    
    return DataProcessResult<List<Dictionary<string,object>>>.Success(readyTopics);
}

// ❌ NEGATIVE
var neo4jDriver = GraphDatabase.Driver("bolt://localhost");  // VIOLATION: direct Neo4j SDK
var session = neo4jDriver.AsyncSession();  // VIOLATION: not through DB Fabric
```

---

## SK-193: Difficulty Adapter
**Domain:** Lesson Personalization  
**AF-4 Retrieval Tags:** `difficulty-adapter`, `adaptive-learning`, `simplify`, `enrich`, `srs`  
**Referenced By:** T308, T311 | F875, F882  

**Pattern:** Adapt lesson difficulty based on studentId's recent topic score from KnowledgeMap. Two modes: Simplify (score < threshold) and Enrich (score > threshold). Both routes pass through safety gate.

```csharp
// ✅ POSITIVE
public async Task<DataProcessResult<Dictionary<string,object>>> AdaptDifficultyAsync(
    string lessonId, string studentId, string topicId, string tenantId)
{
    var mapResult = await _knowledgeMap.GetMapAsync(studentId);
    var topics = (Dictionary<string,object>)mapResult.Data["topics"];
    
    float score = topics.ContainsKey(topicId) 
        ? (float)((Dictionary<string,object>)topics[topicId])["score"]
        : 0.5f;  // default difficulty for new topics
    
    // Thresholds from FREEDOM config (F856) — no literals
    var config = await _localeConfig.GetLocaleConfigAsync(_context.Locale, _context.Grade);
    float simplifyThreshold = (float)config.Data["simplify_threshold"];
    float enrichThreshold = (float)config.Data["enrich_threshold"];
    
    if (score < simplifyThreshold)
        return await _difficultyAdapter.SimplifyAsync(lessonId, score);
    else if (score > enrichThreshold)
        return await _difficultyAdapter.EnrichAsync(lessonId, score);
    
    return await _lessonStore.GetPublishedAsync(lessonId);  // no adaptation needed
}
// ❌ NEGATIVE: if (score < 0.4) // VIOLATION: literal threshold, not FREEDOM config
```

---

## SK-194: Gamification Ledger — Append-Only Pattern
**Domain:** Gamification  
**AF-4 Retrieval Tags:** `gamification`, `ledger`, `append-only`, `points`, `badges`, `anti-cheat`  
**Referenced By:** T309 | F884, F885, F886, F888  

**Pattern:** Ledger is append-only (no UPDATE/DELETE). Points sourced from server computation only. Badge evaluation is async via Queue Fabric. SYNC path returns preview; ASYNC path writes truth.

```csharp
// ✅ POSITIVE — hybrid pattern (same as FLOW-05, extended)
// SYNC path:
public async Task<DataProcessResult<Dictionary<string,object>>> GetPointsPreviewAsync(
    string sessionId, string studentId)
{
    // Grade server-side — never accept client points
    var gradeResult = await _quizGrader.GradeAsync(sessionId, _context.Answers);
    var points = await _pointsCalculator.CalculateAsync(gradeResult.Data, 
        _context.CurrentStreak, _context.BonusFlags);
    
    // Return preview ONLY — no ledger write in sync path (IR-309-1)
    return DataProcessResult<Dictionary<string,object>>.Success(new Dictionary<string,object>
    {
        ["points_preview"] = points.Data["points_earned"],
        ["badge_preview"] = await CheckBadgePreviewAsync(studentId, points)
    });
}

// ASYNC path (via queue event):
public async Task ProcessGamificationAsync(Dictionary<string,object> queueEvent)
{
    // Re-validate consent in async consumer (CF-394)
    var consent = (Dictionary<string,object>)queueEvent["consent_context"];
    await _consentService.ValidateVersionAsync(
        (string)consent["student_id"], (string)consent["consent_version"]);
    
    // Append-only — never UPDATE
    await _ledger.AppendEventAsync(new Dictionary<string, object>
    {
        ["student_id"] = queueEvent["student_id"],
        ["tenant_id"] = queueEvent["tenant_id"],
        ["points"] = queueEvent["server_computed_points"],  // from grader, not client
        ["source_flow"] = "FLOW-24",  // CF-389: deduplication
        ["quiz_attempt_id"] = queueEvent["quiz_attempt_id"],
        ["timestamp"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
    });
}

// ❌ NEGATIVE
await _db.UpdateAsync("UPDATE ledger SET points = points + 100 WHERE student_id = ?");
// VIOLATION: UPDATE on append-only table (CF-384)
var points = request.Body["pointsEarned"];  // VIOLATION: client-submitted points (CF-385)
```

---

## SK-195: Streak Manager — Timezone-Aware
**Domain:** Gamification  
**AF-4 Retrieval Tags:** `streak`, `timezone`, `gamification`, `trust`, `grace-period`  
**Referenced By:** T309, T310 | F887, F897  

**Pattern:** Streak boundary computed from profile timezone (F852), never from client. Redis hot state for fast reads; PostgreSQL for durable persist. Optional streak protection via F897.

```csharp
// ✅ POSITIVE
public async Task<DataProcessResult<Dictionary<string,object>>> UpdateStreakAsync(
    string studentId, string tenantId, long completionTimestampUtc)
{
    // Get timezone from PROFILE — not from client (CF-386)
    var profile = await _studentProfile.GetProfileAsync(studentId, tenantId);
    var timezone = (string)profile.Data["timezone"];  // e.g. "Asia/Jerusalem"
    
    var tz = TimeZoneInfo.FindSystemTimeZoneById(timezone);
    var completionLocal = TimeZoneInfo.ConvertTimeFromUtc(
        DateTimeOffset.FromUnixTimeMilliseconds(completionTimestampUtc).UtcDateTime, tz);
    var completionDate = DateOnly.FromDateTime(completionLocal);
    
    // Get current streak from Redis (fast)
    var currentStreak = await _cache.GetAsync($"streak:{tenantId}:{studentId}");
    var streakData = currentStreak != null 
        ? System.Text.Json.JsonSerializer.Deserialize<Dictionary<string,object>>(currentStreak)
        : new Dictionary<string, object> { ["count"] = 0, ["last_date"] = null };
    
    var lastDate = streakData["last_date"] != null 
        ? DateOnly.Parse((string)streakData["last_date"]) 
        : (DateOnly?)null;
    
    bool extended = lastDate.HasValue && completionDate == lastDate.Value.AddDays(1);
    bool maintained = lastDate.HasValue && completionDate == lastDate.Value;
    
    var newCount = extended ? (int)streakData["count"] + 1 
                 : maintained ? (int)streakData["count"]
                 : 1;  // streak reset
    
    var updated = new Dictionary<string, object>
    {
        ["count"] = newCount,
        ["last_date"] = completionDate.ToString("yyyy-MM-dd"),
        ["timezone"] = timezone
    };
    
    // Hot state in Redis + durable persist in PG (dual write)
    await _cache.SetAsync($"streak:{tenantId}:{studentId}", 
        System.Text.Json.JsonSerializer.Serialize(updated));
    await _db.StoreDocumentAsync(BuildStreakDocument(studentId, tenantId, updated));
    
    return DataProcessResult<Dictionary<string,object>>.Success(updated);
}

// ❌ NEGATIVE
public async Task UpdateStreakAsync(string studentId, string timezone)  
// VIOLATION: timezone from caller, not profile (CF-386)
```

---

## SK-196: Calendar Connector — Fabric-First
**Domain:** Calendar Sync  
**AF-4 Retrieval Tags:** `calendar-sync`, `google-calendar`, `outlook`, `fabric-first`, `queue-pattern`  
**Referenced By:** T308, T310, T313 | F892, F893, F894  

**Pattern:** All calendar operations enqueued via F892 (QUEUE FABRIC). No direct SDK import in service code. Provider resolved from StudentProfile config. Connector interfaces (F893/F894) are the sole calendar integration points.

```csharp
// ✅ POSITIVE — fabric-first calendar sync
public async Task<DataProcessResult<bool>> ScheduleLessonAsync(
    string studentId, string tenantId, string lessonId, long preferredTimestampUtc)
{
    // Resolve provider from profile config — NEVER hardcoded
    var profile = await _studentProfile.GetProfileAsync(studentId, tenantId);
    var provider = (string)profile.Data["calendar_provider"];  // "google"|"outlook"|"caldav"
    
    var calendarEvent = new Dictionary<string, object>
    {
        ["student_id"] = studentId,
        ["tenant_id"] = tenantId,
        ["lesson_id"] = lessonId,
        ["summary"] = "Today's Learning Session",  // FREEDOM: title from ES config
        ["start_timestamp_utc"] = preferredTimestampUtc,
        ["duration_minutes"] = _config.GetValue("lesson_duration_minutes"),  // FREEDOM
        ["source_flow"] = "FLOW-24",  // CF-382: namespace isolation
        ["namespace"] = "lesson"
    };
    
    // Enqueue via QUEUE FABRIC — never direct HTTP (CF-388)
    return await _calendarSyncService.EnqueueSyncAsync(studentId, calendarEvent, provider);
}

// Consumer (F892 → F893/F894):
public async Task ProcessCalendarSyncAsync(Dictionary<string,object> queueEvent)
{
    var provider = (string)queueEvent["provider"];
    
    // Factory resolution — never direct instantiation
    var connector = provider switch
    {
        "google" => await _factory.CreateAsync<IGoogleCalendarConnector>(context),
        "outlook" => await _factory.CreateAsync<IOutlookCalendarConnector>(context),
        _ => throw new NotSupportedException($"Unknown provider: {provider}")
    };
    
    await connector.UpsertEventAsync((Dictionary<string,object>)queueEvent["event"]);
}

// ❌ NEGATIVE
using Google.Apis.Calendar.v3;  // VIOLATION: direct SDK import (CF-388, IR-313-1)
var service = new CalendarService(initializer);  // VIOLATION
await service.Events.Insert(calEvent, "primary").ExecuteAsync();  // VIOLATION
```

---

## SK-197: Reminder Orchestrator — Escalation Ladder
**Domain:** Reminders & Engagement  
**AF-4 Retrieval Tags:** `reminder`, `escalation`, `quiet-hours`, `nudge`, `push-notification`  
**Referenced By:** T308, T310 | F895, F896  

**Pattern:** Quiet hours check BEFORE enqueue. Escalation ladder: calendar task → push notification → "2-minute recap" fallback. All via Queue Fabric (durable). FREEDOM-configurable policy.

```csharp
// ✅ POSITIVE
public async Task<DataProcessResult<bool>> EnqueueReminderAsync(
    string studentId, string tenantId, string lessonId, long scheduledTimestampUtc)
{
    // Check quiet hours FIRST (CF-391)
    var isQuiet = await _quietHours.IsQuietTimeNowAsync(studentId, _context.Timezone);
    if ((bool)isQuiet.Data)
    {
        var nextSlot = await _quietHours.GetNextAllowedSlotAsync(studentId, scheduledTimestampUtc);
        scheduledTimestampUtc = (long)nextSlot.Data;  // defer to next allowed window
    }
    
    // Escalation config from FREEDOM (no literals)
    var policy = await _localeConfig.GetLocaleConfigAsync(_context.Locale, _context.Grade);
    var escalationPolicy = (string)policy.Data["reminder_escalation_policy"];  // "soft"|"hard"
    
    var reminder = new Dictionary<string, object>
    {
        ["student_id"] = studentId,
        ["tenant_id"] = tenantId,
        ["lesson_id"] = lessonId,
        ["scheduled_utc"] = scheduledTimestampUtc,
        ["escalation_policy"] = escalationPolicy,
        ["source_flow"] = "FLOW-24",  // CF-391: dedup key
        ["steps"] = new[] { "calendar_task", "push_notification", "two_minute_recap" }
    };
    
    return await _reminderQueue.EnqueueAsync(reminder);
}
// ❌ NEGATIVE
if (hour >= 22 || hour < 8) return;  // VIOLATION: hardcoded quiet hours (should be FREEDOM config)
await _googleFcm.SendNotification(...);  // VIOLATION: direct FCM SDK, not Queue Fabric
```

---

## SK-198: Multi-Tenant Quota Gate
**Domain:** Multi-Tenancy  
**AF-4 Retrieval Tags:** `multi-tenant`, `quota`, `noisy-neighbor`, `rate-limit`, `isolation`  
**Referenced By:** T307, T308, T312, T314 | F855  

**Pattern:** Tenant quota check before AI-heavy operations. Quota config in ES (FREEDOM). Noisy neighbor detection. Soft throttle for education flows (defer, not hard-fail students).

```csharp
// ✅ POSITIVE
public async Task<DataProcessResult<bool>> ValidateAndConsumeQuotaAsync(
    string tenantId, string operationType, int estimatedTokenCost)
{
    // Scope enforcement first (DNA-5)
    var scopeResult = await _tenantGate.EnforceScopeAsync(tenantId, null);
    if (!scopeResult.IsSuccess) return DataProcessResult<bool>.Fail("SCOPE_VIOLATION");
    
    // Quota from ES FREEDOM config — no literals
    var quotaConfig = await _db.SearchDocumentsAsync<Dictionary<string,object>>(
        BuildSearchFilter(new Dictionary<string, object> 
        { ["tenant_id"] = tenantId, ["config_type"] = "ai_quota" }));
    
    var dailyBudget = (int)quotaConfig.Data["daily_ai_token_budget"];
    var currentUsage = await _cache.GetAsync($"quota:{tenantId}:daily");
    int used = currentUsage != null ? int.Parse(currentUsage) : 0;
    
    if (used + estimatedTokenCost > dailyBudget)
    {
        // Soft throttle — defer to off-peak, not hard-fail (CF-393)
        await _queue.EnqueueAsync(new Dictionary<string, object>
        {
            ["tenant_id"] = tenantId,
            ["operation"] = operationType,
            ["defer_reason"] = "QUOTA_SOFT_LIMIT",
            ["retry_after_utc"] = GetOffPeakSlot()
        });
        return DataProcessResult<bool>.Success(false);  // deferred, not failed
    }
    
    await _cache.IncrementAsync($"quota:{tenantId}:daily", estimatedTokenCost);
    return DataProcessResult<bool>.Success(true);
}
// ❌ NEGATIVE
if (tenantId == "premium-tenant-001") return true;  // VIOLATION: hardcoded tenant ID
// VIOLATION: no quota check before AI calls
```

---

## AF-4 RETRIEVAL INDEX — FLOW-24

| Query Pattern | Returns | Task Types |
|---------------|---------|------------|
| "knowledge map persistence" | SK-189 | T307, T311 |
| "minor consent blocking" | SK-190 | T307, T308, T309 |
| "lesson composer rag llm" | SK-191 | T308, T312, T314 |
| "curriculum graph prerequisites" | SK-192 | T307, T308, T311 |
| "difficulty adaptation adaptive" | SK-193 | T308, T311 |
| "gamification ledger append-only" | SK-194 | T309 |
| "streak timezone trust" | SK-195 | T309, T310 |
| "calendar sync fabric-first" | SK-196 | T308, T310, T313 |
| "reminder escalation quiet hours" | SK-197 | T308, T310 |
| "multi-tenant quota noisy-neighbor" | SK-198 | T307, T308, T312, T314 |

---

## BACKWARD COMPATIBILITY

All SK-1–SK-188 skills remain UNCHANGED.
FLOW-24 adds SK-189–SK-198 (10 new skills).

---

## SAVE POINT: FLOW24:SKILLS_FACTORY_RAG ✅
**Next skill after FLOW-24:** SK-199
