# V62 BFA STRESS TEST — FLOW-24: Learning Calendar Extension (Personal AI Tutor)
## Status: COMPLETE ✅ | BFA Rules CF-380–CF-394 | Stress Tests ST-215–ST-224

---

## BFA (BUSINESS FLOW ARBITER) — PURPOSE

The BFA detects cross-service conflicts BEFORE code ships. Every new entity, event, and API registered by FLOW-24 is cross-checked against FLOW-01 through FLOW-20 for:
- Entity ownership conflicts (two flows mutating the same entity)
- Event naming collisions
- Concurrent write races on shared state
- Scope isolation violations
- MACHINE rule bypass attempts

---

## NEW BFA REGISTRATIONS — FLOW-24

### New Entities (registered in BFA index)
| Entity | Owner Flow | Mutable By | Notes |
|--------|-----------|------------|-------|
| StudentProfile | FLOW-24 | FLOW-24 only | Extends UserProfile from FLOW-01 — no overlap in fields |
| ConsentProfile | FLOW-24 | FLOW-24 only | New entity. GDPR/COPPA-adjacent. |
| KnowledgeMap | FLOW-24 | FLOW-24 only | New entity. |
| LessonPlan | FLOW-24 | FLOW-24 only | New entity. |
| DailyLesson | FLOW-24 | FLOW-24 only | New entity. |
| Quiz + QuizAttempt | FLOW-24 | FLOW-24 only | Append-only. |
| GamificationLedgerEvent | FLOW-24 | FLOW-24 only | Append-only. Extends pattern from FLOW-05. |
| BadgeDefinition + BadgeUnlock | FLOW-24 | FLOW-24 only | New entity. |
| CalendarTaskSyncState | FLOW-24 | FLOW-24 + FLOW-03 | See CF-382 |
| StreakRecord | FLOW-24 | FLOW-24 only | New entity. |

### New Events (registered in BFA event bus index)
| Event | Emitter | Consumers | Notes |
|-------|---------|-----------|-------|
| CalendarExtensionInstalled | FLOW-24 | T307 | New event |
| DailyLessonScheduleTrigger | FLOW-24 | T308 | New event |
| LessonPublished | FLOW-24 | T308, T313 | New event |
| StudentSubmitsQuiz | FLOW-24 | T309 | New event |
| QuizCompleted | FLOW-24 | T311 | New event (async) |
| CalendarEventExpiredWithoutCompletion | FLOW-24 | T310 | New event |
| BadgeUnlocked | FLOW-24 | T309 async | New event |
| WeeklyResearchScheduleTrigger | FLOW-24 | T312 | New event |
| MonthlyCapstoneScheduleTrigger | FLOW-24 | T314 | New event |

---

## BFA CONFLICT RULES — FLOW-24

### CF-380: Multi-Tenant Student Profile Isolation
**TRIGGER:** StudentProfile read/write without tenantId  
**SEVERITY:** CRITICAL  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-01 (User Registration)  
**RULE:**
- StudentProfile extends UserProfile (FLOW-01 identity) but is a FLOW-24-owned entity
- Every query to StudentProfile MUST include tenantId (F855 enforces)
- Cross-tenant student profile access = BUILD FAILURE
**RESOLUTION:** F855.EnforceScopeAsync() runs as first step in all T307, T308, T309 pipelines.
**TEST:** ST-215

---

### CF-381: KnowledgeMap Concurrent Write — Diagnosis vs Quiz Completion
**TRIGGER:** T307 (initial map build) and T309/T311 (score update) targeting same studentId simultaneously  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 internal (T307 ↔ T311)  
**RULE:**
- KnowledgeMap write must be serialized per studentId
- T307 onboarding sets initial map; T311 updates scores. Both write to F858.
- Concurrent writes without ordering = stale score race condition
**RESOLUTION:** F858 UpsertTopicScoreAsync uses optimistic concurrency (version field). T307 initial map write must complete before T311 is eligible to fire for same student (event ordering via queue).
**TEST:** ST-216

---

### CF-382: Calendar Task Ownership — FLOW-24 vs FLOW-03
**TRIGGER:** Both FLOW-24 (lesson tasks) and FLOW-03 (Event Creation & Promotion) create calendar events for the same user  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-03  
**RULE:**
- CalendarTaskSyncState entity is shared. Both flows may upsert calendar events.
- Calendar event namespace MUST include source flow prefix: "lesson:" vs "event:"
- No deletion of events across flows (FLOW-24 must not delete FLOW-03 events and vice versa)
- F892 (CalendarSyncService) routes by event type; sourceFlow must be present in event metadata
**RESOLUTION:** Event metadata includes `source_flow: "FLOW-24"`. F893/F894 connectors enforce namespace-scoped operations.
**TEST:** ST-217

---

### CF-383: Minor Consent Gate — Blocking Propagation
**TRIGGER:** Content generation (T308, T312, T314) called without checking ConsentProfile for minor students  
**SEVERITY:** CRITICAL  
**FLOWS AFFECTED:** FLOW-24 internal (all generation flows)  
**RULE:**
- F853.IsMinorAsync() MUST be called before any AI generation factory (F870, F878, F881)
- isMinor=true triggers F872 strict content policy
- No content generation pathway may bypass minor check
- Minor flag must propagate through queue events to ASYNC path consumers
**RESOLUTION:** T308/T309/T312/T314 each carry isMinor in their event payload. AF-8 security scan validates this propagation.
**TEST:** ST-218

---

### CF-384: Append-Only Ledger Integrity
**TRIGGER:** Any UPDATE or DELETE on GamificationLedgerEvent or QuizAttempt tables  
**SEVERITY:** CRITICAL  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-05 (Lesson Gamification — same ledger pattern)  
**RULE:**
- F884 (IGamificationLedgerService) and F880 (IQuizAttemptStore) are APPEND-ONLY
- Any migration, script, or generated code that issues UPDATE/DELETE against these tables = IMMEDIATE BUILD FAILURE
- BFA monitors schema migration files for these table modifications
**RESOLUTION:** DB schema enforces append-only via triggers/policies. AF-7 compliance scan validates no UPDATE/DELETE in generated service code.
**TEST:** ST-219

---

### CF-385: Points Source Integrity — Server-Side Only
**TRIGGER:** Client-submitted points value accepted by any service  
**SEVERITY:** CRITICAL  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-05 (Lesson Gamification)  
**RULE:**
- Points are calculated by F881 (IQuizGraderService) + F888 (IPointsCalculatorService) ONLY
- Any service accepting a pointsEarned value from the request body = BUILD FAILURE
- SYNC path returns points_preview; this is NOT a confirmed award — ASYNC ledger write is the truth
**RESOLUTION:** AF-6 code review validates no request body fields for points in T309 controller. BFA monitors API contracts for points-related fields in inbound payloads.
**TEST:** ST-220

---

### CF-386: Timezone Streak Manipulation
**TRIGGER:** Streak boundary computed using client-supplied timezone header instead of F852 StudentProfile timezone  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 internal (T309 ↔ F887)  
**RULE:**
- F887.UpdateStreakAsync must derive timezone from F852 (server-stored profile), never from X-Timezone header or client payload
- Test: client sends timezone=UTC while profile stores Asia/Jerusalem → streak boundary must use Asia/Jerusalem
**RESOLUTION:** F887 takes studentId; resolves timezone internally via F852. No timezone parameter accepted from caller.
**TEST:** ST-221

---

### CF-387: Safety Gate Order — Compose Before Gate Before Publish
**TRIGGER:** F873 (LessonPublishService) called before F872 (LessonSafetyGate) passes  
**SEVERITY:** CRITICAL  
**FLOWS AFFECTED:** FLOW-24 internal (T308, T312, T314)  
**RULE:**
- Step order in DAG: F870 (compose) → F872 (safety gate) → F873 (publish)
- Any reversed ordering = BUILD FAILURE
- F873 must require a SafetyGateToken (issued by F872 on pass) in its method signature
**RESOLUTION:** Template 65 DAG enforces step order. AF-9 judge validates SafetyGateToken present in publish call.
**TEST:** ST-222

---

### CF-388: Calendar Provider Hardcoding
**TRIGGER:** Service code directly imports Google Calendar SDK or Microsoft Graph SDK  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-03, FLOW-18 (Visual Flow Creation)  
**RULE:**
- No direct calendar SDK import in any generated service code
- Calendar operations MUST route through F892 (QUEUE FABRIC) → F893/F894 (connectors)
- Provider resolved from F852 profile config
- "Fabric-first, zero platform-specific values in UI and service code" (basic prompt requirement)
**RESOLUTION:** AF-7 compliance scan for calendar SDK import patterns. F893/F894 are the ONLY allowable calendar integration points.
**TEST:** ST-223

---

### CF-389: Gamification Score Conflict — FLOW-05 vs FLOW-24 Ledger
**TRIGGER:** Two flows writing to gamification ledger for same studentId without scope isolation  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-05 (Lesson Gamification)  
**RULE:**
- If student uses both FLOW-05 (lesson gamification) and FLOW-24 (calendar tutor), ledger events MUST carry source_flow field
- Totals API (F884.GetTotalsAsync) can aggregate across flows OR scope to one — FREEDOM config
- No double-awarding same quiz attempt across flows
**RESOLUTION:** F884 event payload includes source_flow and quizAttemptId for deduplication. GetTotalsAsync accepts optional source_flow filter.
**TEST:** ST-224

---

### CF-390: KnowledgeMap vs FLOW-09 Search Index Conflict
**TRIGGER:** FLOW-24 KnowledgeMap Elasticsearch index collides with FLOW-09 (Search & Discovery) indices  
**SEVERITY:** MEDIUM  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-09  
**RULE:**
- FLOW-24 ES indices MUST use prefix: tutor_knowledge_map, tutor_lesson_catalog, tutor_topic_index
- No collision with search_catalog, content_index used by FLOW-09
**RESOLUTION:** F858, F876, F865 use FLOW-24-namespaced ES indices. AF-7 validates index naming in generated code.

---

### CF-391: Reminder Event Collision — FLOW-04 vs FLOW-24
**TRIGGER:** FLOW-04 (Notification Pipeline) and FLOW-24 both dispatch reminders for same user at same time  
**SEVERITY:** MEDIUM  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-04  
**RULE:**
- FLOW-24 reminder events (F896) MUST carry source: "tutor-reminder" in event metadata
- Quiet hours (F895) checked by FLOW-24 before enqueue — FLOW-04 does not know about tutor quiet hours
- Rate limit: max 1 tutor reminder per quiet-hour window (F896 deduplication)
**RESOLUTION:** F896 checks F895 before enqueue. Event metadata includes source_flow. FLOW-04 notification deduplication extended to handle tutor-reminder source.

---

### CF-392: Developer Pack Web Ingestion — Content Safety
**TRIGGER:** T312 (Weekly Research Digest) ingests content outside approved whitelist  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-13 (AI Content Pipeline)  
**RULE:**
- Research sources must be from configured whitelist (F856 FREEDOM config)
- F872 citation gate MUST validate sourceRef before publish
- No hallucinated citations — F872 checks sourceRef resolves to whitelist domain
**RESOLUTION:** F872 extended with citation_validation mode. T312 iron rule IR-312-2 enforced.

---

### CF-393: Multi-Tenant Quota — Noisy Neighbor on AI Calls
**TRIGGER:** Single tenant's students generate disproportionate AI Engine Fabric load  
**SEVERITY:** HIGH  
**FLOWS AFFECTED:** FLOW-24 ↔ FLOW-20 (Sponsored Content — multi-tenant quota patterns)  
**RULE:**
- F855 (IMultiTenantTutorGate) checks tenant quota before every AI factory call
- Per-tenant AI call budget enforced in ES FREEDOM config
- Exceeding quota → queue lesson generation for off-peak slot (no hard failure for students)
**RESOLUTION:** F855.ValidateQuotaAsync() called before F870, F878, F891, F867 in all task types.

---

### CF-394: Consent Propagation to ASYNC Path
**TRIGGER:** ASYNC path events (T309, T311) processed without original consent context  
**SEVERITY:** CRITICAL  
**FLOWS AFFECTED:** FLOW-24 internal  
**RULE:**
- Queue events in T309 ASYNC path MUST carry { studentId, tenantId, isMinor, consentVersion } in event payload
- ASYNC consumers MUST re-validate scope (not assume SYNC path already checked)
- Consent version mismatch (consent revoked between SYNC and ASYNC) → ASYNC path aborts + emits ConsentRevokedDuringProcessing event
**RESOLUTION:** All FLOW-24 queue event payloads include consent_context. ASYNC consumers check F853 at start.

---

## STRESS TESTS — FLOW-24

### ST-215: Cross-Tenant Student Profile Isolation
**SCENARIO:** Student A (tenant-001) attempts to read KnowledgeMap of Student B (tenant-002)  
**EXPECTED:** F855 scope enforcement → 404/403. Zero cross-tenant data exposure.  
**FAILURE MODE:** Missing tenantId on F858 query  
**BFA RULE:** CF-380  
**VERIFICATION:** AF-8 security scan + integration test with two tenant contexts

---

### ST-216: Concurrent KnowledgeMap Write Race
**SCENARIO:** T307 onboarding completing initial map build while T311 fires immediately after quiz completion for same student  
**EXPECTED:** Optimistic concurrency in F858 resolves conflict. Final state reflects later timestamp. No data corruption.  
**FAILURE MODE:** Last-write-wins without version check → stale score  
**BFA RULE:** CF-381  
**VERIFICATION:** Load test with 100 concurrent students completing onboarding + immediate quiz

---

### ST-217: Calendar Event Namespace Collision
**SCENARIO:** FLOW-03 and FLOW-24 both create calendar events for same user in same hour  
**EXPECTED:** Both events created with separate namespace prefixes ("event:xxx" vs "lesson:yyy"). Neither deletes the other.  
**FAILURE MODE:** FLOW-24 overwrites FLOW-03 event (no namespace check)  
**BFA RULE:** CF-382  
**VERIFICATION:** Create FLOW-03 event; trigger FLOW-24 lesson sync; verify both events exist in calendar

---

### ST-218: Minor Consent Gate Bypass Attempt
**SCENARIO:** Client submits lesson generation request for a minor student without consent token  
**EXPECTED:** F853.RequiresParentalConsentAsync() returns true → flow halts at S02 of Template 64. No AI calls made.  
**FAILURE MODE:** Content generation proceeds despite missing consent  
**BFA RULE:** CF-383  
**SEVERITY:** CRITICAL  
**VERIFICATION:** Unit test with isMinor=true, consentGranted=false → F870 never called

---

### ST-219: Append-Only Ledger — Migration Attack
**SCENARIO:** Developer accidentally writes migration script with UPDATE on GamificationLedgerEvent  
**EXPECTED:** BFA migration scanner detects UPDATE/DELETE on ledger table → BUILD FAILURE before deploy  
**FAILURE MODE:** Migration runs; historical events modified; audit trail corrupted  
**BFA RULE:** CF-384  
**VERIFICATION:** BFA migration scanner unit test with synthetic UPDATE migration file

---

### ST-220: Client-Submitted Points Injection
**SCENARIO:** Malicious client submits quiz completion with { "pointsEarned": 99999 } in request body  
**EXPECTED:** F881/F888 compute points server-side. Request body pointsEarned field ignored (not parsed).  
**FAILURE MODE:** Service reads pointsEarned from request and passes to F884  
**BFA RULE:** CF-385  
**SEVERITY:** CRITICAL  
**VERIFICATION:** Integration test with inflated client points. Assert ledger event matches server-computed value.

---

### ST-221: Timezone Streak Manipulation
**SCENARIO:** Student in Asia/Jerusalem timezone sends X-Timezone: UTC header to trick streak into thinking it's still "today"  
**EXPECTED:** F887 uses F852 profile timezone (Asia/Jerusalem). Client header ignored.  
**FAILURE MODE:** F887 accepts client timezone parameter  
**BFA RULE:** CF-386  
**VERIFICATION:** Test with student profile timezone ≠ request timezone. Assert streak uses profile value.

---

### ST-222: Safety Gate Order Violation
**SCENARIO:** New developer reorders DAG steps in Template 65 — puts F873 (publish) before F872 (safety gate)  
**EXPECTED:** AF-9 judge detects missing SafetyGateToken in F873.PublishAsync() call → BUILD FAILURE  
**FAILURE MODE:** Unsafe content published without moderation  
**BFA RULE:** CF-387  
**SEVERITY:** CRITICAL  
**VERIFICATION:** Template validator unit test with reversed step order

---

### ST-223: Calendar Provider SDK Hardcoding
**SCENARIO:** Generated service imports `from google.oauth2 import credentials` directly  
**EXPECTED:** AF-7 compliance scan flags direct SDK import → BUILD FAILURE  
**FAILURE MODE:** Google-specific code in service layer; not swappable to Outlook  
**BFA RULE:** CF-388  
**VERIFICATION:** AF-7 regex scan for known calendar SDK package names in generated service files

---

### ST-224: Ledger Double-Award on FLOW-05 + FLOW-24 Overlap
**SCENARIO:** Student earns points from both FLOW-05 lesson gamification and FLOW-24 quiz in same session  
**EXPECTED:** Two separate ledger events with distinct source_flow values. F884.GetTotalsAsync with source_flow filter returns correct per-flow totals. No double-counting.  
**FAILURE MODE:** Totals aggregated without source_flow scoping → double points awarded  
**BFA RULE:** CF-389  
**VERIFICATION:** Integration test with both FLOW-05 and FLOW-24 events for same studentId. Assert totals correct per flow.

---

## BACKWARD COMPATIBILITY

All CF-1–CF-379 rules remain UNCHANGED.
All ST-1–ST-214 stress tests remain UNCHANGED.
FLOW-24 adds:
- CF-380–CF-394 (15 new BFA rules)
- ST-215–ST-224 (10 new stress tests)

---

## SAVE POINT: FLOW24:BFA_STRESS_TEST ✅
**Next BFA rule after FLOW-24:** CF-395
**Next stress test after FLOW-24:** ST-225
