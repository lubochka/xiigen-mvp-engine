# UNIFIED SOURCE INDEX — FLOW-24: Learning Calendar Extension (Personal AI Tutor)
## Status: COMPLETE ✅ | Design Decisions DD-180–DD-189 | Design Records DR-134–DR-141

---

## DESIGN DECISIONS — FLOW-24

### DD-180: Domain Pack Architecture — Config-Driven, Not Code Branches
**Decision:** The three domain packs (School, Business Owner, Developer) are curriculum configuration bundles stored in Elasticsearch (F857 ICurriculumPackService), not conditional code branches.  
**Rationale:** Freedom Machine principle — adding a new domain pack (e.g., "medical professional", "language learner") requires no code change. Pack config defines: subjects, topic graph seed, questionnaire templates, badge definitions, atom types.  
**Pattern:** New domain = new ES config document. Zero code changes.  
**Cross-refs:** F857, F856, T307, SK-192  
**Alternatives rejected:** Enum-based branching (breaks Open/Closed principle; requires redeploy for each new pack).

---

### DD-181: Hybrid Sync/Async Quiz Completion Contract
**Decision:** Quiz submission uses the same hybrid contract as FLOW-05 (FLOW-05 gamification precedent). SYNC path ≤1s returns points_preview + badge_preview. All persistence (ledger, attempts, streak, plan adaptation) is ASYNC via Queue Fabric.  
**Rationale:** UX requires instant feedback (student sees points immediately). Data integrity requires durable events (no points lost if downstream fails). Same proven pattern from FLOW-05 reduces risk.  
**Pattern:** SYNC → compute only → return preview. ASYNC → enqueue all state mutations → consumer processes with retry + DLQ.  
**Cross-refs:** T309, Template 66, SK-194, CF-381, DR-135  
**Trade-off:** Eventual consistency — leaderboard may lag by seconds. Acceptable for educational context.

---

### DD-182: Graph-RAG for Curriculum Prerequisites
**Decision:** Curriculum prerequisite navigation uses Graph-RAG — a hybrid of graph DB traversal (F864, F866 → Neo4j via DB Fabric) combined with vector similarity search (F865 → RAG Fabric Hybrid strategy).  
**Rationale:** Pure vector search cannot model prerequisite dependency chains (e.g., "you must understand fractions before algebra"). Graph models the dependency; vector finds semantically similar concepts. Combining both gives correct ordering AND topic discovery.  
**Pattern:** F863 checks readiness via graph traversal. F865 finds semantically related topics via vector. Both contribute to topic selection in T308.  
**Cross-refs:** F863, F864, F865, F866, SK-192, T308  
**Alternatives rejected:** Linear vector search only (misses prerequisite ordering); Graph only (misses semantic similarity for enrichment).

---

### DD-183: Append-Only Ledger + Immutable Attempts
**Decision:** GamificationLedgerEvent (F884) and QuizAttempt (F880) tables are APPEND-ONLY. No UPDATE or DELETE ever. BigInt running totals maintained separately.  
**Rationale:** Anti-cheat (cannot retroactively modify points history), auditability (complete event trail), SOC2/ISO-27001 alignment, same pattern as DD-169 (Spend Ledger) from FLOW-20.  
**Pattern:** Every quiz completion appends a new ledger row. Totals derived from aggregation. Correction = compensating append event (negative points with reason).  
**Cross-refs:** F884, F880, SK-194, CF-384, IR-309-2 through IR-309-4  

---

### DD-184: Timezone Sovereignty for Streaks
**Decision:** Streak boundaries computed using the timezone stored in StudentProfile (F852), never from client request headers or client-supplied parameters.  
**Rationale:** Client timezone is untrusted (trivially spoofed to maintain streaks across midnight boundaries). Profile timezone is server-stored truth. This is "trust-critical" — identified explicitly in the product specification.  
**Pattern:** F887.UpdateStreakAsync(studentId, tenantId, completionTimestampUtc) — timezone resolved internally from F852. No timezone parameter.  
**Cross-refs:** F887, F852, SK-195, CF-386, ST-221  

---

### DD-185: Safety Gate as Non-Bypassable Blocking Step
**Decision:** ILessonSafetyGate (F872) is a blocking step in every content generation pipeline. It issues a SafetyGateToken that F873 (publish) requires. No publish path exists without a valid token.  
**Rationale:** Protects minors (age-appropriate content guarantee). Prevents LLM hallucination or unsafe content reaching students. Brand safety for enterprise tenants.  
**Pattern:** F870 compose → F872 evaluate → token issued → F873 PublishAsync(content, safetyGateToken) — token is required parameter.  
**Cross-refs:** F872, F873, SK-191, CF-387, ST-222, IR-308-1, IR-308-2  
**Minor-specific:** isMinor=true → stricter moderation policy. No admin override for minor policy.

---

### DD-186: Calendar Connectors Behind Fabric Interface
**Decision:** Google Calendar (F893) and Outlook Calendar (F894) are implemented as fabric-backed connectors behind ICalendarConnector interface. Service code never imports calendar provider SDKs. Calendar operations are always queued via F892 (QUEUE FABRIC) for durability.  
**Rationale:** "Fabric-first, zero platform-specific values" (basic prompt requirement). Calendar API failures must not fail the lesson generation flow. Queue provides retry + DLQ.  
**Pattern:** Service → F892.EnqueueSyncAsync() → queue consumer resolves F893 or F894 via factory. No direct HTTP to Google/Outlook in service code.  
**Cross-refs:** F892, F893, F894, F895, SK-196, CF-388, IR-313-1 through IR-313-3  
**Supports:** New calendar providers (CalDAV, Apple Calendar) added via new connector factory without changing service code.

---

### DD-187: Server-Side Grading Only
**Decision:** IQuizGraderService (F881) is the exclusive source of quiz scores and points. Client-submitted scores are rejected (not parsed, not logged as valid input).  
**Rationale:** Gamification integrity (prevents cheating). Consistent with FLOW-05 pattern. Required for educational certification contexts.  
**Pattern:** F881.GradeAsync(sessionId, serverStoredAnswers) — answers retrieved from F879 server-stored session, not from request body.  
**Cross-refs:** F881, F888, SK-194, CF-385, ST-220, IR-309-2  

---

### DD-188: FREEDOM Config for All Lesson + Gamification Parameters
**Decision:** All configurable lesson and gamification parameters are stored in Elasticsearch as FREEDOM config documents, accessible via F856/F857. Zero literal values in generated service code.  
**Rationale:** Freedom Machine principle — business admin or tenant admin changes lesson length, points values, badge thresholds, reminder policy without code changes or redeploys.  
**FREEDOM parameters list:**
- lesson_length_minutes, include_story, include_example_count, composition_model
- base_points_per_correct, streak_multiplier_cap, bonus_thresholds
- badge_thresholds, badge_names, badge_icons
- reminder_escalation_policy, quiet_hours_start, quiet_hours_end
- quiz_frequency, difficulty_ramp_rate
- curriculum_pack, subject_weights, sources_whitelist (developer pack)
- leaderboard_scope, refresh_interval  
**Cross-refs:** F856, F857, F885, F887, F888, F895, F896, SK-193, SK-197, DD-180  

---

### DD-189: Consent Propagation in Async Event Chain
**Decision:** All FLOW-24 queue events include a consent_context envelope: { studentId, tenantId, isMinor, consentVersion }. ASYNC consumers re-validate consent at start. If consent was revoked between SYNC and ASYNC processing, the ASYNC consumer aborts and emits ConsentRevokedDuringProcessing event.  
**Rationale:** ASYNC consumers run independently; they cannot assume the SYNC path's consent check is still valid (user may revoke consent between milliseconds). GDPR/COPPA compliance requires consent to be valid at time of processing.  
**Pattern:** All T309 ASYNC path events carry consent_context. F853 called again at start of each async consumer.  
**Cross-refs:** F853, CF-394, T309, T311, SK-190  

---

## DESIGN RECORDS — FLOW-24

### DR-134: Calendar Connector Abstraction
**Context:** Students may use Google Calendar, Outlook, or CalDAV. Service code must not contain provider-specific logic.  
**Record:** All calendar operations route through: service code → F892 queue → async consumer → ICalendarConnector factory resolution → F893 or F894 connector.  
**Effect:** Adding CalDAV or Apple Calendar support = new connector factory. Zero changes to lesson generation service.  
**Status:** DECIDED — implemented in T308, T313 templates.

---

### DR-135: Hybrid Sync/Async Boundary Definition
**Context:** Student UX requires instant quiz result feedback. Data integrity requires durable persistence.  
**Record:** SYNC path ends at: grade (F881) + calculate preview (F888) → return {points_preview, badge_preview}. ASYNC path begins after sync returns: all persistence steps via queue.  
**Effect:** Points preview shown immediately. Confirmed ledger event follows async. Eventual consistency gap is ≤2 seconds in normal operation.  
**Status:** DECIDED — implemented in Template 66, T309.

---

### DR-136: Append-Only Tables — DDL Constraints
**Context:** Append-only guarantee must be enforced at database level, not just application level.  
**Record:** PostgreSQL tables GamificationLedgerEvent and QuizAttempt have DDL-level triggers that RAISE EXCEPTION on UPDATE/DELETE operations. Migration CI gate checks for prohibited operations.  
**Effect:** Even if service code contains a bug or malicious migration is deployed, DB rejects modification attempts.  
**Status:** DECIDED — BFA migration scanner validates this.

---

### DR-137: Timezone Storage in StudentProfile
**Context:** Streak computation requires reliable timezone. Client headers are untrusted.  
**Record:** StudentProfile (F852) stores timezone as IANA timezone string (e.g., "Asia/Jerusalem"). Set during onboarding (T307). Updated only via authenticated profile update flow, not via any runtime request header.  
**Effect:** F887 resolves timezone via F852 lookup. No parameter passing for timezone.  
**Status:** DECIDED — implemented in SK-195, CF-386.

---

### DR-138: SafetyGateToken Protocol
**Context:** To enforce that safety gate cannot be bypassed, publish must require proof of gate evaluation.  
**Record:** F872.EvaluateAsync() returns a SafetyGateToken (signed string) on pass. F873.PublishAsync(content, safetyGateToken) has token as required non-nullable parameter. Token validation includes: timestamp (expires in 60s), contentHash, isMinorPolicy flag.  
**Effect:** Reordering DAG steps so F873 runs before F872 fails at runtime (expired or missing token). AF-9 validates this at code-generation time.  
**Status:** DECIDED — implemented in Template 65, SK-191, CF-387.

---

### DR-139: Domain Pack Versioning
**Context:** Curriculum packs evolve (new topics added, removed, reweighted). Students mid-plan must not be disrupted.  
**Record:** ICurriculumPackService (F857) stores pack documents with version field. StudentProfile references pack_id + pack_version. Plan adaptation (F891) reads from pinned pack_version unless student opts into latest version. Pack upgrades are non-breaking (additive only in same major version).  
**Effect:** Pack v2 can be deployed without affecting students on v1. Tenant admins can migrate cohorts on schedule.  
**Status:** DECIDED — implemented in F857, F891.

---

### DR-140: Research Atom Citation Policy
**Context:** Developer pack (T312) ingests external content. Citations are required to prevent hallucinated facts.  
**Record:** F872 extended with citation_validation_mode for T312. Every claim in a research digest must have sourceRef pointing to a URL in the whitelist. F872 validates sourceRef resolves (HTTP HEAD check) and matches whitelist pattern. Uncertain claims must be tagged with { "certainty": "speculative" }.  
**Effect:** Research digests cannot be published with uncited claims. Students get reliable content with sources.  
**Status:** DECIDED — implemented in SK-191, T312, CF-392.

---

### DR-141: Multi-Tenant Soft Throttle for Education Flows
**Context:** AI quota management for education SaaS. Hard failures (quota exceeded → error) are unacceptable for students mid-lesson.  
**Record:** F855 ValidateAndConsumeQuotaAsync returns Success(false) on soft limit — this means "deferred to off-peak" not "failed". Lesson generation is enqueued for next off-peak window. Student sees "Your lesson is being prepared — check back in a few minutes." No error state.  
**Effect:** Students never see quota errors. Tenant admins see deferred count in analytics. Revenue signal for quota tier upgrade.  
**Status:** DECIDED — implemented in SK-198, CF-393.

---

## CROSS-REFERENCE INDEX — FLOW-24

| Artifact | Referenced By |
|----------|--------------|
| DD-180 (Domain Pack Config) | F857, T307, SK-192 |
| DD-181 (Hybrid Contract) | T309, Template 66, SK-194 |
| DD-182 (Graph-RAG) | F863, F864, F865, T308, SK-192 |
| DD-183 (Append-Only Ledger) | F884, F880, CF-384, SK-194 |
| DD-184 (Timezone Sovereignty) | F887, F852, CF-386, SK-195 |
| DD-185 (Safety Gate Blocking) | F872, F873, CF-387, SK-191 |
| DD-186 (Calendar Fabric-First) | F892, F893, F894, CF-388, SK-196 |
| DD-187 (Server-Side Grading) | F881, CF-385, SK-194 |
| DD-188 (FREEDOM Config) | F856, F857, F885–F888, F895–F896 |
| DD-189 (Consent Propagation) | F853, CF-394, T309, SK-190 |
| DR-134 (Calendar Connector) | T308, T313, F892–F894 |
| DR-135 (Hybrid Boundary) | T309, Template 66 |
| DR-136 (DDL Constraints) | F880, F884, CF-384 |
| DR-137 (Timezone Storage) | F852, F887, CF-386 |
| DR-138 (SafetyGateToken) | F872, F873, CF-387 |
| DR-139 (Pack Versioning) | F857, F891 |
| DR-140 (Citation Policy) | T312, F872, CF-392 |
| DR-141 (Soft Throttle) | F855, CF-393, SK-198 |

---

## BACKWARD COMPATIBILITY

All DD-1–DD-179 remain UNCHANGED.
All DR-1–DR-133 remain UNCHANGED.
FLOW-24 adds DD-180–DD-189 (10 new design decisions) and DR-134–DR-141 (8 new design records).

---

## SAVE POINT: FLOW24:UNIFIED_SOURCE_INDEX ✅
**Next design decision after FLOW-24:** DD-190
**Next design record after FLOW-24:** DR-142
