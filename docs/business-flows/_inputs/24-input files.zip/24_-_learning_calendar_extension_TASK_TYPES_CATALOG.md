# TASK TYPES CATALOG — FLOW-24: Learning Calendar Extension (Personal AI Tutor)
## Status: COMPLETE ✅ | Task Types T307–T314 | Templates 64–67

---

## ENGINE CONTRACT FORMAT REFERENCE
Every task type MUST contain: ARCHETYPE, ENTRY, PURPOSE, DISTINCT FROM, FACTORY DEPENDENCIES, FABRIC RESOLUTION, AF CONFIGURATION, BFA VALIDATION, MACHINE/FREEDOM, IRON RULES, QUALITY GATES.

---

## TASK TYPE: T307 — Student Onboarding & Knowledge Diagnosis
**ARCHETYPE:** ORCHESTRATION  
**ENTRY:** Fires on CalendarExtensionInstalled event OR ManualOnboardingTriggered event  
**PURPOSE:** Collect student profile + consent → run baseline questionnaire + per-subject quizzes → build initial Knowledge Map → generate 30-day lesson plan → create recurring calendar task  
**DISTINCT FROM:** T47 (User Registration — identity only, no knowledge map) | T289 (Webhook delivery — event routing, no diagnosis)  

**FACTORY DEPENDENCIES:** F852, F853, F854, F855, F856, F857, F858, F859, F860, F861, F862, F863, F864, F890, F891, F893, F894 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F852 → DATABASE FABRIC (PostgreSQL) — student profile store
F853 → DATABASE FABRIC (PostgreSQL) — consent profile, minor gate
F854 → CORE FABRIC (MicroserviceBase) — auth context
F855 → CORE FABRIC (MicroserviceBase) — multi-tenant scope enforcement
F856 → DATABASE FABRIC (Elasticsearch) — locale/curriculum config
F857 → DATABASE FABRIC (Elasticsearch) — curriculum pack (school/biz/dev)
F858 → DATABASE FABRIC (Elasticsearch) — knowledge map store
F859 → DATABASE FABRIC (PostgreSQL) — questionnaire definitions
F860 → DATABASE FABRIC (PostgreSQL) — baseline quiz store + attempt append
F861 → AI ENGINE FABRIC (AiDispatcher) — diagnostic scoring (multi-model)
F862 → RAG FABRIC (Vector strategy) — gap pattern matching
F863 → DATABASE FABRIC (Neo4j) — prerequisite validation
F864 → DATABASE FABRIC (Neo4j) — curriculum graph traversal
F890 → DATABASE FABRIC (PostgreSQL) — lesson plan storage
F891 → AI ENGINE FABRIC (AiDispatcher) — 30-day plan generation
F893 → CORE FABRIC (external connector) — Google Calendar event creation
F894 → CORE FABRIC (external connector) — Outlook Calendar event creation
```

**AF CONFIGURATION:**
```
AF-1 (Genesis): Generates onboarding orchestration service extending MicroserviceBase
AF-2 (Planning): Decomposes into: [collect-profile → validate-consent → run-questionnaire → 
                   score-diagnosis → build-knowledge-map → generate-plan → create-calendar-task]
AF-3 (Prompt Library): Retrieves: onboarding-flow, knowledge-diagnosis, consent-gate prompts
AF-4 (RAG): Searches SK-189 (knowledge-map-builder), SK-190 (consent-gate), SK-192 (curriculum-graph)
AF-5 (Multi-model): Parallel scoring of questionnaire responses via F861
AF-6 (Code Review): Reviews: consent gate enforcement, minor flag handling, factory resolution
AF-7 (Compliance): Enforces DNA-1 (no typed models), DNA-5 (tenantId on all queries)
AF-8 (Security): Validates: consent gate cannot be bypassed, minor data isolation
AF-9 (Judge): Validates iron rules — see below
AF-10 (Merge): Combines multi-model diagnostic scores (conservative consensus)
AF-11 (Feedback): Stores onboarding completion rate, diagnosis accuracy metrics
```

**BFA VALIDATION:**
```
CF-380: StudentProfile entity overlaps with FLOW-01 (User Registration) — tenantId scope enforced
CF-381: KnowledgeMap entity NEW — register in BFA index
CF-382: CalendarTask creation conflicts with FLOW-03 (Event Creation) — calendar slot coordination
CF-383: ConsentProfile blocking gate — minor flag must propagate to all downstream tasks
```

**MACHINE / FREEDOM:**
```
MACHINE (fixed, non-negotiable):
  - Minor status = READ-ONLY server-side (F853). No client override.
  - Consent gate MUST fire before any questionnaire starts (F853.RequiresParentalConsentAsync)
  - Diagnostic scoring is server-side only (F861). No client-submitted scores.
  - tenantId present on every DB query (F855 enforces)
  - Graph traversal for prerequisites (F863) runs before plan generation (F891)

FREEDOM (ES config, admin-configurable, no literals in code):
  - questionnaire_length (5/10/15 questions)
  - baseline_quiz_questions_per_subject
  - initial_plan_horizon_days (default 30)
  - calendar_provider (google|outlook|caldav) — per tenant config
  - curriculum_pack (school_grade_X|business_owner|developer)
```

**IRON RULES:**
```
IR-307-1: ConsentProfile MUST be checked before any data collection. BUILD FAILURE if bypassed.
IR-307-2: Minor = true triggers parental consent gate. No data collection before consent confirmed.
IR-307-3: KnowledgeMap score MUST be computed by F861 (server-side). Never accept client-supplied scores.
IR-307-4: CalendarTask creation uses calendar provider from tenant config (F856), not hardcoded Google/Outlook.
IR-307-5: All DB queries include tenantId. Zero-tenantId query = BUILD FAILURE.
IR-307-6: Attempt records (F860) are append-only. No UPDATE/DELETE. BUILD FAILURE if violated.
```

**QUALITY GATES (AF-9 Judge):**
```
QG-307-1: Knowledge Map produced with score for every configured subject (non-null)
QG-307-2: 30-day plan generated with at least 1 topic per active day
QG-307-3: Calendar task created and confirmed (or error logged to DLQ — not silent failure)
QG-307-4: Consent status stored in F853 before any questionnaire data persisted
QG-307-5: All factory calls use CreateAsync() — no direct class instantiation
```

---

## TASK TYPE: T308 — Daily Lesson Generation Pipeline
**ARCHETYPE:** ORCHESTRATION + AI_GENERATION  
**ENTRY:** Fires on DailyLessonScheduleTrigger (cron or CalendarFreeSlotFound event)  
**PURPOSE:** Select next topic from KnowledgeMap + prerequisite graph → fetch RAG atoms → compose micro-lesson via LLM → pass safety gate → publish lesson → upsert calendar event → notify student  
**DISTINCT FROM:** T307 (onboarding diagnosis — runs once) | T50 (Content Management — generic content, no curriculum graph) | T178 (AI Content Pipeline — no curriculum-aware difficulty adaptation)  

**FACTORY DEPENDENCIES:** F856, F858, F862, F863, F864, F865, F867, F868, F869, F870, F871, F872, F873, F874, F875, F876, F877, F890, F892, F895, F896 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F856 → DATABASE FABRIC (ES) — locale + difficulty config
F858 → DATABASE FABRIC (ES) — read knowledge map (topic scores)
F862 → RAG FABRIC (Vector) — similar gap patterns
F863 → DATABASE FABRIC (Neo4j) — prerequisite readiness check
F864 → DATABASE FABRIC (Neo4j) — curriculum graph traversal
F865 → RAG FABRIC (Hybrid) — topic ontology search
F867 → AI ENGINE FABRIC (AiDispatcher) — mastery path planning
F868 → RAG FABRIC (Vector) — learning atom retrieval (definitions/examples/stories)
F869 → DATABASE FABRIC (PG) — topic progress read
F870 → AI ENGINE FABRIC (AiDispatcher) — lesson composition (multi-model)
F871 → RAG FABRIC (Vector) — RAG atom fetcher
F872 → AI ENGINE FABRIC (AiDispatcher) — safety gate (BLOCKING)
F873 → DATABASE FABRIC (MongoDB) — publish lesson
F874 → AI ENGINE FABRIC (AiDispatcher) — localization
F875 → AI ENGINE FABRIC (AiDispatcher) — difficulty adaptation
F876 → DATABASE FABRIC (ES) — lesson catalog index
F877 → DATABASE FABRIC (MongoDB) — lesson content variant store
F890 → DATABASE FABRIC (PG) — lesson plan read
F892 → QUEUE FABRIC (Redis Streams) — calendar sync queue (durable)
F895 → DATABASE FABRIC (PG) — quiet hours check
F896 → QUEUE FABRIC (Redis Streams) — reminder queue
```

**AF CONFIGURATION:**
```
AF-1 (Genesis): Generates DailyLessonGeneratorService extending MicroserviceBase
AF-2 (Planning): Decomposes into: [check-quiet-hours → select-topic → validate-prerequisites → 
                   fetch-atoms → compose-lesson → safety-gate → adapt-difficulty → 
                   publish → sync-calendar → enqueue-reminder]
AF-3 (Prompt Library): Retrieves: lesson-composer, safety-gate, difficulty-adapter prompts
AF-4 (RAG): SK-191 (lesson-composer), SK-192 (curriculum-graph-rag), SK-193 (difficulty-adapter)
AF-5 (Multi-model): Parallel lesson composition via F870 (AiDispatcher)
AF-6 (Code Review): Reviews: safety gate placement (must be after compose, before publish)
AF-7 (Compliance): DNA-1 (no typed models), DNA-2 (empty field skip in lesson search)
AF-8 (Security): Minor flag check before composition; no LLM call before consent verified
AF-9 (Judge): Validates lesson published only after safety gate pass
AF-10 (Merge): Conservative lesson merge — judge selects highest quality + safety score
AF-11 (Feedback): Stores composition quality, safety gate pass rate, model performance
```

**BFA VALIDATION:**
```
CF-382: Calendar event upsert overlaps with FLOW-03 calendar slots — coordinate via F892 queue
CF-384: LessonPublished event NEW — register in BFA index for FLOW-24 downstream
CF-385: Topic selection uses KnowledgeMap — must not conflict with F858 concurrent writes from T309
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - Safety gate (F872) MUST run before publish. No bypass.
  - Minor flag from F853 passed to F872. Stricter policy applied. Non-negotiable.
  - Calendar sync goes through queue (F892) — never direct API call in service code
  - RAG atoms fetched before LLM call (no hallucinated facts without retrieval)

FREEDOM:
  - lesson_length_minutes (5|7|10)
  - include_story (true|false), include_example_count (1|2|3)
  - composition_model (claude|openai|gemini — per tenant config)
  - rag_atom_count (3|5|7)
  - calendar_sync_provider (google|outlook|caldav)
  - reminder_policy (soft|hard|none)
```

**IRON RULES:**
```
IR-308-1: Safety gate (F872) MUST precede publish (F873). Reversed order = BUILD FAILURE.
IR-308-2: Minor=true → F872 uses strict_minor policy. No configurable override.
IR-308-3: Lesson composition (F870) calls AiDispatcher only — no direct openai/anthropic SDK.
IR-308-4: Calendar sync enqueued to QUEUE FABRIC (F892) — never direct HTTP to Google/Outlook.
IR-308-5: RAG atoms (F871) fetched before compose (F870) — no compose without retrieval context.
IR-308-6: Lesson published with citation references for research-mode atoms (DD-179 pattern).
```

**QUALITY GATES (AF-9):**
```
QG-308-1: Safety gate score ≥ threshold (FREEDOM config) before publish
QG-308-2: Lesson contains ≥ 1 example and ≥ 1 quiz question
QG-308-3: Difficulty matches student's current topic score from F858
QG-308-4: Calendar event created or DLQ entry written (no silent calendar failure)
QG-308-5: Lesson indexed in F876 catalog (searchable)
```

---

## TASK TYPE: T309 — Quiz Submission → Hybrid Gamification Gate
**ARCHETYPE:** HYBRID_SYNC_ASYNC  
**ENTRY:** Fires on StudentSubmitsQuiz event  
**PURPOSE:** SYNC path: grade answers server-side → return points preview + badge preview ≤1s. ASYNC path: append ledger event → update streak → evaluate badges → update knowledge map → adapt tomorrow's plan → reschedule calendar if needed.  
**DISTINCT FROM:** T44 (basic gamification in FLOW-05) | T46 (spaced repetition scheduler — planning only, no grading)  

**FACTORY DEPENDENCIES:** F853, F858, F869, F878, F879, F880, F881, F882, F883, F884, F885, F886, F887, F888, F889, F890, F891, F897 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F853 → DATABASE FABRIC (PG) — consent + minor status for point display rules
F858 → DATABASE FABRIC (ES) — knowledge map update (ASYNC)
F869 → DATABASE FABRIC (PG) — topic progress update (ASYNC)
F878 → AI ENGINE FABRIC (AiDispatcher) — N/A (quiz already generated; grader uses rubric)
F879 → DATABASE FABRIC (PG) — quiz session state
F880 → DATABASE FABRIC (PG) — attempt store (append-only, ASYNC)
F881 → AI ENGINE FABRIC (AiDispatcher) — server-side grader (SYNC step)
F882 → AI ENGINE FABRIC (AiDispatcher) — adaptation analysis (ASYNC)
F883 → RAG FABRIC (FanOut) — quiz template lookup (pre-session)
F884 → DATABASE FABRIC (PG) — ledger append event (ASYNC)
F885 → DATABASE FABRIC (ES) — badge definition lookup
F886 → QUEUE FABRIC (Redis Streams) — badge unlock check queue (ASYNC)
F887 → DATABASE FABRIC (Redis + PG) — streak update (ASYNC)
F888 → CORE FABRIC (MicroserviceBase) — points calculation (SYNC step)
F889 → DATABASE FABRIC (Redis) — leaderboard update (ASYNC)
F890 → DATABASE FABRIC (PG) — plan read for adaptation
F891 → AI ENGINE FABRIC (AiDispatcher) — tomorrow's plan adaptation (ASYNC)
F897 → DATABASE FABRIC (PG) — streak protection check (ASYNC)
```

**AF CONFIGURATION:**
```
AF-1 (Genesis): Generates QuizCompletionService (hybrid sync/async) extending MicroserviceBase
AF-2 (Planning): Decomposes into SYNC path (F881+F888 → return preview) and ASYNC path (queue all state updates)
AF-4 (RAG): SK-194 (gamification-ledger), SK-195 (streak-manager), SK-190 (hybrid-sync-async)
AF-7 (Compliance): Validates hybrid contract — sync returns in ≤1s, async via queue
AF-8 (Security): Server-side grading gate — no client score accepted
AF-9 (Judge): Validates atomic ledger append, no UPDATE on attempts
```

**BFA VALIDATION:**
```
CF-386: KnowledgeMap write (F858) conflicts with T308 concurrent read — serialized via event order
CF-387: Ledger append (F884) is append-only — BFA validates no UPDATE/DELETE on ledger table
CF-388: Streak update (F887) uses timezone from F852 — CF ensures no clock manipulation
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - F881 grades server-side. Zero client score input accepted.
  - F884 appends only. No UPDATE/DELETE on ledger.
  - F880 attempts are immutable.
  - F887 streak uses profile timezone (F852), not request header.
  - Hybrid sync/async boundary: SYNC returns in ≤1s. All state mutation = ASYNC.

FREEDOM:
  - base_points_per_correct, streak_multiplier_cap, bonus_thresholds (ES config via F888)
  - badge_thresholds (ES config via F885)
  - streak_protection_enabled, grace_period_hours (F897 / F887 config)
  - adaptation_trigger_threshold (% score at which plan adapts)
  - leaderboard_scope (class|school|tenant|global)
```

**IRON RULES:**
```
IR-309-1: SYNC path MUST NOT write to database (no ledger, no attempt store in sync path). Returns preview only.
IR-309-2: Points calculated by F888 (MACHINE formula). Client-submitted pointsEarned = BUILD FAILURE.
IR-309-3: F880 attempts: append-only. Any UPDATE/DELETE = BUILD FAILURE.
IR-309-4: F884 ledger: append-only. Any UPDATE/DELETE = BUILD FAILURE.
IR-309-5: F887 streak timezone = F852 profile timezone. Request-header timezone = BUILD FAILURE.
IR-309-6: ASYNC path uses QUEUE FABRIC (Redis Streams) — all events durable, DLQ on failure.
```

**QUALITY GATES (AF-9):**
```
QG-309-1: SYNC response contains points_preview and badge_preview within ≤1s
QG-309-2: ASYNC path events confirmed enqueued before SYNC returns
QG-309-3: Knowledge map updated with new topic score (ASYNC completion)
QG-309-4: Tomorrow's plan adapted if score < adaptation_trigger_threshold
QG-309-5: Ledger event includes quizAttemptId for audit trail
```

---

## TASK TYPE: T310 — Missed Lesson Recovery Flow
**ARCHETYPE:** EVENT_PROCESSING  
**ENTRY:** Fires on CalendarEventExpired event where lesson was not completed  
**PURPOSE:** Check quiet hours → offer 2-minute recap micro-lesson → reschedule next available slot → apply streak protection policy if configured  
**DISTINCT FROM:** T308 (lesson generation — creates new lesson) | T309 (quiz completion — gamification)  

**FACTORY DEPENDENCIES:** F852, F853, F873, F876, F887, F890, F891, F892, F895, F896, F897 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F852 → DATABASE FABRIC (PG) — student profile + timezone
F853 → DATABASE FABRIC (PG) — minor status for reminder policy
F873 → DATABASE FABRIC (MongoDB) — retrieve existing published lesson
F876 → DATABASE FABRIC (ES) — catalog search for recap variant
F887 → DATABASE FABRIC (Redis+PG) — streak state read
F890 → DATABASE FABRIC (PG) — lesson plan read
F891 → AI ENGINE FABRIC (AiDispatcher) — reschedule plan recompute
F892 → QUEUE FABRIC (Redis Streams) — calendar sync queue
F895 → DATABASE FABRIC (PG) — quiet hours check
F896 → QUEUE FABRIC (Redis Streams) — reminder escalation queue
F897 → DATABASE FABRIC (PG) — streak protection application
```

**AF CONFIGURATION:**
```
AF-1 (Genesis): Generates MissedLessonRecoveryService extending MicroserviceBase
AF-2 (Planning): [check-quiet-hours → check-streak-protection → offer-recap → reschedule → enqueue-calendar-sync]
AF-4 (RAG): SK-195 (streak-manager), SK-196 (calendar-sync), SK-197 (reminder-orchestrator)
AF-7 (Compliance): DNA-5 scope isolation on all queries
AF-9 (Judge): Validates streak not broken if protection applies; no lesson re-created (reuses F873)
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - Streak protection applied by server (F897), not client request
  - Quiet hours enforced before any reminder sent (F895)
  - Recap uses existing published lesson (F873) — no new AI generation for missed lesson

FREEDOM:
  - streak_protection_enabled (bool), protection_uses_per_month (int)
  - reminder_escalation_policy (soft|hard)
  - recap_duration_minutes
  - reschedule_lookahead_hours
```

**IRON RULES:**
```
IR-310-1: No new lesson composition for missed lesson. Recap reuses F873 published content.
IR-310-2: F895 quiet hours check BEFORE any reminder dispatch.
IR-310-3: F897 streak protection consumes one use token — server tracks count. No client manipulation.
IR-310-4: Calendar reschedule via F892 queue (durable) — no direct calendar API call.
```

**QUALITY GATES (AF-9):**
```
QG-310-1: Quiet hours respected (no reminder during quiet period)
QG-310-2: Streak protection applied if eligible (uses_remaining > 0)
QG-310-3: Next lesson slot rescheduled in calendar (or DLQ if calendar unavailable)
```

---

## TASK TYPE: T311 — Knowledge Map Adaptive Update
**ARCHETYPE:** EVENT_PROCESSING  
**ENTRY:** Fires on QuizCompleted event (ASYNC path from T309) OR WeeklyProgressReview event  
**PURPOSE:** Recompute topic scores, update KnowledgeMap in F858, identify new gaps, trigger prerequisite revalidation, fire plan adaptation if threshold crossed  
**DISTINCT FROM:** T309 (includes grading + gamification — this is the pure map-update step)  

**FACTORY DEPENDENCIES:** F858, F861, F862, F863, F864, F869, F882, F890, F891 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F858 → DATABASE FABRIC (ES) — knowledge map read/write
F861 → AI ENGINE FABRIC (AiDispatcher) — updated score computation
F862 → RAG FABRIC (Vector) — gap similarity analysis
F863 → DATABASE FABRIC (Neo4j) — prerequisite re-check
F864 → DATABASE FABRIC (Neo4j) — graph topology for new unlocks
F869 → DATABASE FABRIC (PG) — topic progress history
F882 → AI ENGINE FABRIC (AiDispatcher) — adaptation recommendation
F890 → DATABASE FABRIC (PG) — current plan read
F891 → AI ENGINE FABRIC (AiDispatcher) — plan adaptation write
```

**AF CONFIGURATION:**
```
AF-1 (Genesis): Generates KnowledgeMapUpdaterService extending MicroserviceBase
AF-7 (Compliance): DNA-2 (empty filter skip in ES queries), DNA-5 (tenantId isolation)
AF-9 (Judge): Validates map update doesn't regress topics incorrectly; prerequisite chain intact
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - Score recomputation is server-side (F861). No client score injection.
  - Prerequisite graph (F863) determines unlock order — not client request.

FREEDOM:
  - score_decay_enabled, decay_half_life_days
  - adaptation_sensitivity_threshold
  - max_topics_per_day (plan constraint)
```

**IRON RULES:**
```
IR-311-1: KnowledgeMap scores computed by F861. No client-supplied overrides accepted.
IR-311-2: Prerequisite validation (F863) runs before any new topic is unlocked in plan.
```

**QUALITY GATES (AF-9):**
```
QG-311-1: Map updated with scores for all attempted topics
QG-311-2: New prerequisite-unlocked topics added to plan if student ready
QG-311-3: Plan adaptation logged to F891 with reason
```

---

## TASK TYPE: T312 — Developer Pack: Weekly Research Digest Builder
**ARCHETYPE:** ORCHESTRATION + AI_GENERATION  
**ENTRY:** Fires on WeeklyResearchScheduleTrigger (cron, e.g. Sunday 10:00 per config)  
**PURPOSE:** Pick research themes from developer knowledge map → ingest trusted sources whitelist → summarize + extract claims with citations → store as RAG atoms → publish weekly digest → schedule calendar block  
**DISTINCT FROM:** T308 (daily lesson — curriculum-driven) | T178 (AI content pipeline — no curriculum graph or citation requirement)  
**NOTE:** Developer domain pack only. Skipped for school/business packs unless enabled via FREEDOM config.  

**FACTORY DEPENDENCIES:** F856, F857, F858, F864, F867, F868, F870, F872, F873, F876, F890, F892, F896 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F856 → DATABASE FABRIC (ES) — locale/pack config
F857 → DATABASE FABRIC (ES) — developer curriculum pack
F858 → DATABASE FABRIC (ES) — developer knowledge map
F864 → DATABASE FABRIC (Neo4j) — skill tree traversal
F867 → AI ENGINE FABRIC (AiDispatcher) — research theme selection
F868 → RAG FABRIC (Vector) — existing atom search (avoid duplication)
F870 → AI ENGINE FABRIC (AiDispatcher) — summarize + extract claims
F872 → AI ENGINE FABRIC (AiDispatcher) — quality/citation gate (BLOCKING)
F873 → DATABASE FABRIC (MongoDB) — publish digest
F876 → DATABASE FABRIC (ES) — index digest in lesson catalog
F890 → DATABASE FABRIC (PG) — plan read
F892 → QUEUE FABRIC (Redis Streams) — calendar sync
F896 → QUEUE FABRIC (Redis Streams) — weekly block reminder
```

**AF CONFIGURATION:**
```
AF-1 (Genesis): Generates WeeklyResearchDigestService extending MicroserviceBase
AF-3 (Prompt Library): Retrieves: research-summarizer, citation-extractor prompts
AF-4 (RAG): SK-192 (curriculum-graph-rag), SK-191 (lesson-composer) — reused
AF-7 (Compliance): DNA-1, DNA-5; citation gate enforced before publish
AF-9 (Judge): Validates citations present, no hallucinated facts, quality score ≥ threshold
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - F872 citation gate MUST pass — digest without citations = BUILD FAILURE
  - Research ingestion from whitelist sources only (no open web scraping without approval)
  - "Unknown if unsure" policy — AI must not present uncertain claims as facts

FREEDOM:
  - sources_whitelist (per tenant/org in ES config)
  - research_cadence (weekly|biweekly), trigger_time
  - themes_per_digest (3|5|7)
  - digest_length_minutes
```

**IRON RULES:**
```
IR-312-1: Every claim in digest MUST include sourceRef citation. No citation = safety gate fail = BUILD FAILURE.
IR-312-2: Sources must be in whitelist (F856 config). No hardcoded source URLs in service code.
IR-312-3: F872 safety gate + citation gate both MUST pass before F873 publish.
```

**QUALITY GATES (AF-9):**
```
QG-312-1: All claims have sourceRef
QG-312-2: Digest summarizes ≥ 3 research themes
QG-312-3: New atoms stored in F868 (RAG store updated for future lessons)
QG-312-4: Calendar block created for weekly review
```

---

## TASK TYPE: T313 — Calendar Conflict Resolution & Rescheduler
**ARCHETYPE:** ORCHESTRATION  
**ENTRY:** Fires on CalendarConflictDetected event OR LessonSlotRequested event  
**PURPOSE:** Find next free time slot in student calendar, respecting quiet hours, school/work hours blackouts, and existing calendar events → upsert or reschedule calendar event  
**DISTINCT FROM:** T308 (lesson generation — this is the scheduling sub-task) | T310 (missed lesson — reactive; this is proactive)  

**FACTORY DEPENDENCIES:** F852, F856, F890, F892, F893, F894, F895 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F852 → DATABASE FABRIC (PG) — student profile, timezone, calendar provider preference
F856 → DATABASE FABRIC (ES) — scheduling config (lesson_duration, blackout_windows)
F890 → DATABASE FABRIC (PG) — current lesson plan
F892 → QUEUE FABRIC (Redis Streams) — calendar sync (durable, retry)
F893 → CORE FABRIC (external connector) — Google Calendar free/busy query
F894 → CORE FABRIC (external connector) — Outlook Calendar free/busy query
F895 → DATABASE FABRIC (PG) — quiet hours
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - Calendar provider resolved from F852 profile (server config), not client header
  - Quiet hours (F895) enforced unconditionally
  - All calendar API calls go through F892 queue — never direct in service code

FREEDOM:
  - preferred_lesson_window (morning|afternoon|evening)
  - reschedule_lookahead_days
  - conflict_avoidance_buffers (before_exam_days, etc.)
  - lesson_duration_minutes
```

**IRON RULES:**
```
IR-313-1: Calendar provider (Google/Outlook) resolved via config (F852), not hardcoded.
IR-313-2: Calendar API calls enqueued via F892 (Queue Fabric). No direct HTTP to calendar APIs.
IR-313-3: Quiet hours (F895) always checked. No scheduling during quiet period.
```

**QUALITY GATES (AF-9):**
```
QG-313-1: New slot found within reschedule_lookahead_days
QG-313-2: No overlap with existing calendar events (free/busy check confirmed)
QG-313-3: No scheduling during quiet hours
QG-313-4: Calendar event upserted or DLQ entry written (never silent failure)
```

---

## TASK TYPE: T314 — Monthly Capstone Generator (Developer + Business Packs)
**ARCHETYPE:** ORCHESTRATION + AI_GENERATION  
**ENTRY:** Fires on MonthlyCapstoneScheduleTrigger  
**PURPOSE:** Identify highest ROI skill gap → generate a small project task with rubric → schedule a calendar focus block → optionally evaluate submitted artifact → update knowledge map  
**DISTINCT FROM:** T308 (daily micro-lesson — this is a larger monthly project)  
**NOTE:** Developer and Business Owner packs only.  

**FACTORY DEPENDENCIES:** F856, F857, F858, F867, F870, F872, F873, F876, F881, F884, F890, F891, F892 — resolved via CreateAsync()  

**FABRIC RESOLUTION:**
```
F856 → DATABASE FABRIC (ES) — pack + locale config
F857 → DATABASE FABRIC (ES) — capstone templates per domain pack
F858 → DATABASE FABRIC (ES) — knowledge map (highest gap identification)
F867 → AI ENGINE FABRIC (AiDispatcher) — capstone theme selection
F870 → AI ENGINE FABRIC (AiDispatcher) — project task + rubric generation
F872 → AI ENGINE FABRIC (AiDispatcher) — quality/safety gate
F873 → DATABASE FABRIC (MongoDB) — capstone publish
F876 → DATABASE FABRIC (ES) — catalog index
F881 → AI ENGINE FABRIC (AiDispatcher) — optional rubric evaluation
F884 → DATABASE FABRIC (PG) — ledger append (capstone completion bonus)
F890 → DATABASE FABRIC (PG) — plan update
F891 → AI ENGINE FABRIC (AiDispatcher) — next month plan regeneration
F892 → QUEUE FABRIC (Redis Streams) — calendar focus block
```

**MACHINE / FREEDOM:**
```
MACHINE:
  - Rubric evaluation (F881) is server-side. No self-reported completion.
  - Safety gate (F872) required before capstone publish.
  - Ledger append (F884) is append-only.

FREEDOM:
  - capstone_frequency (monthly|quarterly)
  - focus_block_hours (1|2|4)
  - capstone_difficulty_level
  - evaluation_mode (ai_rubric|peer_review|self_report_allowed)
```

**IRON RULES:**
```
IR-314-1: Safety gate (F872) required before capstone publish.
IR-314-2: Completion bonus appended to ledger (F884) by server only.
IR-314-3: Calendar focus block via F892 queue — never direct calendar API.
```

**QUALITY GATES (AF-9):**
```
QG-314-1: Capstone aligned to top skill gap from F858
QG-314-2: Rubric present with ≥ 3 evaluation criteria
QG-314-3: Calendar focus block created
QG-314-4: Ledger event logged for capstone completion bonus
```

---

## FLOW TEMPLATES — FLOW-24

### Template 64: student-onboarding-knowledge-map-v1
**Trigger:** CalendarExtensionInstalled | ManualOnboardingTriggered  
**DAG:**
```json
{
  "templateId": "student-onboarding-knowledge-map-v1",
  "version": "1.0",
  "trigger": "CalendarExtensionInstalled",
  "steps": [
    { "stepId": "S01", "factory": "F855", "action": "EnforceScopeAsync", "fabric": "CORE" },
    { "stepId": "S02", "factory": "F853", "action": "RequiresParentalConsentAsync", "fabric": "DATABASE_PG", "blocking": true },
    { "stepId": "S03", "factory": "F852", "action": "UpsertProfileAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S04", "factory": "F856", "action": "GetLocaleConfigAsync", "fabric": "DATABASE_ES" },
    { "stepId": "S05", "factory": "F857", "action": "GetPackAsync", "fabric": "DATABASE_ES" },
    { "stepId": "S06", "factory": "F859", "action": "GetOnboardingQuestionnaireAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S07", "factory": "F860", "action": "GetBaselineQuizAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S08", "factory": "F861", "action": "ScoreResponsesAsync", "fabric": "AI_ENGINE" },
    { "stepId": "S09", "factory": "F861", "action": "BuildKnowledgeMapAsync", "fabric": "AI_ENGINE" },
    { "stepId": "S10", "factory": "F858", "action": "UpsertTopicScoreAsync", "fabric": "DATABASE_ES" },
    { "stepId": "S11", "factory": "F863", "action": "CheckReadinessAsync", "fabric": "DATABASE_NEO4J" },
    { "stepId": "S12", "factory": "F891", "action": "Generate30DayPlanAsync", "fabric": "AI_ENGINE" },
    { "stepId": "S13", "factory": "F890", "action": "UpsertPlanAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S14", "factory": "F892", "action": "EnqueueSyncAsync", "fabric": "QUEUE" }
  ],
  "onError": "DLQ + emit OnboardingFailed event"
}
```

### Template 65: daily-lesson-generation-v1
**Trigger:** DailyLessonScheduleTrigger  
**DAG:**
```json
{
  "templateId": "daily-lesson-generation-v1",
  "version": "1.0",
  "trigger": "DailyLessonScheduleTrigger",
  "steps": [
    { "stepId": "S01", "factory": "F895", "action": "IsQuietTimeNowAsync", "fabric": "DATABASE_PG", "if_true": "defer" },
    { "stepId": "S02", "factory": "F858", "action": "GetGapsAsync", "fabric": "DATABASE_ES" },
    { "stepId": "S03", "factory": "F863", "action": "GetNextReadyTopicsAsync", "fabric": "DATABASE_NEO4J" },
    { "stepId": "S04", "factory": "F868", "action": "FetchAtomsAsync", "fabric": "RAG_VECTOR" },
    { "stepId": "S05", "factory": "F871", "action": "FetchForLessonAsync", "fabric": "RAG_VECTOR" },
    { "stepId": "S06", "factory": "F853", "action": "IsMinorAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S07", "factory": "F870", "action": "ComposeAsync", "fabric": "AI_ENGINE" },
    { "stepId": "S08", "factory": "F875", "action": "SimplifyAsync_or_EnrichAsync", "fabric": "AI_ENGINE" },
    { "stepId": "S09", "factory": "F872", "action": "EvaluateAsync", "fabric": "AI_ENGINE", "blocking": true },
    { "stepId": "S10", "factory": "F873", "action": "PublishAsync", "fabric": "DATABASE_MONGO" },
    { "stepId": "S11", "factory": "F876", "action": "IndexLessonAsync", "fabric": "DATABASE_ES" },
    { "stepId": "S12", "factory": "F892", "action": "EnqueueSyncAsync", "fabric": "QUEUE" },
    { "stepId": "S13", "factory": "F896", "action": "EnqueueReminderAsync", "fabric": "QUEUE" }
  ],
  "onError": "DLQ + emit LessonGenerationFailed event"
}
```

### Template 66: quiz-gamification-hybrid-v1
**Trigger:** StudentSubmitsQuiz  
**DAG:**
```json
{
  "templateId": "quiz-gamification-hybrid-v1",
  "version": "1.0",
  "trigger": "StudentSubmitsQuiz",
  "syncSteps": [
    { "stepId": "SYNC-S01", "factory": "F879", "action": "CompleteSessionAsync", "fabric": "DATABASE_PG" },
    { "stepId": "SYNC-S02", "factory": "F881", "action": "GradeAsync", "fabric": "AI_ENGINE" },
    { "stepId": "SYNC-S03", "factory": "F888", "action": "CalculateAsync", "fabric": "CORE" },
    { "stepId": "SYNC-S04", "returns": "{ points_preview, badge_preview }" }
  ],
  "asyncSteps": [
    { "stepId": "ASYNC-S01", "factory": "F880", "action": "AppendAttemptAsync", "fabric": "DATABASE_PG" },
    { "stepId": "ASYNC-S02", "factory": "F884", "action": "AppendEventAsync", "fabric": "DATABASE_PG" },
    { "stepId": "ASYNC-S03", "factory": "F887", "action": "UpdateStreakAsync", "fabric": "DATABASE_REDIS" },
    { "stepId": "ASYNC-S04", "factory": "F886", "action": "EnqueueUnlockCheckAsync", "fabric": "QUEUE" },
    { "stepId": "ASYNC-S05", "factory": "F889", "action": "UpdateRankAsync", "fabric": "DATABASE_REDIS" },
    { "stepId": "ASYNC-S06", "factory": "F858", "action": "UpsertTopicScoreAsync", "fabric": "DATABASE_ES" },
    { "stepId": "ASYNC-S07", "factory": "F891", "action": "RegenerateTomorrowAsync", "fabric": "AI_ENGINE" }
  ],
  "onError": "DLQ per step + GamificationEventFailed notification"
}
```

### Template 67: missed-lesson-recovery-v1
**Trigger:** CalendarEventExpiredWithoutCompletion  
**DAG:**
```json
{
  "templateId": "missed-lesson-recovery-v1",
  "version": "1.0",
  "trigger": "CalendarEventExpiredWithoutCompletion",
  "steps": [
    { "stepId": "S01", "factory": "F895", "action": "IsQuietTimeNowAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S02", "factory": "F887", "action": "GetStreakAsync", "fabric": "DATABASE_REDIS" },
    { "stepId": "S03", "factory": "F897", "action": "IsProtectedAsync", "fabric": "DATABASE_PG" },
    { "stepId": "S04", "factory": "F873", "action": "GetPublishedAsync", "fabric": "DATABASE_MONGO" },
    { "stepId": "S05", "factory": "F896", "action": "EnqueueReminderAsync", "fabric": "QUEUE" },
    { "stepId": "S06", "factory": "F897", "action": "ApplyProtectionAsync", "fabric": "DATABASE_PG", "conditional": "if_protection_eligible" },
    { "stepId": "S07", "factory": "F892", "action": "EnqueueSyncAsync", "fabric": "QUEUE" }
  ],
  "onError": "DLQ + emit MissedLessonRecoveryFailed event"
}
```

---

## BACKWARD COMPATIBILITY

All T1–T306 task types remain UNCHANGED.
All Templates 1–63 remain UNCHANGED.
FLOW-24 adds T307–T314 (8 new task types) and Templates 64–67 (4 new templates).

---

## SAVE POINT: FLOW24:TASK_TYPES_CATALOG ✅
**Next task type after FLOW-24:** T315
**Next template after FLOW-24:** 68
