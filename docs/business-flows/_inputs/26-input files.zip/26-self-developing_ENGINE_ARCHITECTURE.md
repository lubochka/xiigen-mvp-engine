# XIIGen ENGINE ARCHITECTURE — FLOW-26 ADDENDUM
# Self-Developing Meta-Flow: Factory Registries & Design Records
## FLOW-26 ONLY | F982–F1009 | Families 140–145 | DR-164–DR-175
## Date: 2026-02-27

---

## SAVE POINT: F1009_DEFINED ✅

---

## SYSTEM NUMBERS (FLOW-26)

| Artifact | Start | End | Count |
|----------|-------|-----|-------|
| Factories | F982 | F1009 | 28 |
| Families | 140 | 145 | 6 |
| Design Records | DR-164 | DR-175 | 12 |

---

## FABRIC RESOLUTION SUMMARY (FLOW-26)

| Family | Domain | Primary Fabric | Secondary Fabric |
|--------|--------|---------------|-----------------|
| 140 | Gap Detection & Capability Registry | DATABASE FABRIC (ES) | AI ENGINE FABRIC |
| 141 | Contract & Artifact Generator | AI ENGINE FABRIC | DATABASE FABRIC (ES) |
| 142 | Genesis & Validation Loop | AI ENGINE FABRIC | QUEUE FABRIC |
| 143 | Sandbox & E2E Execution | CORE FABRIC (infra) | QUEUE FABRIC |
| 144 | GitOps Assimilation | EXECUTION FABRIC (FLOW-19) | DATABASE FABRIC |
| 145 | Promotion Ladder & Human Gate | DATABASE FABRIC (ES) | QUEUE FABRIC |

---

## FAMILY 140 — Gap Detection & Capability Registry
**Scope:** Detect capability gaps from flow intents, maintain capability registry, plan reuse strategy
**Task Types:** T367–T370
**Factories:** F982–F988 (7 factories)

---

### F982 — ICapabilityGapDetectorService
**Interface:** `ICapabilityGapDetectorService`
**Fabric Resolution:** AI ENGINE FABRIC (Skill 07 — AiDispatcher) for intent parsing + DATABASE FABRIC (Skill 05 → Elasticsearch) for registry diff
**Operations:**
- `DetectGapsAsync(intentDescription, tenantId)` → `DataProcessResult<GapDetectionResult>`
- `ClassifyGapAsync(gap, tenantId)` → `DataProcessResult<GapClassification>`
**Factory Resolution:** `IExternalServiceFactory<ICapabilityGapDetectorService>.CreateAsync(ctx)` → config-first routing → AI_ENGINE provider + ES provider
**DNA:** ParseDocument (gap = Dictionary<string,object>), tenantId on every query, DataProcessResult<T>
**Events Emitted:** `CapabilityGapDetected`
**IRON RULES:**
- IR-982-1: Gap detection MUST use AI ENGINE FABRIC for intent parsing — no regex/keyword heuristics
- IR-982-2: Every detected gap MUST be classified (MISSING_FACTORY | MISSING_OPERATION | MISSING_PROVIDER)

---

### F983 — ICapabilityRegistryService
**Interface:** `ICapabilityRegistryService`
**Fabric Resolution:** DATABASE FABRIC (Skill 05 → Elasticsearch) — index: `capability-registry-{tenantId}`
**Operations:**
- `RegisterCapabilityAsync(capabilitySpec, tenantId)` → `DataProcessResult<RegistrationResult>`
- `GetCapabilityManifestAsync(factoryInterface, tenantId)` → `DataProcessResult<CapabilityManifest>`
- `InvalidateCacheAsync(tenantId)` → `DataProcessResult<bool>`
- `SearchCapabilitiesAsync(filter, tenantId)` → `DataProcessResult<List<CapabilityManifest>>`
**Factory Resolution:** `IExternalServiceFactory<ICapabilityRegistryService>.CreateAsync(ctx)` → ES provider
**DNA:** BuildSearchFilter (empty fields skipped), tenantId on every query, Dictionary<string,object>
**Events Emitted:** `CapabilityRegistered`, `CapabilityHotReloaded`
**IRON RULES:**
- IR-983-1: All registry reads MUST include tenantId in filter — cross-tenant reads FORBIDDEN
- IR-983-2: Cache invalidation MUST precede hot-reload event emission

---

### F984 — IFlowPlannerService
**Interface:** `IFlowPlannerService`
**Fabric Resolution:** AI ENGINE FABRIC (Skill 07) for DAG planning + DATABASE FABRIC (ES) for template lookup
**Operations:**
- `PlanFlowAsync(intentDescription, tenantId)` → `DataProcessResult<FlowPlan>`
- `DetectSubFlowRequirementAsync(gap, tenantId)` → `DataProcessResult<SubFlowRequirement>`
**Events Emitted:** `FlowPlanned`, `SubFlowRequired`
**IRON RULES:**
- IR-984-1: Planner MUST check capability registry before emitting CapabilityGapDetected
- IR-984-2: Sub-flow detection MUST enforce max depth = 3 (configurable via FREEDOM)

---

### F985 — IReuseDecisionMatrixService
**Interface:** `IReuseDecisionMatrixService`
**Fabric Resolution:** RAG FABRIC (Skills 00a/00b — IRagService, strategy: Hybrid) + AI ENGINE FABRIC (similarity scoring)
**Operations:**
- `EvaluateReuseAsync(capabilitySignature, tenantId)` → `DataProcessResult<ReuseDecision>`
**Events Emitted:** `ReuseDecisionMade`
**IRON RULES:**
- IR-985-1: Reuse scan MUST use RAG FABRIC — direct file system search FORBIDDEN
- IR-985-2: COPY decision requires similarity ≥ 0.95, ADAPT ≥ 0.70

---

### F986 — IReuseScannerService
**Interface:** `IReuseScannerService`
**Fabric Resolution:** RAG FABRIC (Skills 00a/00b) — skill library search
**Operations:**
- `ScanForPatternAsync(capabilitySignature, topK, tenantId)` → `DataProcessResult<List<ReuseCandidate>>`
**IRON RULES:**
- IR-986-1: Scan MUST search existing SK-1–SK-238 library before generating new patterns

---

### F987 — ICapabilityManifestService
**Interface:** `ICapabilityManifestService`
**Fabric Resolution:** DATABASE FABRIC (ES) — index: `capability-manifests-{tenantId}`
**Operations:**
- `StoreManifestAsync(manifest, tenantId)` → `DataProcessResult<bool>`
- `GetManifestByInterfaceAsync(interfaceName, tenantId)` → `DataProcessResult<CapabilityManifest>`
**IRON RULES:**
- IR-987-1: Manifest MUST include fabric resolution mapping for every operation

---

### F988 — ICapabilityGraphService
**Interface:** `ICapabilityGraphService`
**Fabric Resolution:** DATABASE FABRIC (Skill 05 → Elasticsearch or Neo4j provider) — capability dependency graph
**Operations:**
- `BuildCapabilityGraphAsync(gaps, tenantId)` → `DataProcessResult<CapabilityGraph>`
- `DetectCircularDependencyAsync(graph, tenantId)` → `DataProcessResult<bool>`
**IRON RULES:**
- IR-988-1: Circular dependency detection is MANDATORY before sub-flow generation
- IR-988-2: Graph nodes stored as Dictionary<string,object> — no typed graph models

---

## FAMILY 141 — Contract & Artifact Generator
**Scope:** Generate factory specs, task type contracts, event schemas, API contracts, BFA drafts
**Task Types:** T371–T374
**Factories:** F989–F994 (6 factories)

---

### F989 — IContractGeneratorService
**Interface:** `IContractGeneratorService`
**Fabric Resolution:** AI ENGINE FABRIC (AiDispatcher — multi-model) + DATABASE FABRIC (ES: contract-drafts-{tenantId})
**Operations:**
- `GenerateContractAsync(gapSpec, reuseDecision, tenantId)` → `DataProcessResult<ContractBundle>`
**Events Emitted:** `ContractDrafted`
**IRON RULES:**
- IR-989-1: Generated contract MUST follow full engine contract format (ARCHETYPE, FACTORY DEPENDENCIES, FABRIC RESOLUTION, AF CONFIGURATION, BFA VALIDATION, MACHINE/FREEDOM, IR, QG)
- IR-989-2: One-line stubs = BUILD FAILURE

---

### F990 — IFactorySpecGeneratorService
**Interface:** `IFactorySpecGeneratorService`
**Fabric Resolution:** AI ENGINE FABRIC (Skill 07) for generation + DATABASE FABRIC (ES) for storage
**Operations:**
- `GenerateFactorySpecAsync(gap, tenantId)` → `DataProcessResult<FactorySpec>`
**IRON RULES:**
- IR-990-1: Factory spec MUST include fabric resolution mapping
- IR-990-2: Factory spec MUST declare all events emitted

---

### F991 — ITaskTypeContractService
**Interface:** `ITaskTypeContractService`
**Fabric Resolution:** AI ENGINE FABRIC + DATABASE FABRIC (ES: task-type-contracts-{tenantId})
**Operations:**
- `GenerateTaskTypeContractAsync(factorySpec, tenantId)` → `DataProcessResult<TaskTypeContract>`
- `ValidateContractCompletenessAsync(contract, tenantId)` → `DataProcessResult<ValidationResult>`
**IRON RULES:**
- IR-991-1: Task type contract MUST have all required fields — see TASK_TYPES_CATALOG format
- IR-991-2: Contract completeness validation is a MANDATORY gate before genesis phase

---

### F992 — IEventSchemaRegistryService
**Interface:** `IEventSchemaRegistryService`
**Fabric Resolution:** DATABASE FABRIC (ES: event-schema-registry — shared global + tenant override)
**Operations:**
- `RegisterEventSchemaAsync(schema, tenantId)` → `DataProcessResult<bool>`
- `GetEventSchemaAsync(eventName, tenantId)` → `DataProcessResult<EventSchema>`
- `ValidatePayloadAsync(eventName, payload, tenantId)` → `DataProcessResult<bool>`
**IRON RULES:**
- IR-992-1: All new events MUST be registered before GitOps phase
- IR-992-2: Schema MUST include required fields: eventName, version, tenantId (always), payload fields

---

### F993 — IApiContractRegistryService
**Interface:** `IApiContractRegistryService`
**Fabric Resolution:** DATABASE FABRIC (ES: api-contract-registry)
**Operations:**
- `RegisterApiContractAsync(contract, tenantId)` → `DataProcessResult<bool>`
- `CheckBackwardCompatibilityAsync(newContract, existingContract)` → `DataProcessResult<CompatibilityResult>`
**IRON RULES:**
- IR-993-1: Backward compatibility check MANDATORY — breaking changes require explicit DR
- IR-993-2: All new API contracts registered before GitOps phase

---

### F994 — IBfaDraftGeneratorService
**Interface:** `IBfaDraftGeneratorService`
**Fabric Resolution:** AI ENGINE FABRIC (conflict analysis) + DATABASE FABRIC (ES: bfa-registry)
**Operations:**
- `GenerateBfaDraftAsync(contractBundle, tenantId)` → `DataProcessResult<BfaDraft>`
- `RegisterBfaRulesAsync(rules, tenantId)` → `DataProcessResult<bool>`
**IRON RULES:**
- IR-994-1: BFA draft MUST check new rules against CF-1–CF-457 for duplicates
- IR-994-2: All new CF rules MUST follow standard BFA rule format

---

## FAMILY 142 — Genesis & Validation Loop
**Scope:** AF-station bounded generation loop, code bundle creation, test bundle generation, fix application
**Task Types:** T375–T378
**Factories:** F995–F999 (5 factories)

---

### F995 — IGenesisLoopService
**Interface:** `IGenesisLoopService`
**Fabric Resolution:** AI ENGINE FABRIC (AiDispatcher — AF-1 through AF-9) + QUEUE FABRIC (loop events)
**Operations:**
- `RunGenesisAsync(contractBundle, reuseDecision, tenantId)` → `DataProcessResult<GenesisResult>`
**Events Emitted:** `GenesisStarted`, `GenesisIterating`, `GenesisGreen`, `BuildEscalated`
**IRON RULES:**
- IR-995-1: maxRetries = 3 per gap — MACHINE fixed, not configurable (configurable via FREEDOM: 3–5)
- IR-995-2: Judge score threshold ≥ 0.8 for genesis PASS
- IR-995-3: On retry exhaustion, emit BuildEscalated — NEVER silently succeed with failing code

---

### F996 — ICodeBundleValidatorService
**Interface:** `ICodeBundleValidatorService`
**Fabric Resolution:** AI ENGINE FABRIC (AF-6/AF-7/AF-8) + DATABASE FABRIC (ES: validation-results)
**Operations:**
- `ValidateAsync(codeBundle, tenantId)` → `DataProcessResult<ValidationReport>`
**IRON RULES:**
- IR-996-1: DNA-1 through DNA-9 MUST all be checked — partial DNA check = BUILD FAILURE
- IR-996-2: Direct provider imports in generated code = BUILD FAILURE (no exceptions)

---

### F997 — ITestBundleGeneratorService
**Interface:** `ITestBundleGeneratorService`
**Fabric Resolution:** AI ENGINE FABRIC (test generation) + DATABASE FABRIC (test storage)
**Operations:**
- `GenerateTestsAsync(codeBundle, contractBundle, tenantId)` → `DataProcessResult<TestBundle>`
**IRON RULES:**
- IR-997-1: TestBundle MUST include unit tests (fixture-based) AND E2E harness
- IR-997-2: All external calls MUST be intercepted by deterministic harness (SK-226)

---

### F998 — IDeterministicTestHarnessService
**Interface:** `IDeterministicTestHarnessService`
**Fabric Resolution:** DATABASE FABRIC (ES: test-fixtures-{tenantId}) + AI ENGINE FABRIC (fixture generation)
**Operations:**
- `GenerateFixturesAsync(codeBundle, tenantId)` → `DataProcessResult<FixtureBundle>`
- `ValidateHarnessCompletenessAsync(harness, codeBundle, tenantId)` → `DataProcessResult<bool>`
**IRON RULES:**
- IR-998-1: 100% external call interception required — any unintercepted call = harness INCOMPLETE
- IR-998-2: Fixtures stored as Dictionary<string,object> — no typed fixture models

---

### F999 — IFixApplicationService
**Interface:** `IFixApplicationService`
**Fabric Resolution:** AI ENGINE FABRIC (fix generation from failure signatures) + DATABASE FABRIC (patched bundle storage)
**Operations:**
- `ApplyFixAsync(codeBundle, failureSignatures, tenantId)` → `DataProcessResult<PatchedBundle>`
**IRON RULES:**
- IR-999-1: Fix MUST address all failure signatures — partial fix = retry again
- IR-999-2: Fix application must produce a new codeBundle version (immutable — no in-place patching)

---

## FAMILY 143 — Sandbox & E2E Execution
**Scope:** Ephemeral sandbox deployment, E2E flow testing, failure signature extraction, evidence assembly
**Task Types:** T379–T382
**Factories:** F1000–F1004 (5 factories)

---

### F1000 — ISandboxOrchestratorService
**Interface:** `ISandboxOrchestratorService`
**Fabric Resolution:** CORE FABRIC (infrastructure orchestration — FLOW-19 F59 container pattern) + QUEUE FABRIC
**Operations:**
- `CreateSandboxAsync(codeBundle, tenantId)` → `DataProcessResult<SandboxEnvironment>`
- `TeardownSandboxAsync(sandboxId, tenantId)` → `DataProcessResult<bool>` ← ALWAYS RUNS (finally)
**Events Emitted:** `SandboxCreated`, `SandboxTornDown`
**IRON RULES:**
- IR-1000-1: Sandbox creation MUST include tenant namespace isolation: `sandbox-{tenantId}-{runId}`
- IR-1000-2: TeardownSandboxAsync MUST execute in finally block — no exceptions
- IR-1000-3: Sandbox TTL enforced — auto-teardown after FREEDOM-configurable timeout (default 60 min)

---

### F1001 — IEphemeralDeployService
**Interface:** `IEphemeralDeployService`
**Fabric Resolution:** CORE FABRIC (container/K8s — FLOW-19 pattern)
**Operations:**
- `DeployAsync(sandboxId, codeBundle, tenantId)` → `DataProcessResult<DeployResult>`
- `HealthCheckAsync(sandboxId, tenantId)` → `DataProcessResult<HealthStatus>`
**IRON RULES:**
- IR-1001-1: Deploy MUST include health check before E2E — unhealthy = sandbox failure (not E2E failure)
- IR-1001-2: Quota check BEFORE deploy — tenant quota exceeded = DataProcessResult.Failure

---

### F1002 — IE2EFlowTestService
**Interface:** `IE2EFlowTestService`
**Fabric Resolution:** FLOW ENGINE FABRIC (Skill 09 — FlowOrchestrator) + QUEUE FABRIC (test events)
**Operations:**
- `RunE2EAsync(sandboxId, originalFlowSpec, tenantId)` → `DataProcessResult<E2EReport>`
**Events Emitted:** `E2EStarted`, `E2EPassed`, `E2EFailed`
**IRON RULES:**
- IR-1002-1: E2E MUST execute the ORIGINAL requested flow (not a synthetic test) — validates real user intent
- IR-1002-2: E2E MUST assert: output schema, idempotency (run twice → same result), tenantId isolation

---

### F1003 — IFailureSignatureExtractorService
**Interface:** `IFailureSignatureExtractorService`
**Fabric Resolution:** AI ENGINE FABRIC (log analysis) + DATABASE FABRIC (ES: failure-signatures-{tenantId})
**Operations:**
- `ExtractSignaturesAsync(failureReport, tenantId)` → `DataProcessResult<List<FailureSignature>>`
**IRON RULES:**
- IR-1003-1: Each signature MUST include: type, file, line, fixInstruction — incomplete signatures forbidden
- IR-1003-2: Signature extraction MUST use AI ENGINE FABRIC — no regex pattern matching

---

### F1004 — IEvidenceBundleAssemblerService
**Interface:** `IEvidenceBundleAssemblerService`
**Fabric Resolution:** DATABASE FABRIC (ES: evidence-bundles-{tenantId}) + QUEUE FABRIC
**Operations:**
- `AssembleAsync(selfBuildRunId, tenantId)` → `DataProcessResult<EvidenceBundle>`
**Events Emitted:** `EvidenceBundleReady`
**IRON RULES:**
- IR-1004-1: Bundle MUST include all 12 required sections (see SK-227)
- IR-1004-2: Missing DNA matrix or BFA registrations = BUILD FAILURE (cannot proceed to GitOps)

---

## FAMILY 144 — GitOps Assimilation
**Scope:** Commit generated code, open PR, await CI, update registries
**Task Types:** T383–T386
**Factories:** F1005–F1008 (4 factories)

---

### F1005 — IGitOpsAssimilationService
**Interface:** `IGitOpsAssimilationService`
**Fabric Resolution:** EXECUTION FABRIC (FLOW-19: F697 ISourceControlService, F698 ICiCdService, F699 IPrManagementService)
**Operations:**
- `CreateBranchAsync(selfBuildRunId, tenantId)` → `DataProcessResult<BranchRef>`
- `CommitBundleAsync(branch, codeBundle, evidenceSummary, tenantId)` → `DataProcessResult<CommitRef>`
**Events Emitted:** `BranchCreated`, `CodeCommitted`
**IRON RULES:**
- IR-1005-1: Branch naming: `self-build/{tenantId}/{runId}` — immutable convention
- IR-1005-2: Evidence bundle summary MUST be included in commit message

---

### F1006 — IPrManagementService
**Interface:** `IPrManagementService`
**Fabric Resolution:** EXECUTION FABRIC (FLOW-19: F699 IPrManagementService pattern)
**Operations:**
- `OpenPrAsync(branchRef, evidenceBundleId, tenantId)` → `DataProcessResult<PrRef>`
- `AwaitCiResultAsync(prRef, timeout, tenantId)` → `DataProcessResult<CiResult>`
**Events Emitted:** `PrOpened`, `CiGreen`, `CiFailed`, `CiTimeout`
**IRON RULES:**
- IR-1006-1: CORE promotion PRs MUST have required reviewers (from FREEDOM config)
- IR-1006-2: CI timeout emits event and escalates — NEVER waits indefinitely

---

### F1007 — ICiCdGateService
**Interface:** `ICiCdGateService`
**Fabric Resolution:** EXECUTION FABRIC (FLOW-19: F698 ICiCdService)
**Operations:**
- `ValidateCiResultAsync(ciResult, tenantId)` → `DataProcessResult<GateResult>`
**IRON RULES:**
- IR-1007-1: CI failure → extract failure signatures (F1003) → loopback to genesis
- IR-1007-2: CI gate includes security scan, DNA compliance, backward compatibility check

---

### F1008 — IRegistryAssimilationService
**Interface:** `IRegistryAssimilationService`
**Fabric Resolution:** DATABASE FABRIC (ES: factory-registry, capability-registry-{tenantId})
**Operations:**
- `AssimilateFactoryAsync(factorySpec, tenantId)` → `DataProcessResult<bool>`
- `AssimilateCapabilityManifestAsync(manifest, tenantId)` → `DataProcessResult<bool>`
**Events Emitted:** `FactoryAssimilated`, `CapabilityAssimilated`
**IRON RULES:**
- IR-1008-1: Registry update ONLY after PR merged (not on PR open)
- IR-1008-2: Registry update triggers hot-reload (SK-234) automatically

---

## FAMILY 145 — Promotion Ladder & Human Gate
**Scope:** Stage evaluation, promotion record, human approval gate for CORE
**Task Types:** T387–T393
**Factories:** F1009 (1 factory — covers promotion + approval)

---

### F1009 — IPromotionLadderService
**Interface:** `IPromotionLadderService`
**Fabric Resolution:** DATABASE FABRIC (ES: promotion-ledger-{tenantId}) + QUEUE FABRIC (approval events)
**Operations:**
- `EvaluateStageAsync(evidenceBundle, tenantId)` → `DataProcessResult<PromotionDecision>`
- `RequestHumanApprovalAsync(decision, tenantId)` → `DataProcessResult<ApprovalRequest>`
- `AwaitApprovalAsync(approvalId, timeout, tenantId)` → `DataProcessResult<ApprovalResult>`
- `RecordPromotionAsync(decision, approvalResult, tenantId)` → `DataProcessResult<PromotionRecord>`
**Events Emitted:** `PromotionDecided`, `ApprovalRequired`, `ApprovalReceived`, `PromotionCompleted`, `PromotionRejected`
**IRON RULES:**
- IR-1009-1: CORE promotion ALWAYS requires human approval — no config can override this
- IR-1009-2: Stage criteria are MACHINE (fixed) — cannot be changed via FREEDOM config
- IR-1009-3: Promotion record ALWAYS stored — no silent promotions
- IR-1009-4: Approval timeout → stage held at INJECTED (not rejected, not promoted)

---

## DESIGN RECORDS (FLOW-26)

### DR-164 — SelfBuildRun as First-Class Runtime Entity
**Decision:** SelfBuildRun is a persistent, resumable runtime entity stored in Elasticsearch, not an in-memory orchestration object.
**Rationale:** Long-running meta-flows (30 min–24 hr) require sub-60-second recovery from interruption. ES storage with Redis cache layer enables full state recovery on restart.
**Impact:** All phase transitions update SelfBuildRun document. Each phase is idempotent via Idempotency-Key on SelfBuildRunId + phaseId.

### DR-165 — Gap Classification: Three-Type Schema
**Decision:** Gaps classified as exactly: MISSING_FACTORY | MISSING_OPERATION | MISSING_PROVIDER.
**Rationale:** Each type maps to a different artifact generation path (new family vs. extending existing factory vs. adding new fabric provider).
**Impact:** Contract generator (F989) routes differently per gap type.

### DR-166 — maxRetries = 3 Default, FREEDOM-Configurable to 3–5
**Decision:** Genesis loop bounded at 3 retries by default, configurable up to 5 via FREEDOM config.
**Rationale:** Prevents infinite loops; 3 retries covers 95% of fixable issues (DNA violations, missing fields). Beyond 5 = systemic contract problem requiring human design input.
**Impact:** IR-995-1 enforcement. BuildEscalated event triggers human notification.

### DR-167 — Evidence Bundle: 12 Required Sections
**Decision:** Evidence bundle has exactly 12 mandatory sections before GitOps phase can begin.
**Rationale:** Prevents partial promotions. GitOps without complete evidence = security + governance risk.
**Impact:** IR-1004-1 enforcement. Missing sections = BUILD FAILURE at assembly gate.

### DR-168 — CORE Promotion: Human Gate Non-Negotiable
**Decision:** CORE stage promotion requires human approval regardless of automation score, CI result, or tenant tier.
**Rationale:** CORE capabilities affect all tenants. Automated self-modification of production brain is a documented risk (26-self_developing.md). Human gate is the safety mechanism.
**Impact:** IR-1009-1 enforcement. No config can override. ApprovalTimeout holds stage at INJECTED.

### DR-169 — Sandbox Namespace: `sandbox-{tenantId}-{runId}`
**Decision:** Ephemeral sandbox environments always scoped to `sandbox-{tenantId}-{runId}` namespace.
**Rationale:** Multi-tenant isolation (SK-237). Cross-tenant sandbox contamination would be a critical security breach.
**Impact:** IR-1000-1 enforcement. Teardown also uses this namespace for cleanup.

### DR-170 — Deterministic Test Harness: 100% External Call Interception
**Decision:** Unit tests must intercept ALL external calls via fabric interface fixtures. Zero live provider calls in unit tests.
**Rationale:** Live calls introduce flakiness, cost, and non-determinism. Fixture-based harness enables reliable re-runs and offline testing.
**Impact:** IR-998-1 enforcement. Any unintercepted call = harness INCOMPLETE.

### DR-171 — GitOps Branch: `self-build/{tenantId}/{runId}`
**Decision:** Standardized branch naming convention for all self-build assimilation PRs.
**Rationale:** Traceability + tenant isolation. Branch name encodes both tenant and run for audit purposes.
**Impact:** IR-1005-1 enforcement. Registry cannot be updated until PR on this branch merges.

### DR-172 — Reuse Decision Thresholds: COPY ≥ 0.95, ADAPT ≥ 0.70
**Decision:** Similarity scoring determines COPY/ADAPT/REWRITE using fixed thresholds.
**Rationale:** COPY without high confidence risks subtle semantic mismatch. ADAPT is safe at 0.70+ (shared structure, different details). Below 0.70 = insufficient overlap for safe adaptation.
**Impact:** IR-985-2 enforcement. RAG strategy = Hybrid for maximum recall.

### DR-173 — Promotion Ladder: Six Stages, Additive Only
**Decision:** DRAFT → WIRED → VALIDATED → INJECTED → MINIMAL → CORE. Promotion is additive; demotion requires explicit rollback flow (separate from self-build flow).
**Rationale:** Clarity of capability maturity. Accidental demotion could break running flows that depend on a capability at a given stage.
**Impact:** IR-1009-2 enforcement. Stage criteria in SK-229.

### DR-174 — BFA Registration Before GitOps: Mandatory
**Decision:** All new events, APIs, and entities MUST be registered in BFA indices before PR is opened.
**Rationale:** PR review and CI must have access to BFA conflict rules for the new code. Post-merge BFA registration is too late to catch cross-flow conflicts.
**Impact:** IR-994-2, IR-992-1, IR-993-1 enforcement.

### DR-175 — Sub-Flow Max Depth: 3 (FREEDOM-configurable)
**Decision:** Recursive sub-flow generation limited to depth 3 by default, configurable via FREEDOM.
**Rationale:** Unbounded recursion risks combinatorial explosion of contracts, tests, and CI gates. Depth 3 covers all known real-world cases (connector → poll loop → result aggregation).
**Impact:** IR-984-2 enforcement. Depth > config = explicit DR required to extend.

---

## BACKWARD COMPATIBILITY (FLOW-26)

| Check | Status |
|-------|--------|
| F1–F981 unchanged | ✅ PASS — no modifications to existing factories |
| T1–T366 unchanged | ✅ PASS — no modifications to existing task types |
| CF-1–CF-457 unchanged | ✅ PASS — no modifications to existing BFA rules |
| SK-1–SK-222 unchanged | ✅ PASS — no modifications to existing skills |
| DD-1–DD-218 unchanged | ✅ PASS — no modifications to existing design decisions |
| DR-1–DR-163 unchanged | ✅ PASS — no modifications to existing design records |
| DNA-1–DNA-9 stable | ✅ PASS — FLOW-26 enforces existing 9 patterns |
| FLOW-01–FLOW-23 intact | ✅ PASS — existing flows not modified |
| FLOW-19 EXECUTION FABRIC reused | ✅ PASS — F697-F733 referenced via adapter, not modified |
| FLOW-23 TENANT FABRIC reused | ✅ PASS — F967 ITenantIsolationEnforcerService referenced, not modified |

---

## SAVE POINT: F1009_DEFINED ✅ | FAMILIES 140-145 DEFINED ✅ | DR-164-DR-175 DEFINED ✅
