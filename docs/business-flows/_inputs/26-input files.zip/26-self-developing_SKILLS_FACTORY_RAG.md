# XIIGen SKILLS FACTORY & RAG INDEX — FLOW-26 ADDENDUM
# Self-Developing Meta-Flow: Skill Patterns
## FLOW-26 ONLY | SK-223–SK-238 (16 new skills)
## Date: 2026-02-27

---

## SAVE POINT: SK238_DEFINED ✅

---

## REUSE ANALYSIS (FLOW-26)

### Existing Assets → FLOW-26 Needs

| FLOW-26 Need | Existing Asset | Action |
|---|---|---|
| Intent parsing via AI | IAiProvider + AiDispatcher (Skill 07) | ✅ REUSE (AI ENGINE FABRIC) |
| Capability registry (ES read/write) | IDatabaseService → Elasticsearch (Skill 05) | ✅ REUSE (DATABASE FABRIC) |
| Distributed locking | IDatabaseService → Redis (Skill 05) | ✅ REUSE (DATABASE FABRIC pattern) |
| Event publishing (all phases) | IQueueService → Redis Streams (Skill 04) | ✅ REUSE (QUEUE FABRIC) |
| Semantic reuse scan | IRagService (Skills 00a/00b) | ✅ REUSE (RAG FABRIC) |
| Service inheritance base | MicroserviceBase (Skill 01) | ✅ REUSE (CORE FABRIC) |
| Flow DAG orchestration | FlowOrchestrator (Skill 09) | ✅ REUSE (FLOW ENGINE FABRIC) |
| Multi-model code generation | AiDispatcher (Skill 07) | ✅ REUSE — applied to genesis |
| Git/CI operations | FLOW-19 F697-F733 patterns | ✅ ADAPT (EXECUTION FABRIC) |
| Sandbox/container orchestration | FLOW-19 container patterns | ✅ ADAPT (CORE FABRIC infra) |
| Gap detection (new) | — | 🆕 SK-223 |
| Contract-first generation (new) | — | 🆕 SK-224 |
| Genesis loop with retries (new) | — | 🆕 SK-225 |
| Deterministic test harness (new) | — | 🆕 SK-226 |
| Evidence bundle assembly (new) | — | 🆕 SK-227 |
| GitOps assimilation (new) | — | 🆕 SK-228 |
| Promotion ladder governance (new) | — | 🆕 SK-229 |
| Human approval gate (new) | — | 🆕 SK-230 |
| SelfBuildRun state machine (new) | — | 🆕 SK-231 |
| Reuse decision matrix (new) | — | 🆕 SK-232 |
| Failure signature extraction (new) | — | 🆕 SK-233 |
| Capability hot-reload pattern (new) | — | 🆕 SK-234 |
| Meta-flow BFA pack generation (new) | — | 🆕 SK-235 |
| Sandbox teardown finally pattern (new) | — | 🆕 SK-236 |
| Multi-tenant SelfBuild isolation (new) | — | 🆕 SK-237 |
| Recursive sub-flow generation (new) | — | 🆕 SK-238 |

---

## AF-4 RAG RETRIEVAL INDEX (FLOW-26)

| Query Term | Skill(s) Returned |
|---|---|
| gap detection capability registry | SK-223 |
| contract-first factory interface generation | SK-224 |
| genesis loop retry bounded | SK-225 |
| deterministic test harness external call | SK-226 |
| evidence bundle assembly proof | SK-227 |
| gitops commit PR CI assimilation | SK-228 |
| promotion ladder GENERATED CORE | SK-229 |
| human approval gate CORE promotion | SK-230 |
| SelfBuildRun state machine phases | SK-231 |
| reuse decision COPY ADAPT REWRITE | SK-232 |
| failure signature extraction logs | SK-233 |
| capability hot-reload registry | SK-234 |
| BFA pack meta-flow generation | SK-235 |
| sandbox teardown finally cleanup | SK-236 |
| multi-tenant SelfBuild isolation | SK-237 |
| recursive sub-flow generation nested | SK-238 |

---

## SKILL PATTERNS (SK-223 TO SK-238)

---

### SK-223 — Gap Detection Pattern

**ID:** SK-223
**Name:** CapabilityGapDetector
**Archetype:** INVENTORY
**Flow:** FLOW-26
**Fabric:** DATABASE FABRIC (Elasticsearch capability index) + AI ENGINE FABRIC (intent parsing)
**Factories Used:** F982 ICapabilityGapDetectorService, F983 ICapabilityRegistryService, F984 IFlowPlannerService

**When AF-4 returns this:** Query requests gap detection, capability planning, or "what's missing" analysis against an intent description.

**Pattern:**

```
1. Parse intent via AI ENGINE FABRIC → extract required capability signatures
2. Load capability registry via DATABASE FABRIC → BuildSearchFilter with tenantId + capabilityType
3. Diff: required signatures vs registered capabilities → gaps[]
4. For each gap: classify as MISSING_FACTORY | MISSING_OPERATION | MISSING_PROVIDER
5. Emit CapabilityGapDetected event via QUEUE FABRIC
6. Return DataProcessResult<GapDetectionResult> — never throw
```

**MACHINE (fixed):** Gap classification logic, capability signature format, event schema.
**FREEDOM (configurable):** AI model for intent parsing, registry index name, gap threshold.
**DNA Compliance:** ParseDocument (no typed Gap model), BuildSearchFilter (skip empty fields), DataProcessResult<T>, MicroserviceBase, tenantId scope, DynamicController.

**Positive Example:**
```
Input: intent = "text → video generation with OpenAI"
Registry: ITextAnalysisService ✅, IVideoGenerationService ❌
Output: gaps = [{ type: MISSING_FACTORY, interface: "IVideoGenerationService", fabric: "AI_ENGINE" }]
Event: CapabilityGapDetected published to QUEUE FABRIC
```

**Negative Example (FORBIDDEN):**
```csharp
// WRONG: Direct provider check
if (!_openAiClient.HasVideoModel()) { ... }
// WRONG: Typed gap model
var gap = new CapabilityGap { Interface = "IVideoGenerationService" };
// WRONG: Direct DB import
var conn = new ElasticsearchClient(...);
```

---

### SK-224 — Contract-First Generation Pattern

**ID:** SK-224
**Name:** ContractFirstArtifactGenerator
**Archetype:** SYNTHESIS
**Flow:** FLOW-26
**Fabric:** AI ENGINE FABRIC (multi-model generation) + DATABASE FABRIC (contract storage)
**Factories Used:** F989 IContractGeneratorService, F990 IFactorySpecGeneratorService, F991 ITaskTypeContractService

**When AF-4 returns this:** Need to generate factory interface spec, task type contract, fabric resolution mapping, or event schema from a detected gap.

**Pattern:**

```
1. Load gap payload from QUEUE FABRIC (DequeueAsync)
2. AF-2 Planning: decompose gap into contract artifacts needed
3. AF-4 RAG: search existing factory patterns (similarity to existing Fx families)
4. AF-1 Genesis (contract mode): emit factory spec JSON + task type contract JSON
5. Validate: contract completeness gate (all required fields present)
6. Store artifacts via DATABASE FABRIC → Elasticsearch contract-drafts index
7. Register event schemas via F992 IEventSchemaRegistryService
8. Emit ContractDrafted event via QUEUE FABRIC
```

**MACHINE (fixed):** Contract schema format (must match TASK_TYPES_CATALOG format exactly), fabric resolution mapping structure.
**FREEDOM (configurable):** AI model selection, consensus threshold, template selection.
**DNA Compliance:** All artifacts stored as Dictionary<string,object>, BuildSearchFilter, DataProcessResult<T>, MicroserviceBase, tenantId on every write.

**Positive Example:**
```
Gap: MISSING_FACTORY: IVideoGenerationService (AI_ENGINE)
Output contract:
{
  "factoryId": "F1009+", "interface": "IVideoGenerationService",
  "fabricResolution": "AI_ENGINE_FABRIC → AiDispatcher (Skill 07)",
  "operations": ["GenerateVideoAsync"],
  "taskTypeRef": "T367+",
  "eventSchemas": ["VideoGenerationRequested", "VideoGenerationCompleted"]
}
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Skip fabric resolution mapping
{ "factoryId": "F1009", "interface": "IVideoGenerationService" }
// WRONG: One-line stub instead of full engine contract format
T367: VideoGeneration — generates video
```

---

### SK-225 — Genesis Loop with Retries Pattern

**ID:** SK-225
**Name:** BoundedGenesisLoop
**Archetype:** SYNTHESIS + JUDGMENT
**Flow:** FLOW-26
**Fabric:** AI ENGINE FABRIC (generation + review + judge) + QUEUE FABRIC (events) + DATABASE FABRIC (code bundle storage)
**Factories Used:** F995 IGenesisLoopService, F996 ICodeBundleValidatorService, F997 ITestBundleGeneratorService

**When AF-4 returns this:** Need to generate implementation code + tests with AF station loop, bounded retries, and judge feedback.

**Pattern:**

```
LOOP (maxRetries = 3):
  1. AF-4 RAG: search SK library for closest existing implementation pattern
  2. AF-1 Genesis: generate implementation + tests (fabric-first, DNA-compliant)
  3. AF-6 Code Review: automated review → reviewReport
  4. AF-7 Compliance: verify DNA-1 through DNA-9 → complianceReport
  5. AF-8 Security: scan → securityReport
  6. AF-9 Judge: evaluate all reports → pass/fail with feedback
  IF judge.pass → break
  IF judge.fail AND retries < maxRetries:
    extract failure signatures (SK-233)
    apply fix via IFixApplicationService (F999)
    increment retry counter
  IF retries == maxRetries → escalate (emit BuildEscalated event)
```

**MACHINE (fixed):** maxRetries = 3, AF station sequence, DNA-1–DNA-9 checks, escalation on exhaustion.
**FREEDOM (configurable):** AI model per AF station, judge quality threshold (default 0.8), retry backoff.

**Positive Example:**
```
Attempt 1: Genesis generates IVideoGenerationService impl
AF-7: DNA-1 violation (typed model used)
AF-9: FAIL — "Use Dictionary<string,object> via ParseDocument"
Attempt 2: Fix applied — typed model replaced with ParseDocument pattern
AF-9: PASS (score 0.85)
Output: codeBundle stored in ES, TestBundle stored in ES
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Unlimited retries
while (!judge.Pass) { generate(); }
// WRONG: Skip AF-7 DNA compliance check
runAF1(); runAF6(); runAF8(); runAF9();
// WRONG: Throw on retry exhaustion
throw new MaxRetriesException("Build failed");
// CORRECT: return DataProcessResult.Failure("BUILD_ESCALATED", ...)
```

---

### SK-226 — Deterministic Test Harness Pattern

**ID:** SK-226
**Name:** DeterministicTestHarness
**Archetype:** JUDGMENT
**Flow:** FLOW-26
**Fabric:** DATABASE FABRIC (fixture storage) + AI ENGINE FABRIC (test data generation)
**Factories Used:** F998 IDeterministicTestHarnessService

**When AF-4 returns this:** Need to generate deterministic, repeatable tests for externally-dependent code (AI providers, external APIs, databases) that avoid flakiness and record/replay capability.

**Pattern:**

```
1. Identify external calls in codeBundle (AF-4 RAG scans for fabric interface calls)
2. For each external call: generate fixture (recorded response)
   - AI calls: pre-recorded response fixtures (no live calls during tests)
   - DB calls: in-memory or ES testcontainer fixture
   - Queue calls: mock Redis Streams consumer group
3. Generate test harness wrapping fixtures around fabric interfaces
4. Verify: all external calls intercepted (no live provider calls in unit tests)
5. Generate E2E harness separately (uses real sandbox, not fixtures)
6. Store fixtures via DATABASE FABRIC → test-fixtures-{tenantId} index
```

**MACHINE (fixed):** All external calls must be intercepted in unit tests; E2E is separate; fixture format is Dictionary<string,object>.
**FREEDOM (configurable):** Fixture generation AI model, fixture replay strategy.

**Positive Example:**
```
ExternalCall: IAiProvider.GenerateAsync("Generate video from prompt X")
Fixture: { "request_hash": "sha256:...", "response": { "videoUrl": "https://...", "duration": 5 } }
TestHarness: Inject fixture → call → assert response matches expected schema
Result: Unit test passes deterministically (no flakiness, no live AI calls)
```

**Negative Example (FORBIDDEN):**
```csharp
// WRONG: Live AI call in unit test
var result = await _openAi.GenerateAsync("test prompt");
// WRONG: Typed fixture model
var fixture = new VideoFixture { VideoUrl = "https://..." };
// WRONG: No fixture — test depends on external state
Assert.NotNull(await _videoService.GenerateAsync("test"));
```

---

### SK-227 — Evidence Bundle Assembly Pattern

**ID:** SK-227
**Name:** EvidenceBundleAssembler
**Archetype:** JUDGMENT
**Flow:** FLOW-26
**Fabric:** DATABASE FABRIC (bundle storage) + QUEUE FABRIC (completion events)
**Factories Used:** F1004 IEvidenceBundleAssemblerService

**When AF-4 returns this:** Need to assemble comprehensive proof artifacts before GitOps promotion — covering gaps, contracts, implementation, tests, security, DNA compliance, sandbox results, and BFA registrations.

**Pattern:**

```
Collect from all prior phases:
  gaps[]: gap definitions with classification
  contracts[]: factory specs + task type contracts + event schemas
  codeBundle: per-gap implementation + AF review reports
  testBundle: unit fixtures + E2E harness
  unitReport: test results with pass/fail per test
  sandboxRef: ephemeral env reference
  e2eReport: E2E flow trace IDs + pass/fail
  securityReport: AF-8 scan results
  dnaMatrix: DNA-1–DNA-9 compliance per gap
  bfaRegistrations: new entities/events/APIs registered
  promotionDecision: target stage + approver (if CORE)

Assemble into evidence-bundle document (Dictionary<string,object>)
Store via DATABASE FABRIC → evidence-bundles-{tenantId} index
Include: evidenceBundleId, tenantId, selfBuildRunId, timestamp, all collected artifacts

Emit EvidenceBundleReady event via QUEUE FABRIC
```

**MACHINE (fixed):** All sections required (no partial bundles), bundle must include DNA matrix and BFA registrations.
**FREEDOM (configurable):** Storage index prefix, bundle TTL, notification routing.

**Positive Example:**
```
Bundle for SelfBuildRun-abc123:
{
  "evidenceBundleId": "eb-xyz789",
  "tenantId": "tenant-001",
  "selfBuildRunId": "sbr-abc123",
  "gaps": [{ "type": "MISSING_FACTORY", "interface": "IVideoGenerationService" }],
  "dnaMatrix": { "DNA-1": "PASS", "DNA-2": "PASS", ..., "DNA-9": "PASS" },
  "e2eReport": { "passed": true, "traceIds": ["t1", "t2"] },
  "promotionDecision": { "stage": "INJECTED", "requiresHumanApproval": false }
}
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Missing DNA matrix in bundle
{ "gaps": [...], "codeBundle": {...} }  // incomplete — build CANNOT promote
// WRONG: Typed bundle model
var bundle = new EvidenceBundle { Gaps = gapList };
// WRONG: Missing BFA registrations
{ ..., "bfaRegistrations": null }  // null = BUILD FAILURE
```

---

### SK-228 — GitOps Assimilation Pattern

**ID:** SK-228
**Name:** GitOpsAssimilator
**Archetype:** ORCHESTRATION
**Flow:** FLOW-26
**Fabric:** EXECUTION FABRIC (Git/CI via FLOW-19 F697-F733) + QUEUE FABRIC (CI result events) + DATABASE FABRIC (registry updates)
**Factories Used:** F1005 IGitOpsAssimilationService, F1006 IPrManagementService, F1007 ICiCdGateService, F1008 IRegistryAssimilationService

**When AF-4 returns this:** Need to commit generated code, open PR, await CI, and update registries upon successful merge.

**Pattern:**

```
1. Create branch: self-build/{selfBuildRunId} via F697 ISourceControlService (EXECUTION FABRIC)
2. Commit: codeBundle + testBundle + evidence bundle summary via ISourceControlService
3. Open PR: title = "Self-Build: {gapSummary}", body = evidence bundle link
   → Assign reviewers via FREEDOM config (or auto-approve for stages below CORE)
4. Subscribe to CI events via QUEUE FABRIC (CI_RESULT queue)
5. Await CI green (timeout configurable via FREEDOM, default 30 min)
   IF CI_FAIL: extract failure signatures (SK-233) → loopback to genesis (SK-225)
   IF CI_TIMEOUT: emit CiTimeout event → escalate
6. On CI green AND PR merged:
   → Update factory registry via F1008 IRegistryAssimilationService (DATABASE FABRIC)
   → Update capability manifest via F983 ICapabilityRegistryService
   → Emit CapabilityAssimilated event via QUEUE FABRIC
```

**MACHINE (fixed):** Branch naming convention, CI gate required before registry update, registry update only after merge (not after PR open).
**FREEDOM (configurable):** CI timeout, auto-approve threshold (stage < CORE), reviewer assignment rules, target repository.

**Positive Example:**
```
Branch: self-build/sbr-abc123
Commit: "feat(self-build): add IVideoGenerationService via AI_ENGINE_FABRIC"
PR opened → CI triggered → CI green in 12min
Registry updated: F1009 IVideoGenerationService → AI_ENGINE_FABRIC registered
Event: CapabilityAssimilated { factoryId: "F1009", tenantId: "tenant-001" }
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Direct git CLI call
Process.Start("git", "commit -m ...");
// WRONG: Update registry before CI green
await RegisterFactory(F1009);  // before merge
await OpenPr(...);
// WRONG: Skip PR for CORE promotion
await MergeDirectly();  // CORE always requires PR + human approval
```

---

### SK-229 — Promotion Ladder Governance Pattern

**ID:** SK-229
**Name:** PromotionLadderGovernance
**Archetype:** GUARDRAIL
**Flow:** FLOW-26
**Fabric:** DATABASE FABRIC (promotion ledger in ES) + QUEUE FABRIC (promotion events)
**Factories Used:** F1009 IPromotionLadderService

**When AF-4 returns this:** Need to evaluate promotion stage assignment, enforce stage criteria, and record promotion decisions with full audit trail.

**Promotion Stages:**
```
DRAFT → WIRED → VALIDATED → INJECTED → MINIMAL → CORE
```

**Stage Criteria (MACHINE — fixed):**
```
DRAFT:      Evidence bundle created, no tests required
WIRED:      Unit tests pass (harness), DNA compliance PASS
VALIDATED:  E2E tests pass in sandbox
INJECTED:   CI green, registry updated, PR merged
MINIMAL:    2+ production flows using this capability successfully
CORE:       Human approval + security review + 30-day stability window
```

**Pattern:**

```
1. Load evidence bundle via DATABASE FABRIC
2. Evaluate: which stage criteria are met
3. Assign: highest stage where ALL criteria are satisfied
4. IF target stage == CORE: set requiresHumanApproval = true → trigger SK-230
5. Record promotion decision in promotion-ledger-{tenantId} index (DATABASE FABRIC)
6. Emit PromotionDecided event via QUEUE FABRIC
```

**MACHINE (fixed):** Stage criteria are immutable (cannot be skipped), CORE always requires human approval, promotion is additive (cannot demote without explicit rollback).
**FREEDOM (configurable):** MINIMAL usage count threshold (default 2), CORE stability window duration (default 30 days).

**Positive Example:**
```
Evidence bundle: DNA PASS, E2E PASS, CI PASS, registry updated
→ Stage: INJECTED (criteria met through INJECTED, not yet MINIMAL)
Record: { stage: "INJECTED", selfBuildRunId: "sbr-abc123", timestamp: now }
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Skip stages
promotionStage = "CORE"  // when CI hasn't run yet
// WRONG: Auto-promote to CORE without human approval
if (ciGreen) promotionStage = "CORE";
// WRONG: No promotion record
// (promotion must always produce a ledger entry)
```

---

### SK-230 — Human Approval Gate Pattern

**ID:** SK-230
**Name:** HumanApprovalGate
**Archetype:** GUARDRAIL
**Flow:** FLOW-26
**Fabric:** QUEUE FABRIC (approval request/response) + DATABASE FABRIC (approval record) + AI ENGINE FABRIC (approval summary generation)
**Factories Used:** F1009 IPromotionLadderService (approval sub-flow), F1008 IRegistryAssimilationService

**When AF-4 returns this:** Need to pause automated flow, notify approvers, await human decision, and resume or abort based on response.

**Pattern:**

```
1. Generate approval summary via AI ENGINE FABRIC (concise, evidence-linked)
2. Emit ApprovalRequired event via QUEUE FABRIC:
   { approvalId, selfBuildRunId, promotionStage: "CORE", evidenceBundleId, summary }
3. Deliver to approver(s) via notification (FREEDOM: email/Slack/webhook channel)
4. Subscribe to ApprovalResponse queue (timeout: FREEDOM configurable, default 72h)
5. IF APPROVED:
   → Resume promotion → CORE
   → Record approval in approval-records-{tenantId} index
6. IF REJECTED:
   → Emit PromotionRejected event
   → Stage remains at INJECTED/MINIMAL
   → Record rejection with reason
7. IF TIMEOUT:
   → Emit ApprovalTimeout event → stage stays INJECTED
```

**MACHINE (fixed):** CORE promotion ALWAYS requires human approval — no exceptions. Timeout results in stage hold (not rejection). Approval record always stored.
**FREEDOM (configurable):** Approver list, timeout duration, notification channel.

**Positive Example:**
```
ApprovalRequired: { factoryId: "F1009", stage: "CORE", summary: "IVideoGenerationService..." }
→ Approver receives notification
→ Approver responds: APPROVED
→ Stage promoted to CORE, record stored
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Auto-approve CORE
if (approvers.Count == 0) approveCorePromotion();
// WRONG: No timeout handling
await approvalChannel.WaitForever();
// WRONG: No approval record
ApproveAndPromote();  // without storing who approved and when
```

---

### SK-231 — SelfBuildRun State Machine Pattern

**ID:** SK-231
**Name:** SelfBuildRunStateMachine
**Archetype:** ORCHESTRATION
**Flow:** FLOW-26
**Fabric:** DATABASE FABRIC (run state in ES + Redis) + QUEUE FABRIC (phase transition events)
**Factories Used:** F982-F1009 (orchestrated), F984 IFlowPlannerService

**When AF-4 returns this:** Need to manage and persist the full lifecycle state of a SelfBuildRun across phases, including recovery from interruption.

**States:**
```
TRIGGERED → GAPS_DETECTED → CONTRACTS_DRAFTED → GENESIS_IN_PROGRESS
→ GENESIS_GREEN → SANDBOX_DEPLOYED → E2E_PASSED
→ PR_OPENED → CI_GREEN → PROMOTED → COMPLETED
(+ ESCALATED, REJECTED, AWAITING_HUMAN at any phase)
```

**Pattern:**

```
SelfBuildRun document (Dictionary<string,object>):
{
  "runId": "sbr-{uuid}", "tenantId": "...", "state": "TRIGGERED",
  "intent": "...", "gaps": [], "contracts": [], "codeBundle": {},
  "testBundle": {}, "sandboxRef": null, "e2eReport": null,
  "prRef": null, "ciResult": null, "promotionDecision": null,
  "retryCountByGap": {}, "phaseHistory": [], "createdAt": "...", "updatedAt": "..."
}

On each phase transition:
1. Load current run via DATABASE FABRIC (ES: self-build-runs-{tenantId})
2. Validate: transition is legal per state machine
3. Update state + append to phaseHistory
4. Store run via DATABASE FABRIC (upsert)
5. Emit PhaseTransitioned event via QUEUE FABRIC (for observability)

Recovery:
1. Load run by runId → resume from current state
2. Re-execute current phase (all phases are idempotent via Idempotency-Key)
```

**MACHINE (fixed):** State machine transitions, phaseHistory append-only, runId immutable.
**FREEDOM (configurable):** Run TTL (default 7 days), max concurrent runs per tenant.
**DNA Compliance:** Dictionary<string,object> for run document, tenantId on all queries, BuildSearchFilter.

**Positive Example:**
```
State: GENESIS_GREEN → transition to SANDBOX_DEPLOYED
Load run sbr-abc123 → validate GENESIS_GREEN → SANDBOX_DEPLOYED is legal
Update: state = "SANDBOX_DEPLOYED", sandboxRef = { envId: "sb-xyz", endpoints: [...] }
phaseHistory.append({ phase: "SANDBOX_DEPLOYED", timestamp: now })
Store → emit PhaseTransitioned event
```

**Negative Example (FORBIDDEN):**
```
// WRONG: No state persistence between phases
var run = new SelfBuildRun { State = "SANDBOX_DEPLOYED" };  // in-memory only
// WRONG: Skip phase transition validation
run["state"] = "PROMOTED";  // jumping from GENESIS_GREEN to PROMOTED
// WRONG: Typed state model
class SelfBuildRun { public string State { get; set; } }
```

---

### SK-232 — Reuse Decision Matrix Pattern

**ID:** SK-232
**Name:** ReuseDecisionMatrix
**Archetype:** INVENTORY
**Flow:** FLOW-26
**Fabric:** RAG FABRIC (semantic search via SK library) + AI ENGINE FABRIC (similarity scoring)
**Factories Used:** F985 IReuseDecisionMatrixService, F986 IReuseScannerService

**When AF-4 returns this:** Need to determine whether to COPY, ADAPT, or REWRITE a capability based on semantic similarity to existing patterns.

**Reuse Decisions:**
```
COPY:    Similarity ≥ 0.95 — existing pattern is identical; use as-is
ADAPT:   0.70 ≤ Similarity < 0.95 — existing pattern needs modification
REWRITE: Similarity < 0.70 — no close match; generate from scratch
```

**Pattern:**

```
1. For each detected gap: extract capability signature (interface + operations + fabric)
2. RAG FABRIC search: IRagService.SearchAsync(capabilitySignature, strategy: "Hybrid")
3. Score top-3 results via AI ENGINE FABRIC (semantic similarity scoring)
4. Apply matrix:
   - COPY: instruct genesis to clone + register under new factoryId
   - ADAPT: instruct genesis to use existing pattern as base template
   - REWRITE: instruct genesis with no base template
5. Record reusePlan: { gapId, decision, sourceSkill?, similarityScore }
6. Pass reusePlan to genesis loop (SK-225) as context
```

**MACHINE (fixed):** Similarity thresholds, strategy = "Hybrid" for reuse scan.
**FREEDOM (configurable):** Similarity model, top-K candidates.

**Positive Example:**
```
Gap: IVideoGenerationService (AI_ENGINE)
RAG finds: SK-143 (IImageGenerationService) → similarity 0.78
Decision: ADAPT — "Use SK-143 as base, adapt GenerateAsync for video output schema"
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Always REWRITE regardless of similarity
decision = "REWRITE";  // wastes generation tokens, breaks reuse philosophy
// WRONG: COPY without checking similarity
decision = "COPY";  // before RAG scan
// WRONG: Direct code search (not through RAG FABRIC)
var files = Directory.GetFiles("skills/", "*.cs");
```

---

### SK-233 — Failure Signature Extraction Pattern

**ID:** SK-233
**Name:** FailureSignatureExtractor
**Archetype:** JUDGMENT
**Flow:** FLOW-26
**Fabric:** AI ENGINE FABRIC (log analysis) + DATABASE FABRIC (failure signature storage)
**Factories Used:** F1003 IFailureSignatureExtractorService

**When AF-4 returns this:** Need to extract actionable repair instructions from test/CI failure logs to feed back into the genesis loop.

**Failure Signature Types:**
```
DNA_VIOLATION:       "Used typed model at line X — replace with ParseDocument"
MISSING_TENANTID:    "Query at line X missing tenantId filter"
PROVIDER_DIRECT:     "Direct provider import at line X — use fabric interface"
TEST_ASSERTION:      "Assert failed: expected VideoUrl != null, got null"
CI_BUILD_ERROR:      "Build error: missing package reference"
SCHEMA_MISMATCH:     "Event schema VideoGenerationCompleted missing field 'duration'"
```

**Pattern:**

```
1. Load failure report (unitReport, e2eReport, or ciResult)
2. AI ENGINE FABRIC: analyze logs → extract failure signatures[]
3. For each signature: classify type + extract line/file reference + generate fix instruction
4. Store failure signatures via DATABASE FABRIC → failure-signatures-{tenantId} index
5. Return DataProcessResult<FailureSignatures[]> to genesis loop caller
```

**MACHINE (fixed):** All 6 signature types, fix instruction always required (not just classification).
**FREEDOM (configurable):** AI model for log analysis, signature confidence threshold.

**Positive Example:**
```
Log: "System.NullReferenceException: Object reference not set — VideoGenerationService.cs:42"
AI analysis: type = "TEST_ASSERTION", line = 42
fix = "Ensure ParseDocument handles null video_url field with default empty string"
Output: { type: "TEST_ASSERTION", file: "VideoGenerationService.cs", line: 42, fix: "..." }
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Return raw logs without extraction
return DataProcessResult.Success(rawLogs);  // genesis can't repair from raw logs
// WRONG: No fix instruction
{ type: "DNA_VIOLATION", line: 15 }  // missing fix instruction
// WRONG: Typed FailureSignature model
var sig = new FailureSignature { Type = "DNA_VIOLATION" };
```

---

### SK-234 — Capability Hot-Reload Pattern

**ID:** SK-234
**Name:** CapabilityHotReload
**Archetype:** ORCHESTRATION
**Flow:** FLOW-26
**Fabric:** QUEUE FABRIC (hot-reload events) + DATABASE FABRIC (capability manifest) + CORE FABRIC (MicroserviceBase config reload)
**Factories Used:** F1008 IRegistryAssimilationService, F983 ICapabilityRegistryService

**When AF-4 returns this:** Need to make a newly-assimilated capability available to the running engine without full restart, by updating registries and triggering config reload via existing MicroserviceBase mechanisms.

**Pattern:**

```
1. Receive CapabilityAssimilated event from QUEUE FABRIC
2. Update capability manifest in ES (via F983 ICapabilityRegistryService)
3. Invalidate factory registry cache (Redis key: capability-registry-{tenantId})
4. Emit CapabilityHotReloaded event via QUEUE FABRIC
   → Flow Orchestrator listens and re-evaluates pending flows that were blocked on gap
5. Verify: re-run gap detection for pending blocked flows → gap now resolved
6. Resume previously-blocked flows via FLOW ENGINE FABRIC
```

**MACHINE (fixed):** Cache invalidation before hot-reload event emission, pending flow re-evaluation required.
**FREEDOM (configurable):** Cache TTL, max concurrent hot-reloads per tenant.
**DNA Compliance:** No direct Redis import — always via DATABASE FABRIC (Redis provider), always tenantId-scoped cache keys.

**Positive Example:**
```
Event: CapabilityAssimilated { factoryId: "F1009", interface: "IVideoGenerationService" }
→ Capability manifest updated in ES
→ Cache invalidated: capability-registry-tenant-001
→ Event: CapabilityHotReloaded emitted
→ Flow planner re-evaluates "text→video" flow: gap resolved → flow resumes
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Restart service to reload capability
Process.Start("kubectl", "rollout restart deployment/flow-orchestrator");
// WRONG: Direct Redis invalidation (not through fabric)
_redis.KeyDelete("capability-registry-tenant-001");
// WRONG: No pending flow re-evaluation
// (capability added to registry but blocked flows not notified)
```

---

### SK-235 — Meta-Flow BFA Pack Generation Pattern

**ID:** SK-235
**Name:** MetaFlowBfaPackGenerator
**Archetype:** GUARDRAIL
**Flow:** FLOW-26
**Fabric:** DATABASE FABRIC (BFA index in ES) + AI ENGINE FABRIC (conflict analysis)
**Factories Used:** F994 IBfaDraftGeneratorService, F992 IEventSchemaRegistryService, F993 IApiContractRegistryService

**When AF-4 returns this:** Need to generate and register BFA conflict rules for newly-generated capabilities before they can proceed to GitOps, to prevent cross-flow conflicts with existing F1–F1009.

**Pattern:**

```
1. Load generated contracts: factory specs + event schemas + API contracts
2. Load existing BFA registrations via DATABASE FABRIC → bfa-registry-{tenantId} index
3. AI ENGINE FABRIC: analyze new contracts vs existing registrations → candidate conflicts
4. For each candidate conflict: generate CF rule in standard format:
   { cfId, description, trigger, conflictsWith, severity, resolution }
5. Validate: no new rules duplicate existing CF-1–CF-457
6. Register new BFA rules via DATABASE FABRIC → bfa-registry index
7. Register new event schemas via F992 IEventSchemaRegistryService
8. Register new API contracts via F993 IApiContractRegistryService
9. Emit BfaPackRegistered event via QUEUE FABRIC
```

**MACHINE (fixed):** All new events/APIs/entities must be registered before GitOps phase, CFx rules must follow standard format.
**FREEDOM (configurable):** AI model for conflict analysis, conflict sensitivity threshold.

**Positive Example:**
```
New event: VideoGenerationCompleted { videoId, tenantId, videoUrl, duration }
BFA analysis: no conflict with existing CF rules
New CF rule:
CF-491: "VideoGenerationCompleted must carry tenantId; cross-tenant video access = CRITICAL"
Registered → BfaPackRegistered event emitted
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Skip BFA registration and go directly to GitOps
await OpenPr(codeBundle);  // without BFA registration
// WRONG: Register event schema without conflict check
await RegisterEvent(VideoGenerationCompleted);  // before checking existing CF rules
// WRONG: Duplicate CF rule (same conflict already in CF-1–CF-457)
CF-492: "tenantId required on queries" // already covered by DNA-5 / CF-12
```

---

### SK-236 — Sandbox Teardown (Finally Pattern)

**ID:** SK-236
**Name:** SandboxTeardownFinally
**Archetype:** GUARDRAIL
**Flow:** FLOW-26
**Fabric:** CORE FABRIC (container orchestration via FLOW-19 F59 pattern) + QUEUE FABRIC (teardown events) + DATABASE FABRIC (sandbox registry)
**Factories Used:** F1001 IEphemeralDeployService, F1000 ISandboxOrchestratorService

**When AF-4 returns this:** Need to guarantee sandbox environment cleanup regardless of phase outcome (pass, fail, or exception), preventing resource leaks in multi-tenant environments.

**Pattern:**

```
try {
  1. Deploy sandbox (SK per SK-231 SelfBuildRun, state = SANDBOX_DEPLOYED)
  2. Run health checks
  3. Execute E2E tests
  4. Collect results
} catch (any error) {
  5. Store failure report
  6. Emit SandboxTestFailed event
} finally {
  7. ALWAYS: Teardown sandbox via IEphemeralDeployService (container stop + resource release)
  8. ALWAYS: Remove sandbox record from DATABASE FABRIC sandbox-registry-{tenantId}
  9. ALWAYS: Emit SandboxTornDown event via QUEUE FABRIC
  10. ALWAYS: Release tenant quota reservation for sandbox resources
}
```

**MACHINE (fixed):** Teardown ALWAYS runs (finally), quota release ALWAYS runs, sandbox record ALWAYS removed.
**FREEDOM (configurable):** Teardown timeout, resource quotas per tier.

**Positive Example:**
```
try {
  sandbox = await Deploy(codeBundle);
  e2eResult = await RunE2E(sandbox);
} catch (E2EException ex) {
  await StoreFailureReport(ex);
} finally {
  await _sandboxService.TeardownAsync(sandbox.envId, tenantId);
  await _quotaService.ReleaseAsync(tenantId, "sandbox");
  await EnqueueAsync("SandboxTornDown", { envId: sandbox.envId });
}
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Only teardown on success
if (e2eResult.Passed) await Teardown(sandbox);  // leaks resources on failure
// WRONG: No quota release
await TeardownContainer(sandbox);  // without releasing tenant quota
// WRONG: Direct container call
DockerClient.StopContainer(containerId);  // must go through IEphemeralDeployService
```

---

### SK-237 — Multi-Tenant SelfBuild Isolation Pattern

**ID:** SK-237
**Name:** MultiTenantSelfBuildIsolation
**Archetype:** GUARDRAIL
**Flow:** FLOW-26
**Fabric:** CORE FABRIC (MicroserviceBase scope isolation) + DATABASE FABRIC (per-tenant indices) + QUEUE FABRIC (per-tenant consumer groups)
**Factories Used:** F982-F1009 (all must enforce tenantId), F967 ITenantIsolationEnforcerService (from FLOW-23)

**When AF-4 returns this:** Need to enforce that SelfBuildRun artifacts, generated code, capability registrations, sandbox environments, and BFA rules are strictly isolated by tenantId — a tenant's self-build cannot affect another tenant's capabilities.

**Isolation Boundaries:**
```
Capability Registry:    ES index: capability-registry-{tenantId}
Self-Build Runs:        ES index: self-build-runs-{tenantId}
Evidence Bundles:       ES index: evidence-bundles-{tenantId}
Failure Signatures:     ES index: failure-signatures-{tenantId}
Sandbox Environments:   Namespace: sandbox-{tenantId}-{runId}
Promotion Ledger:       ES index: promotion-ledger-{tenantId}
BFA Registrations:      Global BFA (shared) + tenant-specific override index
Queue Consumer Groups:  Group: self-build-{tenantId}
Git Branches:           Branch: self-build/{tenantId}/{runId}
```

**Pattern:**

```
1. Every SelfBuildRun MUST carry tenantId (extracted from Auth context via MicroserviceBase)
2. ALL DB operations: tenantId in BuildSearchFilter — never omit
3. Sandbox deploy: create in namespace sandbox-{tenantId}-{runId}
4. Queue operations: consumer group self-build-{tenantId}
5. Git branch: self-build/{tenantId}/{runId}
6. Capability promotion: tenant-promoted capabilities go to tenant-specific registry
   (Global/CORE capabilities require separate cross-tenant promotion flow)
7. BFA rules: shared global rules (CF-1+) + tenant override rules (separate index)
```

**MACHINE (fixed):** tenantId isolation is non-negotiable at every boundary, cross-tenant capability sharing requires explicit opt-in.
**FREEDOM (configurable):** Tenant tiering (quota limits per tier, from FLOW-23 DD-210).

**Positive Example:**
```
Tenant A runs self-build → capability IVideoGenerationService registered in:
  capability-registry-tenant-A
  self-build-runs-tenant-A
  promotion-ledger-tenant-A (stage: INJECTED)

Tenant B: gap detection for IVideoGenerationService → MISSING_FACTORY
(Tenant B cannot see Tenant A's capability until cross-tenant sharing explicitly enabled)
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Global capability registry without tenantId
var capabilities = await db.SearchAsync("capability-registry", filter: {});
// WRONG: Shared sandbox namespace
sandboxNamespace = "global-sandbox";  // cross-tenant contamination
// WRONG: Tenant A code deployed to Tenant B's registry
await RegisterFactory(tenantId: "tenant-B", source: "tenant-A");  // forbidden
```

---

### SK-238 — Recursive Sub-Flow Generation Pattern

**ID:** SK-238
**Name:** RecursiveSubFlowGenerator
**Archetype:** SYNTHESIS
**Flow:** FLOW-26
**Fabric:** FLOW ENGINE FABRIC (sub-flow definition + orchestration) + AI ENGINE FABRIC (sub-flow planning) + DATABASE FABRIC (sub-flow registry)
**Factories Used:** F984 IFlowPlannerService, F989 IContractGeneratorService, F991 ITaskTypeContractService

**When AF-4 returns this:** A detected gap requires not just a single factory/service, but an entire sub-flow (multiple steps, events, state transitions) to implement the capability correctly.

**Pattern:**

```
Trigger: ContractGenerator (SK-224) determines gap requires sub-flow (not just single factory)
Indicators: gap has > 3 sequential steps, gap includes polling/retry/webhook patterns

1. Sub-flow planning via AI ENGINE FABRIC:
   - Decompose gap into DAG steps
   - Identify each step's factory dependency + fabric resolution
   - Generate child flow template JSON (same format as parent flows)
2. Register child flow template via FLOW ENGINE FABRIC (DATABASE FABRIC → flow-templates index)
3. For each new factory in child flow: run SK-224 (contract-first) + SK-225 (genesis)
4. Child flow template added to childTemplates[] in parent SelfBuildRun
5. BFA check: child flow events/APIs registered via SK-235 (meta-flow BFA pack)
6. Child flow reference added to parent flow template as a nested step

Depth limit: FREEDOM-configurable (default max depth = 3)
Circular dependency check: mandatory (detect A → B → A patterns)
```

**MACHINE (fixed):** Depth limit enforced, circular dependency check mandatory, child flow must follow same engine contract format as parent.
**FREEDOM (configurable):** Max recursion depth, sub-flow naming convention.

**Positive Example:**
```
Gap: IVideoGenerationService needs polling (generation takes 30-120s)
Sub-flow: video-generation-poll-v1
  Step 1: SubmitVideoJob (IVideoGenerationService.SubmitAsync → AI_ENGINE)
  Step 2: PollJobStatus (IVideoGenerationService.PollAsync → AI_ENGINE) [loop]
  Step 3: StoreResult (IDatabaseService → DATABASE_FABRIC → S3/Blob)
  Step 4: EmitVideoReady (IQueueService → QUEUE_FABRIC)
Child flow registered → parent flow references sub-flow at step "GenerateVideo"
```

**Negative Example (FORBIDDEN):**
```
// WRONG: Inline the sub-flow in the parent (no reuse possible)
// Parent step 3 has 12 nested steps inlined instead of referencing child template
// WRONG: No depth limit
while (hasMoreSubFlows) { generateSubFlow(); }  // unbounded recursion
// WRONG: Skip BFA registration for child flow events
// VideoReady event not registered → potential conflict with existing FLOW-11 Media events
```

---

## AF-4 SKILL CROSS-REFERENCE (FLOW-26)

| AF Station | Skills Used | Purpose |
|---|---|---|
| AF-1 Genesis | SK-224, SK-225, SK-238 | Contract + code + sub-flow generation |
| AF-2 Planning | SK-223, SK-232, SK-238 | Gap + reuse + recursion planning |
| AF-3 Prompt Library | SK-224, SK-226 | Contract prompts + test harness prompts |
| AF-4 RAG | SK-232 | Reuse decision matrix |
| AF-5 Multi-model | SK-225 | Bounded genesis loop |
| AF-6 Code Review | SK-225, SK-233 | Review + failure signature |
| AF-7 Compliance | SK-225, SK-226 | DNA check + deterministic harness |
| AF-8 Security | SK-228, SK-237 | GitOps + tenant isolation |
| AF-9 Judge | SK-227, SK-229, SK-233 | Evidence bundle + promotion + failure |
| AF-10 Merge | SK-225, SK-232 | Merge genesis outputs per reuse decision |
| AF-11 Feedback | SK-231, SK-233 | SelfBuildRun history + failure learning |

---

## DNA COMPLIANCE MATRIX (FLOW-26 SKILLS)

| Skill | DNA-1 | DNA-2 | DNA-3 | DNA-4 | DNA-5 | DNA-6 | DNA-7 | DNA-8 | DNA-9 |
|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|
| SK-223 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — |
| SK-224 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — |
| SK-225 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | — |
| SK-226 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | — | — |
| SK-227 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | ✅ | ✅ |
| SK-228 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | ✅ | — |
| SK-229 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | ✅ | ✅ |
| SK-230 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | — | — |
| SK-231 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| SK-232 | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — | — |
| SK-233 | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | — | — |
| SK-234 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | — | — |
| SK-235 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | ✅ | — |
| SK-236 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | — | — |
| SK-237 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ |
| SK-238 | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | ✅ | — |

DNA-1: ParseDocument | DNA-2: BuildSearchFilter | DNA-3: DataProcessResult<T> | DNA-4: MicroserviceBase
DNA-5: Scope Isolation | DNA-6: DynamicController | DNA-7: Idempotency | DNA-8: Outbox | DNA-9: Audit

---

## SAVE POINT: SK238_DEFINED ✅
## FLOW-26 SKILLS FACTORY & RAG INDEX COMPLETE
