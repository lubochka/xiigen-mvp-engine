# SESSION-R0-PRECHECK.md
## Round: R0 | Action: PRE-AUTHORING CHECKS (PC-1 to PC-5)
## Source: FLOW-PLAN-PREPARATION-MERGED.md v5.0 — PRE-AUTHORING CHECKLIST
## Self-contained: zero cross-references, all commands literal
## Must complete before R1. ALL 5 checks must be GREEN. RED = STOP + fix.

---

## CONTEXT
```bash
export FLOW_ID="FLOW-XX"   # ← replace with actual flow ID before running
export BASE_DIR="."        # ← project root (where server/ and contracts/ live)
```

---

## STEP 1 — PC-1: Infrastructure fixture files exist

```bash
GRAPH_FIX=$(ls "$BASE_DIR"/server/src/rag-init/fixtures/*decision-graph* 2>/dev/null | wc -l)
PLAN_FIX=$(ls  "$BASE_DIR"/server/src/rag-init/fixtures/*planning-decisions* 2>/dev/null | wc -l)

[ "$GRAPH_FIX" -gt 0 ] \
  && echo "✅ PC-1a: xiigen-decision-graph fixture exists" \
  || echo "❌ PC-1a FAIL: xiigen-decision-graph fixture MISSING — raise H-class blocking gap, STOP"

[ "$PLAN_FIX" -gt 0 ] \
  && echo "✅ PC-1b: xiigen-planning-decisions fixture exists" \
  || echo "❌ PC-1b FAIL: xiigen-planning-decisions fixture MISSING — raise H-class blocking gap, STOP"
```

**GATE:** Both must print ✅. RED = do not proceed. Create fixture files first.

---

## STEP 2 — PC-2: DpoTriple schema — top-level chosen/rejected (no .code subfields)

```bash
# Confirm DpoTriple uses top-level chosen/rejected strings, NOT chosen.code / rejected.code
K1_VIOLATIONS=$(grep -rn "chosen\.code\|rejected\.code" "$BASE_DIR"/server/src/ --include="*.ts" 2>/dev/null | wc -l)
SESSION_K1=$(grep -rn "chosen\.code\|rejected\.code" "$BASE_DIR"/.claude/skills/ 2>/dev/null | wc -l)

echo "K1 violations in server/src: $K1_VIOLATIONS"
echo "K1 violations in session files: $SESSION_K1"

[ "$K1_VIOLATIONS" = "0" ] && [ "$SESSION_K1" = "0" ] \
  && echo "✅ PC-2: No .code subfield references" \
  || echo "❌ PC-2 FAIL: Found .code subfield references — raise K1 gap before authoring session files"
```

**GATE:** Both counts must be 0. RED = find and fix .code references.

---

## STEP 3 — PC-3: CloudEvent name cross-check (manual verification required)

```bash
echo "PC-3: Manual verification required"
echo ""
echo "For EACH task type in $FLOW_ID:"
echo "  1. Find the contract file:"
find "$BASE_DIR"/server/src/engine-contracts/ -name "*.ts" | xargs grep -l "events" 2>/dev/null | head -5
echo ""
echo "  2. Extract exact CloudEvent type strings:"
grep -rn "type:" "$BASE_DIR"/server/src/engine-contracts/ --include="*.ts" | grep -i "event\|sent\|created\|completed" | head -20
echo ""
echo "  3. Compare against any existing session file event name references"
echo "  4. Mark K2 gap if ANY synonym used (e.g. 'Completed' vs 'Sent')"
echo ""
echo "Record result: PC-3 GREEN (exact match) or RED (mismatch found — raise K2 gap)"
```

**GATE:** Manual confirmation required. Do not proceed if K2 mismatch found.

---

## STEP 4 — PC-4: Archetype registration completeness (4 points per new archetype)

```bash
# Replace with this flow's new archetypes (comma-separated, no spaces)
export NEW_ARCHETYPES="ROUTING ORCHESTRATION"   # ← update for actual flow

for ARCHETYPE in $NEW_ARCHETYPES; do
  echo "--- Checking: $ARCHETYPE ---"

  ENUM=$(grep -c "\"$ARCHETYPE\"" "$BASE_DIR"/server/src/engine-contracts/contract-archetype.enum.ts 2>/dev/null || echo 0)
  BOOT=$(grep -c "\"$ARCHETYPE\"" "$BASE_DIR"/server/src/engine-contracts/engine-contracts.bootstrap.ts 2>/dev/null || echo 0)
  TIER=$(grep -c "\"$ARCHETYPE\"" "$BASE_DIR"/server/src/fabrics/graph/planning/feedback.handler.ts 2>/dev/null || echo 0)
  WIRE=$(grep -rc "$ARCHETYPE" "$BASE_DIR"/server/src/fabrics/graph/planning/topology/ 2>/dev/null | awk -F: '{sum+=$2} END{print sum+0}')

  [ "$ENUM" -gt 0 ] && echo "  ✅ 4a: ContractArchetype enum" || echo "  ❌ 4a FAIL: $ARCHETYPE missing from ContractArchetype enum — raise L1 gap"
  [ "$BOOT" -gt 0 ] && echo "  ✅ 4b: ENGINE_CONTRACTS bootstrap" || echo "  ❌ 4b FAIL: $ARCHETYPE not in bootstrap array — raise L2 gap"
  [ "$TIER" -gt 0 ] && echo "  ✅ 4c: resolveCurriculumTier tierMap" || echo "  ❌ 4c FAIL: $ARCHETYPE not in tierMap — raise L3 gap (V9-003 will fail)"
  [ "$WIRE" -gt 0 ] && echo "  ✅ 4d: Topology wiring" || echo "  ❌ 4d FAIL: $ARCHETYPE not wired in topology/ — raise L4 gap"
done
```

**GATE:** All 4 points GREEN for every new archetype. RED = fix before R1.

---

## STEP 5 — PC-5: Named check registry alignment

```bash
EXPORTED=$(grep -roh "NAMED_CHECK_[A-Z_]*" "$BASE_DIR"/server/src/engine-contracts/ --include="*.ts" 2>/dev/null | sort -u)
EXPORT_COUNT=$(echo "$EXPORTED" | grep -c . || echo 0)

REGISTERED=$(grep -oh "NAMED_CHECK_[A-Z_]*" "$BASE_DIR"/server/src/fabrics/graph/planning/validate.handler.ts 2>/dev/null | sort -u)
REG_COUNT=$(echo "$REGISTERED" | grep -c . || echo 0)

echo "Exported: $EXPORT_COUNT | Registered: $REG_COUNT"

MISSING=$(comm -23 <(echo "$EXPORTED" | sort) <(echo "$REGISTERED" | sort) 2>/dev/null || true)

[ -z "$MISSING" ] \
  && echo "✅ PC-5: All named checks registered" \
  || { echo "❌ PC-5 FAIL — unregistered checks (raise E7 gap for each):"; echo "$MISSING"; }
```

**GATE:** MISSING must be empty. RED = add missing checks to validate.handler.ts before R1.

---

## SUMMARY GATE

```bash
echo ""
echo "=== PC SUMMARY for $FLOW_ID ==="
echo "PC-1a: [GREEN/RED]"
echo "PC-1b: [GREEN/RED]"
echo "PC-2:  [GREEN/RED]"
echo "PC-3:  [GREEN/RED] (manual)"
echo "PC-4:  [GREEN/RED] (per archetype)"
echo "PC-5:  [GREEN/RED]"
echo ""
echo "ALL GREEN → proceed to R1"
echo "ANY RED   → fix and rerun R0 before R1"
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (none found) | — | — |

⛔ STOP — ALL PC-1..PC-5 must be GREEN before proceeding to SESSION-R1.
