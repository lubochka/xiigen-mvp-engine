# FLOW-PREP-MASTER-PLAN — 18+1 Rounds
## Source: FLOW-PLAN-PREPARATION-MERGED.md v5.0 (2026-03-27)
## Session type: PLANNING → GENERATION (one session file per round)
## Cadence: one round at a time — ⛔ STOP after each session file is presented
## Each session file: ONE action item, literal bash commands only, self-contained

---

## MULTI-STACK USAGE POLICY
> **Primary stack: NestJS + React only.**
> All code generation, session files, and engine development targets NestJS (server)
> and React (client) exclusively.
>
> Any simulation round that references an alternative stack (e.g. Laravel, WordPress,
> a legacy language, or a different framework) has **one purpose only:**
> **discovering missing engine capabilities** — interfaces, abstractions, or assumptions
> baked into the engine that would break or degrade when the engine encounters that stack.
>
> The output of those rounds is always an **engine gap** (a missing interface, a hardcoded
> assumption, a check that only works for NestJS). It is never code written in that stack,
> never a session file targeting that stack, and never a gap fix in that stack.
>
> If a simulation round finds a gap via a non-NestJS trace → the fix goes into the
> NestJS engine (e.g. make the check stack-neutral, add an abstraction layer).


## FIXED PROMPT REMINDER (must appear at start of EVERY round response)
**Q1:** PLANNING → GENERATION session type
**Cadence:** One session file per response. ⛔ STOP after present_files. Await "yes".
**Output contract per round:** One SESSION-RN.md file, zipped, presented.
**This prompt is the top priority and must be honored in every round.**

---

## ROUND TABLE

| Round | Session file | Phase | One action item | Source |
|-------|-------------|-------|----------------|--------|
| R0 | SESSION-R0-PRECHECK.md | Pre-A | Run PC-1..PC-5 pre-authoring checks | PRE-AUTHORING CHECKLIST |
| R1 | SESSION-R1-STATE-INIT.md | A | Initialize STATE.json (taskTypeArchetypes + 3 arrays) | MANDATORY STATE.json INIT |
| R2 | SESSION-R2-GRAPH-SEED.md | A | Produce + execute GRAPH_SEEDING_PLAN curl commands | Addition 1 |
| R3 | SESSION-R3-NODE-GRADE.md | A | Record NODE completeness grade → STATE.json | Addition 2 |
| R4 | SESSION-R4-INFRA-GATE.md | Gate | 4 graph health checks + Check 3G DpoTriple round-trip | Addition 3 |
| R5 | SESSION-R5-CLOUDEVENT.md | A | CloudEvent name verification record (K2 prevention) | Addition 16 |
| R6 | SESSION-R6-NAMED-CHECK-REG.md | A | Named check registry — 0 unregistered NAMED_CHECK_* | Addition 17 |
| R7 | SESSION-R7-ARCHETYPE-REG.md | A | Archetype registration completeness (4-point: L1-L4) | Addition 18 |
| R8 | SESSION-R8-ROUTING-DECISION.md | B | ROUTING_DECISION record per cycle appended to STATE.json | Addition 4 |
| R9 | SESSION-R9-NAMED-CHECK-FIRE.md | B | Named check firing → REQUIRES_CHECK edge +0.08 update | Addition 5 |
| R10 | SESSION-R10-GENESIS-SCORE.md | B | Genesis version + score record per cycle → STATE.json | Addition 6 |
| R11 | SESSION-R11-CALIBRATION.md | C | CALIBRATION_COMPARISON REINFORCEMENT triple per task type | Addition 7 |
| R12 | SESSION-R12-EDGE-UPDATE.md | F | Edge confidence update from routing outcomes (3-way) | Addition 8 |
| R13 | SESSION-R13-ARBITER-PROMOTE.md | F | Two-level arbiter promotion (FREEDOM config thresholds) | Addition 9 |
| R14 | SESSION-R14-GENESIS-PATCH.md | F | GENESIS_PATCH_EFFECTIVENESS REINFORCEMENT triple | Addition 10 |
| R15 | SESSION-R15-NODE-CORR.md | F | NODE_COMPLETENESS_CORRELATION graph edge (idempotent PUT) | Addition 11 |
| R16 | SESSION-R16-CROSS-FLOW-DEP.md | F | DOWNSTREAM_DEPENDENCY edge per cross-flow dependency | Addition 12 |
| R17 | SESSION-R17-HANDOFF.md | F | planningLayerLearning section in LEARNING_HANDOFF.json | Addition 13 |
| R18 | SESSION-R18-VALIDATE.md | F | OUTCOME_PENDING → VALIDATED (with F3-L2-7 empty-index guard) | Addition 14 |
| R19 | SESSION-R19-WAVE2-GATE.md | Wave | Planning layer gate before Wave 2 (4 checks, soft gate) | Addition 15 |

**Total: 19 session files (R0 = pre-check gate, R1 = state init, R2–R19 = additions 1–18 in execution order)**

---

## ARTIFACT NUMBERS (from STATE.json 2026-03-27)
```
Next Factory:    F1518   Next Task Type: T587
Next BFA Rule:   CF-797  Next Skill:     SK-520
Test baseline:   5800    (5580 server + 220 client)
```

---

## SELF-CONTAINMENT RULE (applied to every session file)
Each SESSION-RN.md must pass these before delivery:
- Zero cross-references ("see Addition N", "per SK-442", "per the plan")
- Zero undefined ${VAR} — every variable exported in the same file
- Zero English gate descriptions — all gates are literal bash commands
- failures === 0 for any test gate (P19 absolute, not delta)
- ISSUE INVENTORY block before every ⛔ STOP

---

## OUTPUT CONTRACT PER ROUND
```
Done = SESSION-RN.md exists, passes self-containment, is zipped, is presented.
The plan document does not change after R0.
```
