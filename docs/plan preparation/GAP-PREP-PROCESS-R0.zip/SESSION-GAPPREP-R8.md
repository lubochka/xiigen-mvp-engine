# SESSION-GAPPREP-R8.md
## Round: R8 | Phase: GAP DOCUMENT AUTHORING (PLANNING)
## Action: Write FLOW-XX-ENGINE-GAP-LIST.md from all intermediate artifacts
## Output: ✅ FLOW-XX-ENGINE-GAP-LIST.md — the deliverable
## Self-contained

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export ROOT_MAP="$SESSIONS_DIR/${FLOW_ID}-ROOT-CAUSE-MAP.json"
export DEDUP="$SESSIONS_DIR/${FLOW_ID}-GAPS-DEDUP.json"
export INTAKE="$SESSIONS_DIR/${FLOW_ID}-INTAKE.json"
export OUT="$SESSIONS_DIR/${FLOW_ID}-ENGINE-GAP-LIST.md"
```

---

## STEP 1 — Assemble gap document sections

Write the document in this order (each section from deduplicated canonical gaps):

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
gaps = json.load(open(os.environ.get('DEDUP', f'sessions/{flow_id}/{flow_id}-GAPS-DEDUP.json')))['canonical_gaps']
date_str = __import__('datetime').date.today().isoformat()

# Group by layer
from collections import defaultdict
layers = defaultdict(list)
priority_map = {"SILENT_FAILURE":"1", "BREAKS":"2", "PARTIAL":"3", "ADVISORY":"4"}
icon_map = {"SILENT_FAILURE":"🔴","BREAKS":"🟠","PARTIAL":"🟡","ADVISORY":"⬜"}
for g in gaps:
    layers[g.get('layer','7')].append(g)

layer_titles = {
    "1":"ENGINE CODE CHANGES",
    "2":"DATA AND TOPOLOGY CHANGES",
    "3":"SESSION FILE ADDITIONS",
    "4":"NAMED CHECK CATALOG",
    "5":"GRAPH SEEDING",
    "6":"NEW FILES REQUIRED",
    "7":"GOVERNANCE"
}

out_path = os.environ.get('OUT', f'sessions/{flow_id}/{flow_id}-ENGINE-GAP-LIST.md')
with open(out_path, 'w') as f:
    # Header
    f.write(f"# {flow_id} ENGINE GAP LIST\n")
    f.write(f"## What must be added to execute {flow_id} correctly\n")
    f.write(f"## Date: {date_str}\n\n---\n\n")
    f.write("## PRIORITY LEGEND\n```\n🔴 SILENT_FAILURE\n🟠 BREAKS\n🟡 PARTIAL\n⬜ ADVISORY\n```\n\n---\n\n")

    # Layers
    for layer_num in sorted(layers.keys()):
        title = layer_titles.get(str(layer_num), f"LAYER {layer_num}")
        f.write(f"## LAYER {layer_num} — {title}\n\n---\n\n")
        for g in sorted(layers[layer_num], key=lambda x: priority_map.get(x.get('severity','4'),'4')):
            icon = icon_map.get(g.get('severity','⬜'),'⬜')
            gid = g.get('gap_id','GAP-?-?')
            name = g.get('name','[name]')
            file_path = g.get('file','[file path]')
            problem = g.get('problem','[problem description]')
            impact = g.get('impact','[impact description]')
            fix = g.get('fix','[fix description]')
            scope = g.get('scope','[fix class] ~N lines')
            f.write(f"### {gid} {icon} `{file_path}` — {name}\n\n")
            f.write(f"**Problem:** {problem}\n\n")
            f.write(f"**Impact:** {impact}\n\n")
            f.write(f"**Fix:**\n```\n{fix}\n```\n\n")
            f.write(f"**Scope:** {scope}\n\n---\n\n")

    # Execution order summary
    f.write("## EXECUTION ORDER SUMMARY\n\n```\n")
    f.write("PRIORITY 1 — SILENT_FAILUREs:\n")
    for g in gaps:
        if g.get('severity') == 'SILENT_FAILURE':
            f.write(f"  {g['gap_id']}  {g.get('name','')}\n")
    f.write("\nPRIORITY 2 — BREAKS:\n")
    for g in gaps:
        if g.get('severity') == 'BREAKS':
            f.write(f"  {g['gap_id']}  {g.get('name','')}\n")
    f.write("\nPRIORITY 3 — PARTIAL:\n")
    for g in gaps:
        if g.get('severity') == 'PARTIAL':
            f.write(f"  {g['gap_id']}  {g.get('name','')}\n")
    f.write("\nPRIORITY 4 — ADVISORY (deferred):\n")
    for g in gaps:
        if g.get('severity') == 'ADVISORY':
            f.write(f"  {g['gap_id']}  {g.get('name','')}\n")
    f.write("```\n\n---\n\n")

    # Summary table
    f.write("## SUMMARY TABLE\n\n")
    f.write("| ID | Layer | Description | Severity | Scope | Before |\n")
    f.write("|----|-------|-------------|----------|-------|--------|\n")
    for g in sorted(gaps, key=lambda x: (x.get('layer','7'), x.get('gap_id',''))):
        f.write(f"| {g.get('gap_id','')} | {layer_titles.get(str(g.get('layer','?')),'?')} | "
                f"{g.get('name','')} | {icon_map.get(g.get('severity',''),'?')} | "
                f"{g.get('scope','')} | {g.get('before','')} |\n")
    f.write("\n---\n\n")

    # What works today
    f.write("## WHAT WORKS TODAY\n\n```\n[Fill from simulation traces: ✅ items confirmed WORKS]\n```\n")

print(f"Written: {out_path}")
JSEOF
```

---

## STEP 2 — Self-containment verification of the produced document

```bash
echo "=== Gap document verification ==="
# Every section present
for section in "PRIORITY LEGEND" "LAYER 1" "EXECUTION ORDER" "SUMMARY TABLE" "WHAT WORKS"; do
  grep -q "$section" "$OUT" && echo "✅ $section present" || echo "❌ $section MISSING"
done

# Summary table row count matches body gap count
BODY_COUNT=$(grep -c "^### GAP-" "$OUT" 2>/dev/null || echo 0)
TABLE_COUNT=$(grep -c "^| GAP-" "$OUT" 2>/dev/null || echo 0)
[ "$BODY_COUNT" = "$TABLE_COUNT" ] \
  && echo "✅ Body ($BODY_COUNT) and table ($TABLE_COUNT) counts match" \
  || echo "❌ Count mismatch: body=$BODY_COUNT table=$TABLE_COUNT — fix before delivery"
```

---

## STEP 3 — Copy to project sessions directory

```bash
cp "$OUT" "$BASE_DIR/sessions/${FLOW_ID}/${FLOW_ID}-ENGINE-GAP-LIST.md"
echo "Delivered: $BASE_DIR/sessions/${FLOW_ID}/${FLOW_ID}-ENGINE-GAP-LIST.md"
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from verification) | — | — |

⛔ STOP — FLOW-XX-ENGINE-GAP-LIST.md written, all 5 sections present, body/table counts match.
This is the deliverable — feed directly into GAP04-MASTER-PLAN.md template for execution.
