# SESSION-GAPPREP-R3.md
## Round: R3 | Phase: SESSION FILE AUDIT
## Action: FC-8/FC-28/FC-29 scan all session files — cross-refs, V9-003, ISSUE INVENTORY, field paths
## Output: FLOW-XX-GAPS-SES-RAW.json
## Self-contained

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export RAW_OUT="$SESSIONS_DIR/${FLOW_ID}-GAPS-SES-RAW.json"
SESSION_FILES=$(find "$SESSIONS_DIR" -name "SESSION-*.md" | sort)
echo "Auditing: $SESSION_FILES"
```

---

## STEP 1 — FC-8/FC-28: self-containment checks (7 checks per file)

```bash
for f in $SESSION_FILES; do
  echo "=== $f ==="

  # Check 1: cross-references
  XREF=$(grep -cn "see \|follow \|per the \|per P[0-9]\|per SK-\|see skill" "$f" 2>/dev/null || echo 0)
  [ "$XREF" = "0" ] && echo "  ✅ C1 no cross-refs" || echo "  ❌ C1 FAIL: $XREF cross-refs — SES gap"

  # Check 2: undefined variables
  USED=$(grep -oP '\$\{[^}]+\}' "$f" | sort -u)
  DEFINED=$(grep -oP '(?<=export )[A-Z_]+(?==)' "$f" | sort -u)
  UNDEF=$(comm -23 <(echo "$USED" | tr -d '${}'  | sort) <(echo "$DEFINED" | sort) 2>/dev/null | wc -l)
  [ "$UNDEF" = "0" ] && echo "  ✅ C2 no undefined vars" || echo "  ❌ C2 FAIL: $UNDEF undefined vars — SES gap"

  # Check 3: principle references
  PREF=$(grep -cn "apply P[0-9]\|per P[0-9]\|see M[0-9]" "$f" 2>/dev/null || echo 0)
  [ "$PREF" = "0" ] && echo "  ✅ C3 no principle refs" || echo "  ❌ C3 FAIL: $PREF principle refs"

  # Check 4: unfilled placeholders
  PLACEHOLDERS=$(grep -cn "<[A-Z_][A-Z_]*>" "$f" 2>/dev/null | grep -v "Content-Type\|<!--" || echo 0)
  [ "$PLACEHOLDERS" = "0" ] && echo "  ✅ C4 no placeholders" || echo "  ❌ C4: placeholders found"

  # Check 5: English gate descriptions
  ENG=$(grep -cn "verify that \|check whether \|ensure the \|confirm that " "$f" 2>/dev/null || echo 0)
  [ "$ENG" = "0" ] && echo "  ✅ C5 literal gates" || echo "  ❌ C5: $ENG English gates"

  # Check 6: skill references
  SKILLREF=$(grep -cn "see.*SKILL\.md\|load.*SKILL\|per.*SKILL" "$f" 2>/dev/null || echo 0)
  [ "$SKILLREF" = "0" ] && echo "  ✅ C6 no mid-session skill refs" || echo "  ❌ C6: $SKILLREF skill refs"

  # Check 7: partial API bodies
  PARTIAL=$(grep -cn "<insert\|<fill\|<contract here\|<full " "$f" 2>/dev/null || echo 0)
  [ "$PARTIAL" = "0" ] && echo "  ✅ C7 no partial API bodies" || echo "  ❌ C7: $PARTIAL partials"
done
```

---

## STEP 2 — FC-29: ISSUE INVENTORY before every ⛔ STOP

```bash
for f in $SESSION_FILES; do
  STOPS=$(grep -c "⛔ STOP" "$f" 2>/dev/null || echo 0)
  INV=$(grep -c "ISSUE INVENTORY" "$f" 2>/dev/null || echo 0)
  [ "$STOPS" = "0" ] && echo "$f: no ⛔ STOP (ok)" && continue
  [ "$INV" -ge "$STOPS" ] \
    && echo "✅ $f: $STOPS ⛔ STOPs, $INV ISSUE INVENTORYs" \
    || echo "❌ $f: $STOPS ⛔ STOPs, $INV ISSUE INVENTORYs — FC-29 FAIL (SES gap)"
done
```

---

## STEP 3 — V9-003: curriculumTier verification in SESSION-E (must not be removed)

```bash
SESSION_E=$(find "$SESSIONS_DIR" -name "SESSION-E*" | head -1)
[ -n "$SESSION_E" ] && {
  CT=$(grep -c "curriculumTier" "$SESSION_E" 2>/dev/null || echo 0)
  V9=$(grep -c "V9-003\|V9_003" "$SESSION_E" 2>/dev/null || echo 0)
  echo "SESSION-E curriculumTier refs: $CT | V9-003 refs: $V9"
  [ "$CT" -ge 1 ] && echo "✅ curriculumTier verification present" \
    || echo "❌ SES gap: curriculumTier check MISSING from SESSION-E (SILENT_FAILURE)"
} || echo "SESSION-E not found — cannot verify V9-003"
```

---

## STEP 4 — Field path check: d.get('score',0) pattern + violations vs checkResults

```bash
for f in $SESSION_FILES; do
  SCORE_ZERO=$(grep -cn "d\.get.*score.*0\b\|\.get.*'score'.*0\b" "$f" 2>/dev/null || echo 0)
  VIOLATIONS=$(grep -cn "get.*violations\|violations.*get" "$f" 2>/dev/null || echo 0)
  [ "$SCORE_ZERO" -gt 0 ] && echo "❌ $f: score fallback d.get('score',0) — SES gap (ENG-1 dependency)"
  [ "$VIOLATIONS" -gt 0 ] && echo "❌ $f: 'violations' field path — should be stages[validate].output.checkResults"
done
```

---

## Write raw SES gap list

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('RAW_OUT', f'sessions/{flow_id}/{flow_id}-GAPS-SES-RAW.json')
template = {
    "flowId": flow_id, "phase": "session-file-audit",
    "files_audited": [],
    "raw_gaps": []  # {file, check_id, description, severity, fix_type}
}
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(template, f, indent=2)
print(f"Template written: {out}")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from step outputs) | — | — |

⛔ STOP — FLOW-XX-GAPS-SES-RAW.json written.
