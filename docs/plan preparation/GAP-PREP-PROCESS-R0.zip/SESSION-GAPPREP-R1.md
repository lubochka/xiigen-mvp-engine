# SESSION-GAPPREP-R1.md
## Round: R1 | Phase: PLANNING LAYER SIMULATION (E-group)
## Action: Run E1–E9 checks — ES mapping, cycle router, interface completeness,
##         DPO schema, retrospective persistence, teach reachability,
##         named check registry, schema alignment, infra index existence
## Output: Raw J/K/H-class gap list → saved to FLOW-XX-GAPS-E-RAW.json
## Rule: if E1 or E3 BREAKS → flag all R2 traces as "planning layer unreliable"
## Self-contained: all commands literal, all templates inline

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export BASE_DIR="."
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export INTAKE="$SESSIONS_DIR/${FLOW_ID}-INTAKE.json"
export RAW_OUT="$SESSIONS_DIR/${FLOW_ID}-GAPS-E-RAW.json"
```

---

## STEP TABLE FORMAT (inline — record one row per check)
```
| Check | What tested | Handler | Input ✅/⚠️/❌ | Verdict | Gap class | Gap ID |
```
Verdict: WORKS | PARTIAL | BREAKS | WRONG | SILENT_FAILURE

---

## E1 — Graph edge round-trip (ES keyword mapping)

```bash
echo "=== E1: ES term-query round-trip ==="
TEST_ID="E1-GATE-$(date +%s)"

# Seed test doc
curl -sf -X PUT "localhost:9200/xiigen-decision-graph/_doc/${TEST_ID}" \
  -H "Content-Type: application/json" \
  -d '{"fromEntity":"E1:GATE:CHECK","relationship":"TEST","toEntity":"PASS",
       "confidence":1.0,"immutable":false}' > /dev/null

sleep 0.5

FOUND=$(curl -sf "localhost:9200/xiigen-decision-graph/_search" \
  -H "Content-Type: application/json" \
  -d '{"query":{"term":{"fromEntity":"E1:GATE:CHECK"}}}' \
  | jq '.hits.total.value // 0')

[ "$FOUND" -ge 1 ] \
  && echo "E1: WORKS — fromEntity is keyword-mapped" \
  || echo "E1: BREAKS — term query returns 0; fromEntity is text-analyzed not keyword (GAP J4)"

curl -sf -X DELETE "localhost:9200/xiigen-decision-graph/_doc/${TEST_ID}" > /dev/null
export E1_VERDICT=$([ "$FOUND" -ge 1 ] && echo "WORKS" || echo "BREAKS")
```

---

## E2 — Archetype bracket routing (score=0.71 ROUTING)

```bash
echo "=== E2: BootstrapCycleRouter — score=0.71 ROUTING ==="
node -e "
const p = require('$BASE_DIR/server/src/fabrics/graph/planning/bootstrap-cycle-router');
// Trace: does route() query graph BEFORE any hardcoded boundary?
const src = require('fs').readFileSync(
  '$BASE_DIR/server/src/fabrics/graph/planning/bootstrap-cycle-router.ts', 'utf8');

const graphQueryBefore = src.indexOf('graphRag.query') < src.indexOf('STOP_STRUCTURAL') ||
                          src.indexOf('graphRag.query') < src.indexOf('0.50');
console.log('Graph query before boundary check:', graphQueryBefore ? 'YES' : 'NO');
if (!graphQueryBefore) {
  console.log('E2: WRONG — hardcoded boundary fires before graph query (GAP J1)');
} else {
  console.log('E2: WORKS');
}
" 2>/dev/null || echo "E2: Could not load TS source — check path"
```

---

## E3 — MACHINE_CONSTANT override (score=0.0 ATTENDANCE)

```bash
echo "=== E3: ATTENDANCE:SCORE_BRACKET:MACHINE_CONSTANT_INVERSION override ==="
node -e "
const src = require('fs').readFileSync(
  '$BASE_DIR/server/src/fabrics/graph/planning/bootstrap-cycle-router.ts', 'utf8');

// Check: is MACHINE_CONSTANT_INVERSION queried before STOP_STRUCTURAL?
const hasOverrideQuery = /MACHINE_CONSTANT_INVERSION/.test(src);
const overrideBeforeBoundary = src.indexOf('MACHINE_CONSTANT_INVERSION') <
                                src.indexOf('STOP_STRUCTURAL');

console.log('Override query present:', hasOverrideQuery);
console.log('Override before boundary:', overrideBeforeBoundary);
if (!hasOverrideQuery || !overrideBeforeBoundary) {
  console.log('E3: BREAKS — STOP_STRUCTURAL fires for score=0 ATTENDANCE with no override (GAP J1)');
} else {
  console.log('E3: WORKS');
}
" 2>/dev/null || echo "E3: Could not load TS source"
```

---

## E4 — Interface completeness: IScopedMemoryService sorted set methods

```bash
echo "=== E4: IScopedMemoryService sortedSet methods ==="
IFACE="$BASE_DIR/server/src/fabrics/interfaces/scoped-memory.interface.ts"
[ -f "$IFACE" ] || IFACE=$(find "$BASE_DIR/server/src" -name "scoped-memory*" | head -1)

[ -f "$IFACE" ] && {
  HAS_SORTED=$(grep -c "sortedSetAdd\|sortedSetRange\|sortedSetRemove" "$IFACE")
  echo "sortedSet methods in interface: $HAS_SORTED"
  [ "$HAS_SORTED" -ge 3 ] \
    && echo "E4: WORKS" \
    || echo "E4: BREAKS — IScopedMemoryService missing sortedSet methods (GAP J2)"
} || echo "E4: BREAKS — scoped-memory.interface.ts not found (GAP J2)"
```

---

## E5 — Phase F persistence: AiDrivenRetrospectiveService.runR1() result stored

```bash
echo "=== E5: Phase F persistence — runR1() result written to xiigen-flow-lifecycle ==="
RETRO=$(find "$BASE_DIR/server/src" -name "*retrospective*" | head -1)
[ -f "$RETRO" ] && {
  PERSISTS=$(grep -c "storeDocument\|flow-lifecycle\|xiigen-flow-lifecycle" "$RETRO")
  echo "Persistence calls in retrospective service: $PERSISTS"
  [ "$PERSISTS" -ge 1 ] \
    && echo "E5: WORKS" \
    || echo "E5: PARTIAL — runR1() result computed but not written to ES (GAP J3)"
} || echo "E5: PARTIAL — retrospective service not found"
```

---

## E6 — SESSION-TEACH reachability: DESIGN_REASONING triples seeded

```bash
echo "=== E6: SESSION-TEACH → xiigen-planning-decisions seeded and queryable ==="
TEACH_FILES=$(find "$SESSIONS_DIR" -name "SESSION-TEACH*" 2>/dev/null | wc -l)
echo "SESSION-TEACH files found: $TEACH_FILES"

DESIGN_REASONING_COUNT=$(curl -sf "localhost:9200/xiigen-planning-decisions/_count" \
  -H "Content-Type: application/json" \
  -d "{\"query\":{\"bool\":{\"must\":[
    {\"term\":{\"flowId.keyword\":\"$FLOW_ID\"}},
    {\"term\":{\"category.keyword\":\"DESIGN_REASONING\"}}
  ]}}}" 2>/dev/null \
  | jq '.count // 0')
echo "DESIGN_REASONING triples for $FLOW_ID: $DESIGN_REASONING_COUNT"

[ "$TEACH_FILES" -gt 0 ] && [ "$DESIGN_REASONING_COUNT" -gt 0 ] \
  && echo "E6: WORKS" \
  || echo "E6: PARTIAL — SESSION-TEACH files exist ($TEACH_FILES) but $DESIGN_REASONING_COUNT triples in ES"
```

---

## E7 — Named check registry alignment

```bash
echo "=== E7: NAMED_CHECK_* exported vs registered ==="
EXPORTED=$(grep -roh "NAMED_CHECK_[A-Z_]*" "$BASE_DIR/server/src/engine-contracts" \
  --include="*.ts" 2>/dev/null | sort -u)
EXPORT_CT=$(echo "$EXPORTED" | grep -c . || echo 0)

VALIDATE_HANDLER=$(find "$BASE_DIR/server/src" -name "validate.handler.ts" | head -1)
[ -f "$VALIDATE_HANDLER" ] && {
  REGISTERED=$(grep -oh "NAMED_CHECK_[A-Z_]*\|'[a-z:_]*':" "$VALIDATE_HANDLER" | sort -u)
  REG_CT=$(echo "$REGISTERED" | grep -c . || echo 0)
  echo "Exported: $EXPORT_CT | Registered: $REG_CT"
  MISSING=$(comm -23 <(echo "$EXPORTED" | sort) \
                     <(grep -oh "'[a-z:_-]*':" "$VALIDATE_HANDLER" | tr -d "':" | sort) 2>/dev/null)
  [ -z "$MISSING" ] && echo "E7: WORKS" || {
    echo "E7: SILENT_FAILURE — unregistered checks (GAP CHK-layer):"
    echo "$MISSING"
  }
} || echo "E7: BREAKS — validate.handler.ts not found"
```

---

## E8 — DpoTriple schema alignment (no .code subfields)

```bash
echo "=== E8: DpoTriple schema — session files must not use .code subfields ==="
K1=$(grep -rn "chosen\.code\|rejected\.code" "$SESSIONS_DIR" 2>/dev/null | wc -l)
TS_K1=$(grep -rn "chosen\.code\|rejected\.code" "$BASE_DIR/server/src" --include="*.ts" 2>/dev/null | wc -l)
echo "Session file .code refs: $K1 | TypeScript .code refs: $TS_K1"
[ "$K1" = "0" ] && [ "$TS_K1" = "0" ] \
  && echo "E8: WORKS" \
  || echo "E8: WRONG — .code subfield drift (GAP K1)"
```

---

## E9 — Infrastructure index fixture files exist

```bash
echo "=== E9: xiigen-decision-graph + xiigen-planning-decisions fixtures ==="
GRAPH_FIX=$(find "$BASE_DIR/server/src/rag-init/fixtures" -name "*decision-graph*" 2>/dev/null | wc -l)
PLAN_FIX=$(find "$BASE_DIR/server/src/rag-init/fixtures" -name "*planning-decisions*" 2>/dev/null | wc -l)
[ "$GRAPH_FIX" -gt 0 ] && echo "E9a: WORKS — decision-graph fixture found" \
  || echo "E9a: BREAKS — xiigen-decision-graph fixture MISSING (GAP H-class BLOCKING)"
[ "$PLAN_FIX" -gt 0 ] && echo "E9b: WORKS — planning-decisions fixture found" \
  || echo "E9b: BREAKS — xiigen-planning-decisions fixture MISSING (GAP H-class BLOCKING)"
```

---

## STEP: Write raw E-group gap list

```bash
node - <<'JSEOF'
import json, os, datetime

flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('RAW_OUT', f'sessions/{flow_id}/{flow_id}-GAPS-E-RAW.json')

# Populate verdicts from E1–E9 output above
raw_gaps = {
    "flowId": flow_id,
    "phase": "E-group planning layer",
    "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
    "verdicts": {
        "E1": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "J4_if_BREAKS"},
        "E2": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "J1_if_WRONG"},
        "E3": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "J1_if_BREAKS"},
        "E4": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "J2_if_BREAKS"},
        "E5": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "J3_if_PARTIAL"},
        "E6": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "none_if_WORKS"},
        "E7": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "CHK_if_SILENT_FAILURE"},
        "E8": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "K1_if_WRONG"},
        "E9": {"verdict": "FILL_FROM_OUTPUT", "gap_class": "H_if_BREAKS"}
    },
    "planning_layer_reliable": True,  # Set False if E1 or E3 == BREAKS
    "raw_gaps": []   # Populated from verdicts: one entry per non-WORKS check
}

os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(raw_gaps, f, indent=2)
print(f"Template written: {out}")
print("Fill verdict fields from E1–E9 output above, then set planning_layer_reliable")
JSEOF
```

---

## STEP: Flag if E1 or E3 BREAKS

```bash
echo "=== Planning layer reliability verdict ==="
echo "If E1_VERDICT=BREAKS or E3=BREAKS:"
echo "  → Set planning_layer_reliable=false in GAPS-E-RAW.json"
echo "  → All R2 step table verdicts must include note: '(planning layer unreliable — graph routes may be wrong)'"
echo "  → Fix E1/E3 before treating any R2 WORKS verdict as final"
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (populate from check outputs above) | — | — |

⛔ STOP — `FLOW-XX-GAPS-E-RAW.json` written and `planning_layer_reliable` set
before R2. Report which checks were BREAKS/WRONG in approval message.
