# GAP-PREP-MASTER-PLAN.md
## Process: How to produce FLOW-XX-ENGINE-GAP-LIST.md for any flow
## Source: FLOW-01 + FLOW-04 gap documents + XIIGEN-SIMULATION-METHODOLOGY.md
##         + FLOW-PLAN-PREPARATION-MERGED.md (18 additions, PC-1..PC-5)
## Session type: INVESTIGATION → PLANNING (sequential)
## Cadence: one round at a time — ⛔ STOP after each file presented, await "yes"
## Each round: ONE action, self-contained session file, zipped, presented

---

## MULTI-STACK USAGE POLICY
> **Primary stack: NestJS + React only.**
> All code generation, session files, and engine development targets NestJS (server)
> and React (client) exclusively.
>
> Any simulation round that references an alternative stack (e.g. Laravel, WordPress,
> a legacy language, or a different framework) has **one purpose only:**
> **discovering missing engine capabilities** — interfaces, abstractions, or assumptions
> baked into the engine that would break or degrade when the engine encounters that stack.
>
> The output of those rounds is always an **engine gap** (a missing interface, a hardcoded
> assumption, a check that only works for NestJS). It is never code written in that stack,
> never a session file targeting that stack, and never a gap fix in that stack.
>
> If a simulation round finds a gap via a non-NestJS trace → the fix goes into the
> NestJS engine (e.g. make the check stack-neutral, add an abstraction layer).


## FIXED PROMPT REMINDER (top priority — must appear in every round)
**Q1:** INVESTIGATION (R0–R7) then PLANNING (R8) session type
**Cadence:** One session file per response. ⛔ STOP after present_files. Await "yes".
**Output contract:** ONE SESSION-GAPPREP-RN.md per round, self-contained, zipped, presented.
**This prompt is the top priority and must be honored in every round.**

---

## HOW TO USE THIS PLAN
1. Set `FLOW_ID` at the top of each session file (e.g. `FLOW_ID="FLOW-02"`)
2. Execute rounds R0–R8 in order for the target flow
3. R8 produces `FLOW-XX-ENGINE-GAP-LIST.md` — the deliverable
4. The resulting gap document feeds directly into GAP01-MASTER-PLAN.md template
   (rename columns: GAP-ENG-N, GAP-DATA-N, GAP-SESSION-N, GAP-CHK-N, GAP-SEED-N, GAP-GOV-N)

---

## ROUND TABLE

| Round | File | Phase | One action | Output |
|-------|------|-------|-----------|--------|
| R0 | SESSION-GAPPREP-R0.md | INTAKE | Read flow contracts + topology + session file inventory | `FLOW-XX-INTAKE.json` (task types, archetypes, events, session list) |
| R1 | SESSION-GAPPREP-R1.md | PLANNING-LAYER SIM | Run E-group (E1–E9): ES mapping + cycle router + interface + DPO schema | Raw J/K/H-class gap list |
| R2 | SESSION-GAPPREP-R2.md | FLOW EXECUTION SIM | Run A-group trace for this flow's task types (L2/L3 step tables) | Raw ENG/DATA/SESSION gap candidates per task type |
| R3 | SESSION-GAPPREP-R3.md | SESSION FILE AUDIT | FC-8/FC-28/FC-29 scan: cross-refs, V9-003, ISSUE INVENTORY, field paths | Raw SES-layer gap list |
| R4 | SESSION-GAPPREP-R4.md | NAMED CHECK + SEED AUDIT | PC-5 named check registry + PC-1 graph fixture + SEED-01/02 presence in SESSION-A | Raw CHK/SEED/INFRA gap list |
| R5 | SESSION-GAPPREP-R5.md | GAP CLASSIFICATION | Assign gap class A–L, severity 🔴/🟠/🟡/⬜, fix class per gap | Classified gap table (all raw gaps with class+severity) |
| R6 | SESSION-GAPPREP-R6.md | DEDUPLICATION | Merge same-root gaps; promote multi-location gaps to systemic GAP IDs | Deduplicated canonical gap list |
| R7 | SESSION-GAPPREP-R7.md | ROOT CAUSE LADDER | 3-level WHY per gap; group by Level-3 root; count session clusters | Root cause map + session count estimate |
| R8 | SESSION-GAPPREP-R8.md | GAP DOC AUTHORING | Write `FLOW-XX-ENGINE-GAP-LIST.md` (5 layers, priority order, summary table) | ✅ **Deliverable gap document** |

---

## DEPENDENCY MAP
```
R0 (intake) → all rounds depend on it
  └─ R1 (E-group sim) → must complete before R2
       if E1 or E3 BREAKS → flag in R2 traces as "planning layer unreliable"
  └─ R2 (execution sim) → feeds R5
  └─ R3 (session audit) → feeds R5
  └─ R4 (check+seed audit) → feeds R5
  └─ R5 (classify) → feeds R6
       └─ R6 (dedup) → feeds R7
            └─ R7 (root cause) → feeds R8
                 └─ R8 (authoring) → DELIVERABLE
```

---

## GAP LAYER MAP (canonical — used in R5 classification and R8 authoring)

| Layer | Section header | Gap ID prefix | What goes here |
|-------|---------------|--------------|---------------|
| 1 | ENGINE CODE CHANGES | GAP-ENG-N | TypeScript source file changes |
| 2 | DATA + TOPOLOGY | GAP-DATA-N | topology.json, ES documents, fixture files |
| 3 | SESSION FILE ADDITIONS | GAP-SESSION-N | Amendments to SESSION-N.md bash files |
| 4 | NAMED CHECK CATALOG | GAP-CHK-N | Additions to validate.handler NAMED_CHECKS |
| 5 | GRAPH SEEDING | GAP-SEED-N | Phase A curl commands for xiigen-decision-graph |
| 6 | NEW FILES REQUIRED | GAP-FILES-N | New .spec.ts stubs, new session files |
| 7 | GOVERNANCE | GAP-GOV-N | AGENTS.md, skill updates, process rules |

---

## SEVERITY CLASSIFICATION (inline — used in R5)
```
🔴 SILENT_FAILURE  — engine continues, learning data silently corrupted
🟠 BREAKS          — execution fails visibly; 0 triples / 0 registrations
🟡 PARTIAL         — execution proceeds; signal degraded or missing
⬜ ADVISORY        — correct today; architectural gap for future
```

---

## GAP CLASS REFERENCE (inline — used in R5, from simulation methodology)
```
A  External knowledge intake    G  Conversational channel
B  Recursive decomposition      H  Deploy-test-feedback loop
C  Adaptation delta             I  Multi-modal output
D  On-demand capability design  J  Planning layer infrastructure (J1-J4)
E  Dynamic context assembly     K  Session file schema drift (K1-K3)
F  Cross-level constraint       L  Archetype registration gap (L1-L4)
```

---

## FIX CLASS REFERENCE (inline — used in R5)
```
CONTENT      — write prompt, skill, or AF-9 criteria (no code)
INTERFACE    — new fabric interface + provider (~60 lines, follows pattern)
EXTENSION    — extend existing handler/topology/skill (~15-20 lines)
NEW_HANDLER  — new handler type in topology model
INFRASTRUCTURE — new ES index, fixture, external service
CONVENTION   — rule in AGENTS.md or skill, zero code
```

---

## STEP TABLE FORMAT (inline — used in R2 traces)
```
| Step | What must happen | Handler | Input ✅/⚠️/❌ | Output expected | Actual | Gap? |
```
Handler values: ai-generate.handler | validate.handler | route.handler |
  rag-retrieve.handler | feedback.handler | score.handler |
  [IFabricInterface].method | HUMAN | NONE

Verdict values: WORKS | PARTIAL | BREAKS | WRONG | SILENT_FAILURE

---

## GAP ENTRY FORMAT (inline — used in R8 authoring)
```
### GAP-[LAYER]-[N] [emoji] `[file]` — [short name]

**File:** [path/to/file.ts or sessions/FLOW-XX/SESSION-N.md]
**Problem:** [what is missing, what the code does instead]
**Impact:** [what breaks or corrupts at runtime — one scenario trace]
**Fix:** [exact code block or bash commands]
**Scope:** [FIX CLASS] — ~N lines in M files
```

---

## GAP DOCUMENT STRUCTURE (R8 template)
```
# FLOW-XX ENGINE GAP LIST
## What must be added ... | Date | Source
## PRIORITY LEGEND

## LAYER 1 — ENGINE CODE CHANGES
  ### GAP-ENG-1 🔴 ...
  ### GAP-ENG-N ...

## LAYER 2 — DATA AND TOPOLOGY CHANGES
  ### GAP-DATA-1 ...

## LAYER 3 — SESSION FILE ADDITIONS
  ### GAP-SESSION-1 ...

## LAYER 4 — NAMED CHECK CATALOG
  ### GAP-CHK-1 ...

## LAYER 5 — GRAPH SEEDING
  ### GAP-SEED-1 ...
  (note already-present seeds as ✅ confirmed)

## LAYER 6 — NEW FILES REQUIRED (if any)
  ### GAP-FILES-1 ...

## LAYER 7 — GOVERNANCE (if any)
  ### GAP-GOV-1 ...

## EXECUTION ORDER SUMMARY
  PRIORITY 1 — SILENT_FAILUREs
  PRIORITY 2 — BREAKS
  PRIORITY 3 — PARTIAL
  PRIORITY 4 — ADVISORY

## SUMMARY TABLE
  | ID | Layer | Description | Severity | Scope | Before |

## WHAT WORKS TODAY
  ✅ items confirmed working from simulation traces
```

---

## SELF-CONTAINMENT RULE (every session file)
- Zero cross-references (no "see methodology", "per SK-441", "per FLOW-01 pattern")
- All format templates pasted inline
- All bash commands literal, all variables exported in same file
- FOUND-ISSUE PROTOCOL + ISSUE INVENTORY before every ⛔ STOP

---

## OUTPUT CONTRACT PER ROUND
Done = SESSION-GAPPREP-RN.md zipped and presented.
  Investigation rounds (R0–R7): produces a named intermediate artifact
    (INTAKE.json, raw gap lists, classified table, root cause map)
  Planning round (R8): produces FLOW-XX-ENGINE-GAP-LIST.md as final deliverable
