# SESSION-GAPPREP-R7.md
## Round: R7 | Phase: ROOT CAUSE LADDER
## Action: 3-level WHY per gap; group by Level-3 root; collapse to session cluster count
## Output: FLOW-XX-ROOT-CAUSE-MAP.json
## Self-contained

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export DEDUP="$SESSIONS_DIR/${FLOW_ID}-GAPS-DEDUP.json"
export OUT="$SESSIONS_DIR/${FLOW_ID}-ROOT-CAUSE-MAP.json"
```

---

## THREE-LEVEL STRUCTURE (inline)

```
LEVEL 1 — Immediate cause: the specific thing wrong right now
  → MAINTENANCE SESSION fixes it

LEVEL 2 — Structural cause: the pattern or process that allowed the problem
  → Skill update or template change prevents recurrence

LEVEL 3 — Architectural cause: the design decision that produced the structure
  → DESIGN DECISION; may require planning session
```

---

## STEP 1 — For each canonical gap: run 3-level ladder

Apply this template per gap (fill from dedup list):
```
Gap: [GAP-ID] [name]
Level 1: [what is specifically broken in this file/service right now]
Level 2: [what process/template/skill allowed this to persist]
Level 3: [what architectural assumption produced the structural failure]
Act at: [1 only | 1+2 | all three]
```

Common Level-3 roots seen in FLOW-01/FLOW-04:
```
Root A: "PipelineResult omits score — pipeline output contract incomplete"
Root B: "validate.handler NAMED_CHECKS is static — new flows require code changes"
Root C: "Session file rebasing lacks FC-29 sweep — governance block missing"
Root D: "MACHINE_CONSTANT override edge consulted after (not before) structural boundary"
Root E: "AiDrivenRetrospectiveService.runR1() has no persistence caller"
```

---

## STEP 2 — Group canonical gaps by Level-3 root

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
gaps = json.load(open(os.environ.get('DEDUP',
  f'sessions/{flow_id}/{flow_id}-GAPS-DEDUP.json')))['canonical_gaps']

# Group by level_3_root (fill this field in each gap from STEP 1)
from collections import defaultdict
by_root = defaultdict(list)
for g in gaps:
    root3 = g.get('level_3_root', 'UNCLASSIFIED')
    by_root[root3].append(g['gap_id'])

print("Root cause groups:")
for root, gids in by_root.items():
    print(f"  {root}: {gids}")
print()
print(f"Total Level-3 roots: {len(by_root)}")
print(f"Total gaps: {len(gaps)}")
print(f"Session clusters needed: {len(by_root)} (one per Level-3 root)")
JSEOF
```

---

## STEP 3 — Write root cause map

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('OUT', f'sessions/{flow_id}/{flow_id}-ROOT-CAUSE-MAP.json')

root_map = {
    "flowId": flow_id,
    "total_canonical_gaps": 0,
    "level_3_roots": [
        # {
        #   "root_id": "Root-A",
        #   "description": "...",
        #   "gaps_affected": ["GAP-ENG-1"],
        #   "session_cluster": "MAINTENANCE / EXTENSION / PLANNING",
        #   "must_precede": ["Root-B"]
        # }
    ],
    "session_cluster_count": 0,
    "execution_order": []
}
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(root_map, f, indent=2)
print(f"Written: {out}")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from ladder) | — | — |

⛔ STOP — FLOW-XX-ROOT-CAUSE-MAP.json written.
Report: N canonical gaps → M Level-3 roots → K session clusters.
