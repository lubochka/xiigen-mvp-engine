# SESSION-GAPPREP-R5.md
## Round: R5 | Phase: GAP CLASSIFICATION
## Action: Merge all raw gap lists → assign gap class A–L, severity, fix class per gap
## Output: FLOW-XX-GAPS-CLASSIFIED.json
## Self-contained

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export OUT="$SESSIONS_DIR/${FLOW_ID}-GAPS-CLASSIFIED.json"
```

---

## STEP 1 — Load all raw gap files

```bash
node - <<'JSEOF'
import json, os, glob
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
sd = os.environ.get('SESSIONS_DIR', f'sessions/{flow_id}')

raw_files = glob.glob(f"{sd}/*-GAPS-*-RAW.json")
print(f"Raw gap files found: {raw_files}")
all_raw = []
for f in raw_files:
    d = json.load(open(f))
    all_raw.extend(d.get('raw_gaps', []))
print(f"Total raw gap entries: {len(all_raw)}")
JSEOF
```

---

## STEP 2 — Apply classification table (inline)

For each raw gap, fill in:

```
gap_class:   A-L  (see class reference below)
severity:    🔴 SILENT_FAILURE | 🟠 BREAKS | 🟡 PARTIAL | ⬜ ADVISORY
fix_class:   CONTENT | INTERFACE | EXTENSION | NEW_HANDLER | INFRASTRUCTURE | CONVENTION
layer:       1=ENG | 2=DATA | 3=SESSION | 4=CHK | 5=SEED | 6=FILES | 7=GOV
gap_id:      GAP-[LAYER_PREFIX]-[N]  (e.g. GAP-ENG-1, GAP-CHK-2)
```

Gap class reference (inline):
```
A=external intake  B=decomposition  C=adaptation delta  D=on-demand capability
E=dynamic context  F=cross-level constraint  G=conversational channel
H=deploy-test loop  I=multi-modal output
J1=hardcoded override  J2=missing interface method  J3=unpersisted learning  J4=mapping mismatch
K1=DpoTriple field drift  K2=CloudEvent name drift  K3=fixture field drift
L1=enum missing  L2=bootstrap missing  L3=tierMap missing  L4=topology wiring missing
```

---

## STEP 3 — Write classified gap list

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('OUT', f'sessions/{flow_id}/{flow_id}-GAPS-CLASSIFIED.json')

# Fill from STEP 2 manual classification
classified = {
    "flowId": flow_id,
    "total_raw": 0,        # fill from STEP 1 count
    "classified_gaps": []  # one entry per gap with all fields above
}
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(classified, f, indent=2)
print(f"Written: {out}")
print("Fill classified_gaps from STEP 2")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from classification) | — | — |

⛔ STOP — FLOW-XX-GAPS-CLASSIFIED.json written with every raw gap classified.
