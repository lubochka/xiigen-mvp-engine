# SESSION-GAPPREP-R2.md
## Round: R2 | Phase: FLOW EXECUTION SIMULATION (A-group, L2/L3 traces)
## Action: Trace handler chain for each task type → produce step tables
## Output: FLOW-XX-GAPS-A-RAW.json (one step table per task type, raw gap candidates)
## Self-contained: all format templates inline

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export INTAKE="$SESSIONS_DIR/${FLOW_ID}-INTAKE.json"
export RAW_OUT="$SESSIONS_DIR/${FLOW_ID}-GAPS-A-RAW.json"

# Load task types from intake
TASK_TYPES=$(node -e "
import json
d = json.load(open('$INTAKE'))
print(' '.join(t['id'] for t in d['taskTypes']))
")
echo "Tracing task types: $TASK_TYPES"
```

---

## STEP TABLE FORMAT (inline — one table per task type)

```
| Step | What must happen | Handler | Input ✅/⚠️/❌ | Output expected | Actual | Gap? |
```

Handler valid values:
  ai-generate.handler | validate.handler | route.handler | rag-retrieve.handler
  feedback.handler    | score.handler    | [IFabricInterface].method | HUMAN | NONE

Verdict: WORKS | PARTIAL | BREAKS | WRONG | SILENT_FAILURE

Gap entry (when verdict ≠ WORKS):
  gap_class: A–L  |  symptom: one sentence  |  root: one sentence  |  fix_class: CONTENT/INTERFACE/EXTENSION/NEW_HANDLER/INFRASTRUCTURE

---

## FOR EACH TASK TYPE: produce this trace

```
Trace template — copy once per task type TXX:

### TXX — [task type name] ([archetype])

| Step | What must happen | Handler | Input ✅/⚠️/❌ | Output expected | Actual | Gap? |
|------|-----------------|---------|---------------|----------------|--------|------|
| 1  | Read task type contract from xiigen-contracts | rag-retrieve.handler | contract doc ✅/❌ | EngineContract with ironRules[] | ? | ? |
| 2  | Retrieve RAG patterns for this archetype | rag-retrieve.handler | xiigen-rag-patterns ✅/⚠️/❌ | arch patterns for [archetype] | ? | ? |
| 3  | Retrieve genesis prompt | rag-retrieve.handler | xiigen-prompts ✅/⚠️/❌ | genesis prompt for TXX | ? | ? |
| 4  | Generate code (3 providers) | ai-generate.handler | genesis prompt ✅/⚠️/❌, RAG patterns ✅/⚠️/❌ | 3 code candidates | ? | ? |
| 5  | Validate named checks | validate.handler | NAMED_CHECKS[checkId] ✅/⚠️/❌ | CheckResult per check | ? | ? |
| 6  | Score all 3 candidates | score.handler | code + criteria ✅/⚠️/❌ | score 0–1 per candidate | ? | ? |
| 7  | Route on score | route.handler | score ✅, graph edge ✅/⚠️/❌ | CycleAction | ? | ? |
| 8  | Store DPO triple | feedback.handler | chosen/rejected ✅/⚠️/❌, curriculumTier ✅/⚠️/❌ | triple in xiigen-training-data | ? | ? |
| 9  | Emit CloudEvent | feedback.handler | exact event type ✅/⚠️/❌ | event in queue | ? | ? |
| 10 | Learning path: record routing decision | validate.handler | STATE.json ✅/⚠️/❌ | routing_decisions entry | ? | ? |
```

---

## BASH VERIFICATION per task type

```bash
for TT in $TASK_TYPES; do
  echo "=== Tracing $TT ==="

  # Check 1: contract exists
  CONTRACT=$(find "$BASE_DIR/server/src/engine-contracts" -name "*.ts" | \
    xargs grep -l "$TT" 2>/dev/null | head -1)
  [ -n "$CONTRACT" ] && echo "  Step 1 ✅ contract: $CONTRACT" \
    || echo "  Step 1 ❌ no contract file for $TT — BREAKS"

  # Check 3: genesis prompt seeded
  PROMPT_CT=$(curl -sf "localhost:9200/xiigen-prompts/_count" \
    -d "{\"query\":{\"term\":{\"taskTypeId.keyword\":\"$TT\"}}}" 2>/dev/null \
    | jq '.count // 0')
  echo "  Step 3 genesis prompt count: $PROMPT_CT"

  # Check 5: named checks registered
  CHECKS=$(grep -oh "'[a-z:_-]*':" "$BASE_DIR/server/src"/*/*/validate.handler.ts 2>/dev/null | wc -l || echo 0)
  echo "  Step 5 NAMED_CHECKS registered: $CHECKS"

  # Check 9: CloudEvent name in session files matches contract
  EVENT=$(node -e "
import json
d = json.load(open('$INTAKE'))
tt = next((t for t in d['taskTypes'] if t['id']=='$TT'), {})
events = d.get('cloudEvents', {}).get('emitted', [])
print(events[0] if events else 'UNKNOWN')
  " 2>/dev/null)
  SESSION_REF=$(grep -rn "$EVENT" "$SESSIONS_DIR"/*.md 2>/dev/null | wc -l)
  echo "  Step 9 event '$EVENT' referenced in sessions: $SESSION_REF times"
done
```

---

## Write raw A-group gap list

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('RAW_OUT', f'sessions/{flow_id}/{flow_id}-GAPS-A-RAW.json')

template = {
    "flowId": flow_id,
    "phase": "A-group execution traces",
    "step_tables": {},   # key = "T63", value = list of step rows with verdict
    "raw_gaps": []       # one entry per non-WORKS step: {task_type, step, verdict, gap_class, symptom, root}
}
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(template, f, indent=2)
print(f"Template written: {out} — fill step_tables and raw_gaps from traces above")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from trace steps) | — | — |

⛔ STOP — FLOW-XX-GAPS-A-RAW.json written with at least one step table per task type.
