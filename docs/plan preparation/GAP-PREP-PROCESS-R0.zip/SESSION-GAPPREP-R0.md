# SESSION-GAPPREP-R0.md
## Round: R0 | Phase: INTAKE
## Action: Read flow contracts + topology + session file inventory
##         → produce FLOW-XX-INTAKE.json
## All later rounds depend on this output. Must complete before R1.
## Self-contained: all commands literal, zero cross-references

---

## CONFIGURE FOR TARGET FLOW
```bash
export FLOW_ID="FLOW-XX"          # ← replace: FLOW-02, FLOW-03, etc.
export BASE_DIR="."
export CONTRACTS_DIR="$BASE_DIR/server/src/engine-contracts"
export TOPOLOGY_DIR="$BASE_DIR/contracts/topologies"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export OUT="$SESSIONS_DIR/${FLOW_ID}-INTAKE.json"
mkdir -p "$SESSIONS_DIR"
```

---

## WHY FIRST (inline)
Every simulation round (R1–R4) needs:
  - The exact task type IDs this flow introduces (for E-group trace scope)
  - The archetype per task type (for graph seeding verification)
  - The CloudEvent names emitted (for K2 drift check in R1)
  - The session file list (for FC-29 audit scope in R3)
Without this inventory, R1–R4 must guess scope → wrong gap list.

---

## STEP 1 — Locate this flow's contract file(s)

```bash
echo "=== Contract files for $FLOW_ID ==="
find "$CONTRACTS_DIR" -name "*${FLOW_ID}*" -o -name "*flow-$(echo $FLOW_ID | tr '[:upper:]' '[:lower:]' | tr -d '-')*" 2>/dev/null
find "$BASE_DIR/server/src" -name "*.ts" | xargs grep -l "$FLOW_ID" 2>/dev/null | grep -i contract | head -10
```

---

## STEP 2 — Extract task type IDs and archetypes

```bash
echo "=== Task types and archetypes ==="
# Find task type definitions (look for taskTypeId patterns like T47, T63, etc.)
grep -rn "taskTypeId\|archetype\|\"T[0-9]" "$CONTRACTS_DIR" --include="*.ts" | \
  grep -i "$FLOW_ID\|T6[0-9]\|T[0-9][0-9]" | head -30

# Also check topology file
[ -f "$TOPOLOGY_DIR/${FLOW_ID}.topology.json" ] && \
  node -e "
import json, sys
d = json.load(open('$TOPOLOGY_DIR/${FLOW_ID}.topology.json'))
print('Topology task types:', json.dumps(d.get('taskTypeIds', d.get('nodes', {})), indent=2))
" 2>/dev/null || echo "Topology file not found at expected path"
```

**Record:** for each task type: ID (e.g. T63), name, archetype (ROUTING/ATTENDANCE/etc.)

---

## STEP 3 — Extract CloudEvent names emitted by this flow

```bash
echo "=== CloudEvent type strings ==="
# From contract files: look for events[] arrays and type: strings
grep -rn '"type".*"[A-Z][a-z]\+[A-Z]\|events.*\[\|emits' \
  "$CONTRACTS_DIR" --include="*.ts" | head -20

# From topology
[ -f "$TOPOLOGY_DIR/${FLOW_ID}.topology.json" ] && \
  node -e "
import json
d = json.load(open('$TOPOLOGY_DIR/${FLOW_ID}.topology.json'))
# Extract all string values containing 'Event' or capitalized camel-case
import re
text = json.dumps(d)
events = re.findall(r'\"([A-Z][a-zA-Z]+(?:Confirmed|Sent|Created|Updated|Failed|Opened|Closed|Started|Ended))\"', text)
print('Events found in topology:', sorted(set(events)))
" 2>/dev/null
```

**Record:** exact CloudEvent type strings — these are checked against session files in R1 (K2 drift).

---

## STEP 4 — List all session files for this flow

```bash
echo "=== Session files for $FLOW_ID ==="
find "$SESSIONS_DIR" -name "*.md" -o -name "*.sh" 2>/dev/null | sort
find "$BASE_DIR" -name "${FLOW_ID}-SESSION*" -o -name "SESSION-*${FLOW_ID}*" 2>/dev/null | sort
find "$BASE_DIR/docs/sessions" -path "*${FLOW_ID}*" 2>/dev/null | sort
```

**Record:** list of SESSION-A.md, SESSION-B.md, ..., SESSION-F.md, SESSION-TEACH-*.md

---

## STEP 5 — Locate topology.json and check Phase B nodes

```bash
echo "=== Topology.json Phase B nodes ==="
TOPO="$TOPOLOGY_DIR/${FLOW_ID}.topology.json"
[ -f "$TOPO" ] && node -e "
import json
d = json.load(open('$TOPO'))
nodes = d.get('nodes', {})
print('Node count:', len(nodes))
for nid, node in nodes.items():
    print(f'  {nid}: handler={node.get(\"handler\",\"MISSING\")} type={node.get(\"nodeType\",\"?\")}')
" || echo "❌ Topology not found at $TOPO — GAP-DATA candidate"
```

**Record:** whether topology has Phase B execution nodes (rag-retrieve → multi-generate → validate → score → feedback).
Missing = GAP-DATA candidate for R2.

---

## STEP 6 — Check FLOW-XX-ARCHITECTURE-DECISIONS.json

```bash
echo "=== Architecture decisions file ==="
find "$BASE_DIR" -name "${FLOW_ID}-ARCHITECTURE-DECISIONS*" 2>/dev/null
ARCH_FILE=$(find "$BASE_DIR" -name "${FLOW_ID}-ARCHITECTURE-DECISIONS*.json" 2>/dev/null | head -1)
[ -n "$ARCH_FILE" ] && node -e "
import json
d = json.load(open('$ARCH_FILE'))
decs = d.get('decisions', [])
print(f'Decisions: {len(decs)}')
for dec in decs:
    print(f'  {dec.get(\"decisionId\",\"?\")} — {dec.get(\"type\",\"?\")}')
" || echo "No architecture decisions file found"
```

---

## STEP 7 — Check BFA rules for this flow

```bash
echo "=== BFA CF rules for $FLOW_ID ==="
grep -rn "CF-[0-9]\{3,\}" "$BASE_DIR/server/src" --include="*.ts" | \
  grep -i "$FLOW_ID\|T6[0-9]" | head -20
find "$BASE_DIR" -name "xiigen-bfa-rules*" -o -name "*bfa-conflict*" 2>/dev/null | head -5
```

---

## STEP 8 — Write FLOW-XX-INTAKE.json

```bash
node - <<'JSEOF'
import json, subprocess, os

flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out_path = f"{os.environ.get('SESSIONS_DIR', '.')}/{flow_id}-INTAKE.json"

# Populate manually from steps 1-7 output above
intake = {
    "flowId": flow_id,
    "intakeDate": __import__('datetime').datetime.utcnow().isoformat() + "Z",
    "taskTypes": [
        # Fill in from STEP 2:
        # {"id": "T63", "name": "RSVPRegistrar", "archetype": "ATTENDANCE"},
    ],
    "cloudEvents": {
        "emitted":  [],   # Fill from STEP 3: ["RSVPConfirmed", ...]
        "consumed": []    # Fill from STEP 3: ["TicketPurchaseCompleted", ...]
    },
    "sessionFiles": [],   # Fill from STEP 4: ["SESSION-A.md", "SESSION-B.md", ...]
    "topologyHasPhaseB": False,  # Fill from STEP 5: True/False
    "architectureDecisions": [],  # Fill from STEP 6: ["D-04-1", "D-04-2", ...]
    "bfaRules": [],        # Fill from STEP 7: ["CF-802", ...]
    "newArchetypes": []    # Fill: archetypes this flow introduces for the first time
}

with open(out_path, 'w') as f:
    json.dump(intake, f, indent=2)

print(f"Written: {out_path}")
print(json.dumps(intake, indent=2))
JSEOF
```

---

## STEP 9 — Verify intake is complete

```bash
echo "=== R0 completeness check ==="
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
path = f"{os.environ.get('SESSIONS_DIR', '.')}/{flow_id}-INTAKE.json"
d = json.load(open(path))

checks = [
    ("taskTypes populated",           len(d.get('taskTypes', [])) > 0),
    ("cloudEvents.emitted populated", len(d.get('cloudEvents', {}).get('emitted', [])) > 0),
    ("sessionFiles populated",        len(d.get('sessionFiles', [])) > 0),
    ("topologyHasPhaseB set",         d.get('topologyHasPhaseB') is not None),
    ("newArchetypes populated",       len(d.get('newArchetypes', [])) > 0),
]
all_green = True
for label, ok in checks:
    icon = "✅" if ok else "❌"
    print(f"  {icon} {label}")
    if not ok:
        all_green = False
print()
print("ALL GREEN → proceed to R1 (E-group planning layer simulation)" if all_green
      else "RED items → fill INTAKE.json manually before R1")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (populate from steps above) | — | — |

⛔ STOP — all 5 STEP 9 checks must be GREEN before R1.
Deliver `FLOW-XX-INTAKE.json` path in approval message.
