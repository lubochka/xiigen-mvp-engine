# SESSION-GAPPREP-R6.md
## Round: R6 | Phase: DEDUPLICATION + SYSTEMIC PROMOTION
## Action: Merge same-root gaps; promote multi-location gaps to one systemic GAP ID
## Output: FLOW-XX-GAPS-DEDUP.json
## Rule (from simulation methodology §3 Rule 6): same observable root = one GAP ID
## Self-contained

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export CLASSIFIED="$SESSIONS_DIR/${FLOW_ID}-GAPS-CLASSIFIED.json"
export OUT="$SESSIONS_DIR/${FLOW_ID}-GAPS-DEDUP.json"
```

---

## STEP 1 — Deduplication test (inline)

For each pair of gaps, apply this test:
```
Deduplication test: If root cause A is fixed, do BOTH symptoms A and B disappear?
  YES → merge into one gap, add "ALSO_HITS" array with all affected locations
  NO  → keep as separate gaps
```

Common dedup patterns observed in FLOW-01/FLOW-04:
```
"score=0 in genesis history" + "score=0 in routing decisions"
  → same root: PipelineResult.score field absent → ONE gap (GAP-ENG: af-pipeline)

"NAMED_CHECK missing for T63" + "NAMED_CHECK missing for T64"
  → different archetypes, but same root (NAMED_CHECKS not extensible) → ONE systemic gap
  → ALSO_HITS: [T63 check, T64 check, T65 check]

"FC-29 missing SESSION-D" + "FC-29 missing SESSION-E"
  → same process failure (rebasing without FC-29 sweep) → ONE systemic gap with two locations
```

---

## STEP 2 — Fix class distribution check (inline)

```bash
node - <<'JSEOF'
import json, os
from collections import Counter
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
gaps = json.load(open(os.environ.get('CLASSIFIED',
  f'sessions/{flow_id}/{flow_id}-GAPS-CLASSIFIED.json')))['classified_gaps']
dist = Counter(g.get('fix_class','?') for g in gaps)
total = len(gaps)
print(f"Total gaps: {total}")
for fix_class, count in dist.most_common():
    pct = 100*count//total if total else 0
    print(f"  {fix_class}: {count} ({pct}%)")
print()
print("Interpretation (from solution scope gate):")
print(f"  >50% CONTENT → write prompts/rules, no code changes")
print(f"  >30% INTERFACE → predictable effort, ~60 lines each")
print(f"  >20% NEW_HANDLER → topology changes, plan carefully")
JSEOF
```

---

## STEP 3 — Write deduplicated canonical gap list

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('OUT', f'sessions/{flow_id}/{flow_id}-GAPS-DEDUP.json')

dedup = {
    "flowId": flow_id,
    "original_count": 0,   # fill from classified count
    "dedup_count": 0,       # after merging same-root gaps
    "systemic_promotions": [],  # gaps with 2+ locations merged
    "canonical_gaps": [],   # final list — one entry per unique root cause
    "fix_class_distribution": {}
}
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(dedup, f, indent=2)
print(f"Written: {out}")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from dedup) | — | — |

⛔ STOP — FLOW-XX-GAPS-DEDUP.json written. Report original vs dedup count in approval.
