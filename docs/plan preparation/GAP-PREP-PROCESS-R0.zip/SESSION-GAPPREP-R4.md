# SESSION-GAPPREP-R4.md
## Round: R4 | Phase: NAMED CHECK + SEED AUDIT
## Action: PC-5 named check registry + PC-1 fixture check + SEED-01/02 presence
## Output: FLOW-XX-GAPS-CHK-SEED-RAW.json
## Self-contained

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export SESSIONS_DIR="$BASE_DIR/sessions/$FLOW_ID"
export SESSION_A=$(find "$SESSIONS_DIR" -name "SESSION-A*" | head -1)
export RAW_OUT="$SESSIONS_DIR/${FLOW_ID}-GAPS-CHK-SEED-RAW.json"
export INTAKE="$SESSIONS_DIR/${FLOW_ID}-INTAKE.json"
```

---

## STEP 1 — PC-1: fixture files for xiigen-decision-graph + xiigen-planning-decisions

```bash
echo "=== PC-1: Infrastructure fixtures ==="
GRAPH_FIX=$(find "$BASE_DIR/server/src/rag-init/fixtures" -name "*decision-graph*" 2>/dev/null | wc -l)
PLAN_FIX=$(find "$BASE_DIR/server/src/rag-init/fixtures" -name "*planning-decisions*" 2>/dev/null | wc -l)
[ "$GRAPH_FIX" -gt 0 ] && echo "✅ decision-graph fixture" || echo "❌ MISSING decision-graph fixture (GAP-SEED H-class)"
[ "$PLAN_FIX"  -gt 0 ] && echo "✅ planning-decisions fixture" || echo "❌ MISSING planning-decisions fixture (GAP-SEED H-class)"
```

---

## STEP 2 — PC-5: NAMED_CHECK_* exported vs registered in validate.handler

```bash
echo "=== PC-5: Named check alignment ==="
EXPORTED=$(grep -roh "NAMED_CHECK_[A-Z_]*" "$BASE_DIR/server/src/engine-contracts" \
  --include="*.ts" 2>/dev/null | sort -u)
VALIDATE=$(find "$BASE_DIR/server/src" -name "validate.handler.ts" | head -1)
[ -f "$VALIDATE" ] && {
  REGISTERED_KEYS=$(grep -oh "'[a-z:][a-z:_-]*'" "$VALIDATE" 2>/dev/null | tr -d "'" | sort -u)
  MISSING=$(comm -23 <(echo "$EXPORTED" | sort) \
                     <(echo "$REGISTERED_KEYS" | sort) 2>/dev/null)
  [ -z "$MISSING" ] && echo "✅ All NAMED_CHECKs registered" || {
    echo "❌ Unregistered checks (CHK-layer gaps):"
    echo "$MISSING"
  }
} || echo "❌ validate.handler.ts not found"
```

---

## STEP 3 — SEED presence in SESSION-A.md

```bash
echo "=== SEED-01: Arbiter edges in SESSION-A ==="
[ -n "$SESSION_A" ] && {
  # Load archetypes from intake
  ARCHETYPES=$(node -e "
import json
d = json.load(open('$INTAKE'))
print(' '.join(set(t['archetype'] for t in d['taskTypes'])))" 2>/dev/null)
  echo "Archetypes to verify: $ARCHETYPES"
  for ARCH in $ARCHETYPES; do
    CT=$(grep -c "$ARCH.*REQUIRES_MINIMUM_ARBITER\|REQUIRES_MINIMUM_ARBITER.*$ARCH" "$SESSION_A" 2>/dev/null || echo 0)
    [ "$CT" -gt 0 ] && echo "  ✅ $ARCH minimum arbiter edges in SESSION-A" \
      || echo "  ❌ $ARCH minimum arbiter edges MISSING from SESSION-A (GAP-SEED)"
  done
} || echo "SESSION-A not found"

echo ""
echo "=== SEED-02: Score bracket edges in SESSION-A ==="
[ -n "$SESSION_A" ] && {
  for BRACKET in "SCORE_BRACKET:STRUCTURAL" "SCORE_BRACKET:DETAIL_GAP" "SCORE_BRACKET:PASS" "SCORE_BRACKET:PATTERN_MISSING"; do
    CT=$(grep -c "$BRACKET" "$SESSION_A" 2>/dev/null || echo 0)
    [ "$CT" -gt 0 ] && echo "  ✅ $BRACKET seeded" || echo "  ❌ $BRACKET MISSING (GAP-SEED)"
  done
} || echo "SESSION-A not found"
```

---

## STEP 4 — SEED-05: CHECK 18 (ES term-query round-trip) in INFRASTRUCTURE-GATE.md

```bash
INFRA_GATE=$(find "$SESSIONS_DIR" "$BASE_DIR" -name "*INFRASTRUCTURE-GATE*" 2>/dev/null | head -1)
[ -n "$INFRA_GATE" ] && {
  ROUNDTRIP=$(grep -c "term-query\|GATE-CHECK\|round-trip" "$INFRA_GATE" 2>/dev/null || echo 0)
  [ "$ROUNDTRIP" -gt 0 ] && echo "✅ CHECK 18 round-trip present in INFRASTRUCTURE-GATE" \
    || echo "❌ CHECK 18 missing from INFRASTRUCTURE-GATE (GAP-SEED PARTIAL)"
} || echo "INFRASTRUCTURE-GATE file not found"
```

---

## Write raw CHK+SEED gap list

```bash
node - <<'JSEOF'
import json, os
flow_id = os.environ.get('FLOW_ID', 'FLOW-XX')
out = os.environ.get('RAW_OUT', f'sessions/{flow_id}/{flow_id}-GAPS-CHK-SEED-RAW.json')
template = {
    "flowId": flow_id, "phase": "named-check-and-seed-audit",
    "fixture_status": {"decision_graph": "GREEN/RED", "planning_decisions": "GREEN/RED"},
    "named_checks_missing": [],
    "seed_gaps": [],
    "raw_gaps": []
}
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, 'w') as f:
    json.dump(template, f, indent=2)
print(f"Template written: {out}")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from steps) | — | — |

⛔ STOP — FLOW-XX-GAPS-CHK-SEED-RAW.json written. Report named checks and seed gaps found.
