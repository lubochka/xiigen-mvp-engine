# SIMULATION-MASTER-PLAN.md
## Source: XIIGEN-SIMULATION-METHODOLOGY.md v2.0 (2026-03-27)
## Session type: INVESTIGATION
## Cadence: one round at a time — ⛔ STOP after each session file presented
## Each session file: ONE scenario trace OR one synthesis step, self-contained

---

## MULTI-STACK USAGE POLICY
> **Primary stack: NestJS + React only.**
> All code generation, session files, and engine development targets NestJS (server)
> and React (client) exclusively.
>
> Any simulation round that references an alternative stack (e.g. Laravel, WordPress,
> a legacy language, or a different framework) has **one purpose only:**
> **discovering missing engine capabilities** — interfaces, abstractions, or assumptions
> baked into the engine that would break or degrade when the engine encounters that stack.
>
> The output of those rounds is always an **engine gap** (a missing interface, a hardcoded
> assumption, a check that only works for NestJS). It is never code written in that stack,
> never a session file targeting that stack, and never a gap fix in that stack.
>
> If a simulation round finds a gap via a non-NestJS trace → the fix goes into the
> NestJS engine (e.g. make the check stack-neutral, add an abstraction layer).


## FIXED PROMPT REMINDER (appears at start of every round response)
**Q1:** INVESTIGATION session type (SK-441 governs)
**Cadence:** One session file per response. ⛔ STOP after present_files. Await "yes".
**Output contract per round:** One SESSION-SIM-RN.md + step table, zipped, presented.
**SK-441 rule:** "probably works" is NOT a verdict. Trace actual handlers. Name each input ✅/⚠️/❌.
**This prompt is the top priority and must be honored in every round.**

---

## EXECUTION ORDER (from document §1 GROUP E rule)

> **Run GROUP E first.** If E1 or E3 show BREAKS, all GROUP A–D results are
> unreliable — the planning layer is routing wrong and feeding wrong training data.

---

## ROUND TABLE (35 rounds)

### Pre-simulation gate
| Round | File | Scenario | Depth | One action |
|-------|------|---------|-------|-----------|
| R0 | SESSION-SIM-R0.md | E9 | L1 | Verify xiigen-decision-graph + xiigen-planning-decisions fixture files exist (blocking gate — no Layer 2 sim valid without these) |

### GROUP E — Planning layer correctness (must complete before A–D)
| Round | File | Scenario | Depth | One action |
|-------|------|---------|-------|-----------|
| R1 | SESSION-SIM-R1.md | E1 | L2-TS | Graph edge round-trip: seed → term query → verify ES keyword mapping |
| R2 | SESSION-SIM-R2.md | E2 | L2-TS | Archetype bracket routing: score=0.71, ROUTING → CYCLE_WITH_PATCH path trace |
| R3 | SESSION-SIM-R3.md | E3 | L2-TS | Structural override routing: score=0.0, ATTENDANCE, override edge → CYCLE_WITH_PATCH vs STOP_STRUCTURAL |
| R4 | SESSION-SIM-R4.md | E4 | L1 | Interface completeness: IScopedMemoryService sortedSet methods for T64 FIFO pattern |
| R5 | SESSION-SIM-R5.md | E5 | L2-TS | Phase F persistence: AiDrivenRetrospectiveService.runR1() output written to xiigen-flow-lifecycle |
| R6 | SESSION-SIM-R6.md | E6 | L1 | SESSION-TEACH reachability: DESIGN_REASONING triples seeded + queryable at Phase B |
| R7 | SESSION-SIM-R7.md | E7 | L2-TS | Named check registry: every NAMED_CHECK_* in contracts appears in validate.handler.ts NAMED_CHECKS |
| R8 | SESSION-SIM-R8.md | E8 | L1 | DpoTriple schema: session files use top-level chosen/rejected, NOT .code subfields |

### GROUP A — Explicitly designed scenarios (L2/L3 depth)
| Round | File | Scenario | Depth | One action |
|-------|------|---------|-------|-----------|
| R9  | SESSION-SIM-R9.md  | A1 | L3 | Trace NestJS UserRegistrationInitiatorService (T47) generation + learning path |
| R10 | SESSION-SIM-R10.md | A2 | L2 | Trace FLOW-34 Phase 0 infrastructure readiness gate (prerequisite verification) |
| R11 | SESSION-SIM-R11.md | A3 | L3 | Trace Canva C5 adapter generation + 4/5-arbiter consensus gate + learning path |
| R12 | SESSION-SIM-R12.md | A4 | L2 | Trace Figma F1 adapter derived from C5 canonical pattern (delta transfer) |
| R13 | SESSION-SIM-R13.md | A5 | L1 | Trace FLOW-40 session file planning from FLOW-40-CLIENT-PUSH-INFRASTRUCTURE.md |

### GROUP B — Product scenarios (L1 depth — decomposition + orchestration gaps)
| Round | File | Scenario | Depth | One action |
|-------|------|---------|-------|-----------|
| R14 | SESSION-SIM-R14.md | B1 | L1 | Trace: Figma nodes → AI models → review → result (simple flow) |
| R15 | SESSION-SIM-R15.md | B2 | L1 | Trace: user feedback (good/neutral/negative) → stored + incorporated next request |
| R16 | SESSION-SIM-R16.md | B3 | L1 | Trace: 12-screen Figma → capability map → flow architecture → tech design |
| R17 | SESSION-SIM-R17.md | B4 | L1 | Trace: Figma design + 3 existing repos + design system → docs/theme/style |
| R18 | SESSION-SIM-R18.md | B5 | L1 | Trace: text description → design → architecture → skills → plan → code |
| R19 | SESSION-SIM-R19.md | B6 | L1 | Trace: diet app — registration → AI plan → WhatsApp daily loop |
| R20 | SESSION-SIM-R20.md | B7 | L1 | Trace: content pipeline — text/audio → images → video → music → publish |
| R21 | SESSION-SIM-R21.md | B8 | L1 | Trace: generate + deploy + debug networking app from functional spec |

### GROUP C — Cross-cutting capabilities (L1 depth)
| Round | File | Scenario | Depth | One action |
|-------|------|---------|-------|-----------|
| R22 | SESSION-SIM-R22.md | C1 | L1 | Trace: AI-planned RAG retrieval before each AI call |
| R23 | SESSION-SIM-R23.md | C2 | L1 | Trace: AI-planned RAG storage after each AI call |
| R24 | SESSION-SIM-R24.md | C3 | L1 | Trace: flow visualization — running flow → visual progress on UI |
| R25 | SESSION-SIM-R25.md | C4 | L1 | Trace: node debugging — full input/processing/output trace per node |
| R26 | SESSION-SIM-R26.md | C5 | L1 | Trace: generate → deploy → test → integrate loop |
| R27 | SESSION-SIM-R27.md | C6 | L1 | Trace: Pascal 3-repo migration → modern equivalent + comparison docs |
| R28 | SESSION-SIM-R28.md | C7 | L1 | Trace: same flow, different stack (NestJS → Laravel → WordPress) — **engine gap discovery only; output = NestJS engine fix, not stack code** |

### GROUP D — FLOW-34 specific (L2 depth)
| Round | File | Scenario | Depth | One action |
|-------|------|---------|-------|-----------|
| R29 | SESSION-SIM-R29.md | D1 | L2 | Trace: seed 14 platform registry entries at FLOW-34 Phase A |
| R30 | SESSION-SIM-R30.md | D2 | L2 | Trace: resolve artifact boundaries from live ES (next T, F, CF numbers) |
| R31 | SESSION-SIM-R31.md | D3 | L2 | Trace: adapter with 5-arbiter consensus gate (thin compliance verified) |
| R32 | SESSION-SIM-R32.md | D4 | L2 | Trace: pattern transfer C5 (Canva) → M1 (Miro), different SDK |

### Post-simulation synthesis
| Round | File | Action | Source |
|-------|------|--------|--------|
| R33 | SESSION-SIM-R33.md | Systemic gap promotion: merge same-root gaps across scenarios into single GAP IDs | §3 Rule 6 |
| R34 | SESSION-SIM-R34.md | Root cause ladder: group deduplicated gaps by Level 3 root cause; collapse to session count | SK-432 §Cross-gap convergence |

---

## STEP TABLE FORMAT (inline in every session file — no external reference)

```
| Step | What must happen | Handler | Input ✅/⚠️/❌ | Output expected | Actual | Gap? |
```

Handler valid values (literal — do not write "the engine"):
  ai-generate.handler | validate.handler | route.handler | rag-retrieve.handler
  feedback.handler    | score.handler    | [IFabricInterface].method
  HUMAN               | NONE

Actual valid verdicts: WORKS | PARTIAL | BREAKS | WRONG | SILENT_FAILURE

Gap format when BREAKS/WRONG/SILENT_FAILURE:
  GAP ID:    [class]-[n] (e.g. J1-1, E-3, K2-1)
  ROOT CAUSE: one sentence
  FIX CLASS: CONTENT | INTERFACE | EXTENSION | NEW_HANDLER | INFRASTRUCTURE

---

## SELF-CONTAINMENT RULE (applied to every session file)
- Zero cross-references ("see SK-441", "per the doc", "per group E rule")
- All handler names literal (from table above)
- All verdict words from the five-value vocabulary
- ISSUE INVENTORY block before every ⛔ STOP

---

## ARTIFACT NUMBERS (live from STATE.json 2026-03-27)
```
Next Factory: F1518  Next Task Type: T587  Next BFA Rule: CF-797
Next Skill: SK-520   Test baseline: 5800   (5580 server + 220 client)
```

---

## OUTPUT CONTRACT PER ROUND
Done = SESSION-SIM-RN.md contains:
  (a) one complete step table for the scenario, OR one synthesis output
  (b) every step's input marked ✅/⚠️/❌
  (c) every gap in GAP-ID format
  (d) ISSUE INVENTORY before ⛔ STOP
File is zipped and presented. Plan does not change after R0.
