# SESSION-SIM-R0.md
## Round: R0 | Scenario: E9 | Depth: L1
## Action: Verify xiigen-decision-graph + xiigen-planning-decisions fixture files exist
## Source: XIIGEN-SIMULATION-METHODOLOGY.md §1 GROUP E — scenario E9
## RULE: This check runs FIRST. No Layer 2 simulation is valid without these indices.
## Self-contained: all commands literal, zero cross-references

---

## CONTEXT
```bash
export BASE_DIR="."   # ← project root (contains server/)
```

---

## WHY THIS RUNS FIRST (inline — no external reference)

The planning layer simulation rounds (R1–R8, R9–R32) write to and read from two
Elasticsearch indices:
  - xiigen-decision-graph     (graph edges: seeded at Phase A, queried by BootstrapCycleRouter)
  - xiigen-planning-decisions (planning DPO triples: written at Phase B/C/F)

If fixture files for these indices do not exist in server/src/rag-init/fixtures/,
Phase A seeding has no index to write to. ALL downstream simulation steps that
touch either index will silently succeed or fail with misleading errors.

A gap found in R1–R32 against a missing index is NOT a planning-layer gap —
it is an infrastructure gap (class H). Raising a J-class or K-class gap against
a broken infrastructure produces wrong root causes.

This round MUST complete GREEN before any other round runs.

---

## STEP TABLE

| Step | What must happen | Handler | Input ✅/⚠️/❌ | Output expected | Actual | Gap? |
|------|-----------------|---------|---------------|----------------|--------|------|
| 1 | List fixture files in server/src/rag-init/fixtures/ | validate.handler | server/src/rag-init/fixtures/ directory ✅/❌ | File listing | see STEP 1 | see below |
| 2 | Confirm xiigen-decision-graph fixture exists | validate.handler | fixture file for decision-graph ✅/❌ | PASS or GAP-SIM-1 raised | see STEP 2 | see below |
| 3 | Confirm xiigen-planning-decisions fixture exists | validate.handler | fixture file for planning-decisions ✅/❌ | PASS or GAP-SIM-2 raised | see STEP 3 | see below |
| 4 | Confirm ES index live (if ES running) | [IDatabaseService].searchDocuments | localhost:9200 ✅/⚠️/❌ | index exists or not-yet-created | see STEP 4 | informational |

---

## STEP 1 — List fixture files

```bash
echo "=== Fixture directory contents ==="
ls -la "$BASE_DIR"/server/src/rag-init/fixtures/ 2>/dev/null \
  && echo "✅ STEP 1: Fixture directory exists" \
  || echo "❌ STEP 1 FAIL: server/src/rag-init/fixtures/ not found — raise H-class blocking gap"
```

---

## STEP 2 — xiigen-decision-graph fixture

```bash
GRAPH_FIX=$(find "$BASE_DIR"/server/src/rag-init/fixtures/ \
  -name "*decision-graph*" 2>/dev/null | wc -l)

[ "$GRAPH_FIX" -gt 0 ] \
  && echo "✅ STEP 2: xiigen-decision-graph fixture found ($GRAPH_FIX file(s))" \
  || echo "❌ STEP 2 FAIL: xiigen-decision-graph fixture MISSING"

find "$BASE_DIR"/server/src/rag-init/fixtures/ -name "*decision-graph*" 2>/dev/null
```

**Gate:** GRAPH_FIX > 0 required. RED → raise GAP-SIM-1 (see below), STOP.

---

## STEP 3 — xiigen-planning-decisions fixture

```bash
PLAN_FIX=$(find "$BASE_DIR"/server/src/rag-init/fixtures/ \
  -name "*planning-decisions*" 2>/dev/null | wc -l)

[ "$PLAN_FIX" -gt 0 ] \
  && echo "✅ STEP 3: xiigen-planning-decisions fixture found ($PLAN_FIX file(s))" \
  || echo "❌ STEP 3 FAIL: xiigen-planning-decisions fixture MISSING"

find "$BASE_DIR"/server/src/rag-init/fixtures/ -name "*planning-decisions*" 2>/dev/null
```

**Gate:** PLAN_FIX > 0 required. RED → raise GAP-SIM-2 (see below), STOP.

---

## STEP 4 — ES live index check (informational)

```bash
CODE_GRAPH=$(curl -sf -o /dev/null -w "%{http_code}" \
  "localhost:9200/xiigen-decision-graph" 2>/dev/null || echo "000")
CODE_PLAN=$(curl -sf -o /dev/null -w "%{http_code}" \
  "localhost:9200/xiigen-planning-decisions" 2>/dev/null || echo "000")

echo "xiigen-decision-graph     HTTP: $CODE_GRAPH (200=exists, 404=not yet, 000=ES not running)"
echo "xiigen-planning-decisions HTTP: $CODE_PLAN  (200=exists, 404=not yet, 000=ES not running)"
echo ""
echo "Note: 404 or 000 here is NOT a blocking gap if fixture files passed STEP 2-3."
echo "      Index is created from fixtures at Phase A seed time."
echo "      000 means ES not running — start docker compose before R1 execution rounds."
```

---

## GAP DEFINITIONS (if any step RED)

```
GAP-SIM-1
GAP ID:     H-1
NAME:       xiigen-decision-graph fixture missing
FOUND IN:   E9, Step 2
ALSO HITS:  E1, E2, E3, A1, A3, R2–R32 (all Layer 2 sim rounds)

ROOT CAUSE: No fixture file exists for xiigen-decision-graph index.
            Phase A seeding curl commands have no index to write to.
            BootstrapCycleRouter queries return zero results — falls
            back to hardcoded defaults silently.

SYMPTOM:    Phase A seeding "succeeds" (curl returns 201) but the
            index is created ad-hoc without correct keyword mapping
            → term queries in R1 (E1) return zero results.
SYMPTOM_TEST: If fixture file created with correct mapping: E1 WORKS.

CATEGORY:   INFRASTRUCTURE
FIX CLASS:  INFRASTRUCTURE
BLOCKED BY: none
UNBLOCKS:   E1, E2, E3 (all J-class gap traces)

FIX:
  Create server/src/rag-init/fixtures/xiigen-decision-graph.json with:
  {
    "settings": { "number_of_shards": 1 },
    "mappings": {
      "properties": {
        "fromEntity":     { "type": "keyword" },
        "relationship":   { "type": "keyword" },
        "toEntity":       { "type": "keyword" },
        "confidence":     { "type": "float" },
        "observationCount":{ "type": "integer" },
        "immutable":      { "type": "boolean" },
        "source":         { "type": "keyword" },
        "reasoning":      { "type": "text" }
      }
    }
  }
  Note: fromEntity/relationship/toEntity MUST be "keyword" not "text".
  If "text": term queries return zero results. This is gap J4 on top of H-1.

---

GAP-SIM-2
GAP ID:     H-2
NAME:       xiigen-planning-decisions fixture missing
FOUND IN:   E9, Step 3
ALSO HITS:  R11, R14–R32 (all Phase B/C/F DPO triple simulation rounds)

ROOT CAUSE: No fixture file for xiigen-planning-decisions.
            Phase C CALIBRATION_COMPARISON triples have no index.
            Phase F OUTCOME_PENDING → VALIDATED upgrade has no index.
            Addition 14 F3-L2-7 guard correctly blocks with H-class gap.

SYMPTOM_TEST: If fixture created: Phase C/F DPO write rounds WORK.

CATEGORY:   INFRASTRUCTURE
FIX CLASS:  INFRASTRUCTURE
```

---

## R0 SUMMARY

```bash
echo "=== E9 SUMMARY ==="
[ "$GRAPH_FIX" -gt 0 ] && echo "STEP 2: GREEN" || echo "STEP 2: RED — GAP H-1 raised"
[ "$PLAN_FIX"  -gt 0 ] && echo "STEP 3: GREEN" || echo "STEP 3: RED — GAP H-2 raised"
echo ""
echo "STEP 2 GREEN AND STEP 3 GREEN → proceed to R1 (E1 ES mapping trace)"
echo "ANY RED → fix infrastructure first. All other rounds are invalid until GREEN."
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (populate from steps above) | — | — |

⛔ STOP — STEP 2 and STEP 3 must both be GREEN before R1 begins.
