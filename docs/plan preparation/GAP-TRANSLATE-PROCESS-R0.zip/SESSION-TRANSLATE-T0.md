# SESSION-TRANSLATE-T0.md
## Round: T0 | Phase: PARSE
## Action: Read FLOW-XX-ENGINE-GAP-LIST.md → extract all gap entries
##         into structured JSON registry
## Output: FLOW-XX-GAP-REGISTRY.json
## Self-contained: all commands literal, zero cross-references

---

## CONFIGURE
```bash
export GAP_DOC="path/to/FLOW-XX-ENGINE-GAP-LIST.md"   # ← set to actual path
export FLOW_ID="FLOW-XX"                                # ← e.g. FLOW-02
export OUT_DIR="sessions/${FLOW_ID}"
mkdir -p "$OUT_DIR"
export OUT="${OUT_DIR}/${FLOW_ID}-GAP-REGISTRY.json"
```

---

## WHY FIRST (inline)
The gap doc is human-authored markdown. Every subsequent round (T1, T2, session files)
needs the gap data in a queryable form — severity, layer, file, fix text.
Without a registry: T1 would parse the same markdown multiple times → drift risk.
T0 parses once; T1–TN read the JSON.

---

## STEP 1 — Verify gap doc has required sections

```bash
echo "=== Gap doc structure check ==="
for section in "PRIORITY" "LAYER 1" "EXECUTION ORDER" "SUMMARY TABLE"; do
  grep -q "$section" "$GAP_DOC" \
    && echo "✅ Section found: $section" \
    || echo "❌ MISSING section: $section — gap doc may be incomplete"
done

echo ""
echo "Total lines: $(wc -l < "$GAP_DOC")"
echo "Gap entry count (### GAP- headers):"
grep -c "^### GAP-\|^### ENG-\|^### SES-\|^### CHK-\|^### SEED-\|^### GOV-\|^### DATA-\|^### FILES-" \
  "$GAP_DOC" 2>/dev/null || echo "0"
```

---

## STEP 2 — Extract summary table rows (primary registry source)

```bash
echo "=== Extracting summary table ==="
# The summary table is the canonical source — it has one row per gap with:
# | ID | Layer | Description | Severity | Scope | Before |
node - <<'JSEOF'
import re, json, os

gap_doc = os.environ['GAP_DOC']
with open(gap_doc) as f:
    content = f.read()

# Find summary table section
table_match = re.search(
    r'## SUMMARY TABLE.*?\n\|(.*?)\n\|([-|]+)\n(.*?)(?=\n##|\Z)',
    content, re.DOTALL
)

if not table_match:
    print("❌ SUMMARY TABLE not found — check doc format")
    exit(1)

header_raw = table_match.group(1)
rows_raw = table_match.group(3)

# Parse header
headers = [h.strip() for h in header_raw.split('|') if h.strip()]
print(f"Headers: {headers}")

# Parse rows
gaps = []
for row in rows_raw.strip().split('\n'):
    if not row.startswith('|'):
        continue
    cells = [c.strip() for c in row.split('|') if c.strip()]
    if len(cells) >= 4:
        gap = dict(zip(headers, cells))
        gaps.append(gap)
        print(f"  Parsed: {gap.get('ID','?')} | {gap.get('Severity','?')} | {gap.get('Layer','?')}")

print(f"\nTotal gaps extracted from summary table: {len(gaps)}")

# Write registry
registry = {
    "flowId": os.environ.get('FLOW_ID', 'FLOW-XX'),
    "source": os.environ.get('GAP_DOC', ''),
    "total_gaps": len(gaps),
    "gaps": gaps
}
out = os.environ.get('OUT', 'gap-registry.json')
os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
with open(out, 'w') as f:
    json.dump(registry, f, indent=2)
print(f"\nWritten: {out}")
JSEOF
```

---

## STEP 3 — Enrich registry with gap body fields (Problem, Impact, Fix, File path)

```bash
node - <<'JSEOF'
import re, json, os

gap_doc = os.environ['GAP_DOC']
out = os.environ.get('OUT', 'gap-registry.json')

with open(gap_doc) as f:
    content = f.read()

registry = json.load(open(out))

# Parse each gap body section (### GAP-XX-N ... through next ### or ##)
# Support both naming patterns:
#   FLOW-01: ### ENG-01: `file` — name
#   FLOW-04: ### GAP-ENG-1 🔴 `file` — name
gap_sections = re.findall(
    r'^###\s+((?:GAP-)?[A-Z]+-\d+[^#\n]*?)\n(.*?)(?=^###|\Z)',
    content, re.MULTILINE | re.DOTALL
)

body_map = {}
for header, body in gap_sections:
    # Normalize gap ID: "ENG-01: `file`" → "ENG-01", "GAP-ENG-1 🔴 `file`" → "GAP-ENG-1"
    id_match = re.match(r'((?:GAP-)?[A-Z]+-\d+)', header.strip())
    if not id_match:
        continue
    raw_id = id_match.group(1)

    problem_m = re.search(r'\*\*Problem:\*\*\s*(.*?)(?=\*\*[A-Z]|\Z)', body, re.DOTALL)
    impact_m  = re.search(r'\*\*Impact:\*\*\s*(.*?)(?=\*\*[A-Z]|\Z)',  body, re.DOTALL)
    fix_m     = re.search(r'\*\*Fix.*?:\*\*\s*(.*?)(?=\*\*[A-Z]|^---|\Z)', body, re.DOTALL)
    scope_m   = re.search(r'\*\*Scope:\*\*\s*(.*?)(?=\n|\Z)',           body)
    file_m    = re.search(r'\*\*File:\*\*\s*`?([^`\n]+)`?',             body)

    body_map[raw_id] = {
        "problem": problem_m.group(1).strip()[:300] if problem_m else "",
        "impact":  impact_m.group(1).strip()[:300]  if impact_m  else "",
        "fix_excerpt": fix_m.group(1).strip()[:500] if fix_m     else "",
        "scope":   scope_m.group(1).strip()         if scope_m   else "",
        "file":    file_m.group(1).strip()           if file_m    else "",
    }

# Merge into registry gaps
enriched = 0
for gap in registry['gaps']:
    raw_id = gap.get('ID', '')
    # Try direct match, then try without GAP- prefix
    body = body_map.get(raw_id) or body_map.get(raw_id.replace('GAP-',''))
    if body:
        gap.update(body)
        enriched += 1
    else:
        # Fallback: try partial match
        for k, v in body_map.items():
            if raw_id.endswith(k) or k.endswith(raw_id.split('-')[-1]):
                gap.update(v)
                enriched += 1
                break

print(f"Enriched {enriched}/{len(registry['gaps'])} gaps with body fields")

with open(out, 'w') as f:
    json.dump(registry, f, indent=2)
print(f"Updated: {out}")
JSEOF
```

---

## STEP 4 — Extract execution order from gap doc

```bash
node - <<'JSEOF'
import re, json, os

gap_doc = os.environ['GAP_DOC']
out = os.environ.get('OUT', 'gap-registry.json')
with open(gap_doc) as f:
    content = f.read()

# Find execution order / priority section
exec_match = re.search(
    r'(?:##\s+(?:PRIORITY-ORDERED EXECUTION SEQUENCE|EXECUTION ORDER SUMMARY))(.*?)(?=\n##|\Z)',
    content, re.DOTALL
)

registry = json.load(open(out))
if exec_match:
    registry['execution_order_raw'] = exec_match.group(1).strip()
    print("✅ Execution order section found and stored")
    print(registry['execution_order_raw'][:500])
else:
    print("⚠️  No execution order section found — T1 will derive order from severity fields")
    registry['execution_order_raw'] = ""

# Also store deferred gaps (ADVISORY)
advisory = [g for g in registry['gaps']
            if '⬜' in g.get('Severity','') or 'ADVISORY' in g.get('Severity','')]
registry['advisory_deferred'] = [g.get('ID','') for g in advisory]
print(f"\nADVISORY (will be deferred): {registry['advisory_deferred']}")

with open(out, 'w') as f:
    json.dump(registry, f, indent=2)
print(f"Updated: {out}")
JSEOF
```

---

## STEP 5 — Verify registry completeness

```bash
node - <<'JSEOF'
import json, os
out = os.environ.get('OUT', 'gap-registry.json')
reg = json.load(open(out))

print(f"=== {reg.get('flowId','?')} GAP REGISTRY SUMMARY ===")
print(f"Total gaps:      {reg['total_gaps']}")
print(f"Advisory/defer:  {len(reg.get('advisory_deferred',[]))}")
print(f"Actionable:      {reg['total_gaps'] - len(reg.get('advisory_deferred',[]))}")
print()

severity_counts = {}
layer_counts = {}
for g in reg['gaps']:
    sev = g.get('Severity','?')
    lay = g.get('Layer','?')
    severity_counts[sev] = severity_counts.get(sev, 0) + 1
    layer_counts[lay] = layer_counts.get(lay, 0) + 1

print("By severity:")
for k, v in sorted(severity_counts.items()):
    print(f"  {k}: {v}")
print("By layer:")
for k, v in sorted(layer_counts.items()):
    print(f"  {k}: {v}")
print()
print(f"Execution order raw: {'YES' if reg.get('execution_order_raw') else 'NO (derived in T1)'}")
print()
# Check all gaps have minimum fields
missing_fields = [g['ID'] for g in reg['gaps']
                  if not g.get('problem') and not g.get('fix_excerpt')]
if missing_fields:
    print(f"⚠️  Gaps missing body enrichment (manual check needed): {missing_fields}")
else:
    print("✅ All gaps enriched with body fields")
print()
print("→ Proceed to T1 (build block plan + dependency map)")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (populate from steps above) | — | — |

⛔ STOP — `FLOW-XX-GAP-REGISTRY.json` written with all gaps and execution order.
Report: total gaps, actionable count, advisory count in approval message.
