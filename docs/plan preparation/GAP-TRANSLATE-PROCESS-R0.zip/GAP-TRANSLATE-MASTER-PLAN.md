# GAP-TRANSLATE-MASTER-PLAN.md
## Process: How to translate ANY FLOW-XX-ENGINE-GAP-LIST.md
##          into a complete FLOW-XX-GAPS-MASTER-PLAN.md + all SESSION-GAP-RN.md files
## Derived from: FLOW-01 and FLOW-04 gap doc translation (2026-03-27)
## Session type: PLANNING
## Cadence: one round at a time — ⛔ STOP after each file presented, await "yes"

---

## MULTI-STACK USAGE POLICY
> **Primary stack: NestJS + React only.**
> All code generation, session files, and engine development targets NestJS (server)
> and React (client) exclusively.
>
> Any simulation round that references an alternative stack (e.g. Laravel, WordPress,
> a legacy language, or a different framework) has **one purpose only:**
> **discovering missing engine capabilities** — interfaces, abstractions, or assumptions
> baked into the engine that would break or degrade when the engine encounters that stack.
>
> The output of those rounds is always an **engine gap** (a missing interface, a hardcoded
> assumption, a check that only works for NestJS). It is never code written in that stack,
> never a session file targeting that stack, and never a gap fix in that stack.
>
> If a simulation round finds a gap via a non-NestJS trace → the fix goes into the
> NestJS engine (e.g. make the check stack-neutral, add an abstraction layer).


## FIXED PROMPT REMINDER (top priority — must appear in every round)
**Q1:** PLANNING session type
**Cadence:** One session file per response. ⛔ STOP after present_files. Await "yes".
**Output contract:** ONE SESSION-TRANSLATE-TN.md per round, self-contained, zipped, presented.
**This prompt is the top priority and must be honored in every round.**

---

## HOW TO USE
1. Set `GAP_DOC="path/to/FLOW-XX-ENGINE-GAP-LIST.md"` in T0
2. Run T0 → T1 → T2 → T3 in order (each produces an intermediate artifact)
3. T3+ produce the actual session files — one per gap, in block order
4. The final output is `FLOW-XX-GAPS-MASTER-PLAN.md` + all `SESSION-GAP-RN.md` files

---

## ROUND TABLE

### Preparation rounds (T0–T3): produce the master plan

| Round | File | One action | Output |
|-------|------|-----------|--------|
| T0 | SESSION-TRANSLATE-T0.md | Parse gap doc → extract all gap entries into structured JSON registry | `FLOW-XX-GAP-REGISTRY.json` |
| T1 | SESSION-TRANSLATE-T1.md | Apply execution order → assign priority blocks + detect ADVISORY deferrals + build dependency map | `FLOW-XX-BLOCK-PLAN.json` |
| T2 | SESSION-TRANSLATE-T2.md | Write `FLOW-XX-GAPS-MASTER-PLAN.md` from block plan | `FLOW-XX-GAPS-MASTER-PLAN.md` ✅ |

### Session file rounds (T3+): one session file per gap, in block order

| Round | File | One action | Output |
|-------|------|-----------|--------|
| T3 | SESSION-TRANSLATE-T3.md | Write Block 1 Round 0 session file (first SILENT_FAILURE or first verify gap) | `SESSION-GAP-R0.md` |
| T4 | SESSION-TRANSLATE-T4.md | Write Block 1 Round 1 session file | `SESSION-GAP-R1.md` |
| T5 | SESSION-TRANSLATE-T5.md | Write Block 1 Round 2 session file | `SESSION-GAP-R2.md` |
| … | … | Continue in block order until all non-deferred gaps have session files | … |
| TN | SESSION-TRANSLATE-TN.md | Write final session file (last non-deferred gap) | `SESSION-GAP-R(N-3).md` |

**Total rounds = 3 (prep) + count(non-deferred gaps)**

---

## TRANSLATION RULES — what each gap entry field becomes

### From the gap doc summary table row:
```
| ID | Layer | Description | Severity | Scope | Before |
```

| Gap field | → Master plan usage | → Session file usage |
|-----------|--------------------|--------------------|
| `ID` | Round file name: `SESSION-GAP-RN.md` | Header: `Gap ID: ENG-01` |
| `Layer` | Block assignment + session structure type | Determines step sequence (see LAYER MAP) |
| `Description` | Round table "One action" column | Header `## Action:` line |
| `Severity` | Block assignment (🔴→Block1, 🟠→Block2, 🟡→Block3, ⬜→DEFERRED) | Header severity line |
| `Scope` | Round table "File changed" column | `## CONTEXT` file path vars |
| `Before` | Block label (e.g. "FLOW-04 Phase B" → "Block 2") | `## WHY FIRST` deadline statement |

### From the gap entry body:
```
### GAP-XX-N emoji `file` — name
**Problem:** ...
**Impact:** ...
**Fix:** code/curl block
**Scope:** ...
```

| Gap body field | → Session file section |
|----------------|----------------------|
| `Problem` | `## WHY FIRST` — inline explanation (no cross-reference) |
| `Impact` | `## WHY FIRST` — downstream effect (SILENT/BREAKS/PARTIAL) |
| `Fix` code block | Steps containing the exact change (BEFORE/AFTER or curl) |
| `Scope` line count | Step header comment `(~N lines)` |

---

## LAYER MAP — session file structure per gap layer

### Layer 1: TypeScript (GAP-ENG-N)
```
## CONTEXT      → export FILE="server/src/path/to/file.ts"
## WHY FIRST    → Impact inline (from gap body Impact field)
## STEP 1       → grep to locate function/interface + line numbers
## STEP 2       → exact BEFORE block (what exists now)
                → exact AFTER block (what to replace with)
## STEP 3       → compile check: cd server && npx tsc --noEmit
## STEP 4       → test gate: npx jest | tail -5 (failures === 0)
## STEP 5       → verification: grep confirms change present
## ISSUE INVENTORY + ⛔ STOP
```

### Layer 2: Session Files — Bash amendment (GAP-SES-N, GAP-SESSION-N)
```
## CONTEXT      → export SESSION_FILE="sessions/FLOW-XX/SESSION-N.md"
## WHY FIRST    → what FC check fails if missing (FC-29 / V9-003 etc.)
## STEP 1       → grep to find existing ⛔ STOP markers (count)
## STEP 2       → grep to find insertion point (before/after which step)
## STEP 3       → exact text block to INSERT (FOUND-ISSUE PROTOCOL / V9 loop / etc.)
## STEP 4       → verification: grep confirms block present + FC-29 count matches
## ISSUE INVENTORY + ⛔ STOP
```

### Layer 3: Named Check Catalog (GAP-CHK-N)
```
## CONTEXT      → export VALIDATE="server/src/.../validate.handler.ts"
## WHY FIRST    → which archetype, WRONG vs CORRECT pattern, silent impact
## STEP 1       → grep to locate NAMED_CHECKS object in validate.handler.ts
## STEP 2       → exact TypeScript object entry to add (key + regex/fn + message)
## STEP 3       → compile check: npx tsc --noEmit
## STEP 4       → test gate: npx jest | tail -5 (failures === 0)
## STEP 5       → verification: grep confirms key present in NAMED_CHECKS
## DEPENDENCY NOTE (if depends on ENG layer — e.g. CHK-02 needs ENG-02)
## ISSUE INVENTORY + ⛔ STOP
```

### Layer 4: Graph Seeding (GAP-SEED-N)
**Sub-type A — already present, verify only:**
```
## CONTEXT      → export SESSION_A="path/to/SESSION-A.md"
## WHY FIRST    → SILENT_FAILURE if missing (corrupt routing decisions)
## STEP 1       → find SESSION-A.md
## STEP 2       → grep for each expected edge (fromEntity strings)
## STEP 3       → ES live count (informational — 0 ok if Phase A not run yet)
## STEP 4       → verdict: GREEN (both present) or RED (add curl block)
## GAP DEFINITIONS (if RED — exact curl commands to add)
## ISSUE INVENTORY + ⛔ STOP
```
**Sub-type B — must write curl commands:**
```
## CONTEXT      → export SESSION_A="path/to/FLOW-XX-SESSION-A.md"
## WHY FIRST    → which edges, why before Phase B
## STEP 1       → check target session file exists
## STEP 2       → exact curl PUT commands for each edge (from gap Fix block)
## STEP 3       → insertion point in SESSION-A (which step number)
## STEP 4       → ES verification after seeding
## ISSUE INVENTORY + ⛔ STOP
```

### Layer 5 / Data: Topology + Architecture JSON (GAP-DATA-N)
```
## CONTEXT      → export TARGET="contracts/topologies/FLOW-XX.topology.json"
## WHY FIRST    → what breaks if nodes missing (0 triples / handler never fires)
## STEP 1       → read current file state (node -e "import json; ...")
## STEP 2       → exact JSON patch (what section to add/update)
## STEP 3       → verification: node reads file, counts nodes/decisions
## ISSUE INVENTORY + ⛔ STOP
```

### Layer 6: New Files (GAP-FILES-N)
```
## CONTEXT      → export TARGET_DIR="contracts/tests/cross-flow/"
## WHY FIRST    → which boundary, what invariants, when needed
## STEP 1       → check file doesn't already exist
## STEP 2       → exact file content (from gap Fix block — verbatim)
## STEP 3       → verification: file exists + npx jest runs it (stubs pass)
## ISSUE INVENTORY + ⛔ STOP
```

### Layer 7: Governance (GAP-GOV-N)
```
## CONTEXT      → export TARGET="path/to/AGENTS.md or SKILL.md"
## WHY FIRST    → which rule missing, which failure recurs without it
## STEP 1       → locate insertion point (grep for section header)
## STEP 2       → exact text block to add (from gap Fix block — verbatim)
## STEP 3       → verification: grep confirms text present
## ISSUE INVENTORY + ⛔ STOP
```

---

## BLOCK ASSIGNMENT RULES (used in T1)

```
Priority in gap doc          → Block label
─────────────────────────────────────────────────────────
SILENT_FAILURE (🔴)          → Block 1 — fix before any execution re-run
BREAKS (🟠)                  → Block 2 — fix before target flow Phase B
PARTIAL (🟡)                 → Block 3 — fix before next wave
ADVISORY (⬜)                → DEFERRED — not in plan; add to deferred section
"Already done ✅"            → Block 1 Round 0 — verify-only session file
```

**Block label from "Before" field:**
```
"Before" field value              → Block label
──────────────────────────────────────────────────
"FLOW-XX" (current flow)          → Block 1 — FLOW-XX BEFORE EXECUTE
"FLOW-YY" (later flow)            → Block 2 — FLOW-YY BEFORE EXECUTE
"Wave N" / "FLOW-NN+"             → Block 3 — WAVE N BEFORE EXECUTE
"FLOW-XX+" / "process"            → Block 4 — GOVERNANCE (parallel-safe)
```

---

## DEPENDENCY RULE (used in T1)

A dependency exists when the gap body contains any of:
- "Note: [GAP-ID] can only be enforced after [other-GAP-ID]"
- "Requires [other-GAP-ID]"
- "after ENG-0N" / "after R[N]"
- "must exist before"

Record each dependency as: `GAP-A → GAP-B` (GAP-B cannot start until GAP-A's round is done).

---

## DEFERRED RULE (used in T1)

An ADVISORY gap (⬜) is never assigned a round. Instead:
```
## DEFERRED (not in this plan)
GAP-ENG-4 ⬜ file.ts: [name]
  Status: ADVISORY — [why current behavior handles it today]
  Implement: [condition that triggers this work]
```

---

## TEST GATE RULE (inline in every TypeScript session file)
```bash
cd server && npx jest 2>&1 | tail -5   # failures must === 0
# Baseline: [from CLAUDE.md artifactBoundaries.testBaseline]
```
TypeScript rounds only (Layer 1 + Layer 3). Not required for bash/JSON/governance rounds.

---

## SELF-CONTAINMENT RULE (every session file)
- Zero cross-references ("see gap list", "per SK-441", "per Option B")
- All file paths literal (relative to project root)
- TypeScript: exact BEFORE/AFTER lines, never "find the function and add..."
- Bash: literal commands, all vars exported in same file
- JSON patches: exact node/jq command with full structure
- FOUND-ISSUE PROTOCOL + ISSUE INVENTORY before every ⛔ STOP

---

## OUTPUT CONTRACT PER ROUND
Done = one file zipped and presented.
  T0: FLOW-XX-GAP-REGISTRY.json
  T1: FLOW-XX-BLOCK-PLAN.json
  T2: FLOW-XX-GAPS-MASTER-PLAN.md ← the plan document
  T3+: SESSION-GAP-RN.md ← one fixing session file per gap
