# SESSION-TRANSLATE-T3.md
## Round: T3 | Phase: WRITE FIRST SESSION FILE (R0)
## Action: Read R0 gap entry from block plan → write SESSION-GAP-R0.md
##         using the layer-appropriate template
## Output: SESSION-GAP-R0.md
## Self-contained: all commands literal, zero cross-references

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export OUT_DIR="sessions/${FLOW_ID}"
export BLOCK_PLAN="${OUT_DIR}/${FLOW_ID}-BLOCK-PLAN.json"
export REGISTRY="${OUT_DIR}/${FLOW_ID}-GAP-REGISTRY.json"
export OUT="${OUT_DIR}/SESSION-GAP-R0.md"
export BASE_DIR="."
```

---

## STEP 1 — Read the R0 gap entry

```bash
node - <<'JSEOF'
import json, os
plan = json.load(open(os.environ['BLOCK_PLAN']))
reg  = json.load(open(os.environ['REGISTRY']))

# Find R0
r0 = next((r for r in plan['rounds'] if r.get('round') == 'R0'), None)
if not r0:
    print("❌ R0 not found in block plan")
    exit(1)

# Enrich from registry
full = next((g for g in reg['gaps'] if g['ID'] == r0['ID']), r0)
r0.update({k:v for k,v in full.items() if v and k not in r0})

print(f"R0 gap: {r0['ID']}")
print(f"Layer:  {r0.get('Layer','?')}")
print(f"Severity: {r0.get('severity_normalized','?')}")
print(f"File:   {r0.get('file','?')}")
print(f"Action: {r0.get('Description','?')}")
print()
print("Problem (first 200 chars):")
print(r0.get('problem','?')[:200])
print()
print("Fix excerpt (first 300 chars):")
print(r0.get('fix_excerpt','?')[:300])
JSEOF
```

---

## STEP 2 — Select session template by layer and write R0

```bash
node - <<'JSEOF'
import json, os

plan = json.load(open(os.environ['BLOCK_PLAN']))
reg  = json.load(open(os.environ['REGISTRY']))
flow_id  = os.environ['FLOW_ID']
out_path = os.environ['OUT']
base_dir = os.environ.get('BASE_DIR', '.')

r0 = next((r for r in plan['rounds'] if r.get('round') == 'R0'), None)
full = next((g for g in reg['gaps'] if g['ID'] == r0['ID']), r0)
r0.update({k:v for k,v in full.items() if v and k not in r0})

gap_id   = r0['ID']
layer    = r0.get('Layer', '')
sev      = r0.get('severity_normalized', 'PARTIAL')
file_    = r0.get('file', '[FILE PATH]')
problem  = r0.get('problem', '[problem]')
impact   = r0.get('impact', '[impact]')
fix_text = r0.get('fix_excerpt', '[fix steps]')
scope    = r0.get('Scope', '[scope]')
desc     = r0.get('Description', '[description]')

# Severity icon
icon = {'SILENT_FAILURE':'🔴','BREAKS':'🟠','PARTIAL':'🟡','VERIFY':'✅',
        'GOVERNANCE':'⬜','ADVISORY':'⬜'}.get(sev, '')

# Determine layer type
def is_typescript(l): return 'typescript' in l.lower() or 'eng' in gap_id.lower()
def is_session(l):    return 'session' in l.lower()
def is_check(l):      return 'check' in l.lower() or 'chk' in gap_id.lower()
def is_seed(l):       return 'seed' in l.lower()
def is_data(l):       return 'data' in l.lower() or 'topology' in l.lower()
def is_files(l):      return 'file' in l.lower()
def is_gov(l):        return 'gov' in l.lower() or 'govern' in l.lower()

with open(out_path, 'w') as f:
    # Universal header
    f.write(f"# SESSION-GAP-R0.md\n")
    f.write(f"## Round: R0 | Gap: {gap_id} {icon} {sev}\n")
    f.write(f"## Action: {desc}\n")
    f.write(f"## File: {file_}\n")
    f.write(f"## Self-contained: all commands literal, zero cross-references\n\n---\n\n")

    # CONTEXT section
    f.write("## CONTEXT\n```bash\nexport BASE_DIR=\".\"\n")
    if file_ and file_ != '[FILE PATH]':
        varname = "TARGET_FILE"
        f.write(f"export {varname}=\"$BASE_DIR/{file_}\"\n")
    f.write("```\n\n---\n\n")

    # WHY FIRST
    f.write("## WHY FIRST (inline)\n")
    f.write(f"{problem}\n\n")
    f.write(f"**Without this fix:** {impact}\n\n---\n\n")

    # Layer-specific steps
    if is_typescript(layer):
        f.write("## STEP 1 — Locate the target function/interface\n\n")
        f.write(f"```bash\necho '=== Locating in {file_} ==='\n")
        f.write(f"grep -n 'interface\\|class\\|function\\|export' \"$TARGET_FILE\" | head -20\n```\n\n---\n\n")
        f.write("## STEP 2 — Apply the change\n\n")
        f.write("Based on STEP 1 line numbers, apply:\n\n")
        f.write(f"```typescript\n// FROM GAP BODY — exact change:\n{fix_text[:600]}\n```\n\n---\n\n")
        f.write("## STEP 3 — Compile check\n\n")
        f.write("```bash\ncd \"$BASE_DIR/server\" && npx tsc --noEmit 2>&1 | grep 'error TS' | head -10\n# Expected: 0 errors\n```\n\n---\n\n")
        f.write("## STEP 4 — Test gate (P19 absolute)\n\n")
        f.write("```bash\ncd \"$BASE_DIR/server\" && npx jest 2>&1 | tail -5\n# Expected: failures === 0\n```\n\n---\n\n")
        f.write("## STEP 5 — Verification\n\n")
        f.write("```bash\necho '=== Change confirmed ==='\ngrep -n '[KEY TERM FROM FIX]' \"$TARGET_FILE\" | head -5\n# Expected: 1+ hits\n```\n\n---\n\n")

    elif is_session(layer):
        f.write("## STEP 1 — Locate target session file and find ⛔ STOP markers\n\n")
        f.write(f"```bash\nSESSION_FILE=$(find \"$BASE_DIR\" -name '*SESSION*{file_.split('/')[-1]}*' | head -1)\n")
        f.write("STOPS=$(grep -c '⛔ STOP' \"$SESSION_FILE\" 2>/dev/null || echo 0)\n")
        f.write("INV=$(grep -c 'ISSUE INVENTORY' \"$SESSION_FILE\" 2>/dev/null || echo 0)\n")
        f.write("echo \"⛔ STOPs: $STOPS | ISSUE INVENTORYs: $INV\"\n```\n\n---\n\n")
        f.write("## STEP 2 — Find insertion point\n\n")
        f.write("```bash\ngrep -n '⛔ STOP\\|STEP [0-9]' \"$SESSION_FILE\" | head -20\n```\n\n---\n\n")
        f.write("## STEP 3 — Insert the amendment\n\n")
        f.write(f"```bash\n# Amendment to apply:\n# {fix_text[:400]}\n```\n\n---\n\n")
        f.write("## STEP 4 — Verification\n\n")
        f.write("```bash\ngrep -c 'ISSUE INVENTORY' \"$SESSION_FILE\"\n# Expected: equals ⛔ STOP count\n```\n\n---\n\n")

    elif is_seed(layer):
        f.write("## STEP 1 — Locate SESSION-A.md\n\n")
        f.write(f"```bash\nfind \"$BASE_DIR\" -name '*SESSION-A*' 2>/dev/null | grep -v '.git'\n```\n\n---\n\n")
        f.write("## STEP 2 — Verify or seed the edges\n\n")
        f.write(f"```bash\n# Verify content from gap fix block:\n{fix_text[:400]}\n```\n\n---\n\n")
        f.write("## STEP 3 — ES live verification\n\n")
        f.write("```bash\ncurl -sf 'localhost:9200/xiigen-decision-graph/_count' | node -c \"import sys,json; print(json.load(sys.stdin)['count'])\"\n```\n\n---\n\n")

    elif is_data(layer):
        f.write("## STEP 1 — Read current file state\n\n")
        f.write(f"```bash\nnode -e \"const fs=require('fs'); console.log(JSON.stringify(JSON.parse(fs.readFileSync('$TARGET_FILE')), indent=2))\" | head -40\n```\n\n---\n\n")
        f.write("## STEP 2 — Apply JSON patch\n\n")
        f.write(f"```bash\n# From gap fix block:\n{fix_text[:500]}\n```\n\n---\n\n")
        f.write("## STEP 3 — Verify\n\n")
        f.write("```bash\nnode -e \"const d=JSON.parse(require('fs').readFileSync('$TARGET_FILE')); print('nodes:', len(d.get('nodes',{})))\"\n```\n\n---\n\n")

    elif is_gov(layer):
        f.write("## STEP 1 — Locate insertion point in target doc\n\n")
        f.write(f"```bash\ngrep -n 'REBASING\\|RULE\\|SESSION-END\\|## ' \"$TARGET_FILE\" | head -20\n```\n\n---\n\n")
        f.write("## STEP 2 — Insert governance rule\n\n")
        f.write(f"```bash\n# Exact text to add:\n{fix_text[:400]}\n```\n\n---\n\n")
        f.write("## STEP 3 — Verification\n\n")
        f.write("```bash\ngrep -c '[KEY TERM]' \"$TARGET_FILE\"\n# Expected: 1+ hits\n```\n\n---\n\n")

    else:
        f.write("## STEP 1 — Locate target\n\n")
        f.write(f"```bash\nfind \"$BASE_DIR\" -name '{file_.split('/')[-1]}' 2>/dev/null\n```\n\n---\n\n")
        f.write("## STEP 2 — Apply change\n\n")
        f.write(f"```bash\n# From gap fix block:\n{fix_text[:500]}\n```\n\n---\n\n")
        f.write("## STEP 3 — Verify\n\n")
        f.write("```bash\necho 'Verify change applied'\n```\n\n---\n\n")

    # Universal footer
    f.write("## ISSUE INVENTORY\n\n")
    f.write("| Issue | Status | Guard added |\n|-------|--------|-------------|\n")
    f.write("| (populate from steps above) | — | — |\n\n")
    f.write(f"⛔ STOP — {gap_id} fix confirmed before R1.\n")

print(f"Written: {out_path}")
JSEOF
```

---

## STEP 3 — Verify session file structure

```bash
echo "=== SESSION-GAP-R0.md verification ==="
for section in "CONTEXT" "WHY FIRST" "STEP 1" "STEP 2" "ISSUE INVENTORY" "⛔ STOP"; do
  grep -q "$section" "$OUT" \
    && echo "✅ $section" || echo "❌ MISSING: $section"
done
echo "Lines: $(wc -l < "$OUT")"
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from steps) | — | — |

⛔ STOP — `SESSION-GAP-R0.md` written, all sections present.
Subsequent rounds T4, T5, … each write the next session file (R1, R2, …) using the same STEP 2 script — only `R0` → `R1` changes in the node call.
