# SESSION-TRANSLATE-T1.md
## Round: T1 | Phase: BLOCK ASSIGNMENT + DEPENDENCY MAP
## Action: Read FLOW-XX-GAP-REGISTRY.json → assign each gap to a priority block
##         + build inter-gap dependency map → produce FLOW-XX-BLOCK-PLAN.json
## Output: FLOW-XX-BLOCK-PLAN.json
## Self-contained: all commands literal, zero cross-references

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export OUT_DIR="sessions/${FLOW_ID}"
export REGISTRY="${OUT_DIR}/${FLOW_ID}-GAP-REGISTRY.json"
export OUT="${OUT_DIR}/${FLOW_ID}-BLOCK-PLAN.json"
```

---

## WHY FIRST (inline)
The master plan's block structure comes from two sources:
  1. The gap doc's EXECUTION ORDER SUMMARY (priority groups + "Before" labels)
  2. Inter-gap dependency notes in each gap's body
T1 extracts both and produces a machine-readable block plan that T2 renders
into the master plan markdown and T3+ use to sequence session files.

---

## STEP 1 — Apply block assignment rules

Block rules (inline — no external reference):
```
Severity → Block
────────────────────────────────────────────────────
🔴 SILENT_FAILURE      → Block 1 (fix before any re-run)
🟠 BREAKS              → Block 2 (fix before target flow Phase B)
🟡 PARTIAL             → Block 3 (fix before next wave)
⬜ ADVISORY            → DEFERRED (not executed)
"Already done ✅"      → Block 1, sub-type VERIFY (no code change, confirm present)

"Before" label → Block label
────────────────────────────────────────────────────
Current flow (FLOW-XX)         → Block 1: FLOW-XX BEFORE EXECUTE
Later flow (FLOW-YY)           → Block 2: FLOW-YY BEFORE EXECUTE
Wave / FLOW-NN+                → Block 3: WAVE N BEFORE EXECUTE
FLOW-XX+ / process / skill     → Block 4: GOVERNANCE (parallel-safe)
```

```bash
node - <<'JSEOF'
import json, re, os

reg = json.load(open(os.environ['REGISTRY']))
flow_id = reg['flowId']

# Icon → severity string normalizer
def parse_severity(sev_raw):
    if '🔴' in sev_raw or 'SILENT_FAILURE' in sev_raw: return 'SILENT_FAILURE'
    if '🟠' in sev_raw or 'BREAKS' in sev_raw:         return 'BREAKS'
    if '🟡' in sev_raw or 'PARTIAL' in sev_raw:         return 'PARTIAL'
    if '⬜' in sev_raw or 'ADVISORY' in sev_raw:        return 'ADVISORY'
    if '✅' in sev_raw or 'already' in sev_raw.lower(): return 'VERIFY'
    if 'MEDIUM' in sev_raw:                              return 'BREAKS'  # treat as BREAKS
    if 'Process' in sev_raw:                             return 'GOVERNANCE'
    return 'PARTIAL'  # default

# "Before" field → block number
def parse_block(before_raw, flow_id):
    before = before_raw.strip()
    if not before or before == '—':
        return 1
    if flow_id in before:                               return 1
    if re.search(r'FLOW-\d+\b', before):               return 2
    if re.search(r'Wave|FLOW-\d+\+', before):          return 3
    if re.search(r'FLOW-\d+\+|process|skill|\+', before, re.I): return 4
    return 1  # default

# Assign each gap
blocks = {1: [], 2: [], 3: [], 4: [], 'DEFERRED': []}
for gap in reg['gaps']:
    sev = parse_severity(gap.get('Severity', ''))
    before = gap.get('Before', '')
    gap['severity_normalized'] = sev

    if sev == 'ADVISORY':
        blocks['DEFERRED'].append(gap)
        gap['block'] = 'DEFERRED'
    elif sev == 'GOVERNANCE':
        blocks[4].append(gap)
        gap['block'] = 4
    else:
        blk = parse_block(before, flow_id)
        # Override: SILENT_FAILURE always in block 1 or earliest possible
        if sev == 'SILENT_FAILURE' and blk > 1:
            blk = 1
        blocks[blk].append(gap)
        gap['block'] = blk

for b, gaps in blocks.items():
    print(f"Block {b}: {[g.get('ID','?') for g in gaps]}")
JSEOF
```

---

## STEP 2 — Build dependency map

Dependency rule (inline): a dependency exists when a gap body contains:
- "after [GAP-ID]" / "requires [GAP-ID]" / "can only be enforced after [GAP-ID]"
- "must exist before" / "Required before" / "needs [GAP-ID]"

```bash
node - <<'JSEOF'
import json, re, os

reg = json.load(open(os.environ['REGISTRY']))
gaps = reg['gaps']

deps = {}  # gap_id → [list of gap_ids that must run first]

for gap in gaps:
    gid = gap.get('ID', '')
    body = gap.get('problem','') + gap.get('impact','') + gap.get('fix_excerpt','')
    body_lower = body.lower()

    # Find "after ENG-02" / "after GAP-ENG-2" / "requires ENG-02" patterns
    found_deps = re.findall(
        r'(?:after|requires?|needs?|enforced after|must exist before)\s+'
        r'((?:GAP-)?[A-Z]+-\d+)',
        body, re.IGNORECASE
    )

    if found_deps:
        deps[gid] = found_deps
        print(f"Dependency: {gid} → must run after {found_deps}")

if not deps:
    print("No explicit dependencies found in gap bodies")
    print("(Check gap doc body text manually for implicit dependencies)")

# Store in registry
reg['dependencies'] = deps
with open(os.environ['REGISTRY'], 'w') as f:
    json.dump(reg, f, indent=2)
print("\nDependency map stored in registry")
JSEOF
```

---

## STEP 3 — Assign round numbers within each block

```bash
node - <<'JSEOF'
import json, os

reg = json.load(open(os.environ['REGISTRY']))
gaps = reg['gaps']
deps = reg.get('dependencies', {})

# Sort within each block by:
# 1. VERIFY gaps first (no code change — fast confirmation)
# 2. Then SILENT_FAILURE > BREAKS > PARTIAL
# 3. Then respect dependencies (dependents come after their dependencies)

priority_order = {'VERIFY': 0, 'SILENT_FAILURE': 1, 'BREAKS': 2, 'PARTIAL': 3, 'GOVERNANCE': 4}

blocks = {1: [], 2: [], 3: [], 4: [], 'DEFERRED': []}
for gap in gaps:
    b = gap.get('block', 1)
    blocks[b].append(gap)

# Assign round numbers globally (R0, R1, R2, ...)
round_num = 0
plan = []
for block_num in [1, 2, 3, 4]:
    block_gaps = sorted(
        blocks[block_num],
        key=lambda g: priority_order.get(g.get('severity_normalized','PARTIAL'), 3)
    )
    for gap in block_gaps:
        gap['round'] = f"R{round_num}"
        gap['session_file'] = f"SESSION-GAP-R{round_num}.md"
        plan.append(gap)
        round_num += 1

# DEFERRED gaps get no round
for gap in blocks['DEFERRED']:
    gap['round'] = 'DEFERRED'
    gap['session_file'] = None

all_gaps = plan + blocks['DEFERRED']

# Validate: no gap starts before its dependencies
dep_rounds = {g['ID']: int(g['round'][1:]) for g in plan}
for gap in plan:
    gid = gap['ID']
    for dep in deps.get(gid, []):
        dep_round = dep_rounds.get(dep, dep_rounds.get(f"GAP-{dep}", -1))
        if dep_round >= int(gap['round'][1:]):
            print(f"⚠️  DEPENDENCY VIOLATION: {gid} (R{gap['round'][1:]}) before {dep} (R{dep_round})")
            print(f"   Fix: swap rounds for {gid} and {dep}")

print("\n=== ROUND ASSIGNMENTS ===")
for gap in all_gaps:
    if gap.get('round') != 'DEFERRED':
        print(f"  {gap['round']}: {gap['ID']} [{gap.get('severity_normalized','?')}]"
              f" — {gap.get('Description','?')[:60]}")
print(f"\nTotal actionable rounds: R0–R{round_num-1}")
print(f"Deferred: {[g['ID'] for g in blocks['DEFERRED']]}")

out_plan = {
    "flowId": reg['flowId'],
    "total_rounds": round_num,
    "blocks": {
        "1": [g['ID'] for g in blocks[1]],
        "2": [g['ID'] for g in blocks[2]],
        "3": [g['ID'] for g in blocks[3]],
        "4": [g['ID'] for g in blocks[4]],
        "DEFERRED": [g['ID'] for g in blocks['DEFERRED']]
    },
    "rounds": all_gaps,
    "dependencies": deps
}
with open(os.environ['OUT'], 'w') as f:
    json.dump(out_plan, f, indent=2)
print(f"\nWritten: {os.environ['OUT']}")
JSEOF
```

---

## STEP 4 — Verify block plan

```bash
node - <<'JSEOF'
import json, os
plan = json.load(open(os.environ['OUT']))
print(f"=== BLOCK PLAN for {plan['flowId']} ===")
print(f"Total rounds: R0–R{plan['total_rounds']-1}")
print()
for b in ['1','2','3','4','DEFERRED']:
    label = {
        '1': 'Block 1 — FLOW BEFORE EXECUTE',
        '2': 'Block 2 — NEXT FLOW / LATER FLOW',
        '3': 'Block 3 — WAVE / WAVE 2',
        '4': 'Block 4 — GOVERNANCE',
        'DEFERRED': 'DEFERRED (not executed)'
    }[b]
    ids = plan['blocks'][b]
    if ids:
        print(f"  {label}: {ids}")
print()
print("Dependencies:")
if plan.get('dependencies'):
    for k, v in plan['dependencies'].items():
        print(f"  {k} must run after: {v}")
else:
    print("  (none detected)")
print()
print("→ Proceed to T2 (write MASTER-PLAN.md)")
JSEOF
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (populate from steps) | — | — |

⛔ STOP — `FLOW-XX-BLOCK-PLAN.json` written.
Report: round count, block sizes, any dependency violations in approval message.
