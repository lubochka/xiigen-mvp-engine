# SESSION-TRANSLATE-T2.md
## Round: T2 | Phase: WRITE MASTER PLAN
## Action: Read FLOW-XX-BLOCK-PLAN.json → write FLOW-XX-GAPS-MASTER-PLAN.md
## Output: FLOW-XX-GAPS-MASTER-PLAN.md ✅ (the plan document)
## Self-contained: all commands literal, zero cross-references

---

## CONFIGURE
```bash
export FLOW_ID="FLOW-XX"
export OUT_DIR="sessions/${FLOW_ID}"
export BLOCK_PLAN="${OUT_DIR}/${FLOW_ID}-BLOCK-PLAN.json"
export REGISTRY="${OUT_DIR}/${FLOW_ID}-GAP-REGISTRY.json"
export OUT="${OUT_DIR}/${FLOW_ID}-GAPS-MASTER-PLAN.md"

# From CLAUDE.md or STATE.json:
export TEST_BASELINE="5800"     # ← update from live CLAUDE.md
export SERVER_TESTS="5580"
export CLIENT_TESTS="220"
```

---

## STEP 1 — Generate master plan markdown

```bash
node - <<'JSEOF'
import json, os, re

flow_id = os.environ['FLOW_ID']
plan    = json.load(open(os.environ['BLOCK_PLAN']))
reg     = json.load(open(os.environ['REGISTRY']))
test_baseline = os.environ.get('TEST_BASELINE', '?')
server_tests  = os.environ.get('SERVER_TESTS', '?')
client_tests  = os.environ.get('CLIENT_TESTS', '?')
out = os.environ['OUT']

# Collect rounds (not deferred)
rounds = [r for r in plan['rounds'] if r.get('round','DEFERRED') != 'DEFERRED']
deferred = [r for r in plan['rounds'] if r.get('round') == 'DEFERRED']
total = len(rounds)

# Group by block
block_gaps = {1:[], 2:[], 3:[], 4:[]}
for r in rounds:
    block_gaps[r.get('block',1)].append(r)

block_labels = {
    1: f"{flow_id} BEFORE EXECUTE",
    2: "NEXT FLOW BEFORE EXECUTE",
    3: "WAVE / SUBSEQUENT FLOWS",
    4: "GOVERNANCE (parallel-safe)"
}

# Layer → column label
layer_label = {
    'TypeScript': 'TypeScript',  'Bash session': 'Session file',
    'Check catalog': 'Named check', 'Graph seed': 'Graph seed',
    'Governance': 'Governance', 'Topology': 'Topology/Data',
    'Session file': 'Session file', 'New files': 'New files',
    'ENGINE CODE CHANGES': 'TypeScript', 'DATA AND TOPOLOGY': 'Data/Topology',
    'SESSION FILE ADDITIONS': 'Session file', 'NAMED CHECK CATALOG': 'Named check',
    'GRAPH SEEDING': 'Graph seed', 'NEW FILES REQUIRED': 'New files',
}
def norm_layer(raw):
    for k, v in layer_label.items():
        if k.lower() in raw.lower():
            return v
    return raw[:20]

sev_icon = {
    'SILENT_FAILURE':'🔴','BREAKS':'🟠','PARTIAL':'🟡',
    'ADVISORY':'⬜','VERIFY':'✅','GOVERNANCE':'⬜'
}

with open(out, 'w') as f:
    # Header
    f.write(f"# {flow_id}-GAPS-MASTER-PLAN.md\n")
    f.write(f"## Source: {flow_id}-ENGINE-GAP-LIST.md\n")
    f.write(f"## Goal: Close all {total} actionable gaps to enable {flow_id} clean execution\n")
    if deferred:
        f.write(f"## Note: {', '.join(r['ID'] for r in deferred)} ADVISORY — deferred\n")
    f.write("## Session type: MAINTENANCE\n")
    f.write("## Cadence: one round at a time — ⛔ STOP after each file presented\n\n---\n\n")

    # Fixed prompt reminder
    f.write("## FIXED PROMPT REMINDER (top priority — must appear in every round response)\n")
    f.write(f"**Q1:** MAINTENANCE session type\n")
    f.write("**Cadence:** One session file per response. ⛔ STOP after present_files. Await \"yes\".\n")
    f.write(f"**Output contract:** ONE SESSION-GAP-RN.md, literal commands/diffs only,\n")
    f.write("  self-contained, zipped, presented.\n")
    f.write("**This prompt is the top priority and must be honored in every round.**\n\n---\n\n")

    # Priority blocks summary
    f.write("## PRIORITY BLOCKS\n\n```\n")
    for b in [1, 2, 3, 4]:
        if block_gaps[b]:
            ids = [r['ID'] for r in block_gaps[b]]
            rounds_range = f"R{block_gaps[b][0]['round'][1:]}–R{block_gaps[b][-1]['round'][1:]}"
            f.write(f"Block {b} — {block_labels[b]}  ({rounds_range}):  {', '.join(ids)}\n")
    if deferred:
        f.write(f"DEFERRED — not executed:  {', '.join(r['ID'] for r in deferred)}\n")
    f.write("```\n\n---\n\n")

    # Round tables per block
    f.write("## ROUND TABLE\n\n")
    for b in [1, 2, 3, 4]:
        if not block_gaps[b]:
            continue
        f.write(f"### Block {b} — {block_labels[b]}\n\n")
        f.write("| Round | File | Gap | Layer | One action | Severity |\n")
        f.write("|-------|------|-----|-------|-----------|----------|\n")
        for r in block_gaps[b]:
            icon = sev_icon.get(r.get('severity_normalized',''), '')
            layer = norm_layer(r.get('Layer','?'))
            desc = r.get('Description', r.get('problem','?'))[:70]
            file_changed = r.get('file','') or r.get('Scope','')[:40]
            f.write(f"| {r['round']} | {r['session_file']} | {r['ID']} {icon} | {layer} "
                    f"| {desc} | {icon} |\n")
        f.write("\n")

    # Dependency map
    f.write("---\n\n## DEPENDENCY MAP\n```\n")
    deps = plan.get('dependencies', {})
    if deps:
        for gid, dep_list in deps.items():
            r = next((x for x in rounds if x['ID'] == gid), None)
            rnd = r['round'] if r else '?'
            f.write(f"{rnd} ({gid}) — must run after: {dep_list}\n")
    # Find flow readiness gates
    if block_gaps[1]:
        last_b1 = block_gaps[1][-1]['round']
        f.write(f"\nAll Block 1 complete ({last_b1}) → {flow_id} MAY EXECUTE ✅\n")
    if block_gaps[2]:
        last_b2 = block_gaps[2][-1]['round']
        f.write(f"All Block 2 complete ({last_b2}) → NEXT FLOW MAY EXECUTE ✅\n")
    f.write("```\n\n---\n\n")

    # Test gate
    f.write("## TEST GATE (inline — absolute, P19, TypeScript rounds only)\n")
    f.write("```bash\n")
    f.write(f"cd server && npx jest 2>&1 | tail -5   # failures must === 0\n")
    f.write(f"# Baseline: {test_baseline} ({server_tests} server + {client_tests} client)\n")
    ts_rounds = [r['round'] for r in rounds
                 if 'TypeScript' in r.get('Layer','') or 'TypeScript' in norm_layer(r.get('Layer',''))]
    if ts_rounds:
        f.write(f"# TypeScript rounds: {', '.join(ts_rounds)}\n")
    f.write("```\n\n---\n\n")

    # Self-containment rule
    f.write("## SELF-CONTAINMENT RULE (every session file)\n")
    f.write("- Zero cross-references (no \"see gap list\", \"per SK-N\", \"per the doc\")\n")
    f.write("- All file paths literal (relative to project root)\n")
    f.write("- TypeScript changes: exact BEFORE/AFTER lines with line number context\n")
    f.write("- Session file changes: exact before/after block (grep target + replacement)\n")
    f.write("- Bash commands: literal, no undefined ${VAR}\n")
    f.write("- FOUND-ISSUE PROTOCOL + ISSUE INVENTORY before every ⛔ STOP\n\n---\n\n")

    # Deferred section
    if deferred:
        f.write("## DEFERRED (not in this plan)\n```\n")
        for r in deferred:
            f.write(f"{r['ID']} ⬜ {r.get('file','?')}: {r.get('Description','?')}\n")
            f.write(f"  Status: ADVISORY — {r.get('problem','?')[:200]}\n\n")
        f.write("```\n")

print(f"Written: {out}")
JSEOF
```

---

## STEP 2 — Verify master plan structure

```bash
echo "=== Master plan verification ==="
for section in "FIXED PROMPT REMINDER" "PRIORITY BLOCKS" "ROUND TABLE" \
               "DEPENDENCY MAP" "TEST GATE" "SELF-CONTAINMENT"; do
  grep -q "$section" "$OUT" \
    && echo "✅ $section" || echo "❌ MISSING: $section"
done
echo "Total rounds in table: $(grep -c "^| R[0-9]" "$OUT" 2>/dev/null || echo 0)"
echo "Lines: $(wc -l < "$OUT")"
```

---

## ISSUE INVENTORY

| Issue | Status | Guard added |
|-------|--------|-------------|
| (from steps) | — | — |

⛔ STOP — `FLOW-XX-GAPS-MASTER-PLAN.md` written, all 6 sections present.
This is the plan document. Report round count and block breakdown in approval message.
